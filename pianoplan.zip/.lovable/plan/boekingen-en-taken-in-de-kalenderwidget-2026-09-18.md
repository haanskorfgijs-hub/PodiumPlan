# Boekingen en taken in de kalenderwidget

Ja, de opdracht is duidelijk. Naast optredens kunnen widgets straks ook taken tonen, en per taak bepaal je zelf of die meegaat.

## Wat je krijgt

**Widgetpagina (aanmaken en aanpassen)**
- Nieuw blok "Wat komt in de agenda?" met twee vinkjes: **Boekingen** en **Taken**.
- Standaard staat alleen Boekingen aan, zodat bestaande widgets ongewijzigd blijven werken.
- De artiest- en statusfilters blijven alleen voor boekingen gelden.
- In de lijst met bestaande widgets zie je terug of een widget boekingen, taken of beide bevat.

**Taken (nieuwe taak en taak bewerken)**
- Extra vinkje **Opnemen in kalenderwidget**, standaard uit.
- Naast de bestaande datum komt een veld **Tijd** (optioneel). Met tijd wordt het een agenda-item op dat tijdstip (1 uur), zonder tijd een hele-dag-item.
- Zonder datum kan een taak niet in de agenda; het vinkje meldt dat dan.

**In de agenda zelf**
- Taakitems krijgen als titel de taaknaam, met de gekoppelde boeking en artiest erbij als die er zijn.
- Beschrijving bevat de omschrijving, status, de toegewezen persoon en een link naar de taak.
- Meegenomen worden: aangevinkte taken bij boekingen die de widget-eigenaar mag zien, plus aangevinkte taken zonder boeking die de eigenaar zelf heeft gemaakt of aan hem zijn toegewezen.

## Technische uitvoering

1. Migratie:
   - `tasks`: kolommen `show_in_widget boolean not null default false` en `deadline_time time null`.
   - `calendar_widgets`: kolom `include text[] not null default '{bookings}'` (waarden `bookings`, `tasks`).
2. `src/lib/data.ts`: `Task`-type en task-queries uitbreiden met de nieuwe velden; widget-type uitbreiden met `include` plus een constantenlijst `WIDGET_INCLUDE_OPTIONS`.
3. `src/routes/_authenticated/widgets.tsx` en `src/components/widget-dialog.tsx`: vinkjesblok voor Boekingen/Taken, meesturen bij insert/update, samenvatting in de lijst.
4. `src/components/task-dialog.tsx`: vinkje `show_in_widget` + tijdveld toevoegen aan formulier, state en payload.
5. `src/routes/api/public/calendar/$token[.]ics.ts`: boekingen alleen genereren als `bookings` is aangevinkt; bij `tasks` een tweede query op `tasks` met `show_in_widget = true`, gefilterd op zichtbare boekingen van de eigenaar en eigen/toegewezen losse taken, met VEVENT-opbouw (tijd of hele dag) en eigen UID-suffix.
6. Typecheck met `bunx tsgo --noEmit -p tsconfig.json`.
