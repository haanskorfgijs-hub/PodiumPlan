## Standaard-teamleden toevoegen aan bestaande boekingen

Voor elke bestaande boeking met een standaard: iedereen uit het standaardteam die nog niet in het team van die boeking staat, wordt toegevoegd als teamlid (direct geaccepteerd, geen uitnodiging) met beschikbaarheid **Beschikbaar**.

- Het gaat om 139 toevoegingen; 1 persoon stond al in een team en blijft ongewijzigd.
- Bestaande teamleden en hun beschikbaarheid blijven precies zoals ze zijn.
- Rol volgt de bestaande regel: Lezer, of de beheerrol bij artiestbeheerders.
- Geannuleerde boekingen worden overgeslagen.

## Technisch
Eenmalige data-wijziging: booking_members invoegen (status accepted, ON CONFLICT DO NOTHING) en booking_availability 'available' alleen voor die nieuw toegevoegde paren. Activiteitenlog registreert dit automatisch.
