import { isCancelledBooking } from "@/lib/artist-status";
import { createFileRoute } from "@tanstack/react-router";

type Json = Record<string, unknown>;

function esc(value: string) {
  return value.replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
}

function fold(line: string) {
  if (line.length <= 73) return line;
  const parts: string[] = [];
  let rest = line;
  while (rest.length > 73) {
    parts.push(rest.slice(0, 73));
    rest = rest.slice(73);
  }
  parts.push(rest);
  return parts.join("\r\n ");
}

function stamp(date: Date) {
  return date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
}

function dateOnly(value: string) {
  return value.replace(/-/g, "");
}

function localDateTime(date: string, time: string) {
  return `${dateOnly(date)}T${time.replace(":", "")}00`;
}

export const Route = createFileRoute("/api/public/calendar/$token.ics")({
  server: {
    handlers: {
      GET: async ({ params, request }) => {
        const origin = new URL(request.url).origin;
        const token = String((params as unknown as Record<string, string>)["token.ics"] ?? (params as unknown as Record<string, string>).token ?? "").replace(/\.ics$/i, "");
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const { data: widget } = await supabaseAdmin
          .from("calendar_widgets")
          .select("id, name, artist_ids, statuses, content, include, user_id")
          .eq("token", token)
          .maybeSingle();

        if (!widget) return new Response("Not found", { status: 404 });

        const content = ((widget as { content?: string[] | null }).content ?? [
          "booking_link",
        ]) as string[];
        const include = (((widget as { include?: string[] | null }).include ?? [])
          .length
          ? ((widget as { include?: string[] | null }).include as string[])
          : ["bookings"]) as string[];
        const wantsBookings = include.includes("bookings");
        const wantsTasks = include.includes("tasks");
        // Alleen de links zijn instelbaar; overige gegevens staan altijd in het item.
        const LINK_KEYS = ["booking_link", "sheet_link"];
        const wants = (key: string) =>
          LINK_KEYS.includes(key) ? content.includes(key) : true;

        const requestedArtistIds: string[] = ((widget as { artist_ids?: string[] | null })
          .artist_ids ?? []) as string[];

        // Bepaal waar de eigenaar van de widget toegang tot heeft.
        const fullArtistIds = new Set<string>();
        const allowedBookingIds = new Set<string>();
        if (widget.user_id) {
          const [
            { data: createdArtists },
            { data: memberArtists },
            { data: bookingMemberships },
            { data: ownBookings },
          ] = await Promise.all([
            supabaseAdmin.from("artists").select("id").eq("created_by", widget.user_id),
            supabaseAdmin
              .from("artist_members")
              .select("artist_id")
              .eq("user_id", widget.user_id)
              .eq("status", "accepted"),
            supabaseAdmin
              .from("booking_members")
              .select("booking_id")
              .eq("user_id", widget.user_id)
              .eq("status", "accepted"),
            supabaseAdmin.from("bookings").select("id").eq("created_by", widget.user_id),
          ]);
          (createdArtists ?? []).forEach((a) => fullArtistIds.add(a.id));
          (memberArtists ?? []).forEach((m) => {
            if (m.artist_id) fullArtistIds.add(m.artist_id);
          });
          (bookingMemberships ?? []).forEach((m) => {
            if (m.booking_id) allowedBookingIds.add(m.booking_id);
          });
          (ownBookings ?? []).forEach((b) => allowedBookingIds.add(b.id));
        }

        // Artiesten van boekingen waarvoor de eigenaar is uitgenodigd:
        // alleen die specifieke boekingen mogen mee in de feed.
        const invitedArtistIds = new Set<string>();
        if (allowedBookingIds.size) {
          const { data: invitedBookings } = await supabaseAdmin
            .from("bookings")
            .select("artist_id")
            .in("id", Array.from(allowedBookingIds));
          (invitedBookings ?? []).forEach((b) => {
            if (b.artist_id && !fullArtistIds.has(b.artist_id)) invitedArtistIds.add(b.artist_id);
          });
        }

        // Geen selectie = alles wat de eigenaar mag zien.
        const filterArtistIds: string[] = requestedArtistIds.length
          ? requestedArtistIds.filter((id) => fullArtistIds.has(id) || invitedArtistIds.has(id))
          : Array.from(new Set([...fullArtistIds, ...invitedArtistIds]));

        let query = supabaseAdmin
          .from("bookings")
          .select(
            "id, artist_id, event_name, event_date, start_time, end_time, artist_status, field_values, standard_id, location_name, address, postal_code, city, contact_name, contact_phone, contact_email, artists(name)",
          )
          .order("event_date", { ascending: true });

        if (filterArtistIds.length === 0) {
          query = query.in("artist_id", ["00000000-0000-0000-0000-000000000000"]);
        } else {
          query = query.in("artist_id", filterArtistIds);
        }

        const { data: rawBookings = [] } = await query;
        // Boekingen van artiesten waar de eigenaar geen teamlid van is,
        // mogen alleen mee als hij voor die boeking is uitgenodigd.
        const allBookings = (rawBookings ?? []).filter(
          (b) =>
            fullArtistIds.has((b as { artist_id?: string }).artist_id ?? "") ||
            allowedBookingIds.has(b.id),
        );
        const selected = (widget.statuses ?? []) as string[];
        const bookings = selected.length
          ? (allBookings ?? []).filter((b) =>
              selected.some((s) => s.toLowerCase() === (b.artist_status ?? "").toLowerCase()),
            )
          : allBookings ?? [];


        const standardIds = Array.from(
          new Set((bookings ?? []).map((b) => b.standard_id).filter(Boolean) as string[]),
        );
        const standards = standardIds.length
          ? (
              await supabaseAdmin
                .from("performance_standards")
                .select("id, fields")
                .in("id", standardIds)
            ).data ?? []
          : [];
        const standardMap = new Map(standards.map((s) => [s.id, s]));

        const now = stamp(new Date());
        const lines: string[] = [
          "BEGIN:VCALENDAR",
          "VERSION:2.0",
          "PRODID:-//PodiumPlan//Kalenderwidget//NL",
          "CALSCALE:GREGORIAN",
          "METHOD:PUBLISH",
          `X-WR-CALNAME:${esc(widget.name)}`,
          "X-PUBLISHED-TTL:PT1H",
        ];

        for (const b of wantsBookings ? bookings ?? [] : []) {
          const fields = (standardMap.get(b.standard_id ?? "")?.fields ?? []) as Json[];
          const values = (b.field_values ?? {}) as Record<string, string>;

          const nameField = fields.find((f) =>
            /event\s*naam|evenement\s*naam/i.test(String(f.label ?? "").replace(/-/g, "")),
          );
          const eventName =
            (nameField ? values[String(nameField.id)] : "") || b.event_name || "";
          const artistName = (b.artists as { name: string } | null)?.name ?? "";
          const title = artistName || eventName || "Optreden";

          const timeField = fields.find((f) => f.type === "time");
          const rawTime = timeField ? values[String(timeField.id)] ?? "" : "";
          let start = rawTime ? rawTime.split("-")[0]?.trim() ?? "" : "";
          let end = rawTime ? rawTime.split("-")[1]?.trim() ?? "" : "";
          if (!start && b.start_time) start = String(b.start_time).slice(0, 5);
          if (!end && b.end_time) end = String(b.end_time).slice(0, 5);

          const mapField = fields.find((f) => f.type === "map");
          const location =
            (mapField ? values[String(mapField.id)] : "") ||
            [b.location_name, b.address, b.postal_code, b.city].filter(Boolean).join(", ");

          lines.push("BEGIN:VEVENT");
          lines.push(`UID:${b.id}@stagehand`);
          lines.push(`DTSTAMP:${now}`);
          if (start && wants("times")) {
            const endTime = end || start;
            let endDate = b.event_date;
            if (endTime.replace(":", "") <= start.replace(":", "")) {
              const d = new Date(`${b.event_date}T00:00:00Z`);
              d.setUTCDate(d.getUTCDate() + 1);
              endDate = d.toISOString().slice(0, 10);
            }
            lines.push(`DTSTART;TZID=Europe/Amsterdam:${localDateTime(b.event_date, start)}`);
            lines.push(`DTEND;TZID=Europe/Amsterdam:${localDateTime(endDate, endTime)}`);
          } else {
            const next = new Date(`${b.event_date}T00:00:00Z`);
            next.setUTCDate(next.getUTCDate() + 1);
            lines.push(`DTSTART;VALUE=DATE:${dateOnly(b.event_date)}`);
            lines.push(`DTEND;VALUE=DATE:${dateOnly(next.toISOString().slice(0, 10))}`);
          }
          lines.push(fold(`SUMMARY:${esc(title)}`));
          if (location && wants("location")) lines.push(fold(`LOCATION:${esc(location)}`));
          const bookingUrl = `${origin}/bookings/${b.id}`;
          const sheetUrl = `${origin}/booking-sheet/${b.id}`;
          const statusLabel = b.artist_status ?? "";
          const contact = [b.contact_name, b.contact_phone, b.contact_email]
            .filter(Boolean)
            .join(" · ");
          const description = [
            wants("event_name") ? eventName : "",
            wants("status") && statusLabel ? `Status: ${statusLabel}` : "",
            wants("contact") && contact ? `Contact: ${contact}` : "",
            wants("booking_link") ? `Bekijk de boeking: ${bookingUrl}` : "",
            wants("sheet_link") ? `Gegevensblad: ${sheetUrl}` : "",
          ]
            .filter(Boolean)
            .join("\n");
          if (description) lines.push(fold(`DESCRIPTION:${esc(description)}`));
          if (wants("booking_link")) lines.push(fold(`URL:${bookingUrl}`));
          else if (wants("sheet_link")) lines.push(fold(`URL:${sheetUrl}`));
          lines.push(`STATUS:${isCancelledBooking(b) ? "CANCELLED" : "CONFIRMED"}`);
          lines.push("END:VEVENT");
        }

        if (wantsTasks && widget.user_id) {
          // Boekingen die de eigenaar mag zien (voor taken gelden de artiest-
          // en statusfilters van de widget niet).
          const visibleBookingIds = new Set<string>(allowedBookingIds);
          if (fullArtistIds.size) {
            const { data: artistBookings } = await supabaseAdmin
              .from("bookings")
              .select("id")
              .in("artist_id", Array.from(fullArtistIds));
            (artistBookings ?? []).forEach((b) => visibleBookingIds.add(b.id));
          }

          const { data: rawTasks } = await supabaseAdmin
            .from("tasks")
            .select(
              "id, title, description, status, deadline, deadline_time, booking_id, assigned_to, created_by, bookings(artist_id, event_name, artists(name))",
            )
            .eq("show_in_widget", true)
            .not("deadline", "is", null)
            .neq("status", "afgerond");

          // Taken horen alleen in de widget van de artiest van hun boeking.
          const artistFilter = requestedArtistIds.length ? new Set(requestedArtistIds) : null;

          const tasks = (rawTasks ?? []).filter((t) => {
            const bookingArtistId = (
              t.bookings as { artist_id?: string | null } | null
            )?.artist_id;
            if (!t.booking_id) {
              // Losse taken zonder boeking horen bij geen enkele artiest.
              if (artistFilter) return false;
              return t.created_by === widget.user_id || t.assigned_to === widget.user_id;
            }
            if (!visibleBookingIds.has(t.booking_id)) return false;
            if (artistFilter) return Boolean(bookingArtistId && artistFilter.has(bookingArtistId));
            return true;
          });

          for (const t of tasks) {
            const deadline = String(t.deadline);
            const time = t.deadline_time ? String(t.deadline_time).slice(0, 5) : "";
            const booking = t.bookings as
              | { event_name?: string | null; artists?: { name?: string | null } | null }
              | null;
            const extra = [booking?.artists?.name, booking?.event_name]
              .filter(Boolean)
              .join(" · ");
            const title = extra ? `${t.title} (${extra})` : t.title;

            lines.push("BEGIN:VEVENT");
            lines.push(`UID:task-${t.id}@stagehand`);
            lines.push(`DTSTAMP:${now}`);
            if (time) {
              let hour = Number(time.split(":")[0] ?? "00");
              let minute = Number(time.split(":")[1] ?? "00");
              minute += 30;
              if (minute >= 60) {
                hour += 1;
                minute -= 60;
              }
              let endDate = deadline;
              if (hour >= 24) {
                hour -= 24;
                const d = new Date(`${deadline}T00:00:00Z`);
                d.setUTCDate(d.getUTCDate() + 1);
                endDate = d.toISOString().slice(0, 10);
              }
              const endH = String(hour).padStart(2, "0");
              const endM = String(minute).padStart(2, "0");
              lines.push(`DTSTART;TZID=Europe/Amsterdam:${localDateTime(deadline, time)}`);
              lines.push(`DTEND;TZID=Europe/Amsterdam:${localDateTime(endDate, `${endH}:${endM}`)}`);
            } else {
              const next = new Date(`${deadline}T00:00:00Z`);
              next.setUTCDate(next.getUTCDate() + 1);
              lines.push(`DTSTART;VALUE=DATE:${dateOnly(deadline)}`);
              lines.push(`DTEND;VALUE=DATE:${dateOnly(next.toISOString().slice(0, 10))}`);
            }
            lines.push(fold(`SUMMARY:${esc(`Taak: ${title}`)}`));
            const taskUrl = `${origin}/tasks`;
            const description = [
              t.description ?? "",
              t.status ? `Status: ${t.status}` : "",
              `Bekijk de taken: ${taskUrl}`,
            ]
              .filter(Boolean)
              .join("\n");
            lines.push(fold(`DESCRIPTION:${esc(description)}`));
            lines.push(fold(`URL:${taskUrl}`));
            lines.push("STATUS:CONFIRMED");
            lines.push("END:VEVENT");
          }
        }




        lines.push("END:VCALENDAR");

        return new Response(lines.join("\r\n") + "\r\n", {
          headers: {
            "Content-Type": "text/calendar; charset=utf-8",
            "Cache-Control": "public, max-age=60",
            "Content-Disposition": `inline; filename="${token}.ics"`,
          },
        });
      },
    },
  },
});
