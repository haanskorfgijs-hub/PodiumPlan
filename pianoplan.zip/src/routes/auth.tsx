import { createFileRoute } from "@tanstack/react-router";
import { AuthForm } from "@/components/auth-form";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { title: "Accounttoegang — PodiumPlan" },
      { name: "description", content: "Log in of maak een account voor PodiumPlan." },
      { property: "og:title", content: "Accounttoegang — PodiumPlan" },
      { property: "og:description", content: "Toegang tot je artiesten- en boekingsbeheer." },
      { name: "robots", content: "noindex" },
    ],
  }),
  ssr: false,
  component: AuthPage,
});

function AuthPage() {
  return <AuthForm />;
}
