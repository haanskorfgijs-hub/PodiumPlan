import { createFileRoute } from '@tanstack/react-router'
import { createEmailWebhookHandler } from '@lovable.dev/email-js'

// Unsubscribe turns booking email preferences off and remembers the previous
// choice in paused_snapshot; resubscribe restores exactly that choice.
async function profileIdsFor(recipient: unknown) {
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const email = String(recipient ?? '').trim().toLowerCase()
  if (!email) return { supabaseAdmin, ids: [] as string[] }
  const { data } = await supabaseAdmin.from('profiles').select('id').ilike('email', email)
  return { supabaseAdmin, ids: (data ?? []).map((p) => p.id) }
}

export const Route = createFileRoute("/lovable/email/events")({
  server: {
    handlers: {
      POST: ({ request }) => {
        const handler = createEmailWebhookHandler({
          apiKey: process.env['LOVABLE_API_KEY']!,
          on: {
            'email.unsubscribed': async (event) => {
              const { supabaseAdmin, ids } = await profileIdsFor(event.data.recipient)
              if (!ids.length) return
              const db = supabaseAdmin as any
              const { data: rows } = await db.from('email_notification_preferences')
                .select('user_id, booking_invitations, status_changes, paused_snapshot').in('user_id', ids)
              for (const row of rows ?? []) {
                // Keep an existing snapshot so a duplicate delivery doesn't overwrite it with "off".
                const snapshot = row.paused_snapshot ?? { booking_invitations: row.booking_invitations, status_changes: row.status_changes }
                const { error } = await db.from('email_notification_preferences')
                  .update({ booking_invitations: false, status_changes: false, paused_snapshot: snapshot, updated_at: new Date().toISOString() })
                  .eq('user_id', row.user_id)
                if (error) throw new Error(error.message)
              }
              console.log('Unsubscribe applied', event.event_id)
            },
            'email.resubscribed': async (event) => {
              const { supabaseAdmin, ids } = await profileIdsFor(event.data.recipient)
              if (!ids.length) return
              const db = supabaseAdmin as any
              const { data: rows } = await db.from('email_notification_preferences')
                .select('user_id, paused_snapshot').in('user_id', ids).not('paused_snapshot', 'is', null)
              for (const row of rows ?? []) {
                const s = row.paused_snapshot ?? {}
                const { error } = await db.from('email_notification_preferences')
                  .update({ booking_invitations: s.booking_invitations === true, status_changes: s.status_changes === true, paused_snapshot: null, updated_at: new Date().toISOString() })
                  .eq('user_id', row.user_id)
                if (error) throw new Error(error.message)
              }
              console.log('Resubscribe applied', event.event_id)
            },
          },
        })
        return handler(request)
      },
    },
  },
})
