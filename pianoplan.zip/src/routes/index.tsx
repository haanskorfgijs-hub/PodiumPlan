import { createFileRoute, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { AuthForm } from "@/components/auth-form";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Inloggen — PodiumPlan" },
      {
        name: "description",
        content:
          "Log in bij PodiumPlan om optredens, taken, artiesten en eventinformatie centraal te beheren.",
      },
      { property: "og:title", content: "Inloggen — PodiumPlan" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      {
        property: "og:description",
        content: "Log in bij PodiumPlan om optredens, taken, artiesten en eventinformatie centraal te beheren.",
      },
    ],
  }),
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (data.user) throw redirect({ to: "/dashboard" });
  },
  component: LoginPage,
});

function LoginPage() {
  return <AuthForm />;
}
