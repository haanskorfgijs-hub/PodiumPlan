import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";

import { getBookingSheet } from "@/lib/booking-sheet.functions";
import type { Booking, Standard } from "@/lib/data";
import {
  bookingStatusLabel,
  bookingTime,
  fieldTab,
  fieldValues,
  formatBookingDate,
  formatDate,
  formatEuroDate,
  inSheetForBooking,
  runSheetInSheet,
  parseFields,
  parseRunSheet,
  runSheetTimeLabel,
} from "@/lib/data";

export const Route = createFileRoute("/booking-sheet/$id")({
  head: () => ({
    meta: [
      { title: "Gegevensblad boeking — PodiumPlan" },
      {
        name: "description",
        content: "Afdrukbaar gegevensblad met alle boekingsinformatie van dit optreden.",
      },
      { property: "og:title", content: "Gegevensblad boeking — PodiumPlan" },
      {
        property: "og:description",
        content: "Alle boekingsinformatie van dit optreden in één afdrukbaar overzicht.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: BookingSheet,
});

function SheetRow({ label, value }: { label: string; value?: string | null }) {
  return (
    <div className="flex flex-col gap-0.5 border-b border-black/10 py-2.5 last:border-0 sm:flex-row sm:gap-4 sm:py-2">
      <span className="w-full shrink-0 text-[11px] font-medium tracking-wide text-black/50 uppercase sm:w-56">
        {label}
      </span>
      <span className="text-sm whitespace-pre-line break-words text-black">{value || "—"}</span>
    </div>
  );
}

function BookingSheet() {
  const { id } = Route.useParams();
  const fetchSheet = useServerFn(getBookingSheet);
  const { data, isLoading } = useQuery({
    queryKey: ["booking-sheet", id],
    queryFn: () => fetchSheet({ data: { id } }),
  });

  const booking = data?.booking as (Booking & { artists: { name: string } | null }) | undefined;
  const standard = (data?.standard ?? null) as Standard | null;

  useEffect(() => {
    if (booking) document.title = `Gegevensblad — ${booking.event_name}`;
  }, [booking]);

  if (isLoading) {
    return (
      <div className="p-10 text-center text-sm text-muted-foreground">Gegevensblad laden…</div>
    );
  }

  if (!booking) {
    return (
      <div className="p-10 text-center text-sm text-muted-foreground">
        Dit gegevensblad bestaat niet (meer).
      </div>
    );
  }

  const values = fieldValues(booking.field_values);
  const fields = parseFields(standard?.fields).filter(
    (f) => fieldTab(f) === "booking" && inSheetForBooking(f, values),
  );

  const time = bookingTime(booking, standard);
  const sections = Array.from(new Set(fields.map((f) => f.section ?? "Extra velden")));

  const runSheet =
    standard?.run_sheet_enabled && runSheetInSheet(values)
      ? parseRunSheet(booking.run_sheet)
      : [];
  const lower = sections.map((s) => s.toLowerCase());
  const techniekIndex = lower.findIndex((s) => s.includes("techniek"));
  const locatieIndex = lower.findIndex((s) => s.includes("locatie"));
  // Draaiboek onder Techniek, boven Locatie.
  const runSheetAfter =
    techniekIndex >= 0 ? techniekIndex : locatieIndex >= 0 ? locatieIndex - 1 : sections.length - 1;

  const runSheetBlock =
    runSheet.length > 0 ? (
      <section className="mb-6 break-inside-avoid">
        <h2 className="mb-1 text-sm font-semibold">Draaiboek</h2>
        <p className="mb-2 text-xs text-black/60">
          Let op: Tijden in dit draaiboek zijn een richtlijn en kunnen in de praktijk iets afwijken.
        </p>
        <div>
          {runSheet.map((item) => (
            <div
              key={item.id}
              className="flex flex-col gap-0.5 border-b border-black/10 py-2.5 last:border-0 sm:flex-row sm:gap-4 sm:py-2"
            >
              <span className="w-full shrink-0 text-sm font-medium tabular-nums text-black/70 sm:w-56">
                {runSheetTimeLabel(item) || "—"}
              </span>
              <span className="min-w-0">
                <p className="text-sm break-words text-black">{item.title || "—"}</p>
                {item.description ? (
                  <p className="mt-0.5 text-xs whitespace-pre-line text-black/55">
                    {item.description}
                  </p>
                ) : null}
              </span>
            </div>
          ))}
        </div>
      </section>
    ) : null;

  return (
    <div className="min-h-screen bg-neutral-100 py-4 sm:py-8 print:bg-white print:py-0">


      <article className="mx-auto max-w-[820px] bg-white px-4 py-6 text-black shadow-sm sm:px-10 sm:py-10 print:max-w-none print:px-0 print:shadow-none">
        <header className="mb-5 border-b-2 border-black/80 pb-4 sm:mb-6">
          <p className="text-[11px] font-semibold tracking-[0.2em] text-black/50 uppercase">
            Gegevensblad
          </p>
          <h1 className="mt-1 text-xl font-semibold break-words sm:text-2xl">{booking.event_name}</h1>
          <p className="mt-1 text-sm text-black/60">
            {booking.artists?.name ?? ""} · {formatBookingDate(booking.event_date)}
            {time.label ? ` · ${time.label}` : ""} · {bookingStatusLabel(booking)}
          </p>
        </header>

        {sections.length === 0 ? (
          <>
            <p className="text-sm text-black/60">Geen boekingsinformatie beschikbaar.</p>
            {runSheetBlock}
          </>
        ) : (
          sections.map((section, index) => (
            <div key={section}>
              {runSheetAfter < 0 && index === 0 ? runSheetBlock : null}
              <section className="mb-6 break-inside-avoid">
                <h2 className="mb-1 text-sm font-semibold">{section}</h2>
                <div>
                  {fields
                    .filter((f) => (f.section ?? "Extra velden") === section)
                    .map((f) => (
                      <SheetRow
                        key={f.id}
                        label={f.label}
                        value={
                          f.type === "currency" && values[f.id]
                            ? `€ ${values[f.id]}`
                            : f.type === "date" || f.type === "datetime"
                              ? formatEuroDate(values[f.id])
                              : values[f.id]
                        }
                      />
                    ))}
                </div>
              </section>
              {index === runSheetAfter ? runSheetBlock : null}
            </div>
          ))
        )}

        <footer className="mt-8 border-t border-black/10 pt-3 text-[11px] text-black/45">
          Gegenereerd op {formatDate(new Date().toISOString())} · PodiumPlan
        </footer>
      </article>
    </div>
  );
}
