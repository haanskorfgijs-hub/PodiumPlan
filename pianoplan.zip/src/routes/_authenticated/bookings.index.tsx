import { useEffect, useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { MapPin, Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { usePersistentState } from "@/lib/use-persistent-state";
import { useColumnOrder } from "@/lib/column-order";
import { useYearFilter } from "@/lib/year-filter";

import { AppShell } from "@/components/app-shell";

import { useCurrentUser } from "@/lib/session";
import {
  bookingDateTimeKey,
  bookingStatusLabel,
  bookingLocation,
  bookingTime,
  bookingPlayTime,
  formatBookingDate,
  mapsUrl,
  useBookings,
  useStandardMap,
} from "@/lib/data";
import { BookingStatusPill, StatusStripeCell } from "@/components/status-badges";
import { MobileBookingRow } from "@/components/mobile-booking-row";
import { MonthDivider, monthKey } from "@/components/month-divider";
import { ColumnFilter, FilterOption, monthOption } from "@/components/column-filter";
import { MobileFilters } from "@/components/mobile-filters";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/bookings/")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { title: "Boekingen — PodiumPlan" },
      { name: "description", content: "Alle boekingen met sorteren, zoeken en filteren." },
      { property: "og:title", content: "Boekingen — PodiumPlan" },
      { property: "og:description", content: "Overzicht van alle optredens en hun status." },
    ],
  }),
  validateSearch: (search: Record<string, unknown>): { status?: string; artist?: string } => ({
    status: typeof search.status === "string" ? search.status : undefined,
    artist: typeof search.artist === "string" ? search.artist : undefined,
  }),
  component: BookingsPage,
});


type BookingRow = ReturnType<typeof useBookings>["data"] extends (infer T)[] | undefined ? T : never;

type CellArgs = {
  booking: BookingRow;
  time: string;
  playTime: string;
  presenceStart: string;
  location: string;
};

const COLUMNS: {
  key: string;
  label: string;
  className: string;
  cellClassName: string;
  render: (args: CellArgs) => React.ReactNode;
  /** Waarde waarop deze kolom gesorteerd wordt. */
  sortOf: (args: CellArgs) => string;
  /** Waarde waarop deze kolom gefilterd wordt. */
  filterOf: (args: CellArgs) => FilterOption | null;
}[] = [
  {
    key: "date",
    label: "Datum",
    className: "w-[14%]",
    cellClassName: "text-sm whitespace-nowrap",
    render: ({ booking }) => formatBookingDate(booking.event_date),
    sortOf: ({ booking, presenceStart }) => bookingDateTimeKey(booking.event_date, presenceStart),
    filterOf: ({ booking }) => monthOption(booking.event_date),
  },
  {
    key: "time",
    label: "Tijden aanwezig",
    className: "w-[13%]",
    cellClassName: "text-sm whitespace-nowrap tabular-nums text-muted-foreground",
    render: ({ time }) => time || "—",
    sortOf: ({ time }) => time ?? "",
    filterOf: ({ time }) => (time ? { value: time, label: time } : null),
  },
  {
    key: "playTime",
    label: "Speeltijden",
    className: "w-[13%]",
    cellClassName: "text-sm whitespace-nowrap tabular-nums text-muted-foreground",
    render: ({ playTime }) => playTime || "—",
    sortOf: ({ playTime }) => playTime ?? "",
    filterOf: ({ playTime }) => (playTime ? { value: playTime, label: playTime } : null),
  },
  {
    key: "artist",
    label: "Artiest",
    className: "w-[13%]",
    cellClassName: "truncate text-sm text-muted-foreground",
    render: ({ booking }) => booking.artists?.name,
    sortOf: ({ booking }) => booking.artists?.name ?? "",
    filterOf: ({ booking }) =>
      booking.artists?.name ? { value: booking.artists.name, label: booking.artists.name } : null,
  },
  {
    key: "event",
    label: "Event",
    className: "w-[18%]",
    cellClassName: "truncate text-sm font-medium",
    render: ({ booking }) => booking.event_name,
    sortOf: ({ booking }) => booking.event_name ?? "",
    filterOf: ({ booking }) =>
      booking.event_name ? { value: booking.event_name, label: booking.event_name } : null,
  },
  {
    key: "location",
    label: "Locatie",
    className: "w-[19%]",
    cellClassName: "truncate text-sm",
    render: ({ location }) =>
      location ? (
        <a
          href={mapsUrl(location)}
          target="_blank"
          rel="noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="inline-flex max-w-full items-center gap-1 text-primary hover:underline"
        >
          <MapPin className="h-3.5 w-3.5 shrink-0" />
          <span className="truncate">{location}</span>
        </a>
      ) : (
        <span className="text-muted-foreground">—</span>
      ),
    sortOf: ({ location }) => location ?? "",
    filterOf: ({ location }) => (location ? { value: location, label: location } : null),
  },
  {
    key: "status",
    label: "Status",
    className: "w-[10%] text-right",
    cellClassName: "text-right",
    render: ({ booking }) => <BookingStatusPill booking={booking} />,
    sortOf: ({ booking }) => bookingStatusLabel(booking),
    filterOf: ({ booking }) => {
      const label = bookingStatusLabel(booking);
      return label ? { value: label, label } : null;
    },
  },
];

function BookingsPage() {
  const user = useCurrentUser();
  const navigate = useNavigate();
  const { data: bookings = [] } = useBookings();
  const { years, clear: clearYears } = useYearFilter();
  const standardMap = useStandardMap();
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<string>("date");
  const [asc, setAsc] = useState(true);
  const [filters, setFilters] = usePersistentState<Record<string, string[]>>("stagehand.filters.bookings.v2", {});
  const { order, dragProps } = useColumnOrder(
    "podiumplan:columns:bookings",
    COLUMNS.map((c) => c.key),
  );
  const orderedColumns = useMemo(
    () => order.map((key: string) => COLUMNS.find((c) => c.key === key)!).filter(Boolean),
    [order],
  );


  /** Vooraf ingestelde filters via de URL (bijv. vanaf de statistiekenpagina). */
  const { status: statusParam, artist: artistParam } = Route.useSearch();
  useEffect(() => {
    const hasStatus = statusParam !== undefined;
    const hasArtist = artistParam !== undefined;
    if (!hasStatus && !hasArtist) return;

    const statusValues = statusParam ? statusParam.split("~").filter(Boolean) : [];
    const artistNames = artistParam ? artistParam.split("~").filter(Boolean) : [];

    // Bestaande filters vervallen: alleen de filters van de aangeklikte knop blijven over.
    setSearch("");
    const next: Record<string, string[]> = {};
    if (statusValues.length) next.status = statusValues;
    if (artistNames.length) next.artist = artistNames;
    setFilters(Object.keys(next).length ? next : {});
    navigate({ to: "/bookings", search: () => ({ status: undefined, artist: undefined }), replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusParam, artistParam]);


  /** Boekingen verrijkt met afgeleide tijd en locatie. */
  const enriched = useMemo<CellArgs[]>(() => {
    return bookings.map((b) => {
      const standard = b.standard_id ? standardMap.get(b.standard_id) : undefined;
      return {
        booking: b,
        time: bookingTime(b, standard).label,
        playTime: bookingPlayTime(b, standard).label,
        presenceStart: bookingTime(b, standard).start,
        location: bookingLocation(b, standard),
      };
    });
  }, [bookings, standardMap]);

  const optionsFor = useMemo(() => {
    const map: Record<string, FilterOption[]> = {};
    COLUMNS.forEach((col) => {
      const seen = new Map<string, string>();
      enriched.forEach((args) => {
        const opt = col.filterOf(args);
        if (opt && !seen.has(opt.value)) seen.set(opt.value, opt.label);
      });
      map[col.key] = [...seen.entries()]
        .map(([value, label]) => ({ value, label }))
        .sort((a, b) =>
          col.key === "date" ? a.value.localeCompare(b.value) : a.label.localeCompare(b.label),
        );
    });
    return map;
  }, [enriched]);

  /**
   * Opgeslagen filters kunnen na een wijziging van een boeking of standaard
   * naar waardes verwijzen die niet meer bestaan. Zulke filters mogen de
   * volledige lijst niet ongemerkt leeg of onvolledig maken.
   */
  const validFilters = useMemo(() => {
    const next: Record<string, string[]> = {};
    COLUMNS.forEach((col) => {
      const selected = filters[col.key] ?? [];
      if (!selected.length) return;
      const available = new Set((optionsFor[col.key] ?? []).map((option) => option.value));
      const valid = selected.filter((value) => available.has(value));
      if (valid.length) next[col.key] = valid;
    });
    return next;
  }, [filters, optionsFor]);

  const rows = useMemo(() => {
    return enriched
      .filter((args) =>
        COLUMNS.every((col) => {
          const selected = validFilters[col.key];
          if (!selected?.length) return true;
          const opt = col.filterOf(args);
          return opt ? selected.includes(opt.value) : false;
        }),
      )
      .filter(({ booking: b }) =>
        search
          ? [b.event_name, b.artists?.name, b.city, b.location_name]
              .filter(Boolean)
              .join(" ")
              .toLowerCase()
              .includes(search.toLowerCase())
          : true,
      )
      .sort((a, b) => {
        const col = COLUMNS.find((c) => c.key === sort);
        if (!col) return 0;
        const va = col.sortOf(a);
        const vb = col.sortOf(b);
        return asc ? va.localeCompare(vb) : vb.localeCompare(va);
      });
  }, [enriched, search, sort, asc, validFilters]);

  /** Zichtbaar maken welke kolomfilters actief zijn, zodat verborgen rijen verklaarbaar zijn. */
  const activeFilters = useMemo(
    () =>
      COLUMNS.filter((col) => validFilters[col.key]?.length).map((col) => ({
        key: col.key,
        label: `${col.label}: ${(validFilters[col.key] ?? []).join(", ")}`,
      })),
    [validFilters],
  );


  function toggleSort(key: string) {
    if (sort === key) setAsc((v) => !v);
    else {
      setSort(key);
      setAsc(true);
    }
  }

  return (
    <AppShell title="Boekingen" subtitle={`${rows.length} resultaten`} user={user}>
      <div className="panel">
        <div className="flex flex-wrap items-center gap-3 border-b p-4">
          <div className="relative min-w-56 flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="Zoek op event, artiest of stad…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          {activeFilters.length ? (
            <div className="hidden flex-wrap items-center gap-2 md:flex">
              <span className="text-xs text-muted-foreground">Actieve filters:</span>
              {activeFilters.map((f) => (
                <span
                  key={f.key}
                  className="inline-flex items-center gap-1 rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 text-xs text-primary"
                >
                  {f.label}
                  <button
                    type="button"
                    aria-label={`${f.label} filter wissen`}
                    onClick={() => setFilters((prev) => ({ ...prev, [f.key]: [] }))}
                    className="rounded-full p-0.5 hover:bg-primary/20"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              ))}
              <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => setFilters({})}>
                Alles wissen
              </Button>
            </div>
          ) : null}
          {years.length ? (
            <Button variant="outline" size="sm" onClick={clearYears}>
              Alleen {years.slice().sort((a, b) => b - a).join(", ")} · Alle jaren tonen
            </Button>
          ) : null}
        </div>

        <MobileFilters
          columns={orderedColumns
            .filter((c) => !["time", "playTime", "event", "location"].includes(c.key))
            .map((c) => ({ key: c.key, label: c.label }))}
          optionsFor={optionsFor}
          filters={validFilters}
          onChange={(key, values) => setFilters((prev) => ({ ...prev, [key]: values }))}
          onClearAll={() => setFilters({})}
        />


        <div className="hidden overflow-x-auto md:block">
          <Table className="table-fixed [&_td]:py-4">

            <TableHeader>
              <TableRow>
                <TableHead className="w-1.5 p-0" />
                {orderedColumns.map((col) => {
                  return (
                    <TableHead
                      key={col.key}
                      {...dragProps(col.key)}
                      title="Versleep om de kolomvolgorde te wijzigen"
                      className={`${col.className} align-middle select-none cursor-grab data-[dragging=true]:opacity-50`}
                    >
                      <span
                        className={`inline-flex w-full items-center gap-1 whitespace-nowrap ${col.className.includes("text-right") ? "justify-end" : ""}`}
                      >
                        <span
                          className="cursor-pointer truncate whitespace-nowrap hover:underline"
                          onClick={() => toggleSort(col.key)}
                        >
                          {col.label}
                          {sort === col.key ? (asc ? " ↑" : " ↓") : ""}
                        </span>
                        <ColumnFilter
                          options={optionsFor[col.key] ?? []}
                           selected={validFilters[col.key] ?? []}
                          align={col.className.includes("text-right") ? "end" : "start"}
                          onChange={(values) =>
                            setFilters((prev) => ({ ...prev, [col.key]: values }))
                          }
                        />
                      </span>
                    </TableHead>
                  );
                })}
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((args) => (
                <TableRow
                  key={args.booking.id}
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => navigate({ to: "/bookings/$id", params: { id: args.booking.id }, search: { tab: "booking" } })}
                >
                  <StatusStripeCell booking={args.booking} />
                  {orderedColumns.map((col) => (
                    <TableCell key={col.key} className={`${col.cellClassName} align-middle`}>
                      {col.render(args)}
                    </TableCell>
                  ))}
                </TableRow>
              ))}

              {rows.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="py-12 text-center text-sm text-muted-foreground">
                    Geen boekingen gevonden.
                  </TableCell>
                </TableRow>
              ) : null}
            </TableBody>
          </Table>
        </div>

        {/* Mobiele kaartweergave: informatie onder elkaar, ruime tikvlakken. */}
        <ul className="divide-y md:hidden">
          {rows.map(({ booking: b, time, playTime, location }, i) => (
            <li key={b.id}>
              {i === 0 || monthKey(b.event_date) !== monthKey(rows[i - 1]!.booking.event_date) ? (
                <MonthDivider date={b.event_date} />
              ) : null}
              <MobileBookingRow booking={b} presenceTime={time} playTime={playTime} location={location} />
            </li>
          ))}

          {rows.length === 0 ? (
            <li className="px-4 py-10 text-center text-sm text-muted-foreground">
              Geen boekingen gevonden.
            </li>
          ) : null}
        </ul>

      </div>
    </AppShell>
  );
}
