import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Check, Copy, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { AppShell } from "@/components/app-shell";
import { useCurrentUser } from "@/lib/session";
import { supabase } from "@/integrations/supabase/client";
import {
  formatDateTime,
  logActivity,
  useWidgetArtists,
  useWidgets,
  widgetStatusOptions,
  WIDGET_CONTENT_DEFAULT,
  WIDGET_CONTENT_OPTIONS,
  WIDGET_INCLUDE_DEFAULT,
  WIDGET_INCLUDE_LABELS,
  WIDGET_INCLUDE_OPTIONS,
} from "@/lib/data";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { WidgetDialog } from "@/components/widget-dialog";

export const Route = createFileRoute("/_authenticated/widgets")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { title: "Kalenderwidgets — PodiumPlan" },
      { name: "description", content: "Deel de agenda van een artiest via een kalenderwidget." },
      { property: "og:title", content: "Kalenderwidgets — PodiumPlan" },
      { property: "og:description", content: "Publiceer optredens in een externe agenda." },
    ],
  }),
  component: WidgetsPage,
});

function toggle(list: string[], value: string) {
  return list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
}

function WidgetsPage() {
  const user = useCurrentUser();
  const queryClient = useQueryClient();
  const { data: widgets = [] } = useWidgets();
  const { data: artists = [] } = useWidgetArtists();
  const [name, setName] = useState("");
  const [artistIds, setArtistIds] = useState<string[]>([]);
  const [statuses, setStatuses] = useState<string[]>([]);
  const [content, setContent] = useState<string[]>([...WIDGET_CONTENT_DEFAULT]);
  const [include, setInclude] = useState<string[]>([...WIDGET_INCLUDE_DEFAULT]);
  const [saving, setSaving] = useState(false);
  const statusOpts = widgetStatusOptions(artists, artistIds);
  const [copied, setCopied] = useState<string | null>(null);
  const [editing, setEditing] = useState<(typeof widgets)[number] | null>(null);

  function feedUrl(token: string) {
    return `${window.location.origin}/api/public/calendar/${token}.ics`;
  }

  async function create(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return toast.error("Vul een naam in.");
    if (include.length === 0) return toast.error("Kies boekingen, taken of beide.");
    setSaving(true);
    const { error } = await supabase.from("calendar_widgets").insert({
      name: name.trim(),
      artist_ids: artistIds,
      statuses,
      content,
      include,
      user_id: user.id,
    });
    setSaving(false);
    if (error) return toast.error(error.message);
    await logActivity({
      entityType: "widget",
      action: "create",
      summary: `maakte kalenderwidget "${name.trim()}"`,
    });
    setName("");
    setArtistIds([]);
    setStatuses([]);
    setContent([...WIDGET_CONTENT_DEFAULT]);
    setInclude([...WIDGET_INCLUDE_DEFAULT]);
    queryClient.invalidateQueries();
  }




  async function remove(id: string, widgetName: string) {
    const { error } = await supabase.from("calendar_widgets").delete().eq("id", id);
    if (error) return toast.error(error.message);
    await logActivity({
      entityType: "widget",
      action: "delete",
      summary: `verwijderde kalenderwidget "${widgetName}"`,
    });
    queryClient.invalidateQueries();
  }

  function copy(token: string) {
    navigator.clipboard.writeText(feedUrl(token));
    setCopied(token);
    setTimeout(() => setCopied((t) => (t === token ? null : t)), 2000);
  }

  return (
    <AppShell title="Kalenderwidgets" subtitle={`${widgets.length} widgets`} user={user}>
      <div className="grid gap-5 lg:grid-cols-3">
        <form onSubmit={create} className="panel space-y-5 p-5">
          <h2 className="text-sm font-semibold">Nieuwe widget</h2>
          <div className="space-y-2">
            <Label htmlFor="widget-name">Naam</Label>
            <Input id="widget-name" value={name} onChange={(e) => setName(e.target.value)} />
          </div>

          <div className="space-y-2">
            <Label>Inhoud</Label>
            <div className="space-y-2 rounded-md border p-3">
              {WIDGET_INCLUDE_OPTIONS.map((o) => (
                <label key={o.value} className="flex items-center gap-2 text-sm">
                  <Checkbox
                    checked={include.includes(o.value)}
                    onCheckedChange={() => setInclude((prev) => toggle(prev, o.value))}
                  />
                  {o.label}
                </label>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">
              Taken komen alleen mee als ze bij de taak zijn aangevinkt voor de widget.
            </p>
          </div>



          <div className="space-y-2">
            <Label>Artiesten</Label>
            <p className="text-xs text-muted-foreground">
              {artists.length === 0
                ? "Er zijn nog geen artiesten. Deze widget bevat daarom geen optredens."
                : "Niets aanvinken = alle artiesten in de agenda."}
            </p>
            <div className="max-h-52 space-y-2 overflow-y-auto rounded-md border p-3">
              {artists.map((a) => (
                <label key={a.id} className="flex items-center gap-2 text-sm">
                  <Checkbox
                    checked={artistIds.includes(a.id)}
                    onCheckedChange={() => setArtistIds((prev) => toggle(prev, a.id))}
                  />
                  {a.name}
                </label>
              ))}
              {artists.length === 0 ? (
                <p className="text-xs text-muted-foreground">Nog geen artiesten.</p>
              ) : null}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Statussen</Label>
            <p className="text-xs text-muted-foreground">Niets aanvinken = alle statussen.</p>
            <div className="max-h-52 space-y-2 overflow-y-auto rounded-md border p-3">
              {statusOpts.custom.length === 0 ? (
                <p className="text-xs text-muted-foreground">
                  Nog geen statussen. Voeg statussen toe bij de artiest.
                </p>
              ) : null}
              {statusOpts.custom.length ? (
                <>
                  {statusOpts.custom.map((s) => (
                    <label key={s.value} className="flex items-center gap-2 text-sm">
                      <Checkbox
                        checked={statuses.includes(s.value)}
                        onCheckedChange={() => setStatuses((prev) => toggle(prev, s.value))}
                      />
                      {s.label}
                      <span className="text-xs text-muted-foreground">· {s.hint}</span>
                    </label>
                  ))}
                </>
              ) : null}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Inhoud van de agenda-items</Label>
            <p className="text-xs text-muted-foreground">
              Kies wat er per optreden in de agenda komt.
            </p>
            <div className="space-y-2 rounded-md border p-3">
              {WIDGET_CONTENT_OPTIONS.map((o) => (
                <label key={o.value} className="flex items-center gap-2 text-sm">
                  <Checkbox
                    checked={content.includes(o.value)}
                    onCheckedChange={() => setContent((prev) => toggle(prev, o.value))}
                  />
                  {o.label}
                </label>
              ))}
            </div>
          </div>


          <Button type="submit" className="w-full" disabled={saving}>
            <Plus className="mr-2 h-4 w-4" /> Widget aanmaken
          </Button>
        </form>

        <div className="panel lg:col-span-2">
          <div className="border-b px-5 py-4">
            <h2 className="text-sm font-semibold">Bestaande widgets</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Plak de link in Google Agenda, Apple Agenda of Outlook via “agenda via URL
              toevoegen”.
            </p>
          </div>
          <ul className="divide-y">
            {widgets.map((w) => (
              <li key={w.id} className="space-y-3 px-5 py-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{w.name}</p>
                    <p className="mt-1 truncate text-xs text-muted-foreground">
                      {(w.include?.length ? w.include : WIDGET_INCLUDE_DEFAULT)
                        .map((i) => WIDGET_INCLUDE_LABELS[i] ?? i)
                        .join(" + ")}{" "}
                      ·{" "}
                      {w.artist_ids.length
                        ? w.artist_ids
                            .map((id) => artists.find((a) => a.id === id)?.name)
                            .filter(Boolean)
                            .join(", ")
                        : artists.length === 0
                          ? "Geen artiesten"
                          : "Alle artiesten"}{" "}
                      ·{" "}
                      {w.statuses?.length
                        ? w.statuses.join(", ")
                        : "Alle statussen"}{" "}
                      · {formatDateTime(w.created_at)}
                    </p>
                  </div>
                  <div className="flex shrink-0 gap-2">
                    <Button size="sm" variant="outline" onClick={() => copy(w.token)}>
                      {copied === w.token ? (
                        <Check className="mr-2 h-4 w-4" />
                      ) : (
                        <Copy className="mr-2 h-4 w-4" />
                      )}
                      {copied === w.token ? "Gekopieerd" : "Kopieer link"}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setEditing(w)}
                      aria-label={`Pas ${w.name} aan`}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => remove(w.id, w.name)}
                      aria-label={`Verwijder ${w.name}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <code className="block truncate rounded-md bg-muted px-3 py-2 text-xs text-muted-foreground">
                  /api/public/calendar/{w.token}.ics
                </code>
              </li>
            ))}
            {widgets.length === 0 ? (
              <li className="px-5 py-12 text-center text-sm text-muted-foreground">
                Nog geen widgets aangemaakt.
              </li>
            ) : null}
          </ul>
        </div>
      </div>
      <WidgetDialog
        open={editing !== null}
        onOpenChange={(v) => !v && setEditing(null)}
        widget={editing}
      />
    </AppShell>
  );
}
