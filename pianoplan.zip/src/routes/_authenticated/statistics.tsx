import { isCancelledBooking, isCompletedBooking } from "@/lib/artist-status";
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  XAxis,
  YAxis,
} from "recharts";

import { AppShell } from "@/components/app-shell";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentUser } from "@/lib/session";
import { useIsReader } from "@/lib/roles";
import { usePermission } from "@/lib/permissions";
import { useAccessRedirect } from "@/components/access-guard";
import {
  bookingStatusLabel,
  FINANCIAL_STATUS_LABELS,
  fieldTab,
  fieldValues,
  parseFields,
  useArtists,
  useBookings,
  useStandards,
  useStandardMap,
} from "@/lib/data";
import { STATUS_CHART_COLORS, bookingStatusColorOf } from "@/components/status-badges";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useUserPersistentState } from "@/lib/use-persistent-state";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";

export const Route = createFileRoute("/_authenticated/statistics")({
  head: () => ({
    meta: [
      { title: "Statistieken — PodiumPlan" },
      {
        name: "description",
        content: "Inzicht in optredens per artiest, per maand en per status, plus financiële cijfers.",
      },
      { property: "og:title", content: "Statistieken — PodiumPlan" },
      {
        property: "og:description",
        content: "KPI's en grafieken over al je optredens en omzet.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) return;
    const { data: roleRow } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", data.user.id)
      .maybeSingle();
    if (roleRow?.role === "lezer") {
      throw redirect({ to: "/dashboard" });
    }
  },
  component: StatisticsPage,
});

const MONTHS = [
  "jan", "feb", "mrt", "apr", "mei", "jun", "jul", "aug", "sep", "okt", "nov", "dec",
];

const PALETTE = [
  "var(--chart-1)",
  "var(--chart-2)",
  "var(--chart-3)",
  "var(--chart-4)",
  "var(--chart-5)",
];

/**
 * Artiestkleuren: expliciet andere tinten dan de statuskleuren
 * (groen/amber/blauw/rood/paars) uit 'Verdeling per status'.
 */
const ARTIST_BASE = [
  "oklch(0.62 0.16 200)", // teal
  "oklch(0.58 0.17 320)", // magenta
  "oklch(0.66 0.15 130)", // olijf
  "oklch(0.60 0.14 250)", // indigo
  "oklch(0.70 0.14 60)",  // oker
  "oklch(0.55 0.12 170)", // zeegroen
];

const ARTIST_PALETTE = [
  ...ARTIST_BASE,
  ...ARTIST_BASE.map((c) => `color-mix(in oklab, ${c} 65%, white)`),
  ...ARTIST_BASE.map((c) => `color-mix(in oklab, ${c} 70%, black)`),
];



const formatEuro = (n: number) =>
  `€ ${n.toLocaleString("nl-NL", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;

function monthLabelShort(key: string) {
  const [y, m] = key.split("-");
  return `${MONTHS[Number(m) - 1]} ’${y!.slice(2)}`;
}

/** Geannuleerde optredens en optredens met een 'vervanger gezocht'-status tellen niet mee financieel. */
function isExcludedFromFinancial(booking: { status?: string | null; artist_status?: string | null }) {
  const label = bookingStatusLabel(booking).toLowerCase();
  return (
    isCancelledBooking(booking) ||
    label.includes("vervanger")
  );
}


function Kpi({
  label,
  value,
  hint,
  statusFilter,
  artistNames,
}: {
  label: string;
  value: string;
  hint?: string;
  /** Statuslabels (gescheiden door ~) om op de boekingspagina te filteren. */
  statusFilter?: string;
  /** Geselecteerde artiestnamen om ook mee te nemen in de boekingsfilter. */
  artistNames?: string[];
}) {
  const body = (
    <>
      <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">{label}</p>
      <p className="mt-1 text-2xl font-semibold tabular-nums">{value}</p>
      {hint ? <p className="mt-1 text-xs text-muted-foreground">{hint}</p> : null}
    </>
  );

  const hasStatus = statusFilter !== undefined;
  const hasArtist = artistNames && artistNames.length > 0;

  if (!hasStatus && !hasArtist) return <div className="panel p-4">{body}</div>;

  const search: Record<string, string> = {};
  if (hasStatus && statusFilter !== "") search.status = statusFilter;
  if (hasArtist) search.artist = artistNames.join("~");

  return (
    <Link
      to="/bookings"
      search={search}
      className="panel block p-4 text-left transition-colors hover:border-primary/40 hover:bg-accent/40"
    >
      {body}
    </Link>
  );
}


function Panel({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="panel flex h-full flex-col p-4">
      <div className="min-h-[2.5rem]">
        <p className="text-sm font-semibold">{title}</p>
        {subtitle ? <p className="mt-0.5 text-xs text-muted-foreground">{subtitle}</p> : null}
      </div>
      <div className="mt-4 flex-1">{children}</div>
    </div>
  );
}

function EmptyChart() {
  return (
    <div className="flex h-56 items-center justify-center text-sm text-muted-foreground">
      Nog geen gegevens beschikbaar.
    </div>
  );
}

function StatisticsPage() {
  const user = useCurrentUser();
  const { allowed: isAdmin, isLoading: adminLoading } = usePermission("financial.view");
  const { isReader } = useIsReader();
  const { allowed: canViewStats, isLoading: readerLoading } = usePermission("statistics.view");
  useAccessRedirect(canViewStats, readerLoading);
  const { data: yearBookings = [] } = useBookings(); // gefilterd op globale jaarfilter
  const { data: standards = [] } = useStandards();
  const { data: artists = [] } = useArtists();
  const standardMap = useStandardMap();
  const [artistIds, setArtistIds] = useUserPersistentState<string[]>("stats-artists", []);
  const [teamMemberIds, setTeamMemberIds] = useUserPersistentState<string[]>("stats-team-members", []);

  /** Teamleden met hun boekingen, om te filteren op teamlidmaatschap. */
  const { data: teamMemberRows = [] } = useQuery({
    queryKey: ["statistics-team-members"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("booking_members")
        .select("booking_id, user_id, status, profiles(name)");
      if (error) throw error;
      return data as {
        booking_id: string;
        user_id: string;
        status: string;
        profiles: { name: string } | null;
      }[];
    },
  });

  const teamMemberOptions = useMemo(() => {
    const map = new Map<string, string>();
    teamMemberRows.forEach((m) => {
      if (m.status === "accepted" && !map.has(m.user_id)) {
        map.set(m.user_id, m.profiles?.name ?? "Onbekend");
      }
    });
    return [...map.entries()]
      .map(([value, label]) => ({ value, label }))
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [teamMemberRows]);

  /** Leeg = alle artiesten. Teamleden beperkt tot boekingen waar de persoon in het team zit. */
  const bookings = useMemo(() => {
    let rows = yearBookings;
    if (artistIds.length > 0) rows = rows.filter((b) => artistIds.includes(b.artist_id));
    if (teamMemberIds.length > 0) {
      const teamBookingIds = new Set(
        teamMemberRows
          .filter((m) => m.status === "accepted" && teamMemberIds.includes(m.user_id))
          .map((m) => m.booking_id),
      );
      rows = rows.filter((b) => teamBookingIds.has(b.id));
    }
    return rows;
  }, [yearBookings, artistIds, teamMemberIds, teamMemberRows]);

  const artistOptions = useMemo(
    () => artists.map((a) => ({ value: a.id, label: a.name })),
    [artists],
  );

  const selectedArtistNames = useMemo(
    () =>
      artistIds
        .map((id) => artists.find((a) => a.id === id)?.name)
        .filter((name): name is string => Boolean(name)),
    [artistIds, artists],
  );

  /** Vaste kleur per artiestnaam, zodat alle grafieken dezelfde kleuren gebruiken. */
  const artistColorMap = useMemo(() => {
    const names = [...artists].map((a) => a.name).sort((a, b) => a.localeCompare(b));
    yearBookings.forEach((b) => {
      const name = b.artists?.name ?? "Onbekend";
      if (!names.includes(name)) names.push(name);
    });
    const map = new Map<string, string>();
    names.forEach((name, i) => map.set(name, ARTIST_PALETTE[i % ARTIST_PALETTE.length]!));
    return map;
  }, [artists, yearBookings]);

  const artistColor = (name: string) =>
    artistColorMap.get(name) ?? ARTIST_PALETTE[0]!;


  /* --------------------------------- algemeen -------------------------------- */

  const general = useMemo(() => {
    const total = bookings.length;
    const byStatus = new Map<string, number>();
    const statusColors = new Map<string, ReturnType<typeof bookingStatusColorOf>>();
    const byArtist = new Map<string, number>();
    const byMonth = new Map<string, number>();
    const monthArtist = new Map<string, Map<string, number>>();

    const plannedLabels = new Set<string>();
    const doneLabels = new Set<string>();
    const cancelledLabels = new Set<string>();
    const allLabels = new Set<string>();
    let planned = 0;
    let done = 0;
    let cancelled = 0;
    let active = 0;


    bookings.forEach((b) => {
      const label = bookingStatusLabel(b) || "—";
      const excluded = isExcludedFromFinancial(b);
      allLabels.add(label);

      /* De statusverdeling toont alle optredens, ook die niet doorgaan. */
      byStatus.set(label, (byStatus.get(label) ?? 0) + 1);
      if (!statusColors.has(label)) statusColors.set(label, bookingStatusColorOf(b, artists));

      /* Optredens die niet doorgaan tellen niet mee in overige grafieken en gemiddelden. */
      if (!excluded) {
        const artist = b.artists?.name ?? "Onbekend";
        byArtist.set(artist, (byArtist.get(artist) ?? 0) + 1);

        const key = b.event_date.slice(0, 7);
        byMonth.set(key, (byMonth.get(key) ?? 0) + 1);
        if (!monthArtist.has(key)) monthArtist.set(key, new Map());
        const inner = monthArtist.get(key)!;
        inner.set(artist, (inner.get(artist) ?? 0) + 1);
        active += 1;
      }


      const labelLower = label.toLowerCase();
      if (isCancelledBooking(b)) {
        cancelled += 1;
        cancelledLabels.add(label);
      } else if (isCompletedBooking(b)) {
        done += 1;
        doneLabels.add(label);
      } else if ((labelLower === "optie" || labelLower === "definitief") && !excluded) {
        planned += 1;
        plannedLabels.add(label);
      }
    });

    const artistList = [...byArtist.entries()]
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);
    const artistNames = artistList.map((a) => a.name);

    const months = [...byMonth.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([key, count]) => {
        const row: Record<string, string | number> = {
          key,
          label: monthLabelShort(key),
          count,
        };
        artistNames.forEach((name) => {
          row[name] = monthArtist.get(key)?.get(name) ?? 0;
        });
        return row;
      });

    return {
      total,
      planned,
      done,
      cancelled,
      plannedFilter: [...plannedLabels].join("~"),
      doneFilter: [...doneLabels].join("~"),
      cancelledFilter: [...cancelledLabels].join("~"),
      average: months.length ? active / months.length : 0,
      artists: artistList,
      artistNames,

      statuses: [...byStatus.entries()].map(([name, count]) => ({
        name,
        count,
        fill: STATUS_CHART_COLORS[statusColors.get(name) ?? "gray"],
      })),
      months,
    };
  }, [bookings, artists]);

  /* -------------------------------- doorgang --------------------------------- */

  /** Inzicht in welke aanvragen wel en niet zijn doorgegaan. */
  const conversion = useMemo(() => {
    const requests = bookings.length;
    let confirmed = 0;
    const failedByLabel = new Map<string, number>();
    const confirmedLabels = new Set<string>();
    const failedLabels = new Set<string>();
    const byArtist = new Map<string, { requests: number; confirmed: number }>();
    const byMonth = new Map<string, { confirmed: number; failed: number }>();

    bookings.forEach((b) => {
      const label = bookingStatusLabel(b) || "—";
      const failed = isExcludedFromFinancial(b);
      const artist = b.artists?.name ?? "Onbekend";
      const key = b.event_date.slice(0, 7);

      const artistRow = byArtist.get(artist) ?? { requests: 0, confirmed: 0 };
      artistRow.requests += 1;
      const monthRow = byMonth.get(key) ?? { confirmed: 0, failed: 0 };

      if (failed) {
        failedByLabel.set(label, (failedByLabel.get(label) ?? 0) + 1);
        failedLabels.add(label);
        monthRow.failed += 1;
      } else {
        confirmed += 1;
        confirmedLabels.add(label);
        artistRow.confirmed += 1;
        monthRow.confirmed += 1;
      }

      byArtist.set(artist, artistRow);
      byMonth.set(key, monthRow);
    });

    const failedCount = requests - confirmed;

    return {
      requests,
      confirmed,
      failed: failedCount,
      rate: requests ? (confirmed / requests) * 100 : 0,
      confirmedFilter: [...confirmedLabels].join("~"),
      failedFilter: [...failedLabels].join("~"),
      reasons: [...failedByLabel.entries()]
        .map(([name, count]) => ({ name, count }))
        .sort((a, b) => b.count - a.count),
      artists: [...byArtist.entries()]
        .map(([name, row]) => ({
          name,
          requests: row.requests,
          confirmed: row.confirmed,
          failed: row.requests - row.confirmed,
          rate: row.requests ? (row.confirmed / row.requests) * 100 : 0,
        }))
        .sort((a, b) => b.requests - a.requests),
      months: [...byMonth.entries()]
        .sort((a, b) => a[0].localeCompare(b[0]))
        .map(([key, row]) => ({
          label: monthLabelShort(key),
          confirmed: row.confirmed,
          failed: row.failed,
        })),
    };
  }, [bookings]);


  /* -------------------------------- financieel ------------------------------- */

  /** Alle financiële bedrag-velden (currency) over alle standaarden. */
  const currencyLabels = useMemo(() => {
    const labels: string[] = [];
    standards.forEach((s) =>
      parseFields(s.fields)
        .filter((f) => fieldTab(f) === "financial" && f.type === "currency")
        .forEach((f) => {
          if (!labels.includes(f.label)) labels.push(f.label);
        }),
    );
    return labels;
  }, [standards]);

  /** Omzet van één boeking: som van alle financiële bedragvelden. */
  function bookingRevenue(booking: (typeof bookings)[number]) {
    const standard = booking.standard_id ? standardMap.get(booking.standard_id) : undefined;
    const fields = parseFields(standard?.fields).filter(
      (f) => fieldTab(f) === "financial" && f.type === "currency",
    );
    const values = fieldValues(booking.field_values);
    return fields.reduce((sum, f) => {
      const raw = values[f.id] ?? "";
      if (!raw) return sum;
      const cleaned = raw
        .replace(/[^\d,.-]/g, "")
        .replace(/\.(?=\d{3}\b)/g, "")
        .replace(",", ".");
      const n = Number.parseFloat(cleaned);
      return sum + (Number.isFinite(n) ? n : 0);
    }, 0);
  }

  const financial = useMemo(() => {
    let total = 0;
    const byStatus = new Map<string, number>();
    const statusColors = new Map<string, ReturnType<typeof bookingStatusColorOf>>();
    const byMonth = new Map<string, number>();
    const byArtist = new Map<string, number>();
    const monthArtist = new Map<string, Map<string, number>>();
    const monthArtistCount = new Map<string, Map<string, number>>();
    const monthArtistExpected = new Map<string, Map<string, number>>();
    let expected = 0;
    let totalToDate = 0;
    const today = new Date();
    const todayKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;

    bookings.forEach((b) => {
      const amount = bookingRevenue(b);
      if (isExcludedFromFinancial(b)) return;
      total += amount;
      if (b.event_date <= todayKey) totalToDate += amount;

      const status = b.financial_status ?? "nog_spelen";
      byStatus.set(status, (byStatus.get(status) ?? 0) + amount);
      if (status === "nog_spelen" || status === "factureren") expected += amount;

      const key = b.event_date.slice(0, 7);
      byMonth.set(key, (byMonth.get(key) ?? 0) + amount);

      const artist = b.artists?.name ?? "Onbekend";
      byArtist.set(artist, (byArtist.get(artist) ?? 0) + amount);

      if (!monthArtist.has(key)) monthArtist.set(key, new Map());
      const inner = monthArtist.get(key)!;
      inner.set(artist, (inner.get(artist) ?? 0) + amount);

      if (!monthArtistCount.has(key)) monthArtistCount.set(key, new Map());
      const innerCount = monthArtistCount.get(key)!;
      innerCount.set(artist, (innerCount.get(artist) ?? 0) + 1);

      if (status === "nog_spelen" || status === "factureren") {
        if (!monthArtistExpected.has(key)) monthArtistExpected.set(key, new Map());
        const innerExp = monthArtistExpected.get(key)!;
        innerExp.set(artist, (innerExp.get(artist) ?? 0) + amount);
      }
    });

    const artistNames = [...byArtist.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name]) => name);

    const monthKeys = [...byMonth.keys()].sort((a, b) => a.localeCompare(b));

    const monthRows = monthKeys.map((key) => ({
      key,
      label: monthLabelShort(key),
      total: byMonth.get(key) ?? 0,
    }));

    const stacked = monthKeys.map((key) => {
      const row: Record<string, string | number> = { label: monthLabelShort(key) };
      artistNames.forEach((name) => {
        row[name] = monthArtist.get(key)?.get(name) ?? 0;
      });
      return row;
    });

    const totalMonths = monthKeys.length;

    const averagePerArtist = artistNames.map((name) => {
      let sum = 0;
      let count = 0;
      monthKeys.forEach((key) => {
        const value = monthArtist.get(key)?.get(name);
        if (value !== undefined) sum += value;
        count += monthArtistCount.get(key)?.get(name) ?? 0;
      });
      return {
        name,
        average: totalMonths ? sum / totalMonths : 0,
        perBooking: count ? sum / count : 0,
        total: sum,
        bookings: count,
      };
    });

    const expectedPerArtist = artistNames.map((name) => {
      let sum = 0;
      monthKeys.forEach((key) => {
        sum += monthArtistExpected.get(key)?.get(name) ?? 0;
      });
      return { name, expected: totalMonths ? sum / totalMonths : 0 };
    });


    return {
      total,
      totalToDate,
      expected,
      monthRows,
      stacked,
      artistNames,
      averagePerArtist,
      expectedPerArtist,
      statuses: [...byStatus.entries()].map(([key, value]) => ({
        name: FINANCIAL_STATUS_LABELS[key] ?? key,
        value,
      })),
      averageMonth: monthKeys.length ? total / monthKeys.length : 0,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookings, standardMap, currencyLabels]);

  const revenueConfig = { total: { label: "Omzet", color: "var(--chart-1)" } };
  const artistConfig = { count: { label: "Optredens", color: "var(--chart-2)" } };
  const conversionConfig = {
    confirmed: { label: "Doorgegaan", color: "var(--chart-1)" },
    failed: { label: "Niet doorgegaan", color: "var(--chart-4)" },
  };

  /** Kleur per artiest voor de maandgrafiek (algemeen). */
  const monthConfig = useMemo(
    () =>
      Object.fromEntries(
        general.artistNames.map((name) => [name, { label: name, color: artistColor(name) }]),
      ),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [general.artistNames, artistColorMap],
  );

  const stackedConfig = useMemo(
    () =>
      Object.fromEntries(
        financial.artistNames.map((name) => [name, { label: name, color: artistColor(name) }]),
      ),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [financial.artistNames, artistColorMap],
  );


  if (adminLoading || readerLoading) {
    return (
      <AppShell title="Statistieken" user={user}>
        <div className="panel p-10 text-center text-sm text-muted-foreground">Laden…</div>
      </AppShell>
    );
  }

  if (!canViewStats) {
    return (
      <AppShell title="Statistieken" user={user}>
        <div className="panel p-10 text-center text-sm text-muted-foreground">
          Je hebt geen toegang tot de statistieken.
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell
      title="Statistieken"
      subtitle={`${conversion.confirmed} totaal optredens`}
      user={user}
      actions={
        <>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-9 max-w-48 justify-between">
                <span className="truncate">
                  {teamMemberIds.length === 0
                    ? "Alle teamleden"
                    : teamMemberIds.length === 1
                      ? (teamMemberOptions.find((o) => o.value === teamMemberIds[0])?.label ?? "1 teamlid")
                      : `${teamMemberIds.length} teamleden`}
                </span>
                <ChevronDown className="ml-2 size-4 opacity-60" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="max-h-80 w-64 overflow-y-auto">
              <DropdownMenuItem onClick={() => setTeamMemberIds([])}>Alle teamleden</DropdownMenuItem>
              {teamMemberOptions.length ? <DropdownMenuSeparator /> : null}
              {teamMemberOptions.map((o) => (
                <DropdownMenuCheckboxItem
                  key={o.value}
                  checked={teamMemberIds.includes(o.value)}
                  onCheckedChange={() =>
                    setTeamMemberIds((prev) =>
                      prev.includes(o.value)
                        ? prev.filter((v) => v !== o.value)
                        : [...prev, o.value],
                    )
                  }
                  onSelect={(e: Event) => e.preventDefault()}
                >
                  {o.label}
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="h-9 max-w-48 justify-between">
              <span className="truncate">
                {artistIds.length === 0
                  ? "Alle artiesten"
                  : artistIds.length === 1
                    ? (artistOptions.find((o) => o.value === artistIds[0])?.label ?? "1 artiest")
                    : `${artistIds.length} artiesten`}
              </span>
              <ChevronDown className="ml-2 size-4 opacity-60" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="max-h-80 w-64 overflow-y-auto">
            <DropdownMenuItem onClick={() => setArtistIds([])}>Alle artiesten</DropdownMenuItem>
            {artistOptions.length ? <DropdownMenuSeparator /> : null}
            {artistOptions.map((o) => (
              <DropdownMenuCheckboxItem
                key={o.value}
                checked={artistIds.includes(o.value)}
                onCheckedChange={() =>
                  setArtistIds((prev) =>
                    prev.includes(o.value)
                      ? prev.filter((v) => v !== o.value)
                      : [...prev, o.value],
                  )
                }
                onSelect={(e: Event) => e.preventDefault()}
              >
                {o.label}
              </DropdownMenuCheckboxItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
        </>
      }
    >
      <Tabs defaultValue="general" className="gap-4">

        <TabsList className="w-full max-w-md">
          <TabsTrigger value="general" className="flex-1">
            Algemeen
          </TabsTrigger>



          {isAdmin ? (
            <TabsTrigger value="financial" className="flex-1">
              Financieel
            </TabsTrigger>
          ) : null}
        </TabsList>

        {/* ---------------------------------- algemeen --------------------------------- */}
        <TabsContent value="general" className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <Kpi
              label="Totaal aanvragen"
              value={String(conversion.requests)}
              hint="Alle boekingen"
              statusFilter=""
              artistNames={selectedArtistNames}
            />
            <Kpi
              label="Totaal optredens"
              value={String(conversion.confirmed)}
              hint="Wel doorgegaan"
              statusFilter={conversion.confirmedFilter}
              artistNames={selectedArtistNames}
            />
            <Kpi
              label="Niet doorgegaan"
              value={String(conversion.failed)}
              hint="Geannuleerd of vervanger gezocht"
              statusFilter={conversion.failedFilter}
              artistNames={selectedArtistNames}
            />
            <Kpi
              label="Doorgangsratio"
              value={`${conversion.rate.toLocaleString("nl-NL", { maximumFractionDigits: 1 })}%`}
              hint="Optredens / aanvragen"
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            <Kpi
              label="Gepland"
              value={String(general.planned)}
              hint="Optie en definitief"
              statusFilter={general.plannedFilter}
              artistNames={selectedArtistNames}
            />
            <Kpi
              label="Afgerond"
              value={String(general.done)}
              statusFilter={general.doneFilter}
              artistNames={selectedArtistNames}
            />
            <Kpi
              label="Gem. per maand"
              value={general.average.toLocaleString("nl-NL", { maximumFractionDigits: 1 })}
              hint="Doorgegane optredens"
            />
          </div>



          <div className="grid gap-4 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <Panel
                title="Optredens per maand"
                subtitle="Per artiest · excl. optredens die niet doorgaan"
              >
                {general.months.length ? (
                  <>
                    <ChartContainer config={monthConfig} className="h-64 w-full">
                      <BarChart data={general.months}>
                        <CartesianGrid vertical={false} strokeDasharray="3 3" />
                        <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={12} />
                        <YAxis allowDecimals={false} tickLine={false} axisLine={false} width={28} fontSize={12} />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        {general.artistNames.map((name, i) => (
                          <Bar
                            key={name}
                            dataKey={name}
                            stackId="a"
                            fill={artistColor(name)}
                            radius={
                              i === general.artistNames.length - 1 ? [4, 4, 0, 0] : [0, 0, 0, 0]
                            }
                          />
                        ))}
                      </BarChart>
                    </ChartContainer>
                    <ul className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5">
                      {general.artistNames.map((name) => (
                        <li key={name} className="flex items-center gap-2 text-xs">
                          <span
                            className="h-2.5 w-2.5 rounded-full"
                            style={{ background: artistColor(name) }}
                          />
                          <span className="truncate">{name}</span>
                        </li>
                      ))}
                    </ul>
                  </>
                ) : (
                  <EmptyChart />
                )}
              </Panel>

            </div>

            <Panel title="Verdeling per status" subtitle="Alle optredens, incl. niet doorgegaan">
              {general.statuses.length ? (
                <ChartContainer config={{}} className="h-64 w-full">
                  <PieChart>
                    <ChartTooltip content={<ChartTooltipContent nameKey="name" />} />
                    <Pie
                      data={general.statuses}
                      dataKey="count"
                      nameKey="name"
                      innerRadius="55%"
                      outerRadius="80%"
                      paddingAngle={2}
                    >
                      {general.statuses.map((entry) => (
                        <Cell key={entry.name} fill={entry.fill} />
                      ))}
                    </Pie>
                  </PieChart>
                </ChartContainer>
              ) : (
                <EmptyChart />
              )}
              <ul className="mt-3 space-y-1.5">
                {general.statuses.map((s) => (
                  <li key={s.name} className="flex items-center gap-2 text-sm">
                    <span
                      className="h-2.5 w-2.5 rounded-full"
                      style={{ background: s.fill }}
                    />
                    <span className="flex-1 truncate">{s.name}</span>
                    <span className="tabular-nums text-muted-foreground">{s.count}</span>
                  </li>
                ))}
              </ul>
            </Panel>
          </div>

          <Panel title="Optredens per artiest">
            {general.artists.length ? (
              <ChartContainer config={artistConfig} className="h-72 w-full">
                <BarChart data={general.artists} layout="vertical" margin={{ left: 8 }}>
                  <CartesianGrid horizontal={false} strokeDasharray="3 3" />
                  <XAxis type="number" allowDecimals={false} tickLine={false} axisLine={false} fontSize={12} />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={120}
                    tickLine={false}
                    axisLine={false}
                    fontSize={12}
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                    {general.artists.map((a) => (
                      <Cell key={a.name} fill={artistColor(a.name)} />
                    ))}
                  </Bar>

                </BarChart>
              </ChartContainer>
            ) : (
              <EmptyChart />
            )}
          </Panel>

          <div className="grid gap-4 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <Panel title="Doorgegaan vs. niet doorgegaan per maand">
                {conversion.months.length ? (
                  <ChartContainer config={conversionConfig} className="h-64 w-full">
                    <BarChart data={conversion.months}>
                      <CartesianGrid vertical={false} strokeDasharray="3 3" />
                      <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={12} />
                      <YAxis allowDecimals={false} tickLine={false} axisLine={false} width={28} fontSize={12} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Bar dataKey="confirmed" stackId="a" fill="var(--color-confirmed)" radius={[0, 0, 0, 0]} />
                      <Bar dataKey="failed" stackId="a" fill="var(--color-failed)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ChartContainer>
                ) : (
                  <EmptyChart />
                )}
              </Panel>
            </div>

            <Panel title="Reden niet doorgegaan" subtitle="Op basis van de boekingsstatus">
              {conversion.reasons.length ? (
                <ul className="space-y-1.5">
                  {conversion.reasons.map((r, i) => (
                    <li key={r.name} className="flex items-center gap-2 text-sm">
                      <span
                        className="h-2.5 w-2.5 rounded-full"
                        style={{ background: PALETTE[i % PALETTE.length] }}
                      />
                      <span className="flex-1 truncate">{r.name}</span>
                      <span className="tabular-nums text-muted-foreground">{r.count}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-muted-foreground">Alle aanvragen zijn doorgegaan.</p>
              )}
            </Panel>
          </div>

          <Panel title="Doorgang per artiest" subtitle="Aanvragen, optredens en doorgangsratio">
            {conversion.artists.length ? (
              <div className="-mx-4 overflow-x-auto px-4">
                <table className="w-full min-w-[520px] text-sm">
                  <thead>
                    <tr className="border-b text-xs uppercase tracking-wide text-muted-foreground">
                      <th className="py-2 pr-3 text-left font-medium">Artiest</th>
                      <th className="py-2 px-3 text-right font-medium">Aanvragen</th>
                      <th className="py-2 px-3 text-right font-medium">Optredens</th>
                      <th className="py-2 px-3 text-right font-medium">Niet doorgegaan</th>
                      <th className="py-2 pl-3 text-right font-medium">Ratio</th>
                    </tr>
                  </thead>
                  <tbody>
                    {conversion.artists.map((a) => (
                      <tr key={a.name} className="border-b last:border-0">
                        <td className="py-2 pr-3">{a.name}</td>
                        <td className="py-2 px-3 text-right tabular-nums">{a.requests}</td>
                        <td className="py-2 px-3 text-right tabular-nums">{a.confirmed}</td>
                        <td className="py-2 px-3 text-right tabular-nums">{a.failed}</td>
                        <td className="py-2 pl-3 text-right tabular-nums">
                          {a.rate.toLocaleString("nl-NL", { maximumFractionDigits: 1 })}%
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Nog geen gegevens beschikbaar.</p>
            )}
          </Panel>
        </TabsContent>




        {/* --------------------------------- financieel -------------------------------- */}
        {isAdmin ? (
          <TabsContent value="financial" className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
              <Kpi
                label="Totale omzet"
                value={formatEuro(financial.total)}
                hint="Excl. geannuleerde optredens"
              />
              <Kpi
                label="Omzet t/m vandaag"
                value={formatEuro(financial.totalToDate)}
                hint="Excl. geannuleerde optredens"
              />
              <Kpi label="Gem. omzet per maand" value={formatEuro(financial.averageMonth)} />
              <Kpi
                label="Verwachte omzet"
                value={formatEuro(financial.expected)}
                hint="Nog spelen en te factureren"
              />
              <Kpi
                label="Gem. per optreden"
                value={formatEuro(
                  conversion.confirmed ? financial.total / conversion.confirmed : 0,
                )}
                hint="Excl. optredens die niet doorgaan"
              />

            </div>

            <div className="grid gap-4 lg:grid-cols-3">
              <div className="lg:col-span-2">
                <Panel
                  title="Omzet per maand per artiest"
                  subtitle="Top 5 artiesten op omzet"
                >
                  {financial.stacked.length && financial.artistNames.length ? (
                    <>
                      <ChartContainer config={stackedConfig} className="h-72 w-full">
                        <BarChart data={financial.stacked}>
                          <CartesianGrid vertical={false} strokeDasharray="3 3" />
                          <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={12} />
                          <YAxis tickLine={false} axisLine={false} width={56} fontSize={12} />
                          <ChartTooltip
                            cursor={{ fill: "var(--muted)", opacity: 0.4 }}
                            content={(props: {
                              active?: boolean;
                              label?: unknown;
                              payload?: { dataKey?: unknown; value?: unknown; color?: string }[];
                            }) => {
                              const { active, payload, label } = props;
                              if (!active || !payload?.length) return null;
                              const rows = payload.filter((p) => Number(p.value) > 0);
                              const total = rows.reduce((s, p) => s + Number(p.value ?? 0), 0);
                              return (
                                <div className="rounded-lg border bg-background p-2.5 shadow-md">
                                  <p className="mb-1.5 text-xs font-medium">{String(label)}</p>
                                  <ul className="space-y-1">
                                    {rows.map((p) => (
                                      <li
                                        key={String(p.dataKey)}
                                        className="flex items-center gap-2 text-xs"
                                      >
                                        <span
                                          className="h-2.5 w-2.5 rounded-[2px]"
                                          style={{ background: p.color }}
                                        />
                                        <span className="flex-1 truncate">{String(p.dataKey)}</span>
                                        <span className="tabular-nums font-medium">
                                          {formatEuro(Number(p.value))}
                                        </span>
                                      </li>
                                    ))}
                                  </ul>
                                  <div className="mt-1.5 flex items-center justify-between gap-4 border-t pt-1.5 text-xs font-semibold">
                                    <span>Totaal</span>
                                    <span className="tabular-nums">{formatEuro(total)}</span>
                                  </div>
                                </div>
                              );
                            }}
                          />
                          {financial.artistNames.map((name, i) => (
                            <Bar
                              key={name}
                              dataKey={name}
                              stackId="a"
                              fill={artistColor(name)}
                              radius={
                                i === financial.artistNames.length - 1 ? [4, 4, 0, 0] : [0, 0, 0, 0]
                              }
                            />
                          ))}
                        </BarChart>
                      </ChartContainer>
                      <ul className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5">
                        {financial.artistNames.map((name) => (
                          <li key={name} className="flex items-center gap-2 text-xs">
                            <span
                              className="h-2.5 w-2.5 rounded-full"
                              style={{ background: artistColor(name) }}
                            />
                            <span className="truncate">{name}</span>
                          </li>
                        ))}
                      </ul>
                    </>
                  ) : (
                    <EmptyChart />
                  )}
                </Panel>
              </div>

              <Panel title="Verdeling financiële status">
                {financial.statuses.length ? (
                  <ChartContainer config={{}} className="h-64 w-full">
                    <PieChart>
                      <ChartTooltip
                        content={
                          <ChartTooltipContent
                            nameKey="name"
                            formatter={(value) => formatEuro(Number(value))}
                          />
                        }
                      />
                      <Pie
                        data={financial.statuses}
                        dataKey="value"
                        nameKey="name"
                        innerRadius="55%"
                        outerRadius="80%"
                        paddingAngle={2}
                      >
                        {financial.statuses.map((entry, i) => (
                          <Cell key={entry.name} fill={PALETTE[i % PALETTE.length]} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ChartContainer>
                ) : (
                  <EmptyChart />
                )}
                <ul className="mt-3 space-y-1.5">
                  {financial.statuses.map((s, i) => (
                    <li key={s.name} className="flex items-center gap-2 text-sm">
                      <span
                        className="h-2.5 w-2.5 rounded-full"
                        style={{ background: PALETTE[i % PALETTE.length] }}
                      />
                      <span className="flex-1 truncate">{s.name}</span>
                      <span className="tabular-nums text-muted-foreground">
                        {formatEuro(s.value)}
                      </span>
                    </li>
                  ))}
                </ul>
              </Panel>
            </div>


            <Panel
              title="Gemiddeld en verwacht resultaat per maand per artiest"
              subtitle="Gemiddelde omzet over alle maanden"
            >
              {financial.averagePerArtist.length ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b text-xs text-muted-foreground uppercase">
                        <th className="py-2 text-left font-medium">Artiest</th>
                        <th className="py-2 text-right font-medium">Optredens</th>
                        <th className="py-2 text-right font-medium">Totale omzet</th>
                        <th className="py-2 text-right font-medium">Gem. per optreden</th>
                        <th className="py-2 text-right font-medium">Gem. per maand</th>
                        <th className="py-2 text-right font-medium">Verwacht per maand</th>
                      </tr>
                    </thead>
                    <tbody>
                      {financial.averagePerArtist.map((row) => (
                        <tr key={row.name} className="border-b last:border-0">
                          <td className="py-2.5 pr-3">
                            <span className="flex items-center gap-2">
                              <span
                                className="h-2.5 w-2.5 shrink-0 rounded-full"
                                style={{ background: artistColor(row.name) }}
                              />
                              <span className="truncate">{row.name}</span>
                            </span>
                          </td>

                          <td className="py-2.5 text-right tabular-nums">{row.bookings}</td>
                          <td className="py-2.5 text-right tabular-nums">
                            {formatEuro(row.total)}
                          </td>
                          <td className="py-2.5 text-right tabular-nums">
                            {formatEuro(row.perBooking)}
                          </td>
                          <td className="py-2.5 text-right tabular-nums">
                            {formatEuro(row.average)}
                          </td>
                          <td className="py-2.5 text-right tabular-nums">
                            {formatEuro(
                              financial.expectedPerArtist.find((e) => e.name === row.name)
                                ?.expected ?? 0,
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <EmptyChart />
              )}
            </Panel>
          </TabsContent>
        ) : null}
      </Tabs>
    </AppShell>
  );
}
