import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { useCurrentUser } from "@/lib/session";
import { formatDateTime, useActivity, useProfiles } from "@/lib/data";
import { Input } from "@/components/ui/input";
import { useAccessRedirect } from "@/components/access-guard";
import { usePermission } from "@/lib/permissions";

export const Route = createFileRoute("/_authenticated/activity/")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { title: "Activiteitenlog — PodiumPlan" },
      { name: "description", content: "Wie wijzigde wat en wanneer, met volledige historie." },
      { property: "og:title", content: "Activiteitenlog — PodiumPlan" },
      { property: "og:description", content: "Volledige audittrail van je werkomgeving." },
    ],
  }),
  component: ActivityPage,
});

function ActivityPage() {
  const user = useCurrentUser();
  const { allowed, isLoading: permLoading } = usePermission("activity.view");
  useAccessRedirect(allowed, permLoading);
  const { data: activity = [] } = useActivity();
  const { data: profiles = [] } = useProfiles();
  const [search, setSearch] = useState("");

  const rows = useMemo(
    () =>
      activity.filter((a) =>
        search ? a.summary.toLowerCase().includes(search.toLowerCase()) : true,
      ),
    [activity, search],
  );

  const nameOf = (uid?: string | null) => profiles.find((p) => p.id === uid)?.name ?? "Onbekend";

  return (
    <AppShell title="Activiteitenlog" subtitle={`${rows.length} gebeurtenissen`} user={user}>
      <div className="panel">
        <div className="border-b p-4">
          <div className="relative max-w-md">
            <Search className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="Zoek in activiteit…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
        <ul className="divide-y">
          {rows.map((a) => (
            <li key={a.id}>
              <Link
                to="/activity/$id"
                params={{ id: a.id }}
                search={{ fromBooking: undefined, tab: undefined }}
                className="block px-5 py-4 hover:bg-muted/50"
              >
                <p className="text-sm">
                  <span className="font-medium">{nameOf(a.user_id)}</span> {a.summary}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {formatDateTime(a.created_at)} · {a.entity_type}
                </p>
              </Link>
            </li>
          ))}
          {rows.length === 0 ? (
            <li className="px-5 py-12 text-center text-sm text-muted-foreground">
              Geen activiteit gevonden.
            </li>
          ) : null}
        </ul>
      </div>
    </AppShell>
  );
}
