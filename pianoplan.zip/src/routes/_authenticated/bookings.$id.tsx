import { usePermission } from "@/lib/permissions";
import { useState, type MouseEvent } from "react";
import { createFileRoute, Link, useNavigate, useRouter, useCanGoBack } from "@tanstack/react-router";
import { ArrowLeft, Copy, FileText, MapPin, Pencil, Plus, Trash2, Users } from "lucide-react";

import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { useCurrentUser } from "@/lib/session";
import { useCanEditBooking, useMyRole, isEditorRole } from "@/lib/roles";
import { useScopedPermission, useTaskAccess } from "@/lib/permissions";
import { bookingDataTabs } from "@/lib/booking-edit-access";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import {
  BOOKING_TABS,
  BOOKING_TAB_LABELS,
  FIELD_TABS,
  FINANCIAL_STATUSES,
  FINANCIAL_STATUS_LABELS,
  PRICING_TAB,
  fieldTab,

  parseArtistStatuses,
  statusesForStage,
  statusOptions,
  useWidgetArtists,
  bookingTime,
  fieldValues,
  formatBookingDate,
  formatDate,
  formatDateTime,
  logActivity,
  mapsUrl,
  parseFields,
  parseRunSheet,

  useActivity,
  useBooking,
  useBookingAssignees,
  useAvatarUrls,

  useProfiles,
  useStandards,
  useTasks,
} from "@/lib/data";
import { BookingStatusPill, TaskStatusBadge } from "@/components/status-badges";
import { sendBookingEmails } from "@/lib/booking-emails.functions";
import { TaskDialog } from "@/components/task-dialog";
import { EditBookingDialog } from "@/components/edit-booking-dialog";
import { MembersDialog } from "@/components/members-dialog";
import { RunSheetPanel } from "@/components/run-sheet";
import { PricingPanel } from "@/components/pricing";
import { TeamAvailability } from "@/components/team-availability";



import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/bookings/$id")({
  head: () => ({
    meta: [
      { title: "Boekingdetail — PodiumPlan" },
      { name: "description", content: "Alle details, taken en activiteit van deze boeking." },
      { property: "og:title", content: "Boekingdetail — PodiumPlan" },
      { property: "og:description", content: "Eventinformatie, locatie en taken." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  validateSearch: (search: Record<string, unknown>) => {
    const tab = search.tab;
    return {
      tab: typeof tab === "string" && BOOKING_TABS.includes(tab) ? tab : "booking",
    };
  },
  component: BookingDetail,
});


function Row({ label, value, isMap }: { label: string; value?: string | null; isMap?: boolean }) {
  return (
    <div className="flex flex-col gap-1 border-b py-3 last:border-0 sm:flex-row sm:gap-4 sm:py-2.5">
      <span className="w-full shrink-0 text-xs text-muted-foreground sm:w-56 sm:text-sm">
        {label}
      </span>
      {isMap && value ? (
        <a
          href={mapsUrl(value)}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-start gap-1.5 py-0.5 text-sm text-primary hover:underline"
        >
          <MapPin className="mt-0.5 h-4 w-4 shrink-0" />
          <span className="break-words">{value}</span>
        </a>
      ) : (
        <span className="text-sm whitespace-pre-line break-words">{value || "—"}</span>
      )}
    </div>
  );
}


function BookingDetail() {
  const { id } = Route.useParams();
  const user = useCurrentUser();
  const queryClient = useQueryClient();
  const { data: booking, isLoading } = useBooking(id);
  const { data: tasks = [] } = useTasks(id);
  const { data: activity = [] } = useActivity(id);
  const { data: team = [] } = useBookingAssignees(id);
  const { data: avatarUrls = {} } = useAvatarUrls(team.map((p) => p.avatar_url));
  const [showAllActivity, setShowAllActivity] = useState(false);
  const { data: profiles = [] } = useProfiles();

  const { data: standards = [] } = useStandards(booking?.artist_id ?? undefined);
  const { data: artists = [] } = useWidgetArtists();
  const { canEdit: rlsCanEdit } = useCanEditBooking(id);
  const { data: role } = useMyRole();
  const { allowed: hasFullAccess } = usePermission("admin.full_access");
  const { tab: initialTab } = Route.useSearch();
  const [taskOpen, setTaskOpen] = useState(false);
  const [editTask, setEditTask] = useState<string | null>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [membersOpen, setMembersOpen] = useState(false);
  const [duplicating, setDuplicating] = useState(false);
  const navigate = useNavigate();
  const router = useRouter();
  const canGoBack = useCanGoBack();

  const [activeTab, setActiveTab] = useState<string>(initialTab);
  const { allowed: canEditBookings } = useScopedPermission("bookings.edit", { bookingId: id });
  const { allowed: canCreateBooking } = useScopedPermission("bookings.create", {
    artistId: booking?.artist_id,
  });
  const canEdit = rlsCanEdit && canEditBookings;
  const { allowed: canViewPricing } = useScopedPermission("pricing.view", { bookingId: id });
  const { allowed: canManageMembers } = useScopedPermission("members.manage", { bookingId: id });
  const { allowed: canSeeBookingActivity } = useScopedPermission("activity.booking.view", {
    bookingId: id,
  });
  const { allowed: canChangeStatus } = useScopedPermission("bookings.status", { bookingId: id });
  const { canCreate: canManageTasks, canEditTask } = useTaskAccess(id);
  const { allowed: canViewFinancialTab } = useScopedPermission("financial.view", { bookingId: id });
  const visibleTabs = bookingDataTabs(canEdit, hasFullAccess, canViewFinancialTab, canViewPricing);
  const currentTab = visibleTabs.includes(activeTab) ? activeTab : "booking";




  if (isLoading || !booking) {
    return (
      <AppShell title="Boeking" user={user}>
        <div className="panel p-10 text-center text-sm text-muted-foreground">Laden…</div>
      </AppShell>
    );
  }

  const values = fieldValues(booking.field_values);
  const standard = standards.find((s) => s.id === booking.standard_id) ?? standards[0];
  const fields = parseFields(standard?.fields);
  const nameOf = (uid?: string | null) => profiles.find((p) => p.id === uid)?.name ?? "Onbekend";
  const time = bookingTime(booking, standard);
  const artistStatuses = statusesForStage(
    parseArtistStatuses(artists.find((a) => a.id === booking.artist_id)?.booking_statuses),
    "edit",
    booking.event_date,
  );
  const statusChoices = statusOptions(artistStatuses);
  const statusValue = booking.artist_status ?? "";
  

  async function changeStatus(value: string) {
    if (!booking || !statusChoices.some((s) => s.value === value)) return;
    const { data: rows, error } = await supabase
      .from("bookings")
      .update({ artist_status: value })
      .eq("id", id)
      .select("id");
    if (error) return toast.error(error.message);
    if (!rows?.length) return toast.error("Je hebt geen recht om deze boeking aan te passen.");
    await logActivity({
      entityType: "booking",
      entityId: id,
      action: "update",
      summary: `wijzigde de status van ${booking.event_name}`,
      changes: [
        { field: "Status", from: booking.artist_status, to: value },
      ],
    });
    queryClient.invalidateQueries();
    sendBookingEmails({ data: { bookingId: id, kind: "status" } }).catch(() => {});
  }

  async function changeFinancialStatus(status: (typeof FINANCIAL_STATUSES)[number]) {
    const { data: rows, error } = await supabase
      .from("bookings")
      .update({ financial_status: status })
      .eq("id", id)
      .select("id");
    if (error) return toast.error(error.message);
    if (!rows?.length) return toast.error("Je hebt geen recht om deze boeking aan te passen.");
    await logActivity({
      entityType: "booking",
      entityId: id,
      action: "update_financial",
      summary: `wijzigde de financiële status van ${booking!.event_name}`,
      changes: [
        {
          field: "Financiële status",
          from: booking!.financial_status ?? null,
          to: status,
        },
      ],
    });
    queryClient.invalidateQueries();
  }

  async function duplicateBooking() {
    if (!booking) return;
    setDuplicating(true);
    const { data: userData } = await supabase.auth.getUser();
    const newName = `${booking.event_name} (kopie)`;
    const { data, error } = await supabase
      .from("bookings")
      .insert({
        artist_id: booking.artist_id,
        standard_id: booking.standard_id,
        event_name: newName,
        event_date: booking.event_date,
        start_time: booking.start_time,
        end_time: booking.end_time,
        artist_status: booking.artist_status,
        financial_status: booking.financial_status,
        contact_name: booking.contact_name,
        contact_phone: booking.contact_phone,
        contact_email: booking.contact_email,
        location_name: booking.location_name,
        address: booking.address,
        postal_code: booking.postal_code,
        city: booking.city,
        field_values: booking.field_values as never,
        run_sheet: booking.run_sheet as never,
        run_sheet_notes: booking.run_sheet_notes,
        created_by: userData.user?.id ?? null,
      })
      .select("id")
      .single();
    setDuplicating(false);
    if (error) return toast.error(error.message);
    await logActivity({
      entityType: "booking",
      entityId: data.id,
      action: "aangemaakt",
      summary: `heeft boeking "${newName}" aangemaakt als kopie van "${booking.event_name}".`,
    });
    queryClient.invalidateQueries();
    toast.success("Boeking gedupliceerd");
    navigate({ to: "/bookings/$id", params: { id: data.id }, search: { tab: "booking" } });
  }

  async function deleteTask(taskId: string, title: string) {

    const { error } = await supabase.from("tasks").delete().eq("id", taskId);
    if (error) return toast.error(error.message);
    await logActivity({
      entityType: "task",
      entityId: id,
      action: "delete",
      summary: `verwijderde taak "${title}"`,
    });
    queryClient.invalidateQueries();
  }

  /** Statuskiezer (of leesbare status) — hergebruikt in header en mobiele actiebalk. */
  const statusControl = (className = "w-40") =>
    (currentTab === "financial" ? canEdit : canChangeStatus) ? (
      currentTab === "financial" ? (
        canEdit ? (
          <Select
            value={booking!.financial_status ?? "factureren"}
            onValueChange={(v) => changeFinancialStatus(v as (typeof FINANCIAL_STATUSES)[number])}
          >
            <SelectTrigger className={className}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {FINANCIAL_STATUSES.map((s) => (
                <SelectItem key={s} value={s}>
                  {FINANCIAL_STATUS_LABELS[s]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        ) : (
          <span className="text-sm text-muted-foreground">
            {FINANCIAL_STATUS_LABELS[booking!.financial_status ?? "factureren"]}
          </span>
        )
      ) : (
        <Select
          value={statusValue || undefined}
          onValueChange={(v) => changeStatus(v)}
        >
          <SelectTrigger className={className}>
            <SelectValue placeholder={statusChoices.length ? "Status" : "Geen statussen"} />
          </SelectTrigger>
          <SelectContent>
            {statusChoices.map((s) => (
              <SelectItem key={s.value} value={s.value}>
                {s.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )
    ) : currentTab === "financial" ? (
      <span className="text-sm text-muted-foreground">
        {FINANCIAL_STATUS_LABELS[booking!.financial_status ?? "factureren"]}
      </span>
    ) : (
      <BookingStatusPill booking={booking!} />
    );

  const actionButtons = (
    <>
      <Button variant="outline" asChild>
        <a href={`/booking-sheet/${id}`} target="_blank" rel="noreferrer">
          <FileText className="mr-1 h-4 w-4" /> Gegevensblad
        </a>
      </Button>
      {canCreateBooking ? (
        <Button variant="outline" onClick={duplicateBooking} disabled={duplicating}>
          <Copy className="mr-1 h-4 w-4" /> {duplicating ? "Dupliceren…" : "Dupliceren"}
        </Button>
      ) : null}

    </>
  );

  // Terug naar exact de vorige pagina (incl. tabblad/filters) als die in de app ligt.
  const goBack = (e: MouseEvent) => {
    if (canGoBack) {
      e.preventDefault();
      router.history.back();
    }
  };

  return (
    <AppShell
      title={booking.event_name}
      subtitle={`${booking.artists?.name ?? ""} · ${formatBookingDate(booking.event_date)}${
        time.label ? ` · ${time.label}` : ""
      }`}
      user={user}
      actions={
        <div className="hidden items-center gap-2 md:flex">
          {statusControl()}
          {actionButtons}
        </div>
      }
    >
      {currentTab === "financial" ? (
        <Link
          to="/financial"
          search={{ status: undefined }}
          onClick={goBack}
          className="mb-4 inline-flex items-center gap-2 py-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Terug naar financieel
        </Link>
      ) : (
        <Link
          to="/bookings"
          onClick={goBack}
          className="mb-4 inline-flex items-center gap-2 py-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Terug naar boekingen
        </Link>
      )}

      {/* Mobiele actiebalk: statuskiezer en knoppen passen niet in de smalle header. */}
      <div className="mb-4 space-y-2 md:hidden">
        <div className="[&>button]:w-full [&>span]:inline-flex">{statusControl("w-full")}</div>
        <div className="grid grid-cols-2 gap-2 [&_a]:w-full [&_button]:w-full">{actionButtons}</div>
      </div>


      <div className="grid min-w-0 gap-5 xl:grid-cols-3">
        <div className="min-w-0 space-y-5 xl:col-span-2">
          {fields.length ? (
            <section className="panel">
              <div className="flex min-h-8 items-center justify-between gap-3 border-b px-5 py-4">
                <h2 className="text-sm font-semibold break-words">Optreden ({standard?.name})</h2>
                {canEdit ? (
                  <Button variant="outline" size="sm" className="h-8 shrink-0" onClick={() => setEditOpen(true)}>
                    <Pencil className="mr-1 h-4 w-4" /> Aanpassen
                  </Button>
                ) : null}
              </div>
              <Tabs value={currentTab} onValueChange={setActiveTab} className="p-4 sm:p-5">
                {visibleTabs.length > 1 ? (
                  <div className="max-w-full overflow-x-auto">
                    {/* Mobiel: tabbladen vullen samen de volle breedte, elke kolom evenredig
                        met de lengte van zijn naam, zodat er niet zijwaarts geschoven wordt. */}
                    <TabsList
                      className="grid w-full sm:flex sm:w-max"
                      style={{
                        gridTemplateColumns: visibleTabs
                          .map((t) => `${BOOKING_TAB_LABELS[t].length}fr`)
                          .join(" "),
                      }}
                    >
                      {visibleTabs.map((t) => (
                        <TabsTrigger
                          key={t}
                          value={t}
                          className="min-w-0 px-1 text-xs sm:px-3 sm:text-sm"
                        >
                          {BOOKING_TAB_LABELS[t]}
                        </TabsTrigger>
                      ))}
                    </TabsList>
                  </div>
                ) : null}


                {visibleTabs.map((t) => {
                  const tabFields = fields.filter((f) => fieldTab(f) === t);
                  return (
                    <TabsContent key={t} value={t} className="mt-4 space-y-5">
                      {t === PRICING_TAB ? (
                        <PricingPanel fields={fields} values={values} />
                      ) : tabFields.length === 0 ? (
                        <p className="text-sm text-muted-foreground">
                          Nog geen gegevens in dit tabblad.
                        </p>
                      ) : (


                        Array.from(
                          new Set(tabFields.map((f) => f.section ?? "Extra velden")),
                        ).map((section) => (
                          <div key={section}>
                            <h3 className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                              {section}
                            </h3>
                            <div className="mt-2">
                              {tabFields
                                .filter((f) => (f.section ?? "Extra velden") === section)
                                .map((f) => (
                                  <Row
                                    key={f.id}
                                    label={f.label}
                                    isMap={f.type === "map"}

                                    value={
                                      f.type === "currency" && values[f.id]
                                        ? `€ ${values[f.id]}`
                                        : f.type === "date" || f.type === "datetime"
                                          ? formatBookingDate(values[f.id])
                                          : values[f.id]
                                    }
                                  />
                                ))}
                            </div>
                          </div>
                        ))
                      )}
                    </TabsContent>
                  );
                })}
              </Tabs>
            </section>
          ) : null}
        </div>

        <div className="min-w-0 space-y-5">
          <section className="panel">
            <div className="flex min-h-8 items-center justify-between gap-3 border-b px-5 py-4">
              <h2 className="text-sm font-semibold">Taken</h2>
              {canManageTasks ? (
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 shrink-0"
                  onClick={() => {
                    setEditTask(null);
                    setTaskOpen(true);
                  }}
                >
                  <Plus className="mr-1 h-4 w-4" /> Nieuw
                </Button>
              ) : null}
            </div>
            <ul className="divide-y">
              {tasks.map((t) => (
                <li key={t.id} className="group px-4 py-4 sm:px-5 sm:py-3">
                  <div className="flex items-start justify-between gap-3">
                    <button
                      className="min-w-0 flex-1 text-left"
                      onClick={() => {
                        setEditTask(t.id);
                        setTaskOpen(true);
                      }}
                    >
                      <p className="text-sm font-medium break-words sm:truncate">{t.title}</p>
                      <p className="mt-1 text-xs text-muted-foreground">
                        {t.assigned_to ? nameOf(t.assigned_to) : "Niet toegewezen"} · deadline{" "}
                        {formatDate(t.deadline)}
                      </p>
                    </button>
                    <div className="flex shrink-0 items-center gap-2">
                      <div className="flex flex-col items-end gap-1">
                        <TaskStatusBadge status={t.status} />
                      </div>
                      {canEditTask(t) ? (
                        <button
                          onClick={() => deleteTask(t.id, t.title)}
                          className="p-1 text-muted-foreground transition-opacity hover:text-destructive md:opacity-0 md:group-hover:opacity-100"
                          aria-label="Taak verwijderen"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      ) : null}
                    </div>
                  </div>
                </li>

              ))}
              {tasks.length === 0 ? (
                <li className="px-5 py-10 text-center text-sm text-muted-foreground">
                  Nog geen taken.
                </li>
              ) : null}
            </ul>
          </section>

          {standard?.run_sheet_enabled ? (
            <RunSheetPanel
              bookingId={id}
              bookingName={booking.event_name}
              runSheet={parseRunSheet(booking.run_sheet)}
              canEdit={canEdit}
              values={values}
              fields={fields}
            />
          ) : null}


          <section className="panel">
            <div className="flex min-h-8 items-center justify-between gap-3 border-b px-5 py-4">
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-semibold">Teamleden</h2>
                <span className="text-xs text-muted-foreground">{team.length}</span>
              </div>
              {canManageMembers && rlsCanEdit ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setMembersOpen(true)}
                  className="h-8 shrink-0"
                >
                  <Users className="mr-1 h-4 w-4" /> Uitnodigen
                </Button>
              ) : null}
            </div>
            <ul className="divide-y">
              {team.map((p) => (
                <li key={p.id} className="flex items-center gap-3 px-4 py-4 sm:px-5 sm:py-3">
                  <span className="flex h-10 w-10 shrink-0 sm:h-8 sm:w-8 items-center justify-center overflow-hidden rounded-full bg-muted text-xs font-medium text-muted-foreground">
                    {p.avatar_url && avatarUrls[p.avatar_url] ? (
                      <img
                        src={avatarUrls[p.avatar_url]}
                        alt={p.name || p.email}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      (p.name || p.email || "?").slice(0, 1).toUpperCase()
                    )}
                  </span>
                  <span className="min-w-0">
                    <p className="flex items-center gap-2">
                      <span className="truncate text-sm font-medium">{p.name || p.email}</span>
                      {p.invite_status === "pending" ? (
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                          Uitgenodigd
                        </Badge>
                      ) : null}
                    </p>
                    {p.job_title ? (
                      <p className="truncate text-xs font-medium text-primary">{p.job_title}</p>
                    ) : null}
                  </span>
                  <TeamAvailability artistId={booking.artist_id} bookingId={id} userId={p.id} isSelf={p.id === user?.id} />
                </li>
              ))}
              {team.length === 0 ? (
                <li className="px-5 py-10 text-center text-sm text-muted-foreground">
                  Nog geen teamleden.
                </li>
              ) : null}
            </ul>
          </section>

          {canSeeBookingActivity ? (
          <section className="panel">
            <div className="flex min-h-8 items-center justify-between gap-3 border-b px-5 py-4">
              <h2 className="min-h-8 text-sm font-semibold">Activiteit</h2>
            </div>
            <ul className="divide-y">
              {activity.slice(0, showAllActivity ? undefined : 5).map((a) => (
                <li key={a.id}>
                  <Link
                    to="/activity/$id"
                    params={{ id: a.id }}
                    search={{ fromBooking: id, tab: currentTab }}
                    className="block px-4 py-4 hover:bg-muted/50 sm:px-5 sm:py-3"
                  >
                    <p className="text-sm">
                      <span className="font-medium">{nameOf(a.user_id)}</span> {a.summary}
                    </p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {formatDateTime(a.created_at)}
                    </p>
                  </Link>
                </li>
              ))}
              {activity.length === 0 ? (
                <li className="px-5 py-10 text-center text-sm text-muted-foreground">
                  Nog geen activiteit.
                </li>
              ) : null}
            </ul>
            {activity.length > 5 ? (
              <div className="border-t px-5 py-3">
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full"
                  onClick={() => setShowAllActivity((v) => !v)}
                >
                  {showAllActivity
                    ? "Minder weergeven"
                    : `Alle ${activity.length} activiteiten weergeven`}
                </Button>
              </div>
            ) : null}
          </section>
          ) : null}

        </div>
      </div>

      <TaskDialog
        open={taskOpen}
        onOpenChange={setTaskOpen}
        defaultBookingId={id}
        task={tasks.find((t) => t.id === editTask) ?? null}
      />

      <EditBookingDialog
        booking={booking}
        open={editOpen}
        onOpenChange={setEditOpen}
        defaultTab={activeTab}
      />

      <MembersDialog
        scope="booking"
        id={id}
        artistId={booking.artist_id}
        title={booking.event_name}
        open={membersOpen}
        onOpenChange={setMembersOpen}
      />

    </AppShell>
  );
}
