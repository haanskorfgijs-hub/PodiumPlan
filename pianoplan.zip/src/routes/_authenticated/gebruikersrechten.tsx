import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { Fragment, useEffect, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useCurrentUser } from "@/lib/session";
import { useAccessRedirect } from "@/components/access-guard";
import { ROLES, useRoleLabels, useSetRoleLabel, type AppRole } from "@/lib/roles";
import { Input } from "@/components/ui/input";
import {
  PERMISSIONS,
  roleHasPermission,
  useRolePermissions,
  useSetRolePermission,
  usePermission,
} from "@/lib/permissions";

export const Route = createFileRoute("/_authenticated/gebruikersrechten")({
  head: () => ({
    meta: [
      { title: "Accountsrechten — PodiumPlan" },
      { name: "description", content: "Bepaal per type account welke rechten gelden." },
      { property: "og:title", content: "Accountsrechten — PodiumPlan" },
      { property: "og:description", content: "Vink per type account aan wat wel en niet mag." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: PermissionsPage,
});

function PermissionsPage() {
  const user = useCurrentUser();
  const { allowed: isAdmin, isLoading } = usePermission("users.manage");
  useAccessRedirect(isAdmin, isLoading);
  const { data: rows = [] } = useRolePermissions();
  const setPermission = useSetRolePermission();
  const roleLabels = useRoleLabels();

  return (
    <AppShell
      title="Accountsrechten"
      subtitle="Bepaal per type account welke rechten gelden"
      user={user}
      actions={
        <Button variant="outline" asChild>
          <Link to="/users">
            <ArrowLeft className="mr-1 h-4 w-4" /> Gebruikersbeheer
          </Link>
        </Button>
      }
    >
      {isLoading ? (
        <p className="text-sm text-muted-foreground">Laden…</p>
      ) : !isAdmin ? (
        <div className="rounded-xl border p-6">
          <h2 className="text-base font-semibold">Geen toegang</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Alleen een beheerder kan gebruikersrechten aanpassen.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-medium">Recht</th>
                {ROLES.map((r) => (
                  <th key={r} className="w-36 px-2 py-3 text-center font-medium">
                    <RoleNameInput role={r} label={roleLabels[r]} />
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {PERMISSIONS.map((p, i) => {
                const prevCategory = i > 0 ? PERMISSIONS[i - 1].category : null;
                const showCategory = i === 0 || p.category !== prevCategory;
                const colCount = 1 + ROLES.length;
                return (
                  <Fragment key={p.key}>
                    {showCategory && (
                      <tr className="border-t bg-muted/40">
                        <td
                          colSpan={colCount}
                          className="px-4 py-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground"
                        >
                          {p.category}
                        </td>
                      </tr>
                    )}
                    <tr className="border-t">
                      <td className="px-4 py-3">
                        <span className="block font-medium">{p.label}</span>
                        <span className="text-xs text-muted-foreground">{p.hint}</span>
                      </td>
                      {ROLES.map((r) => (
                        <td key={r} className="px-4 py-3 text-center">
                          <Checkbox
                            aria-label={`${p.label} voor ${roleLabels[r]}`}
                            checked={roleHasPermission(rows, r, p.key)}
                            onCheckedChange={(v) =>
                              setPermission.mutate(
                                { role: r, permission: p.key, allowed: v === true },
                                {
                                  onError: () => toast.error("Recht wijzigen mislukt."),
                                },
                              )
                            }
                          />
                        </td>
                      ))}
                    </tr>
                  </Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      <p className="mt-4 text-sm text-muted-foreground">
         Wijzigingen gelden direct.
      </p>
    </AppShell>
  );
}

function RoleNameInput({ role, label }: { role: AppRole; label: string }) {
  const [value, setValue] = useState(label);
  const save = useSetRoleLabel();
  useEffect(() => setValue(label), [label]);
  function commit() {
    const v = value.trim();
    if (!v || v.length > 40) {
      setValue(label);
      toast.error("Naam moet 1 tot 40 tekens zijn.");
      return;
    }
    if (v === label) return;
    save.mutate(
      { role, label: v },
      {
        onSuccess: () => toast.success("Naam opgeslagen."),
        onError: () => {
          setValue(label);
          toast.error("Naam opslaan mislukt.");
        },
      },
    );
  }
  return (
    <Input
      aria-label={`Naam van accounttype ${label}`}
      value={value}
      maxLength={40}
      onChange={(e) => setValue(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === "Enter") (e.target as HTMLInputElement).blur();
      }}
      className="h-8 text-center text-xs font-medium normal-case"
    />
  );
}
