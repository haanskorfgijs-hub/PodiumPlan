import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { Check, HelpCircle, MailQuestion, X } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { useCurrentUser } from "@/lib/session";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useIncomingContactRequests, useInvitations, useRespondInvitation } from "@/lib/invitations";
import { MEMBER_ROLE_LABELS } from "@/components/members-dialog";

export const Route = createFileRoute("/_authenticated/invitations")({
  head: () => ({
    meta: [
      { title: "Uitnodigingen — PodiumPlan" },
      {
        name: "description",
        content: "Bekijk en beantwoord uitnodigingen voor boekingen en artiesten.",
      },
      { property: "og:title", content: "Uitnodigingen — PodiumPlan" },
      { property: "og:description", content: "Accepteer of weiger uitnodigingen voor boekingen." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: InvitationsPage,
});

function InvitationsPage() {
  const user = useCurrentUser();
  const qc = useQueryClient();
  const { data: invitations = [], isLoading } = useInvitations();
  const { data: contactRequests = [], isLoading: loadingContacts } = useIncomingContactRequests();
  const respond = useRespondInvitation();

  async function respondContact(id: string, accept: boolean) {
    const { error } = await supabase.rpc("respond_contact_request", { _id: id, _accept: accept });
    if (error) return toast.error(error.message);
    toast.success(accept ? "Contact toegevoegd" : "Verzoek afgewezen");
    qc.invalidateQueries({ queryKey: ["contacts"] });
    qc.invalidateQueries({ queryKey: ["invitable-users"] });
  }

  async function handle(
    id: string,
    scope: "artist" | "booking",
    accept: boolean,
    availability?: "available" | "tentative" | "unavailable",
  ) {
    try {
      await respond.mutateAsync({ id, scope, accept, availability });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Er ging iets mis.");
    }
  }

  return (
    <AppShell
      title="Uitnodigingen"
      subtitle="Uitnodigingen voor boekingen, artiesten en contacten"
      user={user}
    >
      <div className="divide-y rounded-xl border bg-card">
        {contactRequests.map((c) => (
          <div
            key={c.id}
            className="flex flex-col gap-3 px-4 py-4 sm:flex-row sm:items-center sm:justify-between"
          >
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <p className="truncate font-medium">{c.name || c.email}</p>
                <Badge variant="secondary">Contactverzoek</Badge>
              </div>
              <p className="truncate text-sm text-muted-foreground">{c.email}</p>
            </div>
            <div className="flex shrink-0 gap-2">
              <Button size="sm" onClick={() => respondContact(c.id, true)}>
                <Check className="mr-1 h-4 w-4" /> Accepteren
              </Button>
              <Button size="sm" variant="outline" onClick={() => respondContact(c.id, false)}>
                <X className="mr-1 h-4 w-4" /> Afwijzen
              </Button>
            </div>
          </div>
        ))}
        {invitations.map((inv) => (
          <div
            key={inv.id}
            className="flex flex-col gap-3 px-4 py-4 sm:flex-row sm:items-center sm:justify-between"
          >
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <p className="truncate font-medium">{inv.title || "Zonder naam"}</p>
                <Badge variant="secondary">
                  {inv.scope === "artist" ? "Artiestbeheer" : "Boeking"}
                </Badge>
              </div>
              <p className="truncate text-sm text-muted-foreground">
                {inv.scope === "artist" ? "Beheer volgens je accounttype" : [inv.subtitle, MEMBER_ROLE_LABELS[inv.role]].filter(Boolean).join(" · ")}
              </p>
            </div>
            <div className="flex shrink-0 gap-2">
              <Button
                size="sm"
                onClick={() => handle(inv.id, inv.scope, true)}
                disabled={respond.isPending}
              >
                <Check className="mr-1 h-4 w-4" /> Accepteren
              </Button>
              {inv.scope === "booking" ? (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handle(inv.id, inv.scope, true, "tentative")}
                  disabled={respond.isPending}
                >
                  <HelpCircle className="mr-1 h-4 w-4" /> Misschien
                </Button>
              ) : null}
              <Button
                size="sm"
                variant="outline"
                onClick={() => handle(inv.id, inv.scope, false)}
                disabled={respond.isPending}
              >
                <X className="mr-1 h-4 w-4" /> Weigeren
              </Button>
            </div>
          </div>
        ))}
        {!isLoading && !loadingContacts && invitations.length === 0 && contactRequests.length === 0 ? (
          <div className="flex flex-col items-center gap-2 px-4 py-16 text-center">
            <MailQuestion className="h-8 w-8 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">Je hebt geen openstaande uitnodigingen.</p>
          </div>
        ) : null}
      </div>
    </AppShell>
  );
}
