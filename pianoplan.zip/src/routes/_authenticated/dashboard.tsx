import { useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { TaskDialog } from "@/components/task-dialog";
import { AppShell } from "@/components/app-shell";
import { useCurrentUser } from "@/lib/session";
import { usePersistentState } from "@/lib/use-persistent-state";
import { useColumnOrder } from "@/lib/column-order";
import { FilePlus2, ListChecks, MapPin, Receipt, Send } from "lucide-react";
import { usePermission } from "@/lib/permissions";
import {
  matchesDashboardStatus,
  useDashboardStatusFilter,
} from "@/lib/dashboard-status-filter";

import {
  bookingDateTimeKey,
  bookingLocation,
  fieldTab,
  fieldValues,
  formatBookingDate,
  formatDate,
  formatDateTime,
  mapsUrl,
  parseFields,
  timeRangeStart,
  useActivity,
  useBookings,
  useProfiles,
  useStandardMap,
  useTasks,
  type TaskWithBooking,
} from "@/lib/data";
import { BookingStatusPill, StatusStripeCell, TaskStatusBadge } from "@/components/status-badges";
import { MobileBookingRow } from "@/components/mobile-booking-row";
import { MonthDivider, monthKey } from "@/components/month-divider";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { title: "Dashboard — PodiumPlan" },
      {
        name: "description",
        content: "Overzicht van boekingen deze maand, openstaande taken en recente activiteit.",
      },
      { property: "og:title", content: "Dashboard — PodiumPlan" },
      { property: "og:description", content: "Boekingen, taken en activiteit in één oogopslag." },
    ],
  }),
  component: Dashboard,
});

type BookingRow = NonNullable<ReturnType<typeof useBookings>["data"]>[number];

type CellArgs = { booking: BookingRow; presenceStart: string; playStart: string; location: string };

const COLUMNS: {
  key: string;
  label: string;
  className: string;
  cellClassName: string;
  render: (args: CellArgs) => React.ReactNode;
}[] = [
  {
    key: "date",
    label: "Datum",
    className: "w-[11%] min-w-[6.5rem]",
    cellClassName: "text-sm whitespace-nowrap",
    render: ({ booking }) => formatBookingDate(booking.event_date),
  },
  {
    key: "presence",
    label: "Tijd aanwezig",
    className: "w-[10%] min-w-[5.5rem]",
    cellClassName: "text-sm whitespace-nowrap tabular-nums text-muted-foreground",
    render: ({ presenceStart }) => presenceStart || "—",
  },
  {
    key: "play",
    label: "Begintijd",
    className: "w-[9%] min-w-[5rem]",
    cellClassName: "text-sm whitespace-nowrap tabular-nums text-muted-foreground",
    render: ({ playStart }) => playStart || "—",
  },
  {
    key: "event",
    label: "Evenementnaam",
    className: "w-[20%] min-w-[8rem]",
    cellClassName: "truncate text-sm font-medium",
    render: ({ booking }) => booking.event_name,
  },
  {
    key: "location",
    label: "Locatie",
    className: "w-[18%] min-w-[8rem]",
    cellClassName: "truncate text-sm",
    render: ({ location }) =>
      location ? (
        <a
          href={mapsUrl(location)}
          target="_blank"
          rel="noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="inline-flex max-w-full items-center gap-1 text-primary hover:underline"
        >
          <MapPin className="h-3.5 w-3.5 shrink-0" />
          <span className="truncate">{location}</span>
        </a>
      ) : (
        <span className="text-muted-foreground">—</span>
      ),
  },
  {
    key: "artist",
    label: "Artiest",
    className: "w-[13%] min-w-[6.5rem]",
    cellClassName: "truncate text-sm text-muted-foreground",
    render: ({ booking }) => booking.artists?.name,
  },
  {
    key: "status",
    label: "Status",
    className: "w-[20%] min-w-[8rem] text-right",
    cellClassName: "text-right whitespace-nowrap",
    render: ({ booking }) => <BookingStatusPill booking={booking} />,
  },
];

type TimeRange = "this-month" | "3m" | "6m" | "12m";

const RANGE_OPTIONS: { value: TimeRange; label: string }[] = [
  { value: "this-month", label: "Deze maand" },
  { value: "3m", label: "Komende 3 maanden" },
  { value: "6m", label: "Komende 6 maanden" },
  { value: "12m", label: "Komende 12 maanden" },
];

function Dashboard() {
  const user = useCurrentUser();
  const navigate = useNavigate();
  const { allowed: canSeeFinancial } = usePermission("financial.view");
  const { allowed: canSeeDashboardActivity } = usePermission("activity.dashboard.view");
  
  const { data: bookings = [] } = useBookings();
  const { data: tasks = [] } = useTasks();
  const { data: activity = [] } = useActivity();
  const { data: profiles = [] } = useProfiles();
  const standardMap = useStandardMap();
  const [taskOpen, setTaskOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState<TaskWithBooking | null>(null);
  const { order, dragProps } = useColumnOrder(
    "podiumplan:columns:dashboard",
    COLUMNS.map((c) => c.key),
  );
  const orderedColumns = useMemo(
    () => order.map((key: string) => COLUMNS.find((c) => c.key === key)!).filter(Boolean),
    [order],
  );
  const [timeRange, setTimeRange] = usePersistentState<TimeRange>(
    `podiumplan:dashboard-time-range:${user.id}`,
    "3m",
  );
  const { statuses: dashboardStatuses } = useDashboardStatusFilter(user.id);


  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const rangeEnd = useMemo(() => {
    const d = new Date(today);
    if (timeRange === "this-month") {
      d.setMonth(d.getMonth() + 1, 0);
      d.setHours(23, 59, 59, 999);
    } else {
      const months = timeRange === "3m" ? 3 : timeRange === "6m" ? 6 : 12;
      d.setMonth(d.getMonth() + months);
    }
    return d;
  }, [today, timeRange]);

  const enriched = useMemo<CellArgs[]>(() => {
    return bookings.map((b) => {
      const standard = b.standard_id ? standardMap.get(b.standard_id) : undefined;
      const values = fieldValues(b.field_values);
      const fields = standard ? parseFields(standard.fields) : [];
      const presenceField = fields.find((f) => f.label === "Tijden aanwezig" && f.type === "time");
      const playField = fields.find((f) => f.label === "Speeltijden" && f.type === "time");
      return {
        booking: b,
        presenceStart: timeRangeStart(values[presenceField?.id ?? "base_times_present"]),
        playStart: timeRangeStart(values[playField?.id ?? "base_play_times"]),
        location: bookingLocation(b, standard),
      };
    });
  }, [bookings, standardMap]);

  const upcomingBookings = useMemo(() => {
    return enriched
      .filter(({ booking: b }) => {
        const d = new Date(b.event_date);
        d.setHours(0, 0, 0, 0);
        return (
          d.getTime() >= today.getTime() &&
          d.getTime() <= rangeEnd.getTime() &&
          matchesDashboardStatus(b, dashboardStatuses)
        );
      })
      .sort(
        (a, b) =>
          bookingDateTimeKey(a.booking.event_date, a.presenceStart).localeCompare(
            bookingDateTimeKey(b.booking.event_date, b.presenceStart),
          ),
      );
  }, [enriched, today, rangeEnd, dashboardStatuses]);

  const openTasks = useMemo(() => {
    const sortKey = (t: TaskWithBooking): [number, string] => {
      let group: number;
      let date: string;
      if (t.assigned_to === user.id) {
        group = 0;
        date = t.deadline ?? t.bookings?.event_date ?? "9999-12-31";
      } else if (!t.assigned_to) {
        if (t.deadline) {
          group = 1;
          date = t.deadline;
        } else {
          group = 2;
          date = t.bookings?.event_date ?? "9999-12-31";
        }
      } else {
        group = 3;
        date = t.deadline ?? t.bookings?.event_date ?? "9999-12-31";
      }
      return [group, date];
    };
    return [...tasks]
      .filter((t) => t.status !== "afgerond")
      .sort((a, b) => {
        const [ga, da] = sortKey(a);
        const [gb, db] = sortKey(b);
        if (ga !== gb) return ga - gb;
        return da.localeCompare(db);
      })
      .slice(0, 8);
  }, [tasks, user.id]);


  const nameOf = (id?: string | null) =>
    profiles.find((p) => p.id === id)?.name || (id ? "Onbekend" : "—");

  const toInvoice = bookings.filter((b) => (b.financial_status ?? "nog_spelen") === "factureren");
  const openInvoices = bookings.filter((b) => b.financial_status === "gefactureerd");
  const openAndToInvoice = bookings.filter(
    (b) => b.financial_status === "factureren" || b.financial_status === "gefactureerd",
  );

  const openInvoiceCount = useMemo(() => {
    const numbers = new Set<string>();
    bookings.forEach((b) => {
      if (b.financial_status !== "gefactureerd") return;
      const standard = b.standard_id ? standardMap.get(b.standard_id) : undefined;
      const fields = parseFields(standard?.fields).filter((f) => fieldTab(f) === "financial");
      const values = fieldValues(b.field_values);
      for (const f of fields) {
        const raw = values[f.id] ?? "";
        if (!raw) continue;
        if (/factuurnummer|factuur nr|factuurnr/i.test(f.label)) {
          const trimmed = String(raw).trim();
          if (trimmed) numbers.add(trimmed);
          break;
        }
      }
    });
    return numbers.size;
  }, [bookings, standardMap]);

  return (
    <AppShell
      title="Dashboard"
      subtitle={`Welkom terug${user.name ? `, ${user.name}` : ""}`}
      user={user}
    >
      {canSeeFinancial ? (
        <section className="panel mb-5">
          <div className="border-b px-5 py-4">
            <h2 className="text-sm font-semibold">Financieel</h2>
          </div>
          <div className="grid grid-cols-2 gap-4 p-4 xl:grid-cols-4">
            <button
              type="button"
              onClick={() => navigate({ to: "/financial", search: { tab: "bookings", status: "factureren" } })}
              className="rounded-lg border p-4 text-left transition-colors hover:bg-muted/50"
            >
              <div className="flex items-start justify-between gap-3">
                <p className="text-2xl font-semibold tabular-nums">{toInvoice.length}</p>
                <FilePlus2 className="h-5 w-5 shrink-0 text-muted-foreground" />
              </div>
              <p className="mt-2 text-xs text-primary">Te factureren boekingen</p>
            </button>
            <button
              type="button"
              onClick={() => navigate({ to: "/financial", search: { tab: "bookings", status: "gefactureerd" } })}
              className="rounded-lg border p-4 text-left transition-colors hover:bg-muted/50"
            >
              <div className="flex items-start justify-between gap-3">
                <p className="text-2xl font-semibold tabular-nums">{openInvoices.length}</p>
                <Send className="h-5 w-5 shrink-0 text-muted-foreground" />
              </div>
              <p className="mt-2 text-xs text-primary">Openstaande boekingen</p>
            </button>
            <button
              type="button"
              onClick={() => navigate({ to: "/financial", search: { tab: "bookings", status: "gefactureerd,factureren" } })}
              className="rounded-lg border p-4 text-left transition-colors hover:bg-muted/50"
            >
              <div className="flex items-start justify-between gap-3">
                <p className="text-2xl font-semibold tabular-nums">{openAndToInvoice.length}</p>
                <ListChecks className="h-5 w-5 shrink-0 text-muted-foreground" />
              </div>
              <p className="mt-2 text-xs text-primary">Openstaande &amp; te factureren boekingen</p>
            </button>
            <button
              type="button"
              onClick={() => navigate({ to: "/financial", search: { tab: "invoices", status: "gefactureerd" } })}
              className="rounded-lg border p-4 text-left transition-colors hover:bg-muted/50"
            >
              <div className="flex items-start justify-between gap-3">
                <p className="text-2xl font-semibold tabular-nums">{openInvoiceCount}</p>
                <Receipt className="h-5 w-5 shrink-0 text-muted-foreground" />
              </div>
              <p className="mt-2 text-xs text-primary">Openstaande facturen</p>
            </button>
          </div>
        </section>
      ) : null}

      <div className="grid gap-5 xl:grid-cols-3">
        <section className="panel flex flex-col xl:col-span-2">
          <div className="flex flex-col gap-2 border-b px-5 py-4 md:flex-row md:flex-wrap md:items-center md:justify-between md:gap-3">
            <h2 className="min-w-0 truncate text-sm font-semibold">Aankomende boekingen</h2>
            <div className="flex shrink-0 items-center gap-3">
              <Select value={timeRange} onValueChange={(v) => setTimeRange(v as TimeRange)}>
                <SelectTrigger className="h-8 w-auto min-w-[9rem] text-xs sm:min-w-[11rem]">
                  <SelectValue placeholder="Periode" />
                </SelectTrigger>
                <SelectContent>
                  {RANGE_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value} className="text-xs">
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <span className="text-xs text-muted-foreground">{upcomingBookings.length} boekingen</span>
            </div>
          </div>

          <div className="hidden min-h-[max(16rem,calc(100dvh-25rem))] overflow-x-auto overflow-y-auto md:block md:h-0 md:flex-1">
            <Table className="min-w-[56rem] table-fixed [&_td]:py-4">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-1.5 p-0" />
                  {orderedColumns.map((col) => (
                    <TableHead
                      key={col.key}
                      {...dragProps(col.key)}
                      title="Versleep om de kolomvolgorde te wijzigen"
                      className={`${col.className} align-middle select-none cursor-grab data-[dragging=true]:opacity-50`}
                    >
                      <span
                      className={`inline-flex w-full items-center gap-1 truncate whitespace-nowrap ${col.className.includes("text-right") ? "justify-end" : ""}`}
                      >
                        {col.label}
                      </span>
                    </TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {upcomingBookings.map(({ booking: b, presenceStart, playStart, location }) => (
                  <TableRow
                    key={b.id}
                    className="cursor-pointer hover:bg-muted/50"
                    onClick={() => navigate({ to: "/bookings/$id", params: { id: b.id }, search: { tab: "booking" } })}
                  >
                    <StatusStripeCell booking={b} />
                    {orderedColumns.map((col) => (
                      <TableCell key={col.key} className={`${col.cellClassName} align-middle`}>
                        {col.render({ booking: b, presenceStart, playStart, location })}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
                {upcomingBookings.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="py-10 text-center text-sm text-muted-foreground">
                      Geen aankomende boekingen.
                    </TableCell>
                  </TableRow>
                ) : null}
              </TableBody>
            </Table>
          </div>

          {/* Mobiele kaartweergave: geen horizontaal scrollen, ruime tikvlakken. */}
          <ul className="divide-y md:hidden">
            {upcomingBookings.map(({ booking: b, presenceStart, playStart, location }, i) => {
              const showMonth =
                i === 0 || monthKey(b.event_date) !== monthKey(upcomingBookings[i - 1]!.booking.event_date);
              return (
                <li key={b.id}>
                  {showMonth ? <MonthDivider date={b.event_date} /> : null}
                  <MobileBookingRow booking={b} presenceTime={presenceStart} playTime={playStart} location={location} />
                </li>
              );
            })}

            {upcomingBookings.length === 0 ? (
              <li className="px-4 py-10 text-center text-sm text-muted-foreground">
                Geen aankomende boekingen.
              </li>
            ) : null}
          </ul>
        </section>

        <div className="space-y-5">
          <section className="panel">
            <div className="border-b px-5 py-4">
              <h2 className="text-sm font-semibold">Openstaande taken</h2>
            </div>
            <ul className="divide-y">
              {openTasks.map((t) => (
                <li key={t.id}>
                  <button
                    type="button"
                    onClick={() => {
                      setCurrentTask(t);
                      setTaskOpen(true);
                    }}
                    className="w-full px-4 py-4 text-left transition-colors hover:bg-muted/50 sm:px-5 sm:py-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium">{t.title}</p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          {nameOf(t.assigned_to)} · deadline {formatDate(t.deadline)}
                        </p>
                      </div>
                      <div className="flex shrink-0 flex-col items-end gap-1">
                        <TaskStatusBadge status={t.status} />
                      </div>
                    </div>
                  </button>
                </li>
              ))}
              {openTasks.length === 0 ? (
                <li className="px-5 py-10 text-center text-sm text-muted-foreground">
                  Geen openstaande taken.
                </li>
              ) : null}
            </ul>
          </section>

          {canSeeDashboardActivity ? (
          <section className="panel">
            <div className="border-b px-5 py-4">
              <h2 className="text-sm font-semibold">Recente activiteit</h2>
            </div>
            <ul className="divide-y">
              {activity.slice(0, 8).map((a) => (
                <li key={a.id}>
                  <Link
                    to="/activity/$id"
                    params={{ id: a.id }}
                    search={{ fromBooking: undefined, tab: undefined }}
                    className="block px-4 py-4 hover:bg-muted/50 sm:px-5 sm:py-3"
                  >
                    <p className="text-sm">
                      <span className="font-medium">{nameOf(a.user_id)}</span> {a.summary}
                    </p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {formatDateTime(a.created_at)}
                    </p>
                  </Link>
                </li>
              ))}
              {activity.length === 0 ? (
                <li className="px-5 py-10 text-center text-sm text-muted-foreground">
                  Nog geen activiteit.
                </li>
              ) : null}
            </ul>
          </section>
          ) : null}
        </div>
      </div>

      <TaskDialog open={taskOpen} onOpenChange={setTaskOpen} task={currentTask} />
    </AppShell>
  );
}
