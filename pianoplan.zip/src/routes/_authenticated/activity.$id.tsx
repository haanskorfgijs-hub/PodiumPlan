import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { useCurrentUser } from "@/lib/session";
import { formatDateTime, useActivityItem, useProfiles } from "@/lib/data";

export const Route = createFileRoute("/_authenticated/activity/$id")({
  validateSearch: (search: Record<string, unknown>) => ({
    fromBooking: typeof search.fromBooking === "string" ? search.fromBooking : undefined,
    tab: typeof search.tab === "string" ? search.tab : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Activiteitdetail — PodiumPlan" },
      { name: "description", content: "Exacte wijzigingen van deze gebeurtenis." },
      { property: "og:title", content: "Activiteitdetail — PodiumPlan" },
      { property: "og:description", content: "Van- en naar-waarden per gewijzigd veld." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ActivityDetail,
});

type Change = { field: string; from?: string | null; to?: string | null };

function ActivityDetail() {
  const { id } = Route.useParams();
  const user = useCurrentUser();
  const { data: item, isLoading } = useActivityItem(id);
  const { data: profiles = [] } = useProfiles();
  const { fromBooking, tab } = Route.useSearch();

  const changes = Array.isArray(item?.changes) ? (item.changes as unknown as Change[]) : [];
  const author = profiles.find((p) => p.id === item?.user_id)?.name ?? "Onbekend";

  return (
    <AppShell title="Activiteitdetail" user={user}>
      {fromBooking ? (
        <Link
          to="/bookings/$id"
          params={{ id: fromBooking }}
          search={{ tab: tab ?? "booking" }}
          className="mb-4 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Terug naar boeking
        </Link>
      ) : (
        <Link
          to="/activity"
          className="mb-4 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Terug naar activiteit
        </Link>
      )}

      {isLoading || !item ? (
        <div className="panel p-10 text-center text-sm text-muted-foreground">Laden…</div>
      ) : (
        <div className="panel max-w-3xl p-5">
          <p className="text-sm">
            <span className="font-medium">{author}</span> {item.summary}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            {formatDateTime(item.created_at)} · {item.entity_type} · {item.action}
          </p>

          <div className="mt-6">
            <h2 className="text-sm font-semibold">Wijzigingen</h2>
            <div className="mt-3 hidden grid-cols-3 gap-4 border-b pb-2 text-xs font-medium text-muted-foreground sm:grid">
              <span>Veld / prijsregel</span>
              <span>Voor wijziging</span>
              <span>Na wijziging</span>
            </div>
            <div className="mt-3 divide-y">
              {changes.map((c, i) => (
                <div key={i} className="grid gap-1 py-3 sm:grid-cols-3 sm:gap-4">
                  <span className="min-w-0 break-words text-sm text-muted-foreground">{c.field}</span>
                  <div className="min-w-0 break-words text-sm">
                    <span className="mr-2 text-xs text-muted-foreground sm:hidden">Voor:</span>
                    <span className="line-through opacity-70">{c.from || "leeg"}</span>
                  </div>
                  <div className="min-w-0 break-words text-sm font-medium">
                    <span className="mr-2 text-xs font-normal text-muted-foreground sm:hidden">Na:</span>
                    {c.to || "leeg"}
                  </div>
                </div>
              ))}
              {changes.length === 0 ? (
                <p className="py-3 text-sm text-muted-foreground">
                  Geen veldwijzigingen vastgelegd.
                </p>
              ) : null}
            </div>
          </div>

          {item.entity_type === "booking" && item.entity_id ? (
            <Link
              to="/bookings/$id"
              params={{ id: item.entity_id }}
              search={{ tab: "booking" }}
              className="mt-6 inline-block text-sm text-accent hover:underline"
            >
              Bekijk boeking
            </Link>
          ) : null}
        </div>
      )}
    </AppShell>
  );
}
