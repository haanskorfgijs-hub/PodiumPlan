import { RoleLabel } from "@/lib/role-label";
import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Badge } from "@/components/ui/badge";
import { listAllAccounts } from "@/lib/admin-users.functions";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { useCurrentUser } from "@/lib/session";
import { useAccessRedirect } from "@/components/access-guard";
import { supabase } from "@/integrations/supabase/client";
import { useProfiles, type Profile } from "@/lib/data";
import { ROLES, useUserRoles, type AppRole } from "@/lib/roles";
import { usePermission } from "@/lib/permissions";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/users/")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { title: "Gebruikersbeheer — PodiumPlan" },
      { name: "description", content: "Beheer accounts en rollen binnen PodiumPlan." },
      { property: "og:title", content: "Gebruikersbeheer — PodiumPlan" },
      { property: "og:description", content: "Wijs de rollen Admin, Manager of Lezer toe." },
    ],
  }),
  component: UsersPage,
});

function UsersPage() {
  const user = useCurrentUser();
  const queryClient = useQueryClient();
  const { allowed: isAdmin, isLoading } = usePermission("users.manage");
  useAccessRedirect(isAdmin, isLoading);
  const { data: profiles = [] } = useProfiles();
  const { data: roles = [] } = useUserRoles();
  const fetchAccounts = useServerFn(listAllAccounts);
  const { data: accounts = [] } = useQuery({
    queryKey: ["admin-accounts"],
    enabled: isAdmin,
    queryFn: () => fetchAccounts(),
  });

  const profileOf = (id: string) => profiles.find((p) => p.id === id);
  // Alle aangemaakte accounts, ook accounts zonder bevestigd e-mailadres.
  const rows = (accounts.length > 0
    ? accounts.map((a) => {
        const profile = profileOf(a.id);
        return {
          profile:
            profile ??
            ({
              id: a.id,
              name: "",
              email: a.email,
              avatar_url: null,
              phone: "",
              job_title: "",
              created_at: a.created_at,
            } as Profile),
          confirmed: a.confirmed,
        };
      })
    : profiles.map((profile) => ({ profile, confirmed: true }))
  ).sort((a, b) =>
    (a.profile.name || a.profile.email || "").localeCompare(b.profile.name || b.profile.email || ""),
  );

  const roleOf = (id: string) => roles.find((r) => r.user_id === id)?.role ?? "gebruiker";

  async function setRole(userId: string, role: AppRole) {
    const existing = roles.find((r) => r.user_id === userId);
    const { error } = existing
      ? await supabase.from("user_roles").update({ role }).eq("user_id", userId)
      : await supabase.from("user_roles").insert({ user_id: userId, role });
    if (error) {
      toast.error("Rol wijzigen mislukt.");
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["user-roles"] });
    queryClient.invalidateQueries({ queryKey: ["my-role"] });
  }

  async function setJobTitle(userId: string, jobTitle: string) {
    const { error } = await supabase
      .from("profiles")
      .update({ job_title: jobTitle })
      .eq("id", userId);
    if (error) {
      toast.error("Functietitel opslaan mislukt.");
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["profiles"] });
    queryClient.invalidateQueries({ queryKey: ["booking-assignees"] });
  }


  return (
    <AppShell
      title="Gebruikersbeheer"
      subtitle="Beheer accounts en hun rollen"
      user={user}
      actions={
        isAdmin ? (
          <Button variant="outline" asChild>
            <Link to="/gebruikersrechten">
              <ShieldCheck className="mr-1 h-4 w-4" /> Accountsrechten
            </Link>
          </Button>
        ) : null
      }
    >
      {isLoading ? (
        <p className="text-sm text-muted-foreground">Laden…</p>
      ) : !isAdmin ? (
        <div className="rounded-xl border p-6">
          <h2 className="text-base font-semibold">Geen toegang</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Alleen een beheerder heeft toegang tot deze pagina.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-medium">Naam</th>
                <th className="px-4 py-3 font-medium">E-mailadres</th>
                <th className="w-56 px-4 py-3 font-medium">Functietitel</th>
                <th className="w-48 px-4 py-3 font-medium">ACCOUNTTYPE</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ profile: p, confirmed }) => (
                <ClickableUserRow
                  key={p.id}
                  profile={p}
                  confirmed={confirmed}
                  role={roleOf(p.id)}
                  onSetRole={(r) => setRole(p.id, r)}
                  onSetJobTitle={(v) => setJobTitle(p.id, v)}
                />
              ))}
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-4 py-8 text-center text-muted-foreground">
                    Nog geen accounts gevonden.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}

function ClickableUserRow({
  profile,
  confirmed,
  role,
  onSetRole,
  onSetJobTitle,
}: {
  profile: Profile;
  confirmed: boolean;
  role: AppRole;
  onSetRole: (role: AppRole) => void;
  onSetJobTitle: (value: string) => void;
}) {
  const navigate = useNavigate();
  return (
    <tr
      className="border-t cursor-pointer hover:bg-muted/50"
      onClick={() => navigate({ to: "/users/$id", params: { id: profile.id } })}
    >
      <td className="px-4 py-3 align-middle font-medium">
        <span className="block">{profile.name || profile.email || "—"}</span>
      </td>
      <td className="px-4 py-3 align-middle text-muted-foreground">
        <span className="flex flex-wrap items-center gap-2">
          {profile.email}
          {!confirmed ? <Badge variant="secondary">Niet geactiveerd</Badge> : null}
        </span>
      </td>
      <td className="px-4 py-3 align-middle" onClick={(e) => e.stopPropagation()}>
        <JobTitleCell
          value={profile.job_title ?? ""}
          onSave={onSetJobTitle}
        />
      </td>
      <td className="px-4 py-3 align-middle" onClick={(e) => e.stopPropagation()}>
        <Select value={role} onValueChange={(v) => onSetRole(v as AppRole)}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {ROLES.map((r) => (
              <SelectItem key={r} value={r}>
                <RoleLabel role={r} />
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </td>
    </tr>
  );
}

function JobTitleCell({
  value,
  onSave,
}: {
  value: string;
  onSave: (value: string) => void;
}) {
  const [draft, setDraft] = useState(value);

  useEffect(() => {
    setDraft(value);
  }, [value]);

  return (
    <Input
      value={draft}
      placeholder="Bijv. Manager"
      onChange={(e) => setDraft(e.target.value)}
      onBlur={() => {
        if (draft.trim() !== value.trim()) onSave(draft.trim());
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") e.currentTarget.blur();
      }}
    />
  );
}

