import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Pencil, Plus, Trash2, Users } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { AppShell } from "@/components/app-shell";
import { useCurrentUser } from "@/lib/session";
import {
  
  logActivity,
  parseFields,
  useArtists,
  useBookings,
  useStandards,
  type Artist,
  type Standard,
} from "@/lib/data";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArtistDialog } from "@/components/artist-dialog";
import { StandardDialog } from "@/components/standard-dialog";
import { MembersDialog } from "@/components/members-dialog";
import { useArtistPermissionSet, usePermission } from "@/lib/permissions";
import { AccessDenied, useAccessRedirect } from "@/components/access-guard";

export const Route = createFileRoute("/_authenticated/artists")({
  head: () => ({
    meta: [
      { title: "Artiesten — PodiumPlan" },
      { name: "description", content: "Artiesten en hun optredenstandaarden met eigen velden." },
      { property: "og:title", content: "Artiesten — PodiumPlan" },
      { property: "og:description", content: "Beheer artiesten en optredenstandaarden." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ArtistsPage,
});

function ArtistsPage() {
  const user = useCurrentUser();
  const queryClient = useQueryClient();
  const { allowed: canViewArtists, isLoading: viewLoading } = usePermission("artists.view");
  useAccessRedirect(canViewArtists, viewLoading);
  const { allowed: canManageArtists } = usePermission("artists.manage");
  const isReader = !canManageArtists;
  const { data: artists = [] } = useArtists();
  const artistIds = artists.map((a) => a.id);
  const canCreateStandardFor = useArtistPermissionSet("standards.create", artistIds);
  const canManageMembersFor = useArtistPermissionSet("members.manage.artist", artistIds);
  const { data: standards = [] } = useStandards();
  const { data: bookings = [] } = useBookings();

  const [artistDialog, setArtistDialog] = useState<{ open: boolean; artist?: Artist | null }>({
    open: false,
  });
  const [standardDialog, setStandardDialog] = useState<{
    open: boolean;
    artist?: Artist;
    standard?: Standard | null;
  }>({ open: false });
  const [membersDialog, setMembersDialog] = useState<{ open: boolean; artist?: Artist }>({
    open: false,
  });

  async function deleteArtist(a: Artist) {
    const count = bookings.filter((b) => b.artist_id === a.id).length;
    if (count > 0) {
      return toast.error(
        `Artiest "${a.name}" heeft nog ${count} boeking(en). Verwijder die eerst.`,
      );
    }
    if (!confirm(`Artiest "${a.name}" en bijbehorende standaarden verwijderen?`)) return;
    const { error: stdError } = await supabase
      .from("performance_standards")
      .delete()
      .eq("artist_id", a.id);
    if (stdError) return toast.error(stdError.message);
    const { error } = await supabase.from("artists").delete().eq("id", a.id);
    if (error) return toast.error(error.message);
    await logActivity({
      entityType: "artist",
      entityId: a.id,
      action: "delete",
      summary: `Artiest ${a.name} verwijderd`,
    });
    queryClient.invalidateQueries();
  }

  async function deleteStandard(s: Standard) {
    if (!confirm(`Standaard "${s.name}" verwijderen?`)) return;
    const { data, error } = await supabase
      .from("performance_standards")
      .delete()
      .eq("id", s.id)
      .select("id");
    if (error) return toast.error(error.message);
    if (!data?.length) return toast.error("Je hebt geen recht om deze standaard te verwijderen.");
    await logActivity({
      entityType: "standard",
      entityId: s.id,
      action: "delete",
      summary: `Standaard ${s.name} verwijderd`,
    });
    queryClient.invalidateQueries();
  }

  if (!viewLoading && !canViewArtists) {
    return <AccessDenied title="Artiesten" />;
  }

  return (
    <AppShell
      title="Artiesten"
      subtitle={`${artists.length} artiesten`}
      user={user}
      actions={
        !canManageArtists ? null : (
          <Button onClick={() => setArtistDialog({ open: true, artist: null })}>
            <Plus className="mr-1 h-4 w-4" /> Nieuwe artiest
          </Button>
        )
      }
    >
      <div className="grid gap-5 lg:grid-cols-2">
        {artists.map((a) => {
          const own = standards.filter((s) => s.artist_id === a.id);
          const count = bookings.filter((b) => b.artist_id === a.id).length;
          return (
            <section key={a.id} className="panel p-5">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h2 className="text-base font-semibold">{a.name}</h2>
                  {a.description ? (
                    <p className="mt-1 text-sm text-muted-foreground">{a.description}</p>
                  ) : null}
                  {a.home_location ? (
                    <p className="mt-1 text-xs text-muted-foreground">
                      Thuislocatie: {a.home_location}
                    </p>
                  ) : null}
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <Badge variant="secondary">{count} boekingen</Badge>
                  {canManageMembersFor(a.id) ? (
                    <Button
                      size="icon"
                      variant="ghost"
                      aria-label={`Beheerder toevoegen voor ${a.name}`}
                      onClick={() => setMembersDialog({ open: true, artist: a })}
                    >
                      <Users className="h-4 w-4" />
                    </Button>
                  ) : null}
                  {canManageArtists ? (
                    <Button
                      size="icon"
                      variant="ghost"
                      aria-label={`${a.name} bewerken`}
                      onClick={() => setArtistDialog({ open: true, artist: a })}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                  ) : null}
                  {isReader ? null : (
                    <Button
                      size="icon"
                      variant="ghost"
                      aria-label={`${a.name} verwijderen`}
                      onClick={() => deleteArtist(a)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  )}
                </div>
              </div>

              <div className="mt-5 space-y-4">
                {own.map((s) => {
                  const fields = parseFields(s.fields);
                  return (
                    <div key={s.id} className="rounded-lg border p-3">
                      <div className="flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium">{s.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {fields.length} veld{fields.length === 1 ? "" : "en"}
                          </p>
                        </div>
                        <div className="flex shrink-0 items-center gap-1">
                          {!canCreateStandardFor(a.id) ? null : (
                            <Button
                              size="icon"
                              variant="ghost"
                              aria-label={`${s.name} bewerken`}
                              onClick={() =>
                                setStandardDialog({ open: true, artist: a, standard: s })
                              }
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                          )}
                          {!canCreateStandardFor(a.id) ? null : (
                            <Button
                              size="icon"
                              variant="ghost"
                              aria-label={`${s.name} verwijderen`}
                              onClick={() => deleteStandard(s)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
                {own.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Nog geen optredenstandaard.</p>
                ) : null}

                {!canCreateStandardFor(a.id) ? null : (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setStandardDialog({ open: true, artist: a, standard: null })}
                  >
                    <Plus className="mr-1 h-4 w-4" /> Standaard toevoegen
                  </Button>
                )}
              </div>
            </section>
          );
        })}
        {artists.length === 0 ? (
          <p className="text-sm text-muted-foreground">Nog geen artiesten toegevoegd.</p>
        ) : null}
      </div>

      <ArtistDialog
        open={artistDialog.open}
        artist={artistDialog.artist}
        onOpenChange={(open) => setArtistDialog((p) => ({ ...p, open }))}
      />
      {membersDialog.artist ? (
        <MembersDialog
          scope="artist"
          id={membersDialog.artist.id}
          title={membersDialog.artist.name}
          open={membersDialog.open}
          onOpenChange={(open) => setMembersDialog((p) => ({ ...p, open }))}
        />
      ) : null}
      {standardDialog.artist ? (
        <StandardDialog
          open={standardDialog.open}
          artistId={standardDialog.artist.id}
          artistName={standardDialog.artist.name}
          standard={standardDialog.standard}
          onOpenChange={(open) => setStandardDialog((p) => ({ ...p, open }))}
        />
      ) : null}
    </AppShell>
  );
}
