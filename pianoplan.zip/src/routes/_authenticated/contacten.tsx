import { RoleLabel } from "@/lib/role-label";
// ============= Full file contents =============

import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Check, Trash2, UserPlus, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/app-shell";
import { useCurrentUser } from "@/lib/session";
import { type AppRole } from "@/lib/roles";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/contacten")({
  head: () => ({
    meta: [
      { title: "Contacten — PodiumPlan" },
      { name: "description", content: "Beheer je contacten en contactverzoeken in PodiumPlan." },
      { property: "og:title", content: "Contacten — PodiumPlan" },
      { property: "og:description", content: "Stuur en beantwoord contactverzoeken." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ContactsPage,
});

function ContactsPage() {
  const user = useCurrentUser();
  const qc = useQueryClient();
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("my_contacts");
      if (error) throw error;
      return data ?? [];
    },
  });
  const { data: protectedIds = new Set<string>() } = useQuery({
    queryKey: ["contacts-protected", contacts.map((c) => c.other_id).join(",")],
    enabled: contacts.length > 0,
    queryFn: async () => {
      const { data: auth } = await supabase.auth.getUser();
      const meAdmin = auth.user
        ? (await supabase.rpc("is_admin_user", { _user_id: auth.user.id })).data
        : false;
      const ids = new Set<string>();
      if (meAdmin) return ids;
      await Promise.all(
        contacts.map(async (c) => {
          const { data } = await supabase.rpc("is_admin_user", { _user_id: c.other_id });
          if (data) ids.add(c.other_id);
        }),
      );
      return ids;
    },
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["contacts"] });
    qc.invalidateQueries({ queryKey: ["invitable-users"] });
  };

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const value = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) || value.length > 255)
      return toast.error("Vul een geldig e-mailadres in.");
    setBusy(true);
    const { error } = await supabase.rpc("send_contact_request", { _email: value });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Contactverzoek verstuurd");
    setEmail("");
    refresh();
  }

  async function respond(id: string, accept: boolean) {
    const { error } = await supabase.rpc("respond_contact_request", { _id: id, _accept: accept });
    if (error) return toast.error(error.message);
    toast.success(accept ? "Contact toegevoegd" : "Verzoek afgewezen");
    refresh();
  }

  async function remove(id: string) {
    const { error } = await supabase.from("contacts").delete().eq("id", id);
    if (error) return toast.error(error.message);
    refresh();
  }

  const incoming = contacts.filter((c) => c.incoming && c.status === "pending");
  const accepted = contacts.filter((c) => c.status === "accepted");
  const sent = contacts.filter((c) => !c.incoming && c.status !== "accepted");

  type Contact = (typeof contacts)[number];

  const Cells = ({ c }: { c: Contact }) => (
    <>
      <td className="max-w-[220px] truncate px-4 py-3 font-medium">{c.name || c.email}</td>
      <td className="whitespace-nowrap px-4 py-3">
        {c.account_role ? (
          <Badge variant="secondary"><RoleLabel role={c.account_role} /></Badge>
        ) : (
          <span className="text-muted-foreground">—</span>
        )}
      </td>
      <td className="max-w-[200px] truncate px-4 py-3 text-muted-foreground">
        {c.job_title || <span>—</span>}
      </td>
      <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">{c.email}</td>
    </>
  );

  const Table = ({
    rows,
    actions,
    emptyLabel,
  }: {
    rows: Contact[];
    actions: (c: Contact) => React.ReactNode;
    emptyLabel?: string;
  }) => (
    <div className="overflow-x-auto rounded-xl border bg-card">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b text-left text-xs uppercase tracking-wide text-muted-foreground">
            <th className="px-4 py-2.5 font-medium">Naam</th>
            <th className="px-4 py-2.5 font-medium">Accounttype</th>
            <th className="px-4 py-2.5 font-medium">Functietitel</th>
            <th className="px-4 py-2.5 font-medium">E-mailadres</th>
            <th className="px-4 py-2.5 text-right font-medium">Actie</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {rows.map((c) => (
            <tr key={c.id} className="hover:bg-muted/40">
              <Cells c={c} />
              <td className="px-4 py-3">
                <div className="flex items-center justify-end gap-2">{actions(c)}</div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {!rows.length && emptyLabel ? (
        <p className="px-4 py-8 text-center text-sm text-muted-foreground">{emptyLabel}</p>
      ) : null}
    </div>
  );

  return (
    <AppShell title="Contacten" subtitle="Alleen contacten kun je kiezen bij teams en artiesten" user={user}>
      <div className="space-y-6">
        <form onSubmit={send} className="flex flex-col gap-2 rounded-xl border bg-card p-4 sm:flex-row">
          <Input
            type="email"
            placeholder="E-mailadres van het account"
            value={email}
            maxLength={255}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Button type="submit" disabled={busy || !email.trim()}>
            <UserPlus className="mr-1 h-4 w-4" /> Contactverzoek sturen
          </Button>
        </form>

        {incoming.length ? (
          <section className="space-y-2">
            <h2 className="font-semibold">Ontvangen verzoeken</h2>
            <Table
              rows={incoming}
              actions={(c) => (
                <>
                  <Button size="sm" onClick={() => respond(c.id, true)}>
                    <Check className="mr-1 h-4 w-4" /> Accepteren
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => respond(c.id, false)}>
                    <X className="mr-1 h-4 w-4" /> Afwijzen
                  </Button>
                </>
              )}
            />
          </section>
        ) : null}

        <section className="space-y-2">
          <h2 className="font-semibold">Mijn contacten</h2>
          <Table
            rows={accepted}
            emptyLabel="Nog geen contacten."
            actions={(c) =>
              protectedIds.has(c.other_id) ? (
                <Badge variant="secondary">Admin</Badge>
              ) : (
                <Button
                  size="icon"
                  variant="ghost"
                  aria-label="Contact verwijderen"
                  onClick={() => remove(c.id)}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              )
            }
          />
        </section>

        {sent.length ? (
          <section className="space-y-2">
            <h2 className="font-semibold">Verstuurde verzoeken</h2>
            <Table
              rows={sent}
              actions={(c) => (
                <>
                  {c.status === "declined" ? (
                    <Badge variant="destructive">Afgewezen</Badge>
                  ) : (
                    <Badge variant="secondary">Wacht op antwoord</Badge>
                  )}
                  <Button
                    size="icon"
                    variant="ghost"
                    aria-label="Verzoek verwijderen"
                    onClick={() => remove(c.id)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </>
              )}
            />
          </section>
        ) : null}
      </div>
    </AppShell>
  );
}
