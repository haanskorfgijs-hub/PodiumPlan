import { RoleLabel } from "@/lib/role-label";
import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, CalendarDays, MapPin, Trash2, Users } from "lucide-react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { deleteAccount } from "@/lib/admin-users.functions";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AppShell } from "@/components/app-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentUser } from "@/lib/session";
import { useAccessRedirect } from "@/components/access-guard";
import { formatBookingDate, formatEuroDate, useAvatarUrls, type Profile } from "@/lib/data";
import { type AppRole } from "@/lib/roles";
import { usePermission } from "@/lib/permissions";

export const Route = createFileRoute("/_authenticated/users/$id")({
  head: () => ({
    meta: [
      { title: "Gebruikersdetails — PodiumPlan" },
      { name: "description", content: "Bekijk boekingen, artiesten en taken van een account." },
      { property: "og:title", content: "Gebruikersdetails — PodiumPlan" },
      { property: "og:description", content: "Inzicht in de boekingen en artiesten van een account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: UserDetailPage,
});

type UserDetail = {
  profile: Profile | null;
  role: AppRole | null;
  artists: { id: string; name: string; role: string; status: string; owner: boolean }[];
  bookings: {
    id: string;
    event_name: string;
    event_date: string;
    location_name: string | null;
    city: string | null;
    artist: string | null;
    relation: string;
    status: string;
  }[];
  tasks: { id: string; title: string; status: string; deadline: string | null }[];
};

function useUserDetail(id: string, enabled: boolean) {
  return useQuery({
    queryKey: ["user-detail", id],
    enabled,
    queryFn: async (): Promise<UserDetail> => {
      const [profileRes, roleRes, artistsRes, ownArtistsRes, memberRes, ownBookingsRes, tasksRes] =
        await Promise.all([
          supabase.from("profiles").select("*").eq("id", id).maybeSingle(),
          supabase.from("user_roles").select("role").eq("user_id", id).maybeSingle(),
          supabase
            .from("artist_members")
            .select("status, artists(id, name)")
            .eq("user_id", id),
          supabase.from("artists").select("id, name").eq("created_by", id),
          supabase
            .from("booking_members")
            .select(
              "role, status, bookings(id, event_name, event_date, location_name, city, artist_status, artists(name))",
            )
            .eq("user_id", id),
          supabase
            .from("bookings")
            .select("id, event_name, event_date, location_name, city, artist_status, artists(name)")
            .eq("created_by", id),
          supabase.from("tasks").select("id, title, status, deadline").eq("assigned_to", id),
        ]);

      const artists: UserDetail["artists"] = [
        ...(ownArtistsRes.data ?? []).map((a) => ({
          id: a.id,
          name: a.name,
          role: "Eigenaar",
          status: "accepted",
          owner: true,
        })),
        ...(artistsRes.data ?? [])
          .filter((m) => !!m.artists)
          .map((m) => ({
            id: (m.artists as { id: string }).id,
            name: (m.artists as { name: string }).name,
            role: "Beheerder",
            status: m.status as string,
            owner: false,
          })),
      ];

      const toBooking = (
        b: {
          id: string;
          event_name: string;
          event_date: string;
          location_name: string | null;
          city: string | null;
          artist_status: string | null;
          artists: { name: string } | null;
        },
        relation: string,
      ) => ({
        id: b.id,
        event_name: b.event_name,
        event_date: b.event_date,
        location_name: b.location_name,
        city: b.city,
        artist: b.artists?.name ?? null,
        relation,
        status: b.artist_status ?? "—",
      });

      const bookings: UserDetail["bookings"] = [
        ...(ownBookingsRes.data ?? []).map((b) => toBooking(b as never, "Aangemaakt")),
        ...(memberRes.data ?? [])
          .filter((m) => !!m.bookings)
          .map((m) =>
            toBooking(
              m.bookings as never,
              m.status === "accepted"
                ? m.role === "lezer"
                  ? "Toegevoegd (lezer)"
                  : "Toegevoegd"
                : "Uitgenodigd",
            ),
          ),
      ].sort((a, b) => a.event_date.localeCompare(b.event_date));

      return {
        profile: (profileRes.data as Profile | null) ?? null,
        role: (roleRes.data?.role as AppRole | undefined) ?? null,
        artists,
        bookings,
        tasks: (tasksRes.data ?? []) as UserDetail["tasks"],
      };
    },
  });
}

function UserDetailPage() {
  const { id } = Route.useParams();
  const user = useCurrentUser();
  const navigate = useNavigate();
  const { allowed: isAdmin, isLoading: roleLoading } = usePermission("users.manage");
  useAccessRedirect(isAdmin, roleLoading);
  const { data, isLoading } = useUserDetail(id, isAdmin);
  const { data: avatars = {} } = useAvatarUrls([data?.profile?.avatar_url]);
  const queryClient = useQueryClient();
  const removeAccount = useServerFn(deleteAccount);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  async function handleDelete() {
    setDeleting(true);
    try {
      await removeAccount({ data: { userId: id } });
      toast.success("Account verwijderd.");
      queryClient.invalidateQueries({ queryKey: ["profiles"] });
      queryClient.invalidateQueries({ queryKey: ["admin-accounts"] });
      queryClient.invalidateQueries({ queryKey: ["user-roles"] });
      navigate({ to: "/users" });
    } catch {
      toast.error("Account verwijderen mislukt.");
    } finally {
      setDeleting(false);
      setConfirmOpen(false);
    }
  }

  const profile = data?.profile;
  const avatar = profile?.avatar_url ? avatars[profile.avatar_url] : undefined;

  return (
    <AppShell
      title={profile?.name || profile?.email || "Gebruiker"}
      subtitle="Accountdetails en betrokkenheid"
      user={user}
    >
      {roleLoading ? (
        <p className="text-sm text-muted-foreground">Laden…</p>
      ) : !isAdmin ? (
        <div className="rounded-xl border p-6">
          <h2 className="text-base font-semibold">Geen toegang</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Alleen een beheerder heeft toegang tot deze pagina.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => navigate({ to: "/users" })}>
              <ArrowLeft className="mr-2 h-4 w-4" /> Terug naar gebruikersbeheer
            </Button>
            {user?.id !== id ? (
              <Button
                variant="destructive"
                size="sm"
                className="ml-auto"
                onClick={() => setConfirmOpen(true)}
              >
                <Trash2 className="mr-2 h-4 w-4" /> Account verwijderen
              </Button>
            ) : null}
          </div>

          <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Account definitief verwijderen?</AlertDialogTitle>
                <AlertDialogDescription>
                  Het account {profile?.name || profile?.email || ""} wordt volledig verwijderd,
                  inclusief het profiel en de uitnodigingen. Dit kan niet ongedaan worden gemaakt.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel disabled={deleting}>Annuleren</AlertDialogCancel>
                <AlertDialogAction
                  disabled={deleting}
                  onClick={(e) => {
                    e.preventDefault();
                    void handleDelete();
                  }}
                >
                  {deleting ? "Verwijderen…" : "Verwijderen"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          {isLoading ? (
            <p className="text-sm text-muted-foreground">Laden…</p>
          ) : !profile ? (
            <div className="rounded-xl border p-6 text-sm text-muted-foreground">
              Dit account is niet gevonden.
            </div>
          ) : (
            <>
              <section className="rounded-xl border p-5">
                <div className="flex flex-wrap items-center gap-4">
                  <div className="flex h-14 w-14 items-center justify-center overflow-hidden rounded-full bg-muted text-lg font-semibold">
                    {avatar ? (
                      <img src={avatar} alt={profile.name || profile.email} className="h-full w-full object-cover" />
                    ) : (
                      (profile.name || profile.email || "?").charAt(0).toUpperCase()
                    )}
                  </div>
                  <div className="min-w-0">
                    <h2 className="truncate text-lg font-semibold">{profile.name || "—"}</h2>
                    <p className="truncate text-sm text-muted-foreground">{profile.email}</p>
                    {profile.job_title ? (
                      <p className="text-sm text-muted-foreground">{profile.job_title}</p>
                    ) : null}
                  </div>
                  <div className="ml-auto flex flex-wrap items-center gap-2">
                    {data?.role ? <Badge variant="secondary"><RoleLabel role={data.role} /></Badge> : null}
                    {profile.phone ? <Badge variant="outline">{profile.phone}</Badge> : null}
                  </div>
                </div>
                <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-3">
                  <div>
                    <dt className="text-muted-foreground">Boekingen</dt>
                    <dd className="font-medium">{data?.bookings.length ?? 0}</dd>
                  </div>
                  <div>
                    <dt className="text-muted-foreground">Artiesten</dt>
                    <dd className="font-medium">{data?.artists.length ?? 0}</dd>
                  </div>
                  <div>
                    <dt className="text-muted-foreground">Account sinds</dt>
                    <dd className="font-medium">{formatEuroDate(profile.created_at)}</dd>
                  </div>
                </dl>
              </section>

              <section className="rounded-xl border">
                <header className="flex items-center gap-2 border-b px-5 py-3">
                  <CalendarDays className="h-4 w-4 text-muted-foreground" />
                  <h3 className="text-sm font-semibold">Boekingen</h3>
                </header>
                {data && data.bookings.length > 0 ? (
                  <ul className="divide-y">
                    {data.bookings.map((b) => (
                      <li key={`${b.id}-${b.relation}`}>
                        <Link
                          to="/bookings/$id"
                          params={{ id: b.id }}
                          search={{ tab: "booking" }}
                          className="flex flex-wrap items-center gap-x-3 gap-y-1 px-5 py-3 text-sm hover:bg-muted/50"
                        >
                          <span className="w-24 shrink-0 text-muted-foreground">
                            {formatBookingDate(b.event_date)}
                          </span>
                          <span className="font-medium">{b.event_name}</span>
                          {b.artist ? (
                            <span className="text-muted-foreground">· {b.artist}</span>
                          ) : null}
                          {b.location_name || b.city ? (
                            <span className="flex items-center gap-1 text-muted-foreground">
                              <MapPin className="h-3.5 w-3.5" />
                              {[b.location_name, b.city].filter(Boolean).join(", ")}
                            </span>
                          ) : null}
                          <span className="ml-auto flex items-center gap-2">
                            <Badge variant="outline">{b.status}</Badge>
                            <Badge variant={b.relation === "Uitgenodigd" ? "secondary" : "outline"}>
                              {b.relation}
                            </Badge>
                          </span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="px-5 py-6 text-sm text-muted-foreground">
                    Dit account is nog niet aan boekingen toegevoegd.
                  </p>
                )}
              </section>

              <section className="rounded-xl border">
                <header className="flex items-center gap-2 border-b px-5 py-3">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <h3 className="text-sm font-semibold">Artiesten</h3>
                </header>
                {data && data.artists.length > 0 ? (
                  <ul className="divide-y">
                    {data.artists.map((a) => (
                      <li
                        key={`${a.id}-${a.role}`}
                        className="flex flex-wrap items-center gap-2 px-5 py-3 text-sm"
                      >
                        <span className="font-medium">{a.name}</span>
                        <span className="ml-auto flex items-center gap-2">
                          <Badge variant="outline">{a.owner ? "Eigenaar" : a.role}</Badge>
                          {a.status === "pending" ? <Badge variant="secondary">Uitgenodigd</Badge> : null}
                        </span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="px-5 py-6 text-sm text-muted-foreground">
                    Dit account is nog niet aan artiesten gekoppeld.
                  </p>
                )}
              </section>

              <section className="rounded-xl border">
                <header className="border-b px-5 py-3">
                  <h3 className="text-sm font-semibold">Toegewezen taken</h3>
                </header>
                {data && data.tasks.length > 0 ? (
                  <ul className="divide-y">
                    {data.tasks.map((t) => (
                      <li key={t.id} className="flex flex-wrap items-center gap-2 px-5 py-3 text-sm">
                        <span className="font-medium">{t.title}</span>
                        {t.deadline ? (
                          <span className="text-muted-foreground">· {formatEuroDate(t.deadline)}</span>
                        ) : null}
                        <Badge variant="outline" className="ml-auto">
                          {t.status}
                        </Badge>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="px-5 py-6 text-sm text-muted-foreground">Geen open taken.</p>
                )}
              </section>
            </>
          )}
        </div>
      )}
    </AppShell>
  );
}
