import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { useCurrentUser } from "@/lib/session";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Check, ChevronDown, Moon, Sun, X } from "lucide-react";
import { useTheme } from "@/lib/theme";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { DEFAULT_EMAIL_NOTIFICATION_PREFERENCES, normalizeEmailNotificationPreferences, type EmailNotificationPreferences } from "@/lib/email-notification-preferences";
import { resubscribeMyEmail } from "@/lib/email-resubscribe.functions";
import {
  useDashboardStatusFilter,
  useDashboardStatusOptions,
} from "@/lib/dashboard-status-filter";


export const Route = createFileRoute("/_authenticated/gebruiksinstellingen")({
  head: () => ({
    meta: [
      { title: "Gebruiksinstellingen — PodiumPlan" },
      {
        name: "description",
        content: "Beheer je persoonlijke gebruiksinstellingen in PodiumPlan.",
      },
      { property: "og:title", content: "Gebruiksinstellingen — PodiumPlan" },
      { property: "og:description", content: "Beheer je persoonlijke gebruiksinstellingen." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: GebruiksinstellingenPage,
});

function GebruiksinstellingenPage() {
  const user = useCurrentUser();
  const queryClient = useQueryClient();
  const { statuses, setStatuses } = useDashboardStatusFilter(user.id);
  const options = useDashboardStatusOptions();
  const { theme, toggle: toggleTheme } = useTheme();
  const prefsQuery = useQuery({
    queryKey: ["email-notification-preferences", user.id],
    queryFn: async () => {
      const { data } = await (supabase as any)
        .from("email_notification_preferences")
        .select("booking_invitations, status_changes, statuses")
        .eq("user_id", user.id)
        .maybeSingle();
      return normalizeEmailNotificationPreferences(
        data ? { bookingInvitations: data.booking_invitations, statusChanges: data.status_changes, statuses: data.statuses } : DEFAULT_EMAIL_NOTIFICATION_PREFERENCES,
      );
    },
  });
  const emailPreferences = prefsQuery.data ?? DEFAULT_EMAIL_NOTIFICATION_PREFERENCES;
  const setEmailPreferences = async (next: EmailNotificationPreferences) => {
    const normalized = normalizeEmailNotificationPreferences(next);
    queryClient.setQueryData(["email-notification-preferences", user.id], normalized);
    const { error } = await (supabase as any).from("email_notification_preferences").upsert({
      user_id: user.id,
      booking_invitations: normalized.bookingInvitations,
      status_changes: normalized.statusChanges,
      statuses: normalized.statuses,
      paused_snapshot: null,
      updated_at: new Date().toISOString(),
    });
    if (error) {
      toast.error("E-mailvoorkeuren opslaan mislukt");
      queryClient.invalidateQueries({ queryKey: ["email-notification-preferences", user.id] });
      return;
    }
    const turnedOn = (normalized.bookingInvitations && !emailPreferences.bookingInvitations) || (normalized.statusChanges && !emailPreferences.statusChanges);
    if (turnedOn) {
      const r = await resubscribeMyEmail();
      if (!r.ok) toast.error("Opnieuw aanmelden voor e-mails mislukt");
    }
  };
  const emailStatusOptions = [...options];
  for (const status of emailPreferences.statuses) {
    if (!emailStatusOptions.some((option) => option.label.toLowerCase() === status)) {
      emailStatusOptions.push({ label: status });
    }
  }


  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const toggle = (label: string, checked: boolean) => {
    setStatuses(
      checked
        ? [...statuses.filter((s) => s.toLowerCase() !== label.toLowerCase()), label]
        : statuses.filter((s) => s.toLowerCase() !== label.toLowerCase()),
    );
  };

  const visible = query.trim()
    ? options.filter((o) => o.label.toLowerCase().includes(query.trim().toLowerCase()))
    : options;

  const selectedCount = statuses.length;

  return (
    <AppShell
      title="Gebruiksinstellingen"
      subtitle="Persoonlijke voorkeuren en instellingen"
      user={user}
    >
      <div className="mx-auto max-w-3xl space-y-5">
        <section className="panel">
          <div className="border-b px-5 py-4">
            <h2 className="text-sm font-semibold">E-mailnotificaties</h2>
          </div>
          <div className="space-y-5 p-5">
            <label className="flex cursor-pointer items-center gap-3 text-sm">
              <Checkbox
                checked={emailPreferences.bookingInvitations}
                onCheckedChange={(checked) => setEmailPreferences({ ...emailPreferences, bookingInvitations: checked === true })}
              />
              <span>Uitnodigingen voor boekingen</span>
            </label>
            <div className="space-y-3">
              <label className="flex cursor-pointer items-center gap-3 text-sm">
                <Checkbox
                  checked={emailPreferences.statusChanges}
                  onCheckedChange={(checked) => setEmailPreferences({ ...emailPreferences, statusChanges: checked === true })}
                />
                <span>Statuswijzigingen</span>
              </label>
              {emailPreferences.statusChanges && (
                <fieldset className="ml-7 space-y-3 border-l pl-4">
                  <legend className="mb-2 text-sm font-medium">E-mail ontvangen bij deze statussen</legend>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {emailStatusOptions.map((option) => {
                      const key = option.label.toLowerCase();
                      return (
                        <label key={key} className="flex min-w-0 cursor-pointer items-start gap-2 text-sm">
                          <Checkbox
                            className="mt-0.5 shrink-0"
                            checked={emailPreferences.statuses.includes(key)}
                            onCheckedChange={(checked) => setEmailPreferences({
                              ...emailPreferences,
                              statuses: checked === true
                                ? [...emailPreferences.statuses.filter((status) => status !== key), key]
                                : emailPreferences.statuses.filter((status) => status !== key),
                            })}
                          />
                          <span className="min-w-0 break-words">{option.label}{option.hint && <span className="ml-2 text-xs text-muted-foreground">{option.hint}</span>}</span>
                        </label>
                      );
                    })}
                  </div>
                </fieldset>
              )}
            </div>
          </div>
        </section>

        <section className="panel">
          <div className="border-b px-5 py-4">
            <h2 className="text-sm font-semibold">Weergave</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Kies tussen een lichte of donkere weergave. Dit geldt op mobiel en desktop.
            </p>
          </div>
          <div className="flex items-center justify-between gap-3 p-5">
            <span className="text-sm">
              {theme === "dark" ? "Donkere weergave" : "Lichte weergave"}
            </span>
            <Button variant="outline" onClick={toggleTheme}>
              {theme === "dark" ? (
                <Sun className="mr-2 h-4 w-4" />
              ) : (
                <Moon className="mr-2 h-4 w-4" />
              )}
              Wisselen
            </Button>
          </div>
        </section>

        <section className="panel">
          <div className="border-b px-5 py-4">
            <h2 className="text-sm font-semibold">Boekingen op het dashboard</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Kies welke statussen je op het dashboard wilt zien. Kies je niets, dan worden
              alleen actieve boekingen weergegeven.
            </p>
          </div>
          <div className="p-5">
            <Popover open={open} onOpenChange={setOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-between sm:w-auto">
                  <span>
                    {selectedCount === 0
                      ? "Standaardweergave"
                      : `${selectedCount} status${selectedCount === 1 ? "" : "sen"} geselecteerd`}
                  </span>
                  <ChevronDown className="ml-2 h-4 w-4 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[min(24rem,90vw)] p-0" align="start">
                <div className="border-b p-2">
                  <Input
                    autoFocus
                    className="h-8 text-sm"
                    placeholder="Zoeken…"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                  />
                </div>
                <div className="max-h-64 overflow-y-auto p-1">
                  {visible.length === 0 ? (
                    <p className="p-3 text-center text-xs text-muted-foreground">
                      Geen statussen
                    </p>
                  ) : (
                    visible.map((o) => {
                      const checked = statuses.some(
                        (s) => s.toLowerCase() === o.label.toLowerCase(),
                      );
                      return (
                        <label
                          key={o.label}
                          className="flex cursor-pointer items-center gap-2 rounded px-2 py-1.5 text-sm hover:bg-muted"
                        >
                          <Checkbox
                            checked={checked}
                            onCheckedChange={(v) => toggle(o.label, v === true)}
                          />
                          <span className="flex-1 truncate">{o.label}</span>
                          {o.hint && (
                            <span className="text-xs text-muted-foreground">{o.hint}</span>
                          )}
                        </label>
                      );
                    })
                  )}
                </div>
                <div className="flex items-center justify-between gap-2 border-t p-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 px-2 text-xs"
                    onClick={() => setStatuses([])}
                  >
                    <X className="mr-1 h-3 w-3" /> Standaard
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 px-2 text-xs"
                    onClick={() => setStatuses(options.map((o) => o.label))}
                  >
                    <Check className="mr-1 h-3 w-3" /> Alles
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </section>
      </div>
    </AppShell>
  );
}
