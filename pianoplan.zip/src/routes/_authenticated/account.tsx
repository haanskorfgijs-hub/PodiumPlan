import { RoleLabel } from "@/lib/role-label";
import { useEffect, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Loader2, Upload } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useCurrentUser } from "@/lib/session";
import { useMyRole } from "@/lib/roles";

export const Route = createFileRoute("/_authenticated/account")({
  head: () => ({
    meta: [
      { title: "Accountinstellingen — PodiumPlan" },
      {
        name: "description",
        content: "Beheer je profielfoto, e-mailadres, telefoonnummer en wachtwoord in PodiumPlan.",
      },
      { property: "og:title", content: "Accountinstellingen — PodiumPlan" },
      { property: "og:description", content: "Beheer je profiel en inloggegevens." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AccountPage,
});

function useMyProfile() {
  return useQuery({
    queryKey: ["my-profile"],
    queryFn: async () => {
      const { data: auth } = await supabase.auth.getUser();
      if (!auth.user) return null;
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", auth.user.id)
        .maybeSingle();
      if (error) throw error;
      return { ...data, id: auth.user.id, authEmail: auth.user.email ?? "" };
    },
  });
}

function AccountPage() {
  const user = useCurrentUser();
  const queryClient = useQueryClient();
  const { data: profile } = useMyProfile();
  const fileRef = useRef<HTMLInputElement>(null);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const { data: role } = useMyRole();
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [password2, setPassword2] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingEmail, setSavingEmail] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);

  useEffect(() => {
    if (!profile) return;
    const full = (profile.name ?? "").trim();
    const idx = full.indexOf(" ");
    setFirstName(idx === -1 ? full : full.slice(0, idx));
    setLastName(idx === -1 ? "" : full.slice(idx + 1));
    setPhone((profile as { phone?: string }).phone ?? "");
    setEmail(profile.authEmail ?? "");
  }, [profile]);

  const avatarPath = (profile as { avatar_url?: string | null } | null)?.avatar_url ?? null;

  useEffect(() => {
    let active = true;
    if (!avatarPath) {
      setAvatarUrl(null);
      return;
    }
    supabase.storage
      .from("avatars")
      .createSignedUrl(avatarPath, 60 * 60)
      .then(({ data }) => {
        if (active) setAvatarUrl(data?.signedUrl ?? null);
      });
    return () => {
      active = false;
    };
  }, [avatarPath]);

  async function uploadAvatar(file: File) {
    if (!profile?.id) return;
    if (!file.type.startsWith("image/")) return toast.error("Kies een afbeelding.");
    if (file.size > 5 * 1024 * 1024) return toast.error("Maximaal 5 MB.");
    setUploading(true);
    const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
    const path = `${profile.id}/avatar-${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("avatars").upload(path, file, { upsert: true });
    if (error) {
      setUploading(false);
      return toast.error(error.message);
    }
    const { error: dbError } = await supabase
      .from("profiles")
      .update({ avatar_url: path })
      .eq("id", profile.id);
    setUploading(false);
    if (dbError) return toast.error(dbError.message);
    queryClient.invalidateQueries({ queryKey: ["my-profile"] });
    queryClient.invalidateQueries({ queryKey: ["current-user"] });
    queryClient.invalidateQueries({ queryKey: ["profiles"] });
  }

  async function removeAvatar() {
    if (!profile?.id) return;
    if (avatarPath) await supabase.storage.from("avatars").remove([avatarPath]);
    const { error } = await supabase
      .from("profiles")
      .update({ avatar_url: null })
      .eq("id", profile.id);
    if (error) return toast.error(error.message);
    queryClient.invalidateQueries({ queryKey: ["my-profile"] });
    queryClient.invalidateQueries({ queryKey: ["current-user"] });
    queryClient.invalidateQueries({ queryKey: ["profiles"] });
  }

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault();
    if (!profile?.id) return;
    const name = [firstName.trim(), lastName.trim()].filter(Boolean).join(" ");
    if (!firstName.trim()) return toast.error("Vul je voornaam in.");
    setSavingProfile(true);
    const { error } = await supabase
      .from("profiles")
      .update({ name, phone: phone.trim() })
      .eq("id", profile.id);
    setSavingProfile(false);
    if (error) return toast.error(error.message);
    queryClient.invalidateQueries({ queryKey: ["my-profile"] });
    queryClient.invalidateQueries({ queryKey: ["current-user"] });
    queryClient.invalidateQueries({ queryKey: ["profiles"] });
  }

  async function saveEmail(e: React.FormEvent) {
    e.preventDefault();
    const next = email.trim();
    if (!next) return toast.error("Vul een e-mailadres in.");
    setSavingEmail(true);
    const { error } = await supabase.auth.updateUser(
      { email: next },
      { emailRedirectTo: `${window.location.origin}/account` },
    );
    setSavingEmail(false);
    if (error) return toast.error(error.message);
    toast.message("Bevestig het nieuwe e-mailadres via de link in je mailbox.");
  }

  async function savePassword(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 6) return toast.error("Minimaal 6 tekens.");
    if (password !== password2) return toast.error("Wachtwoorden komen niet overeen.");
    setSavingPassword(true);
    const { error } = await supabase.auth.updateUser({ password });
    setSavingPassword(false);
    if (error) return toast.error(error.message);
    setPassword("");
    setPassword2("");
  }

  const initials = (firstName || user.email || "?").slice(0, 2).toUpperCase();

  return (
    <AppShell title="Accountinstellingen" subtitle="Beheer je profiel en inloggegevens" user={user}>
      <div className="mx-auto grid max-w-3xl gap-6">
        <section className="panel p-6">
          <h2 className="text-base font-semibold">Profielfoto</h2>
          <div className="mt-4 flex flex-wrap items-center gap-4">
            <Avatar className="h-20 w-20 border">
              {avatarUrl ? <AvatarImage src={avatarUrl} alt="Profielfoto" /> : null}
              <AvatarFallback className="bg-primary text-primary-foreground">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-wrap gap-2">
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) uploadAvatar(file);
                  e.target.value = "";
                }}
              />
              <Button
                type="button"
                variant="outline"
                disabled={uploading}
                onClick={() => fileRef.current?.click()}
              >
                {uploading ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Upload className="mr-2 h-4 w-4" />
                )}
                Foto uploaden
              </Button>
              {avatarPath ? (
                <Button type="button" variant="ghost" onClick={removeAvatar}>
                  Verwijderen
                </Button>
              ) : null}
            </div>
          </div>
        </section>

        <section className="panel p-6">
          <h2 className="text-base font-semibold">Profielgegevens</h2>
          <form onSubmit={saveProfile} className="mt-4 grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="account-first-name">Voornaam</Label>
              <Input id="account-first-name" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="account-last-name">Achternaam</Label>
              <Input id="account-last-name" value={lastName} onChange={(e) => setLastName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="account-phone">Telefoonnummer</Label>
              <Input
                id="account-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+31 6 12345678"
              />
            </div>
            <div className="sm:col-span-2">
              <Button type="submit" disabled={savingProfile}>
                {savingProfile ? "Bezig…" : "Opslaan"}
              </Button>
            </div>
          </form>
        </section>

        <section className="panel p-6">
          <h2 className="text-base font-semibold">Mijn rechten</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Accounttype: <span className="font-medium text-foreground">{role ? <RoleLabel role={role} /> : "—"}</span>
          </p>
        </section>

        <section className="panel p-6">
          <h2 className="text-base font-semibold">E-mailadres</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Je ontvangt een bevestigingsmail op het nieuwe adres.
          </p>
          <form onSubmit={saveEmail} className="mt-4 flex flex-wrap items-end gap-3">
            <div className="min-w-56 flex-1 space-y-2">
              <Label htmlFor="account-email">E-mailadres</Label>
              <Input
                id="account-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <Button type="submit" disabled={savingEmail}>
              {savingEmail ? "Bezig…" : "Wijzigen"}
            </Button>
          </form>
        </section>

        <section className="panel p-6">
          <h2 className="text-base font-semibold">Wachtwoord</h2>
          <form onSubmit={savePassword} className="mt-4 grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="account-password">Nieuw wachtwoord</Label>
              <Input
                id="account-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="account-password2">Herhaal wachtwoord</Label>
              <Input
                id="account-password2"
                type="password"
                value={password2}
                onChange={(e) => setPassword2(e.target.value)}
              />
            </div>
            <div className="sm:col-span-2">
              <Button type="submit" disabled={savingPassword}>
                {savingPassword ? "Bezig…" : "Wachtwoord bijwerken"}
              </Button>
            </div>
          </form>
        </section>
      </div>
    </AppShell>
  );
}
