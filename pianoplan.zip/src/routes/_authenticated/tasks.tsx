import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Plus, Search, Trash2 } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { useCurrentUser } from "@/lib/session";
import {
  TASK_STATUS_LABELS,
  formatBookingDate,
  formatDate,
  useProfiles,
  useTasks,
  type TaskWithBooking,
} from "@/lib/data";
import { BookingStatusPill, TaskStatusBadge } from "@/components/status-badges";
import { TaskDialog } from "@/components/task-dialog";
import { ColumnFilter, FilterOption, monthOption } from "@/components/column-filter";
import { MobileFilters } from "@/components/mobile-filters";
import { usePersistentState } from "@/lib/use-persistent-state";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useIsReader } from "@/lib/roles";
import { useTaskAccess } from "@/lib/permissions";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import { logActivity } from "@/lib/data";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/tasks")({
  head: () => ({
    meta: [
      { title: "Takenlijst — PodiumPlan" },
      { name: "description", content: "Alle taken met filters op status, boeking en persoon." },
      { property: "og:title", content: "Takenlijst — PodiumPlan" },
      { property: "og:description", content: "Houd elke taak rond je optredens bij." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TasksPage,
});

type CellArgs = { task: TaskWithBooking; assignee: string };

const COLUMNS: {
  key: string;
  label: string;
  className: string;
  cellClassName: string;
  render: (args: CellArgs) => React.ReactNode;
  sortOf: (args: CellArgs) => string;
  filterOf: (args: CellArgs) => FilterOption | null;
}[] = [
  {
    key: "title",
    label: "Taak",
    className: "",
    cellClassName: "font-medium",
    render: ({ task }) => task.title,
    sortOf: ({ task }) => task.title ?? "",
    filterOf: ({ task }) => (task.title ? { value: task.title, label: task.title } : null),
  },
  {
    key: "booking",
    label: "Boeking",
    className: "w-56",
    cellClassName: "truncate text-muted-foreground",
    render: ({ task }) =>
      task.booking_id ? (
        <Link
          to="/bookings/$id"
          params={{ id: task.booking_id }}
          search={{ tab: "booking" }}
          onClick={(e) => e.stopPropagation()}
          className="hover:text-foreground hover:underline"
        >
          {task.bookings?.event_name ?? "Boeking"}
        </Link>
      ) : (
        "—"
      ),
    sortOf: ({ task }) => task.bookings?.event_name ?? "",
    filterOf: ({ task }) =>
      task.bookings?.event_name
        ? { value: task.bookings.event_name, label: task.bookings.event_name }
        : null,
  },
  {
    key: "booking_date",
    label: "Boekingsdatum",
    className: "w-36",
    cellClassName: "whitespace-nowrap text-sm",
    render: ({ task }) =>
      task.bookings?.event_date ? formatBookingDate(task.bookings.event_date) : "—",
    sortOf: ({ task }) => task.bookings?.event_date ?? "",
    filterOf: ({ task }) => monthOption(task.bookings?.event_date),
  },
  {
    key: "booking_status",
    label: "Boekingsstatus",
    className: "w-40",
    cellClassName: "",
    render: ({ task }) =>
      task.bookings ? (
        <BookingStatusPill
          booking={{
            artist_status: task.bookings.artist_status,
            artist_id: task.bookings.artist_id,
          }}
        />
      ) : (
        "—"
      ),
    sortOf: ({ task }) => task.bookings?.artist_status ?? "",
    filterOf: ({ task }) => {
      const value = task.bookings?.artist_status;
      return value ? { value, label: value } : null;
    },
  },
  {
    key: "assignee",
    label: "Toegewezen",
    className: "w-44",
    cellClassName: "truncate",
    render: ({ assignee }) => assignee,
    sortOf: ({ assignee }) => (assignee === "—" ? "" : assignee),
    filterOf: ({ assignee }) =>
      assignee && assignee !== "—" ? { value: assignee, label: assignee } : null,
  },
  {
    key: "deadline",
    label: "Deadline",
    className: "w-36",
    cellClassName: "whitespace-nowrap text-sm",
    render: ({ task }) => formatDate(task.deadline),
    sortOf: ({ task }) => task.deadline ?? "",
    filterOf: ({ task }) => monthOption(task.deadline),
  },
  {
    key: "status",
    label: "Status",
    className: "w-40",
    cellClassName: "",
    render: ({ task }) => <TaskStatusBadge status={task.status} />,
    sortOf: ({ task }) => (task.status ? (TASK_STATUS_LABELS[task.status] ?? task.status) : ""),
    filterOf: ({ task }) =>
      task.status
        ? { value: task.status, label: TASK_STATUS_LABELS[task.status] ?? task.status }
        : null,
  },
];

function TasksPage() {
  const user = useCurrentUser();
  const { isReader: roleIsReader } = useIsReader();
  const { data: tasks = [] } = useTasks();
  const { canCreate, canEditTask } = useTaskAccess(undefined, tasks.flatMap((t) => t.booking_id ? [t.booking_id] : []));
  const canManageTasks = canCreate;
  const isReader = roleIsReader || !canCreate;
  const queryClient = useQueryClient();
  const { data: profiles = [] } = useProfiles();
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<string>("deadline");
  const [asc, setAsc] = useState(true);
  const [open, setOpen] = useState(false);
  const [current, setCurrent] = useState<TaskWithBooking | null>(null);
  const [filters, setFilters] = usePersistentState<Record<string, string[]>>(
    "stagehand.filters.tasks",
    {},
  );

  const enriched = useMemo<CellArgs[]>(
    () =>
      tasks.map((task) => ({
        task,
        assignee:
          profiles.find((p) => p.id === task.assigned_to)?.name ??
          (task.assigned_to ? "Onbekend" : "—"),
      })),
    [tasks, profiles],
  );

  const optionsFor = useMemo(() => {
    const map: Record<string, FilterOption[]> = {};
    COLUMNS.forEach((col) => {
      const seen = new Map<string, string>();
      enriched.forEach((args) => {
        const opt = col.filterOf(args);
        if (opt && !seen.has(opt.value)) seen.set(opt.value, opt.label);
      });
      map[col.key] = [...seen.entries()]
        .map(([value, label]) => ({ value, label }))
        .sort((a, b) =>
          col.key === "booking_date" || col.key === "deadline"
            ? a.value.localeCompare(b.value)
            : a.label.localeCompare(b.label),
        );
    });
    return map;
  }, [enriched]);

  const rows = useMemo(
    () =>
      enriched
        .filter((args) =>
          COLUMNS.every((col) => {
            const selected = filters[col.key];
            if (!selected?.length) return true;
            const opt = col.filterOf(args);
            return opt ? selected.includes(opt.value) : false;
          }),
        )
        .filter(({ task: t }) =>
          search
            ? [t.title, t.description, t.bookings?.event_name]
                .filter(Boolean)
                .join(" ")
                .toLowerCase()
                .includes(search.toLowerCase())
            : true,
        )
        .sort((a, b) => {
          const col = COLUMNS.find((c) => c.key === sort);
          if (!col) return 0;
          const va = col.sortOf(a) || "\uffff";
          const vb = col.sortOf(b) || "\uffff";
          return asc ? va.localeCompare(vb) : vb.localeCompare(va);
        }),
    [enriched, search, filters, sort, asc],
  );

  async function removeTask(task: TaskWithBooking) {
    if (!window.confirm(`Taak "${task.title}" verwijderen?`)) return;
    const { error } = await supabase.from("tasks").delete().eq("id", task.id);
    if (error) return toast.error(error.message);
    await logActivity({
      entityType: "task",
      entityId: task.booking_id ?? task.id,
      action: "delete",
      summary: `verwijderde taak "${task.title}"`,
    });
    queryClient.invalidateQueries();
  }

  return (
    <AppShell
      title="Takenlijst"
      subtitle={`${rows.length} taken`}
      user={user}
      actions={
        canManageTasks ? (
          <Button
            onClick={() => {
              setCurrent(null);
              setOpen(true);
            }}
          >
            <Plus className="mr-2 h-4 w-4" /> Nieuwe taak
          </Button>
        ) : null
      }
    >
      <div className="panel">
        <div className="flex flex-wrap items-center gap-3 border-b p-4">
          <div className="relative min-w-56 flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="Zoek op taak of boeking…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        <MobileFilters
          columns={COLUMNS.map((c) => ({ key: c.key, label: c.label }))}
          optionsFor={optionsFor}
          filters={filters}
          onChange={(key, values) => setFilters((prev) => ({ ...prev, [key]: values }))}
          onClearAll={() => setFilters({})}
        />


        <div className="hidden overflow-x-auto md:block">
          <Table className="[&_td]:py-4">

            <TableHeader>
              <TableRow>
                {COLUMNS.map((col) => (
                  <TableHead key={col.key} className={col.className}>
                    <span className="inline-flex items-center gap-1">
                      <span
                        className="cursor-pointer select-none hover:underline"
                        onClick={() => {
                          if (sort === col.key) setAsc((v) => !v);
                          else {
                            setSort(col.key);
                            setAsc(true);
                          }
                        }}
                      >
                        {col.label}
                        {sort === col.key ? (asc ? " ↑" : " ↓") : ""}
                      </span>
                      <ColumnFilter
                        options={optionsFor[col.key] ?? []}
                        selected={filters[col.key] ?? []}
                        onChange={(values) =>
                          setFilters((prev) => ({ ...prev, [col.key]: values }))
                        }
                      />
                    </span>
                  </TableHead>
                ))}
                {isReader ? null : <TableHead className="w-12" />}
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((args) => (
                <TableRow
                  key={args.task.id}
                  className="cursor-pointer"
                  onClick={() => {
                    setCurrent(args.task);
                    setOpen(true);
                  }}
                >
                  {COLUMNS.map((col) => (
                    <TableCell key={col.key} className={col.cellClassName}>
                      {col.render(args)}
                    </TableCell>
                  ))}
                  {isReader ? null : (
                    <TableCell className="text-right">
                      {canEditTask(args.task) ? (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            void removeTask(args.task);
                          }}
                          className="text-muted-foreground transition-colors hover:text-destructive"
                          aria-label="Taak verwijderen"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      ) : null}
                    </TableCell>
                  )}
                </TableRow>
              ))}
              {rows.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={COLUMNS.length + (isReader ? 0 : 1)}
                    className="py-12 text-center text-sm text-muted-foreground"
                  >
                    Geen taken gevonden.
                  </TableCell>
                </TableRow>
              ) : null}
            </TableBody>
          </Table>
        </div>

        {/* Mobiele kaartweergave voor taken. */}
        <ul className="divide-y md:hidden">
          {rows.map(({ task: t, assignee }) => (
            <li key={t.id} className="flex items-start gap-2 px-4 py-4">
              <button
                type="button"
                onClick={() => {
                  setCurrent(t);
                  setOpen(true);
                }}
                className="min-w-0 flex-1 text-left"
              >
                <div className="flex items-start justify-between gap-3">
                  <p className="min-w-0 text-base font-semibold break-words">{t.title}</p>
                  <span className="shrink-0">
                    <TaskStatusBadge status={t.status} />
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground break-words">
                  {t.bookings?.event_name ?? "Geen boeking"}
                  {t.bookings?.event_date ? ` · ${formatBookingDate(t.bookings.event_date)}` : ""}
                </p>
                <p className="mt-0.5 text-sm text-muted-foreground">
                  {assignee} · deadline {formatDate(t.deadline)}
                </p>
              </button>
              {isReader || !canEditTask(t) ? null : (
                <button
                  onClick={() => void removeTask(t)}
                  className="-mr-2 grid h-11 w-11 shrink-0 place-items-center text-muted-foreground transition-colors active:text-destructive"
                  aria-label="Taak verwijderen"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              )}
            </li>
          ))}
          {rows.length === 0 ? (
            <li className="px-4 py-10 text-center text-sm text-muted-foreground">
              Geen taken gevonden.
            </li>
          ) : null}
        </ul>

      </div>

      <TaskDialog open={open} onOpenChange={setOpen} task={current} />
    </AppShell>
  );
}
