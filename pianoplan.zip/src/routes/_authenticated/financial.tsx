import { useEffect, useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { usePersistentState } from "@/lib/use-persistent-state";
import { useColumnOrder } from "@/lib/column-order";

import { AppShell } from "@/components/app-shell";

import { useCurrentUser } from "@/lib/session";
import { usePermission } from "@/lib/permissions";
import { useAccessRedirect } from "@/components/access-guard";
import {
  bookingDateTimeKey,
  bookingStatusLabel,
  bookingTime,
  FINANCIAL_STATUS_LABELS,
  fieldTab,
  fieldValues,
  formatBookingDate,
  parseFields,
  useArtists,
  useBookings,
  useStandards,
  useStandardMap,
} from "@/lib/data";
import {
  BookingStatusPill,
  bookingStatusColorOf,
  FinancialStatusBadge,
  FinancialStatusStripeCell,
  financialStatusColor,
} from "@/components/status-badges";
import { MobileDateCard } from "@/components/mobile-date-card";
import { MonthDivider, monthKey } from "@/components/month-divider";
import { ColumnFilter, FilterOption, monthOption } from "@/components/column-filter";
import { MobileFilters } from "@/components/mobile-filters";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FinancialInvoices } from "@/components/financial-invoices";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/financial")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { title: "Financieel — PodiumPlan" },
      {
        name: "description",
        content: "Financieel overzicht van alle boekingen met bedragen en factuurstatus.",
      },
      { property: "og:title", content: "Financieel — PodiumPlan" },
      {
        property: "og:description",
        content: "Bekijk per boeking de financiële velden en de factuurstatus.",
      },
    ],
  }),
  validateSearch: (search: Record<string, unknown>) => {
    const result: { status?: string; tab?: string } = {};
    if (typeof search.status === "string") result.status = search.status;
    if (typeof search.tab === "string") result.tab = search.tab;
    return result;
  },
  component: FinancialPage,
});


function FinancialPage() {
  const user = useCurrentUser();
  const navigate = useNavigate();
  const { allowed: isAdmin, isLoading: adminLoading } = usePermission("admin.full_access");
  const { data: bookings = [] } = useBookings();
  const { data: standards = [] } = useStandards();
  const { data: artists = [] } = useArtists();
  const standardMap = useStandardMap();
  const [search, setSearch] = useState("");

  const { allowed: canViewFinancial, isLoading: permLoading } = usePermission("financial.view");
  const allowed = canViewFinancial;
  useAccessRedirect(allowed, permLoading);
  const loading = adminLoading || permLoading;

  /** Geselecteerde waardes per kolomkey ("date", "artist", "event", "status", "f:<label>"). */
  const [filters, setFilters] = usePersistentState<Record<string, string[]>>("stagehand.filters.financial", {});

  /** Vooraf ingestelde financiële status via de URL (bijv. vanaf het dashboard). */
  const { status: statusParam, tab: tabParam } = Route.useSearch();
  const [activeTab, setActiveTab] = useState<"bookings" | "invoices">("bookings");

  useEffect(() => {
    if (tabParam === "invoices") setActiveTab("invoices");
    else if (tabParam === "bookings") setActiveTab("bookings");
    else if (sessionStorage.getItem("podiumplan:financial-tab") === "invoices") setActiveTab("invoices");
  }, [tabParam]);

  useEffect(() => {
    sessionStorage.setItem("podiumplan:financial-tab", activeTab);
  }, [activeTab]);

  useEffect(() => {
    if (!statusParam) return;
    // Bestaande filters vervallen: alleen het filter van de aangeklikte knop blijft over.
    setSearch("");
    setFilters({ status: statusParam.split(",").filter(Boolean) });
    navigate({ to: "/financial", search: () => ({ status: undefined, tab: undefined }), replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusParam]);



  /** Unieke financiële veldlabels over alle standaarden. */
  const financialColumns = useMemo(() => {
    const labels: string[] = [];
    standards.forEach((s) =>
      parseFields(s.fields)
        .filter((f) => fieldTab(f) === "financial")
        .forEach((f) => {
          if (!labels.includes(f.label)) labels.push(f.label);
        }),
    );
    return labels;
  }, [standards]);

  /** Welke labels zijn bedragen (€)? */
  const currencyColumns = useMemo(() => {
    const set = new Set<string>();
    standards.forEach((s) =>
      parseFields(s.fields)
        .filter((f) => fieldTab(f) === "financial" && f.type === "currency")
        .forEach((f) => set.add(f.label)),
    );
    return set;
  }, [standards]);

  function rawValue(booking: (typeof bookings)[number], label: string) {
    const standard = booking.standard_id ? standardMap.get(booking.standard_id) : undefined;
    const field = parseFields(standard?.fields).find(
      (f) => fieldTab(f) === "financial" && f.label === label,
    );
    if (!field) return "";
    return fieldValues(booking.field_values)[field.id] ?? "";
  }

  function numericValue(booking: (typeof bookings)[number], label: string) {
    const raw = rawValue(booking, label);
    if (!raw) return 0;
    const cleaned = raw.replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}\b)/g, "").replace(",", ".");
    const n = Number.parseFloat(cleaned);
    return Number.isFinite(n) ? n : 0;
  }

  /** Filterwaarde van een boeking per kolomkey. */
  function optionOf(booking: (typeof bookings)[number], key: string): FilterOption | null {
    if (key === "date") return monthOption(booking.event_date);
    if (key === "artist")
      return booking.artists?.name
        ? { value: booking.artists.name, label: booking.artists.name }
        : null;
    if (key === "event")
      return booking.event_name ? { value: booking.event_name, label: booking.event_name } : null;
    if (key === "booking_status") {
      const label = bookingStatusLabel(booking) || "Optie";
      return { value: label, label };
    }
    if (key === "status") {
      const status = booking.financial_status ?? "nog_spelen";
      return { value: status, label: FINANCIAL_STATUS_LABELS[status] ?? status };
    }
    if (key.startsWith("f:")) {
      const raw = rawValue(booking, key.slice(2));
      return raw ? { value: raw, label: raw } : null;
    }
    return null;
  }

  const columnKeys = useMemo(
    () => ["date", "artist", "event", "booking_status", ...financialColumns.map((l) => `f:${l}`), "status"],
    [financialColumns],
  );

  const optionsFor = useMemo(() => {
    const map: Record<string, FilterOption[]> = {};
    columnKeys.forEach((key) => {
      const seen = new Map<string, string>();
      bookings.forEach((b) => {
        const opt = optionOf(b, key);
        if (opt && !seen.has(opt.value)) seen.set(opt.value, opt.label);
      });
      map[key] = [...seen.entries()]
        .map(([value, label]) => ({ value, label }))
        .sort((a, b) =>
          key === "date" ? a.value.localeCompare(b.value) : a.label.localeCompare(b.label),
        );
    });
    return map;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookings, columnKeys, standardMap]);

  const rows = useMemo(() => {
    return bookings
      .filter((b) =>
        columnKeys.every((key) => {
          const selected = filters[key];
          if (!selected?.length) return true;
          const opt = optionOf(b, key);
          return opt ? selected.includes(opt.value) : false;
        }),
      )
      .filter((b) =>
        search
          ? [b.event_name, b.artists?.name]
              .filter(Boolean)
              .join(" ")
              .toLowerCase()
              .includes(search.toLowerCase())
          : true,
      )
      .sort((a, b) => {
        const standardA = a.standard_id ? standardMap.get(a.standard_id) : undefined;
        const standardB = b.standard_id ? standardMap.get(b.standard_id) : undefined;
        return bookingDateTimeKey(a.event_date, bookingTime(a, standardA).start).localeCompare(
          bookingDateTimeKey(b.event_date, bookingTime(b, standardB).start),
        );
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookings, search, filters, columnKeys, standardMap]);

  const totals = useMemo(() => {
    const out: Record<string, number> = {};
    financialColumns.forEach((label) => {
      if (!currencyColumns.has(label)) return;
      out[label] = rows.reduce((sum, b) => sum + numericValue(b, label), 0);
    });
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows, financialColumns, currencyColumns]);

  const formatEuro = (n: number) =>
    `€ ${n.toLocaleString("nl-NL", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  function cellValue(bookingId: string, label: string) {
    const booking = bookings.find((b) => b.id === bookingId);
    if (!booking) return "";
    const raw = rawValue(booking, label);
    if (!raw) return "";
    return currencyColumns.has(label) ? `€ ${raw}` : raw;
  }

  type FinColumn = {
    key: string;
    label: string;
    className: string;
    style?: React.CSSProperties;
    cellClassName: string;
    render: (b: (typeof bookings)[number]) => React.ReactNode;
  };

  const dynamicCount = financialColumns.length;
  const remainingPct = Math.max(0, 40);
  const finWidth = dynamicCount > 0 ? `${(remainingPct / dynamicCount).toFixed(2)}%` : undefined;

  const columnDefs = useMemo<FinColumn[]>(
    () => [
      {
        key: "date",
        label: "Datum",
        className: "w-[10%]",
        cellClassName: "text-sm whitespace-nowrap",
        render: (b) => formatBookingDate(b.event_date),
      },
      {
        key: "artist",
        label: "Artiest",
        className: "w-[12%]",
        cellClassName: "truncate text-sm text-muted-foreground",
        render: (b) => b.artists?.name,
      },
      {
        key: "event",
        label: "Event",
        className: "w-[18%]",
        cellClassName: "truncate text-sm font-medium",
        render: (b) => b.event_name,
      },
      {
        key: "booking_status",
        label: "Boekingsstatus",
        className: "w-[10%]",
        cellClassName: "text-sm whitespace-nowrap",
        render: (b) => <BookingStatusPill booking={b} />,
      },
      ...financialColumns.map((label) => ({
        key: `f:${label}`,
        label,
        className: "min-w-0 overflow-hidden",
        style: finWidth ? { width: finWidth } : undefined,
        cellClassName: "truncate text-sm tabular-nums",
        render: (b: (typeof bookings)[number]) => {
          const value = cellValue(b.id, label);
          return value || <span className="text-muted-foreground">—</span>;
        },
      })),
      {
        key: "status",
        label: "Financiële status",
        className: "w-[10%] text-right",
        cellClassName: "text-right",
        render: (b) => <FinancialStatusBadge status={b.financial_status ?? "nog_spelen"} />,
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [financialColumns, currencyColumns, bookings, standardMap, finWidth],
  );

  const { order, dragProps } = useColumnOrder(
    "podiumplan:columns:financial",
    columnDefs.map((c) => c.key),
  );
  const orderedColumns = useMemo(
    () =>
      order
        .map((key: string) => columnDefs.find((c) => c.key === key))
        .filter((c): c is FinColumn => Boolean(c)),
    [order, columnDefs],
  );

  function filterFor(key: string, align: "start" | "end" = "start") {
    return (
      <ColumnFilter
        options={optionsFor[key] ?? []}
        selected={filters[key] ?? []}
        align={align}
        onChange={(values) => setFilters((prev) => ({ ...prev, [key]: values }))}
      />
    );
  }

  if (loading) {
    return (
      <AppShell title="Financieel" user={user}>
        <div className="panel p-10 text-center text-sm text-muted-foreground">Laden…</div>
      </AppShell>
    );
  }

  if (!allowed) {
    return (
      <AppShell title="Financieel" user={user}>
        <div className="panel p-10 text-center text-sm text-muted-foreground">
          Je hebt geen toegang tot het financiële overzicht.
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell title="Financieel" subtitle={`${rows.length} boekingen`} user={user}>
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "bookings" | "invoices")} className="space-y-4">
        <TabsList>
          <TabsTrigger value="bookings">Boekingen</TabsTrigger>
          <TabsTrigger value="invoices">Facturen</TabsTrigger>
        </TabsList>
        <TabsContent value="invoices">
          <FinancialInvoices resetStatus={tabParam === "invoices" ? statusParam : undefined} />
        </TabsContent>
        <TabsContent value="bookings">
      <div className="panel">
        <div className="flex flex-wrap items-center gap-3 border-b p-4">
          <div className="relative min-w-56 flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="Zoek op event of artiest…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        <MobileFilters
          columns={orderedColumns.map((c) => ({ key: c.key, label: c.label }))}
          optionsFor={optionsFor}
          filters={filters}
          onChange={(key, values) => setFilters((prev) => ({ ...prev, [key]: values }))}
          onClearAll={() => setFilters({})}
        />


        <div className="hidden overflow-x-auto md:block">
          <Table className="table-fixed [&_td]:py-4">

            <TableHeader>
              <TableRow>
                <TableHead className="w-1.5 p-0" />
                {orderedColumns.map((col) => {
                  const right = col.className.includes("text-right");
                  return (
                    <TableHead
                      key={col.key}
                      {...dragProps(col.key)}
                      title="Versleep om de kolomvolgorde te wijzigen"
                      style={col.style}
                      className={`${col.className} align-middle select-none cursor-grab data-[dragging=true]:opacity-50`}
                    >
                      <span
                        className={`inline-flex w-full min-w-0 items-center gap-1 ${right ? "justify-end" : ""}`}
                      >
                        <span className="truncate">{col.label}</span>
                        {filterFor(col.key, right ? "end" : "start")}
                      </span>
                    </TableHead>
                  );
                })}
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((b) => (
                <TableRow
                  key={b.id}
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() =>
                    navigate({
                      to: "/bookings/$id",
                      params: { id: b.id },
                      search: { tab: "financial" },
                    })
                  }
                >
                  <FinancialStatusStripeCell status={b.financial_status} />
                  {orderedColumns.map((col) => (
                    <TableCell key={col.key} className={`${col.cellClassName} align-middle`}>
                      {col.render(b)}
                    </TableCell>
                  ))}
                </TableRow>
              ))}

              {rows.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={financialColumns.length + 6}
                    className="py-12 text-center text-sm text-muted-foreground"
                  >
                    Geen boekingen gevonden.
                  </TableCell>
                </TableRow>
              ) : null}

              {rows.length > 0 && currencyColumns.size > 0 ? (
                <TableRow className="bg-muted/40 font-semibold hover:bg-muted/40">
                  {orderedColumns.map((col, i) => {
                    if (i === 0)
                      return (
                        <TableCell key={col.key} colSpan={2} className="text-sm">
                          Totaal ({rows.length} boekingen)
                        </TableCell>
                      );
                    const label = col.key.startsWith("f:") ? col.key.slice(2) : null;
                    return (
                      <TableCell key={col.key} className="text-sm tabular-nums whitespace-nowrap">
                        {label && currencyColumns.has(label) ? formatEuro(totals[label] ?? 0) : null}
                      </TableCell>
                    );
                  })}
                </TableRow>
              ) : null}
            </TableBody>
          </Table>
        </div>

        {/* Mobiele kaartweergave: financiële velden onder elkaar. */}
        <ul className="divide-y md:hidden">
          {rows.map((b, i) => (
            <li key={b.id}>
              {i === 0 || monthKey(b.event_date) !== monthKey(rows[i - 1]!.event_date) ? (
                <MonthDivider date={b.event_date} />
              ) : null}
              <MobileDateCard
                date={b.event_date}
                color={financialStatusColor(b.financial_status)}
                onClick={() =>
                  navigate({
                    to: "/bookings/$id",
                    params: { id: b.id },
                    search: { tab: "financial" },
                  })
                }
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-base font-semibold break-words">{b.event_name}</p>
                    <p className="mt-0.5 text-sm text-muted-foreground">
                      {b.artists?.name} · {formatBookingDate(b.event_date)}
                    </p>
                  </div>
                  <span className="shrink-0">
                    <FinancialStatusBadge status={b.financial_status ?? "nog_spelen"} />
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <BookingStatusPill booking={b} />
                </div>
                <dl className="mt-1 grid grid-cols-2 gap-x-4 gap-y-2">
                  {financialColumns.map((label) => {
                    const value = cellValue(b.id, label);
                    if (!value) return null;
                    return (
                      <div key={label} className="min-w-0">
                        <dt className="text-xs text-muted-foreground">{label}</dt>
                        <dd className="text-sm font-medium tabular-nums break-words">{value}</dd>
                      </div>
                    );
                  })}
                </dl>
              </MobileDateCard>
            </li>
          ))}
          {rows.length === 0 ? (
            <li className="px-4 py-10 text-center text-sm text-muted-foreground">
              Geen boekingen gevonden.
            </li>
          ) : null}
          {rows.length > 0 && currencyColumns.size > 0 ? (
            <li className="bg-muted/40 px-4 py-4">
              <p className="text-sm font-semibold">Totaal ({rows.length} boekingen)</p>
              <dl className="mt-2 grid grid-cols-2 gap-x-4 gap-y-2">
                {financialColumns
                  .filter((label) => currencyColumns.has(label))
                  .map((label) => (
                    <div key={label} className="min-w-0">
                      <dt className="text-xs text-muted-foreground">{label}</dt>
                      <dd className="text-sm font-semibold tabular-nums">
                        {formatEuro(totals[label] ?? 0)}
                      </dd>
                    </div>
                  ))}
              </dl>
            </li>
          ) : null}
        </ul>

      </div>
        </TabsContent>
      </Tabs>
    </AppShell>
  );
}
