import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Wachtwoord opnieuw instellen — PodiumPlan" },
      { name: "description", content: "Stel een nieuw wachtwoord in voor je PodiumPlan-account." },
      { property: "og:title", content: "Wachtwoord opnieuw instellen — PodiumPlan" },
      { property: "og:description", content: "Kies een nieuw wachtwoord." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  ssr: false,
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [checking, setChecking] = useState(true);
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>();
  const [resendEmail, setResendEmail] = useState("");
  const [resending, setResending] = useState(false);
  const [resendInfo, setResendInfo] = useState<string>();

  useEffect(() => {
    let active = true;
    let settled = false;

    const url = new URL(window.location.href);
    const hash = new URLSearchParams(window.location.hash.replace(/^#/, ""));
    const tokenHash = url.searchParams.get("token_hash") ?? url.searchParams.get("token");
    const recoveryLink =
      url.searchParams.get("type") === "recovery" ||
      hash.get("type") === "recovery" ||
      Boolean(url.searchParams.get("code") || tokenHash || hash.get("access_token"));

    function finish(ok: boolean) {
      if (!active || settled) return;
      settled = true;
      setReady(ok);
      setChecking(false);
    }

    // De auth-client verwerkt code- en hashlinks zelf. Verwerk die hier niet nogmaals:
    // herstelcodes zijn eenmalig en dubbel verwerken maakt een geldige link ongeldig.
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (session && (event === "PASSWORD_RECOVERY" || (recoveryLink && event === "SIGNED_IN"))) {
        window.history.replaceState({}, document.title, window.location.pathname);
        finish(true);
      }
    });

    async function prepare() {
      // token_hash-links worden niet automatisch door de client verwerkt.
      if (tokenHash) {
        const { data, error: verifyError } = await supabase.auth.verifyOtp({
          token_hash: tokenHash,
          type: "recovery",
        });
        if (verifyError || !data.session) return finish(false);
        window.history.replaceState({}, document.title, window.location.pathname);
        return finish(true);
      }

      // Geef de client tijd om een code- of hashlink precies één keer te verwerken.
      for (let i = 0; i < 20 && active && !settled; i++) {
        const { data } = await supabase.auth.getSession();
        if (recoveryLink && data.session) {
          window.history.replaceState({}, document.title, window.location.pathname);
          return finish(true);
        }
        await new Promise((r) => setTimeout(r, 250));
      }
      finish(false);
    }

    prepare().catch(() => finish(false));

    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(undefined);
    if (password.length < 6) return setError("Het wachtwoord moet minimaal 6 tekens bevatten.");
    setLoading(true);
    const { error: updateError } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (updateError) {
      const m = updateError.message.toLowerCase();
      if (m.includes("password should be at least"))
        return setError("Het wachtwoord moet minimaal 6 tekens bevatten.");
      if (m.includes("same password"))
        return setError("Kies een wachtwoord dat afwijkt van je huidige wachtwoord.");
      if (m.includes("session") || m.includes("expired") || m.includes("token"))
        return setError("Deze resetlink is verlopen. Vraag een nieuwe link aan.");
      return setError("Er ging iets mis. Probeer het opnieuw.");
    }
    navigate({ to: "/dashboard" });
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="panel w-full max-w-md p-6">
        <h1 className="text-xl font-semibold">Nieuw wachtwoord instellen</h1>
        {checking ? (
          <p className="mt-3 text-sm text-muted-foreground">Resetlink controleren…</p>
        ) : !ready ? (
          <div className="mt-3 space-y-4">
            <p className="text-sm text-muted-foreground">
              Deze link is verlopen of al gebruikt. Vraag hieronder een nieuwe link aan.
            </p>
            <div className="space-y-2">
              <Label htmlFor="resend-email">E-mailadres</Label>
              <Input
                id="resend-email"
                type="email"
                value={resendEmail}
                onChange={(e) => setResendEmail(e.target.value)}
              />
            </div>
            {resendInfo ? <p className="text-sm font-medium text-primary">{resendInfo}</p> : null}
            <Button
              type="button"
              className="w-full"
              disabled={resending}
              onClick={async () => {
                setResendInfo(undefined);
                if (!resendEmail.trim()) return setResendInfo("Vul je e-mailadres in.");
                setResending(true);
                const { error: resendError } = await supabase.auth.resetPasswordForEmail(resendEmail.trim(), {
                  redirectTo: `${window.location.origin}/reset-password`,
                });
                setResending(false);
                if (resendError) {
                  const message = resendError.message.toLowerCase();
                  if (message.includes("security purposes") || message.includes("rate limit")) {
                    return setResendInfo("Wacht even voordat je opnieuw een link aanvraagt.");
                  }
                  return setResendInfo("De link kon niet worden verstuurd. Probeer het later opnieuw.");
                }
                setResendInfo(
                  "We hebben je een nieuwe link gestuurd. Open die link op dit apparaat en klik hem maar één keer aan.",
                );
              }}
            >
              {resending ? "Bezig…" : "Nieuwe link sturen"}
            </Button>
          </div>
        ) : (
          <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
            <div className="space-y-2">
              <Label htmlFor="new-password">Nieuw wachtwoord</Label>
              <Input
                id="new-password"
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            {error ? (
              <p role="alert" className="text-sm font-medium text-destructive">
                {error}
              </p>
            ) : null}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Bezig…" : "Wachtwoord opslaan"}
            </Button>
          </form>
        )}
      </div>
    </div>
  );
}
