export type EmailNotificationPreferences = {
  bookingInvitations: boolean;
  statusChanges: boolean;
  statuses: string[];
};

export const DEFAULT_EMAIL_NOTIFICATION_PREFERENCES: EmailNotificationPreferences = {
  bookingInvitations: false,
  statusChanges: false,
  statuses: [],
};

export function normalizeEmailNotificationPreferences(value: unknown): EmailNotificationPreferences {
  if (!value || typeof value !== "object") return { ...DEFAULT_EMAIL_NOTIFICATION_PREFERENCES, statuses: [] };
  const preferences = value as Partial<EmailNotificationPreferences>;
  return {
    bookingInvitations: preferences.bookingInvitations === true,
    statusChanges: preferences.statusChanges === true,
    statuses: Array.isArray(preferences.statuses)
      ? [...new Set(preferences.statuses.filter((status): status is string => typeof status === "string" && !!status.trim()).map((status) => status.trim().toLowerCase()))]
      : [],
  };
}

export function wantsBookingStatusEmail(preferences: EmailNotificationPreferences, status: string): boolean {
  return preferences.statusChanges && preferences.statuses.some((selected) => selected.trim().toLowerCase() === status.trim().toLowerCase());
}

export function wantsBookingInvitationEmail(preferences: EmailNotificationPreferences): boolean {
  return preferences.bookingInvitations;
}