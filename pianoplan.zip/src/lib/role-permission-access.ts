import type { AppRole } from "@/lib/roles";

export type RolePermissionRow = { role: AppRole; permission: string; allowed: boolean };

/** Account-type precedence changes scope only, never grants administrator powers. */
export function usesAccountPermissions(role: AppRole | null | undefined) {
  return role === "admin" || role === "host";
}

/** Stored settings are authoritative; missing permissions never grant access. */
export function roleHasPermission(
  rows: RolePermissionRow[] | undefined,
  role: AppRole | null | undefined,
  key: string,
) {
  if (!role) return false;
  return rows?.find((row) => row.role === role && row.permission === key)?.allowed ?? false;
}