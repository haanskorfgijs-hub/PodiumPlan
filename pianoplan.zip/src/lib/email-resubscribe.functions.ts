import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const SENDER_DOMAIN = "notify.podiumplan.gijshaanskorf.nl";

/** Called when the user turns a booking email preference back on: renews consent for their own address. */
export const resubscribeMyEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: me } = await context.supabase.from("profiles").select("email").eq("id", context.userId).maybeSingle();
    if (!me?.email) return { ok: false };
    const { getEmailUnsubscribe, setEmailUnsubscribe } = await import("@lovable.dev/email-js");
    const apiKey = process.env.LOVABLE_API_KEY!;
    try {
      const current = await getEmailUnsubscribe({ recipient: me.email, domain: SENDER_DOMAIN }, { apiKey });
      if (!current.subscribed) await setEmailUnsubscribe({ recipient: me.email, domain: SENDER_DOMAIN, subscribed: true }, { apiKey });
      return { ok: true };
    } catch (error) {
      console.error("Resubscribe failed", error);
      return { ok: false };
    }
  });
