import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { usePermission, useBookingPermissionSet } from "@/lib/permissions";
import { useCurrentUser } from "@/lib/session";
import { matchesYearFilter, useYearFilter } from "@/lib/year-filter";

export type Artist = Tables<"artists">;
export type Standard = Tables<"performance_standards">;
export type Booking = Tables<"bookings">;
export type Task = Tables<"tasks">;
export type Profile = Tables<"profiles">;
export type Activity = Tables<"activity_log">;
export type Widget = Tables<"calendar_widgets">;

export type FieldType =
  | "text"
  | "textarea"
  | "dropdown"
  | "date"
  | "time"
  | "datetime"
  | "boolean"
  | "map"
  | "distance"
  | "currency"
  | "formula"
  | "notes";

export type FieldTab = "booking" | "financial" | "pricing";

export const FIELD_TABS: FieldTab[] = ["booking", "financial"];
export const FIELD_TAB_LABELS: Record<FieldTab, string> = {
  booking: "Boekingsinformatie",
  financial: "Financieel",
  pricing: "Prijsbepaling",
};

export interface StandardField {
  id: string;
  label: string;
  type: FieldType;
  section?: string;
  tab?: FieldTab;
  options?: string[];
  default?: string;
  /** Excel-achtige formule voor een rekenveld, bijv. "=[Kilometers]*0,35". */
  formula?: string;
  /** Opnemen in het publieke gegevensblad (standaard aan). */
  sheet?: boolean;
  /** Prijsregel voor de offerteberekening (zie FieldPricing). */
  pricing?: FieldPricing;
}

/** Velden zonder expliciete keuze worden meegenomen in het gegevensblad. */
export function inSheet(f: StandardField) {
  return f.sheet !== false;
}

/** Sleutel in field_values waarin per boeking de uitgesloten gegevensblad-velden staan. */
export const SHEET_EXCLUDE_KEY = "__sheet_excluded";

/** Uitgesloten veld-ids voor het gegevensblad van deze boeking. */
export function sheetExcluded(values: Record<string, string>): string[] {
  return (values[SHEET_EXCLUDE_KEY] ?? "")
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean);
}

/** Staat dit veld in het gegevensblad van deze boeking? */
export function inSheetForBooking(f: StandardField, values: Record<string, string>) {
  if (values[SHEET_EXCLUDE_KEY] === undefined) return inSheet(f);
  return !sheetExcluded(values).includes(f.id);
}

/** Zet de uitsluitingslijst bij (aan/uit) voor één veld. */
export function toggleSheetField(
  values: Record<string, string>,
  fields: StandardField[],
  fieldId: string,
  include: boolean,
): string {
  const current =
    values[SHEET_EXCLUDE_KEY] === undefined
      ? fields.filter((f) => !inSheet(f)).map((f) => f.id)
      : sheetExcluded(values);
  const next = include
    ? current.filter((id) => id !== fieldId)
    : Array.from(new Set([...current, fieldId]));
  return next.join(",");
}



export function fieldTab(f: StandardField): FieldTab {
  if (f.tab === "financial") return "financial";
  if (f.tab === "pricing") return "pricing";
  return "booking";
}



export const FIELD_TYPE_LABELS: Record<FieldType, string> = {
  text: "Korte tekst",
  textarea: "Lange tekst",
  dropdown: "Dropdown",
  date: "Datum",
  time: "Tijd (begin–eind)",
  datetime: "Datum + tijd",
  boolean: "Ja/Nee keuze",
  map: "Kaartlocatie",
  distance: "Afstand (km)",
  currency: "Bedrag (€)",
  formula: "Formule (berekening)",
  notes: "Notities",
};


/* ------------------------- eigen statussen per artiest ------------------------ */

import type { ArtistStatus, StatusColor, StatusStage } from "@/lib/artist-status";
export { bookingStatusLabel, defaultArtistStatuses } from "@/lib/artist-status";
export type { ArtistStatus, StatusColor, StatusStage } from "@/lib/artist-status";

export const STATUS_COLORS: StatusColor[] = ["green", "amber", "blue", "red", "purple", "gray"];

export const STATUS_COLOR_LABELS: Record<StatusColor, string> = {
  green: "Groen",
  amber: "Oranje",
  blue: "Blauw",
  red: "Rood",
  purple: "Paars",
  gray: "Grijs",
};

export function parseArtistStatuses(value: unknown): ArtistStatus[] {
  if (!Array.isArray(value)) return [];
  return (value as ArtistStatus[]).filter((s) => s && typeof s.label === "string" && s.label.trim());
}

/**
 * Statussen die in een bepaalde fase gekozen mogen worden.
 * Statussen met fase "after" komen erbij vanaf de dag dat de boeking plaatsvindt
 * (alleen bij het aanpassen van een boeking).
 */
export function statusesForStage(
  list: ArtistStatus[],
  stage: StatusStage,
  eventDate?: string | null,
): ArtistStatus[] {
  const today = new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Amsterdam" }).format(new Date());
  const afterAllowed =
    stage === "edit" && !!eventDate && eventDate.slice(0, 10) <= today;
  return list.filter((s) => {
    if (!s.stage) return stage !== "after";
    if (s.stage === "after") return afterAllowed;
    // Bij aanpassen zijn ook de aanmaak-statussen beschikbaar.
    if (stage === "edit") return s.stage === "edit" || s.stage === "create";
    return s.stage === stage;
  });
}



/** Statusopties voor een boeking: uitsluitend de eigen statussen van de artiest. */
export function statusOptions(list: ArtistStatus[]) {
  return [...new Map(list.map((s) => [s.label, s])).values()]
    .slice()
    .sort((a, b) => a.label.localeCompare(b.label))
    .map((s) => ({ value: s.label, label: s.label, custom: true }));
}

/**
 * Statusopties voor een kalenderwidget: uitsluitend de eigen statussen van de
 * (geselecteerde) artiesten.
 */
export function widgetStatusOptions(
  artists: { id: string; name: string; booking_statuses?: unknown }[],
  artistIds: string[],
) {
  const scoped = artistIds.length ? artists.filter((a) => artistIds.includes(a.id)) : artists;
  const custom: { value: string; label: string; hint: string }[] = [];
  const seen = new Set<string>();
  for (const a of scoped) {
    for (const s of parseArtistStatuses(a.booking_statuses)) {
      if (seen.has(s.label)) continue;
      seen.add(s.label);
      custom.push({ value: s.label, label: s.label, hint: a.name });
    }
  }
  custom.sort((a, b) => a.label.localeCompare(b.label));
  return { standard: [] as { value: string; label: string; hint: string }[], custom };
}

/** Wat er in de agenda-items van een kalenderwidget mag komen. */
export const WIDGET_CONTENT_OPTIONS = [
  { value: "booking_link", label: "Link naar boeking" },
  { value: "sheet_link", label: "Link naar gegevensblad" },
] as const;

export const WIDGET_CONTENT_DEFAULT = ["booking_link"];

/** Welke soorten items een kalenderwidget toont. */
export const WIDGET_INCLUDE_OPTIONS = [
  { value: "bookings", label: "Boekingen" },
  { value: "tasks", label: "Taken" },
] as const;

export const WIDGET_INCLUDE_DEFAULT = ["bookings"];

export const WIDGET_INCLUDE_LABELS: Record<string, string> = {
  bookings: "Boekingen",
  tasks: "Taken",
};



export const FINANCIAL_STATUSES = ["factureren", "gefactureerd", "geannuleerd", "nog_spelen", "voldaan"] as const;
export const FINANCIAL_STATUS_LABELS: Record<string, string> = {
  factureren: "Factureren",
  gefactureerd: "Gefactureerd",
  geannuleerd: "Geannuleerd",
  nog_spelen: "Nog spelen",
  voldaan: "Voldaan",
};
export const TASK_STATUSES = ["afgerond", "in_behandeling", "open"] as const;
export const TASK_STATUS_LABELS: Record<string, string> = {
  afgerond: "Afgerond",
  in_behandeling: "In behandeling",
  open: "Open",
};

/* ----------------------------- vaste basisvelden ---------------------------- */

/** Sectie waarin de vaste velden altijd staan. */
export const BASE_SECTION = "Eventgegevens";

interface BaseFieldSpec {
  id: string;
  label: string;
  type: FieldType;
  /** Labels van bestaande velden die op dit vaste veld gemapt worden. */
  aliases: string[];
}

/** Vaste, niet-verwijderbare velden in elke optredenstandaard. */
export const BASE_FIELD_SPECS: BaseFieldSpec[] = [
  { id: "base_event_name", label: "Eventnaam", type: "text", aliases: ["eventnaam", "evenementnaam"] },
  { id: "base_date", label: "Datum", type: "date", aliases: ["datum"] },
  {
    id: "base_times_present",
    label: "Tijden aanwezig",
    type: "time",
    aliases: ["tijden aanwezig", "tijd aanwezig", "tijd", "tijden"],
  },
  { id: "base_play_times", label: "Speeltijden", type: "time", aliases: ["speeltijden", "speeltijd"] },
  { id: "base_location", label: "Locatie", type: "map", aliases: ["locatie", "kaartlocatie"] },
];

const BASE_LABELS = BASE_FIELD_SPECS.map((s) => s.label.toLowerCase());

/** Is dit een vast veld (niet verwijderbaar of aanpasbaar)? */
export function isBaseField(f: StandardField) {
  return (
    BASE_FIELD_SPECS.some((s) => s.id === f.id) || BASE_LABELS.includes(f.label.trim().toLowerCase())
  );
}

function norm(v: string) {
  return v.trim().toLowerCase().replace(/[-_]/g, " ").replace(/\s+/g, " ");
}

/**
 * Zorgt dat elke standaard de vaste basisvelden bevat: bestaande velden met een
 * overeenkomend label houden hun id (zodat boekingswaarden bewaard blijven) en
 * ontbrekende velden worden toegevoegd. Vaste velden staan altijd bovenaan.
 */
export function ensureBaseFields(fields: StandardField[]): StandardField[] {
  const used = new Set<string>();
  const base = BASE_FIELD_SPECS.map((spec) => {
    const match = fields.find(
      (f) =>
        !used.has(f.id) &&
        (f.id === spec.id || spec.aliases.includes(norm(f.label ?? ""))),
    );
    if (match) used.add(match.id);
    return {
      ...(match ?? { id: spec.id }),
      label: spec.label,
      type: spec.type,
      section: BASE_SECTION,
      tab: "booking" as FieldTab,
    } as StandardField;
  });
  return [...base, ...fields.filter((f) => !used.has(f.id))];
}

export function parseFields(value: unknown): StandardField[] {
  if (!Array.isArray(value)) return [];
  return ensureBaseFields(value as unknown as StandardField[]);
}


export function fieldValues(value: unknown): Record<string, string> {
  if (!value || typeof value !== "object") return {};
  return value as Record<string, string>;
}

/* ---------------------------------- queries --------------------------------- */

export function useArtists() {
  return useQuery({
    queryKey: ["artists"],
    queryFn: async () => {
      const { data, error } = await supabase.from("artists").select("*").order("name");
      if (error) throw error;
      return data as Artist[];
    },
  });
}

/**
 * Artiesten die in een kalenderwidget gekozen mogen worden: eigen artiesten,
 * artiesten waar je teamlid bent én artiesten van boekingen waarvoor je
 * bent uitgenodigd.
 */
export function useWidgetArtists() {
  return useQuery({
    queryKey: ["widget-artists"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("widget_artists");
      if (error) throw error;
      return (data ?? []) as { id: string; name: string; booking_statuses: unknown }[];
    },
  });
}

export function useStandards(artistId?: string) {
  return useQuery({
    queryKey: ["standards", artistId ?? "all"],
    queryFn: async () => {
      let q = supabase.from("performance_standards").select("*").order("created_at");
      if (artistId) q = q.eq("artist_id", artistId);
      const { data, error } = await q;
      if (error) throw error;
      return data as Standard[];
    },
  });
}

export type BookingWithArtist = Booking & { artists: { name: string } | null };

/** Alle boekingen, zonder de globale jaarfilter. */
export function useAllBookings() {
  return useQuery({
    queryKey: ["bookings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("*, artists(name)")
        .order("event_date", { ascending: true });
      if (error) throw error;
      return data as BookingWithArtist[];
    },
  });
}

/** Boekingen, gefilterd op de globale jaarselectie. */
export function useBookings() {
  const query = useAllBookings();
  const { years } = useYearFilter();
  const data = useMemo(
    () => query.data?.filter((b) => matchesYearFilter(b.event_date, years)),
    [query.data, years],
  );
  return { ...query, data } as typeof query;
}

export function useBooking(id: string) {
  return useQuery({
    queryKey: ["booking", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("*, artists(name)")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return data as BookingWithArtist | null;
    },
  });
}

export type TaskWithBooking = Task & {
  bookings: {
    event_name: string;
    event_date: string;
    artist_status?: string | null;
    artist_id?: string | null;
  } | null;
};

export function useTasks(bookingId?: string) {
  const { years } = useYearFilter();
  const query = useQuery({
    queryKey: ["tasks", bookingId ?? "all"],
    queryFn: async () => {
      let q = supabase.from("tasks").select("*, bookings(event_name, event_date, artist_status, artist_id)");
      if (bookingId) q = q.eq("booking_id", bookingId);
      const { data, error } = await q;
      if (error) throw error;
      // RLS bepaalt de zichtbaarheid: taken van boekingen waar het account aan
      // is toegevoegd zijn zichtbaar, ook voor de rol lezer.
      return data as TaskWithBooking[];
    },
  });
  const user = useCurrentUser();
  const bookingIds = useMemo(
    () => (query.data ?? []).map((t) => t.booking_id).filter((v): v is string => !!v),
    [query.data],
  );
  const { allows } = useBookingPermissionSet("tasks.view.all", bookingIds);
  const data = useMemo(() => {
    let rows = query.data;
    if (!bookingId) rows = rows?.filter((t) => matchesYearFilter(t.bookings?.event_date, years));
    // Zonder het recht "Alle taken bekijken" (bijv. rol Lezer bij een artiest of
    // boeking) blijven alleen taken zichtbaar die aan dit account zijn toegewezen.
    rows = rows?.filter(
      (t) => allows(t.booking_id) || (!!user.id && t.assigned_to === user.id),
    );
    return rows;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query.data, years, bookingId, allows, user.id]);
  return { ...query, data } as typeof query;
}


export function useProfiles() {
  return useQuery({
    queryKey: ["profiles"],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("*").order("name");
      if (error) throw error;
      return data as Profile[];
    },
  });
}

/** Ondertekende URL's voor avatarpaden uit de privé-bucket, gemapt op pad. */
export function useAvatarUrls(paths: (string | null | undefined)[]) {
  const keys = [...new Set(paths.filter((p): p is string => !!p))].sort();
  return useQuery({
    queryKey: ["avatar-urls", keys.join(",")],
    enabled: keys.length > 0,
    staleTime: 30 * 60 * 1000,
    queryFn: async () => {
      const map: Record<string, string> = {};
      const { data } = await supabase.storage.from("avatars").createSignedUrls(keys, 60 * 60);
      (data ?? []).forEach((r) => {
        if (r.path && r.signedUrl) map[r.path] = r.signedUrl;
      });
      return map;
    },
  });
}


/** Teamlid van een boeking, inclusief of de uitnodiging al is geaccepteerd. */
export type TeamMember = Pick<Profile, "id" | "name" | "email" | "phone" | "job_title" | "avatar_url"> & {
  invite_status: "accepted" | "pending";
};

/** Alleen expliciete boekingsleden; makers en artiestbeheerders zijn geen impliciete deelnemers. */
export function useBookingAssignees(bookingId?: string) {
  return useQuery({
    queryKey: ["booking-assignees", bookingId],
    enabled: !!bookingId,
    queryFn: async (): Promise<TeamMember[]> => {
      // Beveiligde functie: geeft het volledige team terug voor iedere rol die
      // de boeking mag zien.
      const { data, error } = await supabase.rpc("booking_team", {
        _booking_id: bookingId!,
      });
      if (error) throw error;
      return (data ?? []) as TeamMember[];
    },
  });
}

/** Activiteiten over financiële gegevens/status zijn alleen voor admins. */
export function isFinancialActivity(a: Pick<Activity, "action">) {
  return a.action.endsWith("_financial");
}

/**
 * Mag dit account de financiële activiteiten van deze boeking zien? Globaal
 * recht, of het recht van de rol die het account bij die boeking heeft.
 */
async function financialActivityAllowed(bookingIds: string[]) {
  const allowed = new Set<string>();
  await Promise.all(
    bookingIds.map(async (id) => {
      const { data } = await supabase.rpc("booking_permission", {
        _booking_id: id,
        _key: "activity.financial.view",
      });
      if (data) allowed.add(id);
    }),
  );
  return allowed;
}

export function useActivity(entityId?: string) {
  const { allowed: globalFinancial } = usePermission("activity.financial.view");
  return useQuery({
    queryKey: ["activity", entityId ?? "all", globalFinancial],
    queryFn: async () => {
      let q = supabase
        .from("activity_log")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(200);
      if (entityId) q = q.eq("entity_id", entityId);
      const { data, error } = await q;
      if (error) throw error;
      const rows = data as Activity[];

      const financialBookings = [
        ...new Set(
          rows
            .filter((a) => isFinancialActivity(a) && a.entity_type === "booking" && a.entity_id)
            .map((a) => a.entity_id as string),
        ),
      ];
      const allowed = await financialActivityAllowed(financialBookings);
      return rows
        .filter(
          (a) =>
            !isFinancialActivity(a) || (a.entity_type === "booking" ? !!a.entity_id && allowed.has(a.entity_id) : globalFinancial),
        )
        .slice(0, 100);
    },
  });
}

export function useActivityItem(id: string) {
  const { allowed: globalFinancial } = usePermission("activity.financial.view");
  return useQuery({
    queryKey: ["activity-item", id, globalFinancial],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("activity_log")
        .select("*")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      const row = data as Activity | null;
      if (!row || !isFinancialActivity(row)) return row;
      if (row.entity_type !== "booking" || !row.entity_id) return globalFinancial ? row : null;
      const allowed = await financialActivityAllowed([row.entity_id]);
      return allowed.has(row.entity_id) ? row : null;
    },
  });
}

export function useWidgets() {
  return useQuery({
    queryKey: ["widgets"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("calendar_widgets")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Widget[];
    },
  });
}

/* --------------------------------- activity --------------------------------- */

export async function logActivity(input: {
  entityType: string;
  entityId?: string | null;
  action: string;
  summary: string;
  changes?: { field: string; from?: string | null; to?: string | null }[];
}) {
  const { data } = await supabase.auth.getUser();
  if (!data.user) return;
  await supabase.from("activity_log").insert({
    user_id: data.user.id,
    entity_type: input.entityType,
    entity_id: input.entityId ?? null,
    action: input.action,
    summary: input.summary,
    changes: input.changes ?? [],
  });
}

export function diffChanges<T extends Record<string, unknown>>(
  before: T,
  after: Partial<T>,
  labels: Record<string, string>,
) {
  const out: { field: string; from: string | null; to: string | null }[] = [];
  for (const key of Object.keys(after)) {
    const from = before[key];
    const to = after[key];
    if (JSON.stringify(from ?? null) !== JSON.stringify(to ?? null)) {
      out.push({
        field: labels[key] ?? key,
        from: from == null ? null : String(from),
        to: to == null ? null : String(to),
      });
    }
  }
  return out;
}

/* --------------------------------- realtime --------------------------------- */

/** Which cached lists a change in a table can affect; unknown tables refresh everything. */
const REALTIME_TABLE_KEYS: Record<string, string[]> = {
  bookings: ["bookings", "booking", "activity", "booking-assignees", "scoped-permission", "scoped-permission-bookings", "can-edit-booking"],
  booking_members: ["bookings", "booking", "booking-assignees", "members", "invitations", "scoped-permission", "scoped-permission-bookings", "can-edit-booking", "statistics-team-members"],
  booking_availability: ["booking", "booking-availability"],
  tasks: ["tasks", "booking"],
  artists: ["artists", "widget-artists", "bookings"],
  artist_members: ["artists", "widget-artists", "members", "scoped-permission", "scoped-permission-artists"],
  performance_standards: ["standards"],
  profiles: ["profiles", "avatar-urls", "booking-assignees", "my-profile", "current-user", "contacts", "invitable-users", "user-detail"],
  notifications: ["notifications", "invitations"],
  calendar_widgets: ["widgets"],
  activity_log: ["activity", "activity-item"],
};

export function useRealtimeSync() {
  const queryClient = useQueryClient();
  useEffect(() => {
    const pending = new Set<string>();
    let timer: ReturnType<typeof setTimeout> | null = null;
    const flush = () => {
      timer = null;
      const tables = [...pending];
      pending.clear();
      const keys = new Set<string>();
      for (const t of tables) {
        const mapped = REALTIME_TABLE_KEYS[t];
        if (!mapped) {
          queryClient.invalidateQueries();
          return;
        }
        mapped.forEach((k) => keys.add(k));
      }
      queryClient.invalidateQueries({
        predicate: (q) => keys.has(String(q.queryKey[0])),
      });
    };
    const channel = supabase
      .channel(`workspace-changes-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "*", schema: "public" }, (payload) => {
        pending.add(payload.table);
        // Bundle bursts of changes (e.g. one save touching several rows) into one refresh.
        if (!timer) timer = setTimeout(flush, 400);
      })
      .subscribe();
    return () => {
      if (timer) clearTimeout(timer);
      supabase.removeChannel(channel);
    };
  }, [queryClient]);
}

/* ---------------------------------- helpers --------------------------------- */

export function formatDate(value?: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString("nl-NL", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

/** Boekingdatum met Nederlandse dagafkorting, bijvoorbeeld: Ma 23 sep 2026. */
export function formatBookingDate(value?: string | null) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  const weekday = date
    .toLocaleDateString("nl-NL", { weekday: "short" })
    .replace(".", "");
  return `${weekday.charAt(0).toUpperCase()}${weekday.slice(1)} ${formatDate(value)}`;
}

/** Toont een veldwaarde met datum (of datum+tijd) in Europese notatie: 03-08-2026. */
export function formatEuroDate(value?: string | null) {
  if (!value) return value ?? "";
  const [datePart, timePart] = value.split("T");
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec((datePart ?? "").trim());
  if (!m) return value;
  const date = `${m[3]}-${m[2]}-${m[1]}`;
  const time = (timePart ?? "").slice(0, 5);
  return time ? `${date} ${time}` : date;
}

export function formatTime(value?: string | null) {
  if (!value) return "—";
  return value.slice(0, 5);
}

/** Sorteerkey die de datum combineert met een optionele HH:MM-tijd. */
export function bookingDateTimeKey(
  date: string | null | undefined,
  time?: string | null | undefined,
) {
  const d = date?.slice(0, 10) ?? "";
  const t = time?.slice(0, 5) || "00:00";
  return `${d}T${t}`;
}

export function formatDateTime(value?: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleString("nl-NL", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function mapsQuery(booking: {
  location_name?: string | null;
  address?: string | null;
  postal_code?: string | null;
  city?: string | null;
}) {
  return [booking.address, booking.postal_code, booking.city, booking.location_name]
    .filter(Boolean)
    .join(", ");
}

/* ------------------------------ standard tasks ------------------------------ */

export interface DefaultTask {
  id: string;
  title: string;
  description?: string;
  daysBefore?: number | null;
}

export function parseDefaultTasks(value: unknown): DefaultTask[] {
  if (!Array.isArray(value)) return [];
  return value as unknown as DefaultTask[];
}

/* ------------------------------ standard team ------------------------------- */

export interface DefaultTeamMember {
  userId: string;
  role: "boeker" | "gebruiker" | "lezer";
}

export function parseDefaultTeam(value: unknown): DefaultTeamMember[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter(
      (m): m is { userId: unknown; role: unknown } =>
        !!m && typeof m === "object" && "userId" in m,
    )
    .map((m) => ({
      userId: String(m.userId),
      role: (m.role === "boeker" || m.role === "gebruiker" ? m.role : "lezer") as
        DefaultTeamMember["role"],
    }))
    .filter((m) => m.userId);
}

/* -------------------------- booking display helpers ------------------------- */

export function useStandardMap() {
  const { data: standards = [] } = useStandards();
  const map = new Map<string, Standard>();
  standards.forEach((s) => map.set(s.id, s));
  return map;
}

/** Begin- en eindtijd uit het eerste tijdveld van de standaard (fallback: kolommen). */
export function bookingTime(
  booking: Pick<Booking, "field_values" | "standard_id" | "start_time" | "end_time">,
  standard?: Standard | null,
) {
  const values = fieldValues(booking.field_values);
  const fields = parseFields(standard?.fields);
  const timeField = fields.find((f) => f.type === "time");
  const raw = timeField ? values[timeField.id] : "";
  if (raw) {
    const [start = "", end = ""] = raw.split("-").map((v) => v.trim());
    return { start, end, label: end ? `${start} – ${end}` : start };
  }
  const start = booking.start_time ? booking.start_time.slice(0, 5) : "";
  const end = booking.end_time ? booking.end_time.slice(0, 5) : "";
  return { start, end, label: start ? (end ? `${start} – ${end}` : start) : "" };
}

/** Begin- en eindtijd uit het speeltijden-veld van de standaard. */
export function bookingPlayTime(
  booking: Pick<Booking, "field_values">,
  standard?: Standard | null,
) {
  const values = fieldValues(booking.field_values);
  const fields = parseFields(standard?.fields);
  const playField =
    fields.find((f) => f.id === "base_play_times") ??
    fields.find((f) => /speeltijd(en)?/i.test(f.label));
  const raw = playField ? values[playField.id] : "";
  if (raw) {
    const [start = "", end = ""] = raw.split("-").map((v) => v.trim());
    return { start, end, label: end ? `${start} – ${end}` : start };
  }
  return { start: "", end: "", label: "" };
}

/** Starttijd uit een tijd-range zoals 'HH:MM - HH:MM'. */
export function timeRangeStart(raw?: string | null): string {
  if (!raw) return "";
  const [start] = raw.split("-").map((v) => v.trim());
  return start;
}

/** Locatietekst uit het eerste kaartveld van de standaard (fallback: kolommen). */
export function bookingLocation(
  booking: Pick<Booking, "field_values" | "location_name" | "address" | "postal_code" | "city">,
  standard?: Standard | null,
) {
  const values = fieldValues(booking.field_values);
  const fields = parseFields(standard?.fields);
  const mapField = fields.find((f) => f.type === "map");
  const raw = mapField ? values[mapField.id] : "";
  return (raw || mapsQuery(booking)).trim();
}

/** Het veld met de evenementnaam binnen een standaard. */
export function eventNameField(fields: StandardField[]) {
  return fields.find((f) => /event\s*naam|evenement\s*naam/i.test(f.label.replace(/-/g, "")));
}


export function mapsUrl(query: string) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}

export function mapsEmbedUrl(query: string) {
  return `https://maps.google.com/maps?q=${encodeURIComponent(query)}&output=embed`;
}

/* -------------------------------- draaiboek -------------------------------- */

export interface RunSheetItem {
  id: string;
  /** Begintijd (HH:MM) */
  time: string;
  /** Eindtijd (HH:MM, optioneel) */
  endTime?: string;
  /** Activiteit */
  title: string;
  description?: string;
}

export function parseRunSheet(value: unknown): RunSheetItem[] {
  if (!Array.isArray(value)) return [];
  return (value as RunSheetItem[]).filter((i) => i && typeof i === "object");
}

export function sortRunSheet(items: RunSheetItem[]) {
  return [...items].sort((a, b) => (a.time || "99:99").localeCompare(b.time || "99:99"));
}

/** "09:00 – 10:00" of alleen de begintijd. */
export function runSheetTimeLabel(item: RunSheetItem) {
  if (item.time && item.endTime) return `${item.time} – ${item.endTime}`;
  return item.time || item.endTime || "";
}

export function newRunSheetItem(): RunSheetItem {
  return {
    id: `r_${Math.random().toString(36).slice(2, 10)}`,
    time: "",
    endTime: "",
    title: "",
    description: "",
  };
}

/** Draaiboek als platte tekst: één regel per gebeurtenis, toelichting eronder. */
export function runSheetToText(items: RunSheetItem[]) {
  return items
    .map((i) => {
      const time = [i.time, i.endTime].filter(Boolean).join(" - ");
      const head = [time, i.title].filter(Boolean).join(" ").trim();
      const desc = (i.description ?? "").trim();
      return desc ? `${head}\n${desc}` : head;
    })
    .join("\n");
}

const RUN_SHEET_LINE =
  /^\s*(\d{1,2}[:.]\d{2})\s*(?:[-–—]\s*(\d{1,2}[:.]\d{2})?)?\s*(.*)$/;

function normalizeTime(value?: string) {
  if (!value) return "";
  const [h = "", m = ""] = value.replace(".", ":").split(":");
  return `${h.padStart(2, "0")}:${m}`;
}

/** Parseert draaiboektekst terug naar regels. Ids zijn stabiel op positie. */
export function parseRunSheetText(text: string): RunSheetItem[] {
  const items: RunSheetItem[] = [];
  for (const raw of text.split("\n")) {
    const line = raw.trim();
    if (!line) continue;
    const match = RUN_SHEET_LINE.exec(line);
    if (match) {
      items.push({
        id: `r_${items.length + 1}`,
        time: normalizeTime(match[1]),
        endTime: normalizeTime(match[2]),
        title: (match[3] ?? "").trim(),
        description: "",
      });
      continue;
    }
    const last = items[items.length - 1];
    if (last) {
      last.description = last.description ? `${last.description}\n${line}` : line;
    } else {
      items.push({ id: `r_${items.length + 1}`, time: "", endTime: "", title: line });
    }
  }
  return items;
}


/* ------------------------------ prijsbepaling ------------------------------ */

/** Prijsregel die aan een boekingsveld gekoppeld kan worden. */
export interface FieldPricing {
  /** Vast bedrag zodra het veld is ingevuld. */
  amount?: number | null;
  /** Bedrag per keuzeoptie (dropdown). */
  options?: Record<string, number>;
  /** Tarief per tijdseenheid (tijdveld begin–eind). */
  rate?: number | null;
  /** Lengte van de tijdseenheid in minuten (standaard 60). */
  unitMinutes?: number | null;
  /** Prijs is afhankelijk van de duur (vast bedrag met staffel). */
  timeBased?: boolean;
  /** Vast bedrag tot en met het maximum aantal uren. */
  baseAmount?: number | null;
  /** Verouderd: bedrag per uur tot het maximum aantal uren. */
  hourlyRate?: number | null;
  /** Maximum aantal uren dat in het vaste bedrag zit. */
  maxHours?: number | null;
  /** Bedrag voor het eerste uur boven het maximum. */
  firstOvertimeRate?: number | null;
  /** Bedrag per uur vanaf het tweede uur boven het maximum. */
  overtimeRate?: number | null;
  /** Id van het tijdveld waarvan de duur gebruikt wordt (leeg = automatisch). */
  timeFieldId?: string | null;
  /** Tijdafhankelijke tarieven per keuzeoptie (keuzelijst). */
  optionTime?: Record<
    string,
    {
      baseAmount?: number | null;
      hourlyRate?: number | null;
      maxHours?: number | null;
      firstOvertimeRate?: number | null;
      overtimeRate?: number | null;
    }
  >;




  /** Bedrag per berekende kilometer (afstandsveld). */
  perKm?: number | null;

  /** Excel-achtige formule die het bedrag van deze regel bepaalt. */
  formula?: string | null;

  /** Veld is uit de prijsbepaling verwijderd (standaardniveau). */
  excluded?: boolean;
}


export const PRICING_TAB = "pricing";
export const PRICING_TAB_LABEL = "Prijsbepaling";

/** Alle tabbladen van een boeking (velden + prijsbepaling) voor een admin. */
export const BOOKING_TABS = [...FIELD_TABS, PRICING_TAB] as string[];
export const BOOKING_TAB_LABELS: Record<string, string> = {
  ...FIELD_TAB_LABELS,
  [PRICING_TAB]: PRICING_TAB_LABEL,
};

const PRICE_KEY = "__price:";
export const PRICE_TOTAL_KEY = `${PRICE_KEY}total`;
/** Veld-ids die in deze boeking uit de prijsbepaling verwijderd zijn. */
export const PRICE_HIDDEN_KEY = `${PRICE_KEY}hidden`;
/** Extra, handmatig toegevoegde prijsregels van deze boeking. */
export const PRICE_EXTRAS_KEY = `${PRICE_KEY}extras`;

export interface PriceExtra {
  id: string;
  label: string;
  amount: string;
}

export function parseHiddenPriceFields(values: Record<string, string>): string[] {
  try {
    const parsed = JSON.parse(values[PRICE_HIDDEN_KEY] ?? "[]");
    return Array.isArray(parsed) ? parsed.filter((v): v is string => typeof v === "string") : [];
  } catch {
    return [];
  }
}

export function serializeHiddenPriceFields(ids: string[]) {
  return JSON.stringify(ids);
}

export function parsePriceExtras(values: Record<string, string>): PriceExtra[] {
  try {
    const parsed = JSON.parse(values[PRICE_EXTRAS_KEY] ?? "[]");
    if (!Array.isArray(parsed)) return [];
    return parsed.map((e, i) => ({
      id: String(e?.id ?? `x_${i + 1}`),
      label: String(e?.label ?? ""),
      amount: e?.amount == null ? "" : String(e.amount),
    }));
  } catch {
    return [];
  }
}

export function serializePriceExtras(extras: PriceExtra[]) {
  return JSON.stringify(extras);
}

export function priceOverrideKey(fieldId: string) {
  return `${PRICE_KEY}${fieldId}`;
}

export function isPriceKey(key: string) {
  return key.startsWith(PRICE_KEY);
}


function toNumber(value: unknown): number | null {
  if (value == null || value === "") return null;
  const n = Number(String(value).replace(/\s|€/g, "").replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

export function formatEuro(amount: number) {
  return new Intl.NumberFormat("nl-NL", {
    style: "currency",
    currency: "EUR",
    minimumFractionDigits: 2,
  }).format(amount);
}

function minutesBetween(raw: string) {
  const [start = "", end = ""] = raw.split("-").map((v) => v.trim());
  if (!start || !end) return 0;
  const [sh = "0", sm = "0"] = start.split(":");
  const [eh = "0", em = "0"] = end.split(":");
  let diff = Number(eh) * 60 + Number(em) - (Number(sh) * 60 + Number(sm));
  if (diff < 0) diff += 24 * 60;
  return diff;
}

export interface PriceLine {
  fieldId: string;
  /** Gezet bij handmatig toegevoegde extra regels. */
  extraId?: string;
  label: string;

  /** Uitleg van de berekening, bijv. "€ 75,00 × 4 u". */
  detail: string;
  /** Berekende prijs volgens de prijsregel. */
  computed: number;
  /** Handmatig overschreven prijs (indien ingevuld). */
  override: number | null;
  /** Het bedrag dat meetelt in het totaal. */
  amount: number;
}

/** Heeft dit veld een prijsregel? */
export function hasPricingRule(f: StandardField) {
  const p = f.pricing;
  if (!p) return false;
  if ((p.formula ?? "").trim()) return true;
  if (p.timeBased) {
    if (
      toNumber(p.baseAmount) != null ||
      toNumber(p.hourlyRate) != null ||
      toNumber(p.firstOvertimeRate) != null ||
      toNumber(p.overtimeRate) != null
    )
      return true;
    if (
      Object.values(p.optionTime ?? {}).some(
        (r) =>
          toNumber(r?.baseAmount) != null ||
          toNumber(r?.hourlyRate) != null ||
          toNumber(r?.firstOvertimeRate) != null ||
          toNumber(r?.overtimeRate) != null,
      )
    )
      return true;
  }



  if (toNumber(p.amount) != null) return true;
  if (toNumber(p.perKm) != null) return true;
  if (toNumber(p.rate) != null) return true;
  return Object.values(p.options ?? {}).some((v) => toNumber(v) != null);
}

/** Haalt het aantal kilometers uit een berekende afstandswaarde ("12,3 km — A → B"). */
export function parseDistanceKm(raw: string): number | null {
  const m = raw.match(/-?\d+(?:[.,]\d+)?/);
  if (!m) return null;
  const n = Number(m[0].replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

/** Aantal uren voor een tijdafhankelijke prijsregel. */
function pricingHours(
  f: StandardField,
  fields: StandardField[],
  values: Record<string, string>,
): number {
  const chosen = f.pricing?.timeFieldId;
  if (chosen) {
    const m = minutesBetween((values[chosen] ?? "").trim());
    return m > 0 ? m / 60 : 0;
  }
  const own = minutesBetween((values[f.id] ?? "").trim());
  if (own > 0) return own / 60;

  for (const other of fields) {
    if (other.type !== "time") continue;
    const m = minutesBetween((values[other.id] ?? "").trim());
    if (m > 0) return m / 60;
  }
  return 0;
}

/**
 * Rekent een eenvoudige, Excel-achtige formule uit: + - * / en haakjes.
 * Verwijzingen naar andere velden of prijsregels staan tussen blokhaken,
 * bijvoorbeeld "=[Kilometers] * 0,35 + [Voorrijkosten]".
 */
export function evaluateFormula(
  input: string,
  resolve: (name: string) => number | null,
): number | null {
  let s = input.trim();
  if (s.startsWith("=")) s = s.slice(1);
  if (!s.trim()) return null;
  let i = 0;
  let failed = false;
  const skip = () => {
    while (i < s.length && /\s/.test(s[i] ?? "")) i++;
  };
  function factor(): number {
    skip();
    const c = s[i];
    if (c === "-") {
      i++;
      return -factor();
    }
    if (c === "+") {
      i++;
      return factor();
    }
    if (c === "(") {
      i++;
      const v = expr();
      skip();
      if (s[i] === ")") i++;
      else failed = true;
      return v;
    }
    if (c === "[") {
      const end = s.indexOf("]", i);
      if (end < 0) {
        failed = true;
        return 0;
      }
      const name = s.slice(i + 1, end);
      i = end + 1;
      const value = resolve(name);
      if (value == null) {
        failed = true;
        return 0;
      }
      return value;
    }
    const match = /^\d+(?:[.,]\d+)?/.exec(s.slice(i));
    if (match?.[0]) {
      i += match[0].length;
      return Number(match[0].replace(",", "."));
    }
    failed = true;
    return 0;
  }
  function term(): number {
    let v = factor();
    for (;;) {
      skip();
      const c = s[i];
      if (c === "*") {
        i++;
        v *= factor();
      } else if (c === "/") {
        i++;
        const d = factor();
        if (!d) {
          failed = true;
          return 0;
        }
        v /= d;
      } else return v;
    }
  }
  function expr(): number {
    let v = term();
    for (;;) {
      skip();
      const c = s[i];
      if (c === "+") {
        i++;
        v += term();
      } else if (c === "-") {
        i++;
        v -= term();
      } else return v;
    }
  }
  const value = expr();
  skip();
  if (failed || i < s.length || !Number.isFinite(value)) return null;
  return Number(value.toFixed(2));
}

/** Numerieke waarde van een boekingsveld (kilometers, uren, bedrag of getal). */
export function fieldNumericValue(
  f: StandardField,
  values: Record<string, string>,
): number | null {
  const raw = (values[f.id] ?? "").trim();
  if (!raw) return null;
  if (f.type === "distance") return parseDistanceKm(raw);
  if (f.type === "time") {
    const m = minutesBetween(raw);
    return m > 0 ? m / 60 : null;
  }
  if (f.type === "boolean") return /^(ja|true|yes)$/i.test(raw) ? 1 : 0;
  return toNumber(raw);
}

/** Zoekt bij een formulenaam de waarde van het bijbehorende veld of prijsregel. */
function formulaResolver(fields: StandardField[], values: Record<string, string>) {
  const byName = new Map<string, StandardField>();
  for (const f of fields) {
    const key = f.label.trim().toLowerCase();
    if (key && !byName.has(key)) byName.set(key, f);
  }
  const cache = new Map<string, number | null>();
  const busy = new Set<string>();
  const resolve = (name: string): number | null => {
    const key = name.trim().toLowerCase();
    if (cache.has(key)) return cache.get(key) ?? null;
    const f = byName.get(key);
    if (!f || busy.has(key)) return null;
    busy.add(key);
    let out: number | null = null;
    if (f.type === "formula") {
      out = (f.formula ?? "").trim() ? evaluateFormula(f.formula ?? "", resolve) : null;
    } else if (hasPricingRule(f) || fieldTab(f) === "pricing") {
      const override = toNumber(values[priceOverrideKey(f.id)]);
      const result = computeFieldPrice(f, fields, values, resolve);
      out = override ?? (result.applies ? result.computed : null);
    } else {
      out = fieldNumericValue(f, values);
    }
    busy.delete(key);
    cache.set(key, out);
    return out;
  };
  return resolve;
}

/** Uitkomst van een rekenveld (veldtype Formule) binnen een boeking. */
export function evaluateFieldFormula(
  f: StandardField,
  fields: StandardField[],
  values: Record<string, string>,
): number | null {
  const formula = (f.formula ?? "").trim();
  if (!formula) return null;
  return evaluateFormula(formula, formulaResolver(fields, values));
}

/** Berekent één prijsregel van een boeking. */
function computeFieldPrice(
  f: StandardField,
  fields: StandardField[],
  values: Record<string, string>,
  resolve: (name: string) => number | null,
): { computed: number; detail: string; applies: boolean } {
  const tab = fieldTab(f);
  const p = f.pricing;
  const raw = (values[f.id] ?? "").trim();
  let computed = 0;
  let detail = "";
  let applies = false;

  const formula = (p?.formula ?? "").trim();
  if (formula) {
    const value = evaluateFormula(formula, resolve);
    if (value != null) return { computed: value, detail: formula, applies: true };
    return { computed: 0, detail: "Formule kan nog niet berekend worden", applies: false };
  }

  if (p?.timeBased) {
    // Bij een keuzelijst gelden de tarieven van de gekozen optie.
    const optionRule = f.type === "dropdown" && raw ? p.optionTime?.[raw] : undefined;
    const useOptions = f.type === "dropdown" && !!p.optionTime;
    const rule = optionRule ?? (useOptions ? undefined : p);
    const maxHours = toNumber(rule?.maxHours);
    const legacyHourly = toNumber(rule?.hourlyRate);
    // Vast bedrag tot het maximum aantal uren (oude uurtarieven worden omgerekend).
    const baseAmount =
      toNumber(rule?.baseAmount) ??
      (legacyHourly != null && maxHours != null ? legacyHourly * maxHours : legacyHourly) ??
      0;
    const overtime = toNumber(rule?.overtimeRate) ?? 0;
    // Tarief voor het eerste uur boven het maximum (leeg = zelfde als daarboven).
    const firstOvertime = toNumber(rule?.firstOvertimeRate) ?? overtime;
    const hours = pricingHours(f, fields, values);
    if (rule && hours > 0 && (baseAmount || overtime || firstOvertime)) {
      const extra = maxHours != null ? Math.max(0, hours - maxHours) : 0;
      // Eerste uur na het vaste aantal uren wordt altijd naar boven afgerond.
      const firstHour = extra > 0 ? 1 : 0;
      const restHours = Math.max(0, extra - 1);

      computed = baseAmount + firstHour * firstOvertime + restHours * overtime;
      const round = (n: number) => Number(n.toFixed(2));
      detail = `${optionRule ? `${raw}: ` : ""}${formatEuro(baseAmount)}${
        maxHours != null ? ` tot ${round(maxHours)} u` : ""
      }`;
      if (firstHour > 0)
        detail += ` + ${formatEuro(firstOvertime)} × ${round(firstHour)} u (1e uur extra)`;
      if (restHours > 0) detail += ` + ${formatEuro(overtime)} × ${round(restHours)} u extra`;
      applies = true;
    }
  } else if (tab === "pricing") {
    // Eigen prijsregel: geldt altijd, met het ingestelde bedrag.
    const fixed = toNumber(p?.amount);
    computed = fixed ?? 0;
    applies = true;
  } else if (p) {
    if (f.type === "dropdown" && raw) {
      const optionAmount = toNumber(p.options?.[raw]);
      if (optionAmount != null) {
        computed = optionAmount;
        detail = raw;
        applies = true;
      }
    } else if (f.type === "distance") {
      const perKm = toNumber(p.perKm);
      const km = parseDistanceKm(raw);
      if (perKm != null && km != null && km > 0) {
        computed = perKm * km;
        detail = `${formatEuro(perKm)} × ${Number(km.toFixed(1))} km`;
        applies = true;
      }
    } else if (f.type === "time") {
      const rate = toNumber(p.rate);
      const unit = toNumber(p.unitMinutes) || 60;
      const minutes = minutesBetween(raw);
      if (rate != null && minutes > 0) {
        const units = minutes / unit;
        computed = rate * units;
        detail = `${formatEuro(rate)} × ${Number(units.toFixed(2))} ${
          unit === 60 ? "u" : `× ${unit} min`
        }`;
        applies = true;
      }
    }
    if (!applies) {
      const fixed = toNumber(p.amount);
      const filled = f.type === "boolean" ? /^(ja|true|yes)$/i.test(raw) : raw !== "";
      if (fixed != null && filled) {
        computed = fixed;
        detail = raw && f.type !== "boolean" ? raw : "";
        applies = true;
      }
    }
  }

  return { computed, detail, applies };
}

/** Berekent de prijsregels van een boeking op basis van de standaardvelden. */
export function priceLines(
  fields: StandardField[],
  values: Record<string, string>,
): PriceLine[] {
  const lines: PriceLine[] = [];
  const hidden = parseHiddenPriceFields(values);
  const resolve = formulaResolver(fields, values);
  for (const f of fields) {
    const tab = fieldTab(f);
    if (tab === "financial") continue;
    if (hidden.includes(f.id)) continue;
    if (f.pricing?.excluded) continue;
    const override = toNumber(values[priceOverrideKey(f.id)]);
    const { computed, detail, applies } = computeFieldPrice(f, fields, values, resolve);

    if (!applies && override == null) continue;
    lines.push({
      fieldId: f.id,
      label: f.label || "Naamloze regel",
      detail,
      computed,
      override,
      amount: override ?? computed,
    });
  }

  for (const extra of parsePriceExtras(values)) {
    const amount = toNumber(extra.amount) ?? 0;
    lines.push({
      fieldId: `extra:${extra.id}`,
      extraId: extra.id,
      label: extra.label || "Extra regel",
      detail: "",
      computed: amount,
      override: null,
      amount,
    });
  }
  return lines;
}


/**
 * Totale offerteprijs. De offerteprijs is alleen het bedrag dat handmatig is
 * ingevuld; zolang dat veld leeg is blijft de offerteprijs leeg (manual = null)
 * en staat alleen de berekende som klaar.
 */
export function priceTotal(lines: PriceLine[], values: Record<string, string>) {
  const sum = lines.reduce((acc, l) => acc + l.amount, 0);
  const manual = toNumber(values[PRICE_TOTAL_KEY]);
  return { sum, manual, total: manual ?? sum, overridden: manual != null };
}

/** Pseudo veld-id voor het draaiboek in de gegevensblad-uitsluitingen. */
export const RUN_SHEET_SHEET_ID = "__run_sheet";

/** Staat het draaiboek in het gegevensblad van deze boeking? */
export function runSheetInSheet(values: Record<string, string>) {
  if (values[SHEET_EXCLUDE_KEY] === undefined) return true;
  return !sheetExcluded(values).includes(RUN_SHEET_SHEET_ID);
}
