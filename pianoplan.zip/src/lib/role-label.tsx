import { useRoleLabels, type AppRole } from "@/lib/roles";

export function RoleLabel({ role }: { role: AppRole | string }) {
  const labels = useRoleLabels();
  return <>{labels[role as AppRole] ?? role}</>;
}
