import * as React from 'react'
import { Body, Button, Container, Head, Heading, Hr, Html, Preview, Section, Text } from '@react-email/components'

export interface BookingEmailProps {
  name?: string
  eventName?: string
  artistName?: string
  date?: string
  location?: string
  status?: string
  url?: string
}

export function BookingEmailLayout({ preview, title, intro, props }: { preview: string; title: string; intro: string; props: BookingEmailProps }) {
  const rows: [string, string | undefined][] = [
    ['Evenement', props.eventName],
    ['Artiest', props.artistName],
    ['Datum', props.date],
    ['Locatie', props.location],
    ['Status', props.status],
  ]
  return (
    <Html lang="nl" dir="ltr">
      <Head />
      <Preview>{preview}</Preview>
      <Body style={main}>
        <Container style={container}>
          <Text style={brand}>PodiumPlan</Text>
          <Heading style={h1}>{title}</Heading>
          <Text style={text}>{props.name ? `Hoi ${props.name},` : 'Hoi,'}</Text>
          <Text style={text}>{intro}</Text>
          <Section style={card}>
            {rows.filter(([, v]) => v).map(([label, value]) => (
              <Text key={label} style={row}><span style={labelStyle}>{label}: </span>{value}</Text>
            ))}
          </Section>
          {props.url && <Button href={props.url} style={button}>Bekijk boeking</Button>}
          <Hr style={hr} />
          <Text style={footer}>Je ontvangt deze e-mail omdat je dit hebt ingesteld bij Gebruiksinstellingen in PodiumPlan.</Text>
        </Container>
      </Body>
    </Html>
  )
}

const main = { backgroundColor: '#ffffff', fontFamily: "Manrope, Arial, Helvetica, sans-serif" }
const container = { padding: '28px 24px', maxWidth: '560px' }
const brand = { fontSize: '13px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' as const, color: '#1f4e8c', margin: '0 0 16px' }
const h1 = { fontSize: '22px', color: '#141c2b', margin: '0 0 16px' }
const text = { fontSize: '15px', lineHeight: '22px', color: '#475569', margin: '0 0 12px' }
const card = { backgroundColor: '#f5f7fa', border: '1px solid #e2e8f0', borderRadius: '10px', padding: '12px 16px', margin: '16px 0 20px' }
const row = { fontSize: '14px', color: '#141c2b', margin: '4px 0' }
const labelStyle = { color: '#64748b' }
const button = { backgroundColor: '#1f4e8c', color: '#ffffff', borderRadius: '8px', padding: '12px 20px', fontSize: '14px', fontWeight: 600, textDecoration: 'none' }
const hr = { borderColor: '#e2e8f0', margin: '28px 0 12px' }
const footer = { fontSize: '12px', color: '#94a3b8' }
