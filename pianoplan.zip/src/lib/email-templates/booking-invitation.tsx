import * as React from 'react'
import type { TemplateEntry } from './registry'
import { BookingEmailLayout, type BookingEmailProps } from './booking-email-layout'

const Email = (props: BookingEmailProps & { inviter?: string }) => (
  <BookingEmailLayout
    preview={`Uitnodiging voor ${props.eventName ?? 'een boeking'}`}
    title="Je bent uitgenodigd voor een boeking"
    intro={`${props.inviter ?? 'Iemand'} heeft je uitgenodigd voor het team van deze boeking. Open de boeking om je beschikbaarheid door te geven.`}
    props={props}
  />
)

export const template = {
  component: Email,
  subject: (d: Record<string, any>) => `Uitnodiging: ${d.eventName ?? 'boeking'}`,
  displayName: 'Uitnodiging voor boeking',
  previewData: { name: 'Gijs', inviter: 'Sanne', eventName: 'Zomerconcert', artistName: 'Het Trio', date: '12 juli 2026', location: 'Amsterdam', url: 'https://podiumplan.gijshaanskorf.nl' },
} satisfies TemplateEntry
