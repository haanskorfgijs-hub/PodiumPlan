import * as React from 'react'
import type { TemplateEntry } from './registry'
import { BookingEmailLayout, type BookingEmailProps } from './booking-email-layout'

const Email = (props: BookingEmailProps) => (
  <BookingEmailLayout
    preview={`Nieuwe status: ${props.status ?? ''}`}
    title={`Status gewijzigd naar ${props.status ?? 'een nieuwe status'}`}
    intro="De status van een boeking waar je bij betrokken bent is gewijzigd."
    props={props}
  />
)

export const template = {
  component: Email,
  subject: (d: Record<string, any>) => `Status ${d.eventName ?? 'boeking'}: ${d.status ?? 'gewijzigd'}`,
  displayName: 'Statuswijziging boeking',
  previewData: { name: 'Gijs', eventName: 'Zomerconcert', artistName: 'Het Trio', date: '12 juli 2026', location: 'Amsterdam', status: 'Bevestigd', url: 'https://podiumplan.gijshaanskorf.nl' },
} satisfies TemplateEntry
