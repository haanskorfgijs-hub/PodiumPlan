export type StatusColor = "green" | "amber" | "blue" | "red" | "purple" | "gray";
export type StatusStage = "create" | "edit" | "after";
export interface ArtistStatus {
  id: string;
  label: string;
  color: StatusColor;
  stage?: StatusStage;
}

export function defaultArtistStatuses(): ArtistStatus[] {
  return [
    { id: crypto.randomUUID(), label: "Optie", color: "amber", stage: "create" },
    { id: crypto.randomUUID(), label: "Definitief", color: "green", stage: "create" },
    { id: crypto.randomUUID(), label: "Geannuleerd", color: "red", stage: "edit" },
    { id: crypto.randomUUID(), label: "Afgerond", color: "gray", stage: "after" },
  ];
}

export function bookingStatusLabel(booking: { artist_status?: string | null }) {
  return booking.artist_status ?? "";
}

export function isCancelledBooking(booking: { artist_status?: string | null }) {
  return /geannuleerd|afgezegd/i.test(bookingStatusLabel(booking));
}

export function isCompletedBooking(booking: { artist_status?: string | null }) {
  return bookingStatusLabel(booking).trim().toLowerCase() === "afgerond";
}

export function isActiveBooking(booking: { artist_status?: string | null }) {
  return !!bookingStatusLabel(booking) && !isCancelledBooking(booking) && !isCompletedBooking(booking);
}