import { useCallback, useEffect, useState } from "react";

export function useColumnOrder(storageKey: string, defaults: string[]) {
  const [order, setOrder] = useState<string[]>(defaults);
  const [dragging, setDragging] = useState<string | null>(null);

  const defaultsKey = defaults.join("|");

  useEffect(() => {
    const all = defaultsKey ? defaultsKey.split("|") : [];
    try {
      const raw = window.localStorage.getItem(storageKey);
      if (!raw) {
        setOrder(all);
        return;
      }
      const saved = JSON.parse(raw) as string[];
      if (!Array.isArray(saved)) {
        setOrder(all);
        return;
      }
      const kept = saved.filter((k) => all.includes(k));
      const missing = all.filter((k) => !kept.includes(k));
      setOrder([...kept, ...missing]);
    } catch {
      setOrder(all);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storageKey, defaultsKey]);


  const persist = useCallback(
    (next: string[]) => {
      setOrder(next);
      try {
        window.localStorage.setItem(storageKey, JSON.stringify(next));
      } catch {
        /* ignore */
      }
    },
    [storageKey],
  );

  const move = useCallback(
    (from: string, to: string) => {
      if (from === to) return;
      setOrder((prev) => {
        const next = prev.filter((k) => k !== from);
        const idx = next.indexOf(to);
        next.splice(idx < 0 ? next.length : idx, 0, from);
        try {
          window.localStorage.setItem(storageKey, JSON.stringify(next));
        } catch {
          /* ignore */
        }
        return next;
      });
    },
    [storageKey],
  );

  const reset = useCallback(() => persist(defaults), [persist, defaults]);

  const dragProps = useCallback(
    (key: string) => ({
      draggable: true,
      onDragStart: (e: React.DragEvent) => {
        setDragging(key);
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/plain", key);
      },
      onDragOver: (e: React.DragEvent) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = "move";
      },
      onDrop: (e: React.DragEvent) => {
        e.preventDefault();
        const from = e.dataTransfer.getData("text/plain") || dragging;
        if (from) move(from, key);
        setDragging(null);
      },
      onDragEnd: () => setDragging(null),
      "data-dragging": dragging === key ? "true" : undefined,
    }),
    [dragging, move],
  );

  return { order, dragProps, dragging, reset };
}
