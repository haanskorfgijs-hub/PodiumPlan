import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type AppRole = Database["public"]["Enums"]["app_role"];

export const ROLES: AppRole[] = ["admin", "host", "boeker", "gebruiker", "lezer"];

export const ROLE_LABELS: Record<AppRole, string> = {
  admin: "Admin",
  host: "Nieuw accounttype",
  boeker: "Boeker",
  gebruiker: "Manager",
  lezer: "Lezer",
};

export function useMyRole() {
  return useQuery({
    queryKey: ["my-role"],
    queryFn: async (): Promise<AppRole | null> => {
      const { data: auth } = await supabase.auth.getUser();
      if (!auth.user) return null;
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", auth.user.id)
        .maybeSingle();
      return (data?.role as AppRole) ?? null;
    },
  });
}


export function useIsReader() {
  const { data, isLoading } = useMyRole();
  return { isReader: data === "lezer", isLoading };
}

/** Boeker: zelfde rechten als Gebruiker, maar mag geen artiesten of standaarden aanmaken. */
export function useIsBoeker() {
  const { data, isLoading } = useMyRole();
  return { isBoeker: data === "boeker", isLoading };
}

/** Mag de huidige gebruiker nieuwe artiesten en optredenstandaarden aanmaken? */
export function useCanCreateArtists() {
  const { data, isLoading } = useMyRole();
  return { canCreate: data !== "lezer" && data !== "boeker", isLoading };
}

/** Rollen met dezelfde rechten als Gebruiker (inclusief Boeker). */
export function isEditorRole(role?: AppRole | null) {
  return role === "gebruiker" || role === "boeker";
}

/** Mag de huidige gebruiker deze boeking aanpassen (eigenaar, admin of lid met rol gebruiker)? */
export function useCanEditBooking(bookingId?: string) {
  const { data, isLoading } = useQuery({
    queryKey: ["can-edit-booking", bookingId],
    enabled: !!bookingId,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("can_edit_booking", {
        _booking_id: bookingId!,
      });
      if (error) throw error;
      return !!data;
    },
  });
  return { canEdit: !!data, isLoading };
}


export function useUserRoles() {
  return useQuery({
    queryKey: ["user-roles"],
    queryFn: async () => {
      const { data, error } = await supabase.from("user_roles").select("user_id, role");
      if (error) throw error;
      return data as { user_id: string; role: AppRole }[];
    },
  });
}

/** Aanpasbare namen van accounttypes; valt terug op de standaardnamen. */
export function useRoleLabels() {
  const { data } = useQuery({
    queryKey: ["role-labels"],
    queryFn: async () => {
      const { data, error } = await supabase.from("role_labels").select("role, label");
      if (error) throw error;
      return data as { role: AppRole; label: string }[];
    },
  });
  const labels = { ...ROLE_LABELS };
  for (const row of data ?? []) labels[row.role] = row.label;
  return labels;
}

export function useSetRoleLabel() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ role, label }: { role: AppRole; label: string }) => {
      const { error } = await supabase
        .from("role_labels")
        .upsert({ role, label: label.trim(), updated_at: new Date().toISOString() });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["role-labels"] }),
  });
}
