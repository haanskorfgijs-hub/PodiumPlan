import { formatEuro, priceLines, priceTotal, type StandardField, type PriceLine } from "@/lib/data";

export type PricingChange = { field: string; from: string | null; to: string | null };

/** Store readable snapshots, not internal price keys or serialized extra rules. */
export function pricingChanges(
  beforeFields: StandardField[],
  afterFields: StandardField[],
  before: Record<string, string>,
  after: Record<string, string>,
): PricingChange[] {
  const oldLines = priceLines(beforeFields, before);
  const newLines = priceLines(afterFields, after);
  const oldById = new Map(oldLines.map((line) => [line.fieldId, line]));
  const newById = new Map(newLines.map((line) => [line.fieldId, line]));
  const changes: PricingChange[] = [];
  const describe = (line: PriceLine) => {
    const mode = line.extraId ? "extra regel" : line.override != null ? "handmatig" : "berekend";
    return `${formatEuro(line.amount)} (${mode})`;
  };
  for (const id of new Set([...oldById.keys(), ...newById.keys()])) {
    const oldLine = oldById.get(id);
    const newLine = newById.get(id);
    const label = newLine?.label ?? oldLine?.label ?? "Naamloze regel";
    if (!oldLine || !newLine) {
      changes.push({
        field: `${label} — ${newLine ? "regel toegevoegd" : "regel verwijderd"}`,
        from: oldLine ? describe(oldLine) : null,
        to: newLine ? describe(newLine) : null,
      });
      continue;
    }
    if (oldLine.label !== newLine.label) {
      changes.push({ field: `${oldLine.label} — omschrijving`, from: oldLine.label, to: newLine.label });
    }
    const from = describe(oldLine);
    const to = describe(newLine);
    if (from !== to) changes.push({ field: `${label} — bedrag`, from, to });
    if (oldLine.detail !== newLine.detail) {
      changes.push({ field: `${label} — berekening`, from: oldLine.detail || null, to: newLine.detail || null });
    }
  }
  const oldTotal = priceTotal(oldLines, before);
  const newTotal = priceTotal(newLines, after);
  if (oldTotal.sum !== newTotal.sum) {
    changes.push({ field: "Berekende prijs", from: formatEuro(oldTotal.sum), to: formatEuro(newTotal.sum) });
  }
  // De offerteprijs is leeg zolang die niet handmatig is ingevuld.
  const describeTotal = (total: ReturnType<typeof priceTotal>) =>
    total.manual == null ? null : formatEuro(total.manual);
  const oldOffer = describeTotal(oldTotal);
  const newOffer = describeTotal(newTotal);
  if (oldOffer !== newOffer) {
    changes.push({ field: "Offerteprijs", from: oldOffer, to: newOffer });
  }
  return changes;
}