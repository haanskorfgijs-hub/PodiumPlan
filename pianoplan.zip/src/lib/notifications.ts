import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useNotificationAccess } from "@/lib/permissions";

export type Notification = {
  id: string;
  type: string;
  title: string;
  body: string;
  link: string | null;
  read_at: string | null;
  created_at: string;
};

/**
 * Meldingen voor de ingelogde gebruiker (nieuwste eerst).
 * Ongelezen meldingen plus uitnodigingen die nog open staan: die blijven
 * zichtbaar tot de uitnodiging is geaccepteerd of afgewezen.
 */
export function useNotifications() {
  const canSee = useNotificationAccess();
  const queryClient = useQueryClient();

  // Nieuwe meldingen (zoals uitnodigingen) direct binnenhalen zonder herladen.
  useEffect(() => {
    const channel = supabase
      .channel(`notifications-inbox-${Math.random().toString(36).slice(2)}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "notifications" },
        () => {
          queryClient.invalidateQueries({ queryKey: ["notifications"] });
          queryClient.invalidateQueries({ queryKey: ["invitations"] });
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [queryClient]);

  return useQuery({
    // Realtime delivers new notifications; no background polling, so the
    // database can hibernate when the app sits idle.
    refetchOnWindowFocus: true,
    queryKey: ["notifications"],
    queryFn: async () => {
      const [{ data, error }, { data: invites, error: inviteError }] = await Promise.all([
        supabase
          .from("notifications")
          .select("id, type, title, body, link, read_at, created_at")
          .or("read_at.is.null,type.eq.invite")
          .order("created_at", { ascending: false })
          .limit(100),
        supabase.rpc("my_invitations"),
      ]);
      if (error) throw error;
      if (inviteError) throw inviteError;
      const openTitles = new Set(
        ((invites ?? []) as { title: string | null }[]).map((i) => (i.title ?? "").trim()),
      );
      const rows = (data ?? []) as Notification[];
      return rows.filter(
        (n) =>
          canSee(n.type) &&
          (n.type === "invite" ? openTitles.has((n.body ?? "").trim()) : !n.read_at),
      );
    },
  });
}

/** Uitnodigingsmeldingen blijven staan tot de uitnodiging is behandeld. */
export function isPersistentNotification(n: Pick<Notification, "type">) {
  return n.type === "invite";
}


export function useMarkNotificationsRead() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (ids: string[] | null) => {
      const { error } = await supabase.rpc("mark_notifications_read", {
        _ids: ids as unknown as string[],
      });
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["notifications"] }),
  });
}
