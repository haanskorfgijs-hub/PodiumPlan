/** Booking editing never grants financial access; that requires its separate permission. */
export function bookingDataTabs(canEdit: boolean, _isAdmin: boolean, canViewFinancial: boolean, canViewPricing: boolean): string[] {
  return ["booking", ...(canViewFinancial ? ["financial"] : []), ...(canEdit || canViewPricing ? ["pricing"] : [])];
}