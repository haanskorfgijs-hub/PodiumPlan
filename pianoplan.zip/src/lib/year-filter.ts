import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

/**
 * Globale jaarfilter: geldt op alle pagina's en wordt per account onthouden
 * (localStorage, gekoppeld aan het gebruikers-id, dus ook na opnieuw inloggen).
 */

// Versie 2 wist de oude, domeingebonden jaarselectie die op de gepubliceerde
// site ongemerkt boekingen bleef verbergen. Nieuwe keuzes worden weer bewaard.
const PREFIX = "stagehand:year-filter:v2:";

let userId: string | null = null;
let years: number[] = [];
const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((l) => l());
}

function load(id: string) {
  try {
    const raw = localStorage.getItem(PREFIX + id);
    const parsed = raw ? (JSON.parse(raw) as unknown) : null;
    years = Array.isArray(parsed) ? parsed.filter((y) => typeof y === "number") : [];
  } catch {
    years = [];
  }
  emit();
}

let initialized = false;
function init() {
  if (initialized || typeof window === "undefined") return;
  initialized = true;
  supabase.auth.getUser().then(({ data }) => {
    userId = data.user?.id ?? null;
    if (userId) load(userId);
  });
  supabase.auth.onAuthStateChange((_event, session) => {
    const next = session?.user?.id ?? null;
    if (next === userId) return;
    userId = next;
    if (userId) load(userId);
    else {
      years = [];
      emit();
    }
  });
}

function setYears(next: number[]) {
  years = [...new Set(next)].sort((a, b) => a - b);
  emit();
  if (userId) {
    try {
      localStorage.setItem(PREFIX + userId, JSON.stringify(years));
    } catch {
      /* ignore */
    }
  }
}

export function useYearFilter() {
  const [value, setValue] = useState<number[]>(years);

  useEffect(() => {
    init();
    const listener = () => setValue(years);
    listeners.add(listener);
    listener();
    return () => {
      listeners.delete(listener);
    };
  }, []);

  const toggleYear = useCallback((year: number) => {
    setYears(years.includes(year) ? years.filter((y) => y !== year) : [...years, year]);
  }, []);

  return { years: value, setYears, toggleYear, clear: () => setYears([]) };
}

/** True als de datum binnen de geselecteerde jaren valt (leeg = alles tonen). */
export function matchesYearFilter(date: string | null | undefined, selected: number[]) {
  if (selected.length === 0) return true;
  if (!date) return false;
  const year = Number(String(date).slice(0, 4));
  return selected.includes(year);
}
