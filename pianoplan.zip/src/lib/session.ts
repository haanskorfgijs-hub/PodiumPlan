import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function useCurrentUser() {
  const { data } = useQuery({
    queryKey: ["current-user"],
    queryFn: async () => {
      const { data: auth } = await supabase.auth.getUser();
      if (!auth.user) return null;
      const { data: profile } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", auth.user.id)
        .maybeSingle();
      let avatarUrl: string | null = null;
      if (profile?.avatar_url) {
        const { data: signed } = await supabase.storage
          .from("avatars")
          .createSignedUrl(profile.avatar_url, 60 * 60);
        avatarUrl = signed?.signedUrl ?? null;
      }
      return {
        id: auth.user.id,
        email: auth.user.email ?? "",
        name: profile?.name ?? auth.user.user_metadata?.name ?? "",
        avatarUrl,
      };
    },
  });
  return data ?? { id: "", email: "", name: "", avatarUrl: null as string | null };
}
