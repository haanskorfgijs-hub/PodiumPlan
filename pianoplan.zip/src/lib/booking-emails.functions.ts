import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { normalizeEmailNotificationPreferences, wantsBookingInvitationEmail, wantsBookingStatusEmail } from "@/lib/email-notification-preferences";

type Input = { bookingId: string; kind: "invitation" | "status" };

const APP_URL = "https://podiumplan.gijshaanskorf.nl";

/**
 * Sends booking emails for an event the caller just caused. The server
 * re-reads the booking and recipients itself; the browser only says which
 * booking changed. Idempotency keys make repeated calls harmless.
 */
export const sendBookingEmails = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: Input) => {
    if (!input || typeof input.bookingId !== "string" || !/^[0-9a-f-]{36}$/i.test(input.bookingId)) throw new Error("Ongeldige boeking");
    if (input.kind !== "invitation" && input.kind !== "status") throw new Error("Ongeldig type");
    return input;
  })
  .handler(async ({ data, context }) => {
    // Caller must be able to see the booking.
    const { data: visible } = await context.supabase.from("bookings").select("id").eq("id", data.bookingId).maybeSingle();
    if (!visible) return { sent: 0 };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");

    const { data: booking } = await supabaseAdmin
      .from("bookings")
      .select("id, event_name, event_date, location_name, city, artist_status, updated_at, artist_id, artists(name)")
      .eq("id", data.bookingId)
      .maybeSingle();
    if (!booking) return { sent: 0 };

    const status = booking.artist_status ?? "";
    const wantedStatus = data.kind === "invitation" ? "pending" : "accepted";
    const { data: members } = await supabaseAdmin
      .from("booking_members")
      .select("id, user_id, status")
      .eq("booking_id", booking.id)
      .eq("status", wantedStatus);
    const recipients = (members ?? []).filter((m) => m.user_id !== context.userId);
    if (!recipients.length) return { sent: 0 };

    const ids = recipients.map((m) => m.user_id);
    const [{ data: profiles }, { data: prefRows }, { data: me }] = await Promise.all([
      supabaseAdmin.from("profiles").select("id, name, email").in("id", ids),
      (supabaseAdmin as any).from("email_notification_preferences").select("user_id, booking_invitations, status_changes, statuses").in("user_id", ids),
      supabaseAdmin.from("profiles").select("name").eq("id", context.userId).maybeSingle(),
    ]);

    const common = {
      eventName: booking.event_name,
      artistName: (booking as any).artists?.name ?? undefined,
      date: new Date(booking.event_date).toLocaleDateString("nl-NL", { day: "numeric", month: "long", year: "numeric" }),
      location: [booking.location_name, booking.city].filter(Boolean).join(", ") || undefined,
      status,
      url: `${APP_URL}/bookings/${booking.id}`,
    };

    let sent = 0;
    for (const member of recipients) {
      const profile = profiles?.find((p) => p.id === member.user_id);
      const row = (prefRows as any[] | null)?.find((p) => p.user_id === member.user_id);
      if (!profile?.email || !row) continue;
      const prefs = normalizeEmailNotificationPreferences({ bookingInvitations: row.booking_invitations, statusChanges: row.status_changes, statuses: row.statuses });
      try {
        if (data.kind === "invitation") {
          if (!wantsBookingInvitationEmail(prefs)) continue;
          const r = await sendTemplateEmail("booking-invitation", profile.email, {
            templateData: { ...common, name: profile.name, inviter: me?.name },
            idempotencyKey: `booking-invitation-${member.id}`,
          });
          if (r.sent) sent++;
        } else {
          if (!wantsBookingStatusEmail(prefs, status)) continue;
          const r = await sendTemplateEmail("booking-status-change", profile.email, {
            templateData: { ...common, name: profile.name },
            idempotencyKey: `booking-status-${booking.id}-${member.user_id}-${booking.updated_at}`,
          });
          if (r.sent) sent++;
        }
      } catch (error) {
        console.error("Booking email failed", error);
      }
    }
    return { sent };
  });
