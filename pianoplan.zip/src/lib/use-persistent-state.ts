import { useState, useEffect } from "react";
import { useCurrentUser } from "@/lib/session";

export function usePersistentState<T>(
  key: string,
  initialValue: T,
): [T, (value: T | ((prev: T) => T)) => void] {
  const [state, setState] = useState<T>(initialValue);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    // Reset bij sleutelwijziging, zodat de vorige waarde nooit onder de
    // nieuwe sleutel wordt weggeschreven.
    setLoaded(false);
    setState(initialValue);
    try {
      const raw = localStorage.getItem(key);
      if (raw) setState(JSON.parse(raw) as T);
    } catch {
      /* ignore corrupt storage */
    }
    setLoaded(true);
    // initialValue is een stabiele standaard; alleen de sleutel stuurt herladen.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  useEffect(() => {
    if (!loaded) return;
    try {
      localStorage.setItem(key, JSON.stringify(state));
    } catch {
      /* ignore */
    }
  }, [key, state, loaded]);

  return [state, setState];
}

/**
 * Persistent state per account: de sleutel krijgt het gebruikers-id als
 * achtervoegsel, zodat elke gebruiker (ook na accountwissel) de eigen
 * keuze terugziet. Zonder ingelogde gebruiker wordt er niets bewaard.
 */
export function useUserPersistentState<T>(
  key: string,
  initialValue: T,
): [T, (value: T | ((prev: T) => T)) => void] {
  const user = useCurrentUser();
  const scopedKey = user.id ? `${key}:${user.id}` : `${key}:__anonymous__`;
  return usePersistentState(scopedKey, initialValue);
}
