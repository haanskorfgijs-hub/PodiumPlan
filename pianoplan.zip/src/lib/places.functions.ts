import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export interface PlaceSuggestion {
  id: string;
  name: string;
  address: string;
}

export const searchPlaces = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) => z.object({ query: z.string().min(2).max(200) }).parse(data))
  .handler(async ({ data }): Promise<PlaceSuggestion[]> => {
    const lovableKey = process.env.LOVABLE_API_KEY;
    const mapsKey = process.env.GOOGLE_MAPS_API_KEY;
    if (!lovableKey || !mapsKey) throw new Error("Google Maps koppeling ontbreekt");

    const response = await fetch(
      "https://connector-gateway.lovable.dev/google_maps/places/v1/places:searchText",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${lovableKey}`,
          "X-Connection-Api-Key": mapsKey,
          "Content-Type": "application/json",
          "X-Goog-FieldMask": "places.id,places.displayName,places.formattedAddress",
        },
        body: JSON.stringify({ textQuery: data.query, languageCode: "nl", maxResultCount: 6 }),
      },
    );

    if (response.status === 403) {
      const details: Array<{ reason?: string }> =
        ((await response.json()) as { error?: { details?: Array<{ reason?: string }> } })?.error
          ?.details ?? [];
      const reason = details.find((d) => d.reason)?.reason;
      if (reason === "API_KEY_HTTP_REFERRER_BLOCKED") {
        throw new Error(
          'Google Maps-sleutel is referrer-beperkt. Zet de applicatiebeperking van de serversleutel op "Geen" of "IP-adressen".',
        );
      }
      if (reason === "API_KEY_SERVICE_BLOCKED") {
        throw new Error(
          "Google Maps-sleutel staat de Places API niet toe. Voeg deze API toe aan de toegestane API's van de serversleutel.",
        );
      }
      throw new Error("Google Maps-verzoek geweigerd (403).");
    }

    if (!response.ok) {
      const body = await response.text();
      throw new Error(`Places-verzoek mislukt [${response.status}]: ${body}`);
    }

    const json = (await response.json()) as {
      places?: Array<{
        id?: string;
        displayName?: { text?: string };
        formattedAddress?: string;
      }>;
    };

    return (json.places ?? []).map((p, i) => ({
      id: p.id ?? String(i),
      name: p.displayName?.text ?? "",
      address: p.formattedAddress ?? "",
    }));
  });

export interface DrivingDistance {
  /** Afstand in kilometers, één decimaal. */
  km: number;
  /** Reistijd in minuten, afgerond. */
  minutes: number;
}

export const computeDrivingDistance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) =>
    z
      .object({
        origin: z.string().min(3).max(300),
        destination: z.string().min(3).max(300),
      })
      .parse(data),
  )
  .handler(async ({ data }): Promise<DrivingDistance> => {
    const lovableKey = process.env.LOVABLE_API_KEY;
    const mapsKey = process.env.GOOGLE_MAPS_API_KEY;
    if (!lovableKey || !mapsKey) throw new Error("Google Maps koppeling ontbreekt");

    const response = await fetch(
      "https://connector-gateway.lovable.dev/google_maps/routes/directions/v2:computeRoutes",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${lovableKey}`,
          "X-Connection-Api-Key": mapsKey,
          "Content-Type": "application/json",
          "X-Goog-FieldMask": "routes.distanceMeters,routes.duration",
        },
        body: JSON.stringify({
          origin: { address: data.origin },
          destination: { address: data.destination },
          travelMode: "DRIVE",
          languageCode: "nl",
          units: "METRIC",
        }),
      },
    );

    if (response.status === 403) {
      const details: Array<{ reason?: string }> =
        ((await response.json()) as { error?: { details?: Array<{ reason?: string }> } })?.error
          ?.details ?? [];
      const reason = details.find((d) => d.reason)?.reason;
      if (reason === "API_KEY_SERVICE_BLOCKED") {
        throw new Error(
          "Google Maps-sleutel staat de Routes API niet toe. Voeg deze API toe aan de toegestane API's van de serversleutel.",
        );
      }
      throw new Error("Google Maps-verzoek geweigerd (403).");
    }

    if (!response.ok) {
      const body = await response.text();
      throw new Error(`Routeverzoek mislukt [${response.status}]: ${body}`);
    }

    const json = (await response.json()) as {
      routes?: Array<{ distanceMeters?: number; duration?: string }>;
    };
    const route = json.routes?.[0];
    if (!route?.distanceMeters) throw new Error("Geen autoroute gevonden tussen deze locaties.");

    const seconds = Number((route.duration ?? "0s").replace("s", "")) || 0;
    return {
      km: Math.round(route.distanceMeters / 100) / 10,
      minutes: Math.round(seconds / 60),
    };
  });
