import { isActiveBooking } from "@/lib/artist-status";
import { useMemo } from "react";
import { usePersistentState } from "@/lib/use-persistent-state";
import {
  bookingStatusLabel,
  parseArtistStatuses,
  useWidgetArtists,
} from "@/lib/data";

/**
 * Persoonlijke instelling: welke boekingsstatussen op het dashboard worden
 * weergegeven. Een lege lijst betekent de standaardweergave (alleen actieve
 * artieststatussen, zonder geannuleerde of afgeronde boekingen).
 */
export function useDashboardStatusFilter(userId: string) {
  const [statuses, setStatuses] = usePersistentState<string[]>(
    `podiumplan:dashboard-statuses:${userId}`,
    [],
  );
  return { statuses, setStatuses };
}

/** Alle statuslabels die gekozen kunnen worden: standaard + eigen artieststatussen. */
export function useDashboardStatusOptions() {
  const { data: artists = [] } = useWidgetArtists();
  return useMemo(() => {
    const seen = new Set<string>();
    const options: { label: string; hint?: string }[] = [];
    for (const a of artists) {
      for (const s of parseArtistStatuses(a.booking_statuses)) {
        const key = s.label.toLowerCase();
        if (seen.has(key)) continue;
      seen.add(key);
      options.push({ label: s.label, hint: a.name });
    }
  }
  return options.sort((a, b) => a.label.localeCompare(b.label));
}, [artists]);
}

/** Bepaalt of een boeking met de gekozen instelling op het dashboard hoort. */
export function matchesDashboardStatus(
  booking: { status?: string | null; artist_status?: string | null },
  statuses: string[],
) {
  if (!statuses.length) {
    return isActiveBooking(booking);
  }
  const label = bookingStatusLabel(booking).toLowerCase();
  return statuses.some((s) => s.toLowerCase() === label);
}
