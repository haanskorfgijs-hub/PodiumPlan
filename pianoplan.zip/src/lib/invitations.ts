import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type MemberRole = Database["public"]["Enums"]["member_role"];

export type Invitation = {
  id: string;
  scope: "artist" | "booking";
  role: MemberRole;
  status: "pending" | "accepted" | "declined";
  title: string | null;
  subtitle: string | null;
  created_at: string;
};

export function useInvitations() {
  return useQuery({
    queryKey: ["invitations"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("my_invitations");
      if (error) throw error;
      return (data ?? []) as unknown as Invitation[];
    },
  });
}

/** Ontvangen contactverzoeken die nog open staan. */
export function useIncomingContactRequests() {
  return useQuery({
    queryKey: ["contacts"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("my_contacts");
      if (error) throw error;
      return data ?? [];
    },
    select: (rows) => rows.filter((c) => c.incoming && c.status === "pending"),
  });
}

export function useRespondInvitation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (vars: {
      id: string;
      scope: "artist" | "booking";
      accept: boolean;
      availability?: "available" | "tentative" | "unavailable";
    }) => {
      const { error } = await supabase.rpc("respond_invitation", {
        _id: vars.id,
        _scope: vars.scope,
        _accept: vars.accept,
        _availability: vars.availability ?? null,
      });
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries(),
  });
}
