import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useMyRole, type AppRole } from "@/lib/roles";
import { useCurrentUser } from "@/lib/session";
import { roleHasPermission, usesAccountPermissions, type RolePermissionRow } from "@/lib/role-permission-access";
export { roleHasPermission, type RolePermissionRow } from "@/lib/role-permission-access";

export type PermissionKey =
  | "artists.view"
  | "artists.manage"
  | "standards.create"
  | "bookings.create"
  | "bookings.edit"
  | "bookings.status"
  | "bookings.delete"
  | "pricing.view"
  | "financial.view"
  | "statistics.view"
  | "activity.view"
  | "activity.financial.view"
  | "activity.dashboard.view"
  | "activity.booking.view"
  | "tasks.manage"
  | "tasks.manage.own"
  | "tasks.view.all"
  | "members.manage"
  | "members.manage.artist"
  | "users.manage"
  | "notifications.invite"
  | "notifications.invite_response"
  | "notifications.booking_status"
  | "notifications.new_user"
  | "admin.full_access"
  | "admin.switch_account"
  | "admin.availability"
  | "admin.contacts";

type PermissionDef = { key: PermissionKey; label: string; hint: string; category: string };

export const PERMISSIONS: PermissionDef[] = [
  // Artiesten
  { key: "artists.view", label: "Pagina Artiesten bekijken", hint: "Artiesten en standaarden inzien", category: "Artiesten" },
  {
    key: "artists.manage",
    label: "Artiesten aanmaken, aanpassen en verwijderen",
    hint: "Artiesten toevoegen, bewerken en verwijderen",
    category: "Artiesten",
  },
  {
    key: "standards.create",
    label: "Standaarden aanmaken, aanpassen en verwijderen",
    hint: "Optredenstandaarden toevoegen, bewerken en verwijderen",
    category: "Artiesten",
  },
  // Boekingen
  { key: "bookings.create", label: "Boekingen aanmaken", hint: "Nieuwe boekingen toevoegen", category: "Boekingen" },
  { key: "bookings.edit", label: "Boekingen aanpassen", hint: "Boekingsinformatie, prijsbepaling en draaiboek bewerken; exclusief Financieel", category: "Boekingen" },
  { key: "bookings.status", label: "Status van boekingen wijzigen", hint: "Alleen de status van een boeking aanpassen, zonder de boeking te bewerken", category: "Boekingen" },
  { key: "bookings.delete", label: "Boekingen verwijderen", hint: "Eigen boekingen wissen", category: "Boekingen" },
  // Teamleden
  { key: "members.manage", label: "Teamleden uitnodigen per boeking", hint: "Mensen uitnodigen en verwijderen", category: "Teamleden" },
  {
    key: "members.manage.artist",
    label: "Beheerders toevoegen per artiest",
    hint: "Beheerders uitnodigen en verwijderen; hun rechten volgen hun accounttype",
    category: "Teamleden",
  },
  // Taken
  { key: "tasks.manage", label: "Taken beheren", hint: "Taken aanmaken en aanpassen", category: "Taken" },
  {
    key: "tasks.manage.own",
    label: "Eigen taken beheren",
    hint: "Alleen taken voor het eigen account aanmaken en bewerken",
    category: "Taken",
  },
  {
    key: "tasks.view.all",
    label: "Alle taken bekijken",
    hint: "Zonder dit recht zie je alleen taken die aan jou zijn toegewezen",
    category: "Taken",
  },
  // Financieel
  { key: "pricing.view", label: "Prijsbepaling bekijken", hint: "Tabblad Prijsbepaling", category: "Financieel" },
  { key: "financial.view", label: "Pagina Financieel bekijken", hint: "Financiële gegevens en bedragen", category: "Financieel" },
  {
    key: "activity.financial.view",
    label: "Financiële activiteiten bekijken",
    hint: "Financiële wijzigingen in het activiteitenlog",
    category: "Financieel",
  },
  // Rapporten
  { key: "statistics.view", label: "Pagina Statistieken bekijken", hint: "Pagina Statistieken", category: "Rapporten" },
  {
    key: "activity.view",
    label: "Pagina Activiteitenlog bekijken",
    hint: "Alle activiteiten van alle boekingen",
    category: "Rapporten",
  },
  {
    key: "activity.dashboard.view",
    label: "Recente activiteit zichtbaar op dashboard",
    hint: "Blok Recente activiteit op het dashboard",
    category: "Rapporten",
  },
  {
    key: "activity.booking.view",
    label: "Activiteit zichtbaar bij boeking",
    hint: "Blok Activiteit op de boekingspagina",
    category: "Rapporten",
  },
  // Beheer
  {
    key: "users.manage",
    label: "Gebruikers en rechten beheren",
    hint: "Pagina's Gebruikersbeheer en Accountsrechten",
    category: "Beheer",
  },
  {
    key: "admin.full_access",
    label: "Volledige toegang tot alles",
    hint: "Alle artiesten, boekingen, standaarden, taken en activiteit zien en beheren, ook zonder lidmaatschap",
    category: "Beheer",
  },
  {
    key: "admin.switch_account",
    label: "Wisselen naar andere accounts",
    hint: "Via het menu rechtsboven tijdelijk als een ander account werken",
    category: "Beheer",
  },
  {
    key: "admin.availability",
    label: "Beschikbaarheid van teamleden aanpassen",
    hint: "Beschikbaarheid van anderen in een boekingsteam wijzigen",
    category: "Beheer",
  },
  {
    key: "admin.contacts",
    label: "Vast contact van iedereen",
    hint: "Staat automatisch bij iedereen in Contacten en kan daar niet verwijderd worden",
    category: "Beheer",
  },
  // Meldingen
  {
    key: "notifications.invite",
    label: "Melding: uitnodigingen",
    hint: "Uitnodigingen voor een boeking of artiest",
    category: "Meldingen",
  },
  {
    key: "notifications.invite_response",
    label: "Melding: antwoord op uitnodiging",
    hint: "Iemand accepteert of wijst een uitnodiging af",
    category: "Meldingen",
  },
  {
    key: "notifications.booking_status",
    label: "Melding: status van boeking gewijzigd",
    hint: "Wijziging van de boekingsstatus",
    category: "Meldingen",
  },
  {
    key: "notifications.new_user",
    label: "Melding: nieuw account geregistreerd",
    hint: "Ontvang een melding wanneer iemand een nieuw account registreert",
    category: "Meldingen",
  },
];

/** Meldingstype uit de database -> recht dat het zichtbaar maakt. */
export const NOTIFICATION_PERMISSIONS: Record<string, PermissionKey> = {
  invite: "notifications.invite",
  invite_response: "notifications.invite_response",
  booking_status: "notifications.booking_status",
  new_user: "notifications.new_user",
};

/** Welke meldingstypen mag de ingelogde gebruiker zien? */
export function useNotificationAccess() {
  const { data: role } = useMyRole();
  const { data: rows } = useRolePermissions();
  return (type: string) => {
    const key = NOTIFICATION_PERMISSIONS[type];
    if (!key) return true;
    return roleHasPermission(rows, role, key);
  };
}

export function useRolePermissions() {
  return useQuery({
    queryKey: ["role-permissions"],
    queryFn: async (): Promise<RolePermissionRow[]> => {
      const { data, error } = await supabase
        .from("role_permissions")
        .select("role, permission, allowed");
      if (error) throw error;
      return (data ?? []) as RolePermissionRow[];
    },
  });
}

/** Mag de huidige gebruiker dit? */
export function usePermission(key: PermissionKey) {
  const { data: role, isLoading: roleLoading } = useMyRole();
  const { data: rows, isLoading: rowsLoading } = useRolePermissions();
  return {
    allowed: roleHasPermission(rows, role, key),
    isLoading: roleLoading || rowsLoading,
  };
}

/**
 * Boekingsrechten worden server-side bepaald door de teamrol; artiestrechten
 * blijven gebaseerd op het accounttype.
 */
export function useScopedPermission(
  key: PermissionKey,
  scope: { artistId?: string | null; bookingId?: string | null },
) {
  const { allowed: globalAllowed, isLoading } = usePermission(key);
  const { data: role } = useMyRole();
  const accountOnly = usesAccountPermissions(role);
  const artistId = scope.artistId ?? undefined;
  const bookingId = scope.bookingId ?? undefined;
  const { data: scoped, isLoading: scopedLoading } = useQuery({
    queryKey: ["scoped-permission", key, artistId ?? null, bookingId ?? null],
    enabled: !!bookingId || (!accountOnly && !globalAllowed && !!artistId),
    queryFn: async () => {
      if (bookingId) {
        const { data, error } = await supabase.rpc("booking_permission", {
          _booking_id: bookingId,
          _key: key,
        });
        if (error) throw error;
        return !!data;
      }
      if (!artistId) return false;
      const { data, error } = await supabase.rpc("artist_permission", {
        _artist_id: artistId,
        _key: key,
      });
      if (error) throw error;
      return !!data;
    },
  });
  return {
    allowed: bookingId ? !!scoped : accountOnly ? globalAllowed : globalAllowed || !!scoped,
    isLoading: bookingId ? scopedLoading : isLoading || scopedLoading,
  };
}

/** Voor welke boekingen uit de lijst geldt dit recht (globaal of via toegewezen rol)? */
export function useBookingPermissionSet(key: PermissionKey, bookingIds: string[]) {
  const { allowed: globalAllowed } = usePermission(key);
  const ids = [...new Set(bookingIds)].sort();
  const { data } = useQuery({
    queryKey: ["scoped-permission-bookings", key, ids],
    enabled: ids.length > 0,
    queryFn: async () => {
      const results = await Promise.all(
        ids.map(async (bookingId) => {
          const { data, error } = await supabase.rpc("booking_permission", {
            _booking_id: bookingId,
            _key: key,
          });
          if (error) throw error;
          return data ? bookingId : null;
        }),
      );
      return results.filter((v): v is string => !!v);
    },
  });
  const allowedIds = new Set(data ?? []);
  return {
    globalAllowed,
    allows: (bookingId?: string | null) =>
      bookingId ? allowedIds.has(bookingId) : globalAllowed,
  };
}

/** Voor welke artiesten uit de lijst geldt dit recht (globaal of via toegewezen rol)? */
export function useArtistPermissionSet(key: PermissionKey, artistIds: string[]) {
  const { allowed: globalAllowed } = usePermission(key);
  const { data: role } = useMyRole();
  const accountOnly = usesAccountPermissions(role);
  const ids = [...artistIds].sort();
  const { data } = useQuery({
    queryKey: ["scoped-permission-artists", key, ids],
    enabled: !accountOnly && !globalAllowed && ids.length > 0,
    queryFn: async () => {
      const results = await Promise.all(
        ids.map(async (artistId) => {
          const { data, error } = await supabase.rpc("artist_permission", {
            _artist_id: artistId,
            _key: key,
          });
          if (error) throw error;
          return data ? artistId : null;
        }),
      );
      return results.filter((v): v is string => !!v);
    },
  });
  const allowedIds = new Set(data ?? []);
  return (artistId: string) => accountOnly ? globalAllowed : globalAllowed || allowedIds.has(artistId);
}

/**
 * Takenrechten gecombineerd: volledig beheer of alleen taken voor het eigen account.
 */
export function useTaskAccess(bookingId?: string | null, bookingIds: string[] = []) {
  const user = useCurrentUser();
  const { allowed: canManageAll } = useScopedPermission("tasks.manage", { bookingId });
  const { allowed: canManageOwn } = useScopedPermission("tasks.manage.own", { bookingId });
  const allAccess = useBookingPermissionSet("tasks.manage", bookingIds);
  const ownAccess = useBookingPermissionSet("tasks.manage.own", bookingIds);
  const canEditTask = (
    task?: { booking_id?: string | null; assigned_to?: string | null; created_by?: string | null } | null,
  ) => {
    const all = !bookingId && task?.booking_id ? allAccess.allows(task.booking_id) : canManageAll;
    const own = !bookingId && task?.booking_id ? ownAccess.allows(task.booking_id) : canManageOwn;
    if (all) return true;
    if (!own) return false;
    if (!task) return true;
    return Boolean(user.id) && (task.assigned_to === user.id || task.created_by === user.id);
  };
  return {
    userId: user.id,
    canManageAll,
    canManageOwn,
    canCreate: canManageAll || canManageOwn,
    ownOnly: !canManageAll && canManageOwn,
    canEditTask,
  };
}



export function useSetRolePermission() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (input: { role: AppRole; permission: PermissionKey; allowed: boolean }) => {
      const { error } = await supabase
        .from("role_permissions")
        .upsert(
          { role: input.role, permission: input.permission, allowed: input.allowed },
          { onConflict: "role,permission" },
        );
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["role-permissions"] });
      queryClient.invalidateQueries({ queryKey: ["can-edit-booking"] });
      queryClient.invalidateQueries({ queryKey: ["scoped-permission"] });
      queryClient.invalidateQueries({ queryKey: ["scoped-permission-bookings"] });
      queryClient.invalidateQueries({ queryKey: ["scoped-permission-artists"] });
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
    },
  });
}
