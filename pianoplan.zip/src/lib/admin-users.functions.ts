import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type AdminAccount = {
  id: string;
  email: string;
  created_at: string;
  confirmed: boolean;
  last_sign_in_at: string | null;
};

type MinimalClient = {
  from: (table: "user_roles") => {
    select: (cols: string) => {
      eq: (col: string, val: string) => {
        eq: (col: string, val: string) => {
          maybeSingle: () => Promise<{ data: unknown; error: unknown }>;
        };
      };
    };
  };
};

async function assertAdmin(supabase: MinimalClient, userId: string) {
  void userId;
  const { data, error } = await (supabase as unknown as {
    rpc: (fn: string, args: Record<string, unknown>) => Promise<{ data: unknown; error: unknown }>;
  }).rpc("has_permission", { _key: "admin.switch_account" });
  if (error || data !== true) {
    throw new Response("Forbidden", { status: 403 });
  }
}

/** Alle aangemaakte accounts, ook accounts die hun e-mailadres nog niet bevestigd hebben. */
export const listAllAccounts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AdminAccount[]> => {
    await assertAdmin(context.supabase as never, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const accounts: AdminAccount[] = [];
    for (let page = 1; page <= 20; page++) {
      const { data, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 200 });
      if (error) throw error;
      for (const u of data.users) {
        accounts.push({
          id: u.id,
          email: u.email ?? "",
          created_at: u.created_at,
          confirmed: Boolean(u.email_confirmed_at ?? u.confirmed_at),
          last_sign_in_at: u.last_sign_in_at ?? null,
        });
      }
      if (data.users.length < 200) break;
    }
    return accounts;
  });

/** Verwijdert een account definitief (auth + profiel). */
export const deleteAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) => z.object({ userId: z.string().uuid() }).parse(data))
  .handler(async ({ context, data }) => {
    await assertAdmin(context.supabase as never, context.userId);
    if (data.userId === context.userId) {
      throw new Response("Je kunt je eigen account niet verwijderen.", { status: 400 });
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error: purgeError } = await supabaseAdmin.rpc("purge_user_data", {
      _user_id: data.userId,
    });
    if (purgeError) throw purgeError;
    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.userId, false);
    if (error) throw error;
    return { ok: true };
  });

/** Admin wisselt naar een ander account: levert een eenmalige inlogcode op. */
export const switchToAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ userId: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }): Promise<{ tokenHash: string }> => {
    await assertAdmin(context.supabase as never, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: target, error } = await supabaseAdmin.auth.admin.getUserById(data.userId);
    if (error || !target.user?.email) throw new Error("Account niet gevonden.");
    const { data: link, error: linkError } = await supabaseAdmin.auth.admin.generateLink({
      type: "magiclink",
      email: target.user.email,
    });
    if (linkError || !link.properties?.hashed_token) throw new Error("Wisselen mislukt.");
    return { tokenHash: link.properties.hashed_token };
  });
