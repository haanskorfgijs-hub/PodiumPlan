import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/**
 * Publiek gegevensblad: haalt één boeking + bijbehorende standaard op zonder login.
 * De boeking-id (UUID) fungeert als geheime sleutel; er wordt geen lijst blootgesteld.
 */
export const getBookingSheet = createServerFn({ method: "GET" })
  .inputValidator((data) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: booking, error } = await supabaseAdmin
      .from("bookings")
      .select("*, artists(name)")
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!booking) return null;

    let standard = null;
    if (booking.standard_id) {
      const { data: std } = await supabaseAdmin
        .from("performance_standards")
        .select("*")
        .eq("id", booking.standard_id)
        .maybeSingle();
      standard = std ?? null;
    }

    return { booking, standard };
  });
