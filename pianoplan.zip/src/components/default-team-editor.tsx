import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Check, ChevronsUpDown, Trash2, UserPlus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { DefaultTeamMember } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

/**
 * Bewerkbare lijst met standaard teamleden (gebruiker + teamrol), gebruikt bij
 * de optredenstandaard en bij het aanmaken van een boeking.
 */
export function DefaultTeamEditor({
  value,
  onChange,
}: {
  value: DefaultTeamMember[];
  onChange: (v: DefaultTeamMember[]) => void;
}) {
  const [pickerOpen, setPickerOpen] = useState(false);
  const [userId, setUserId] = useState("");

  const { data: accounts = [] } = useQuery({
    queryKey: ["invitable-users", "with-self"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("invitable_users");
      if (error) throw error;
      const list = (data ?? []) as { id: string; name: string; email: string }[];
      // Eigen account ook kunnen kiezen.
      const { data: auth } = await supabase.auth.getUser();
      const me = auth.user;
      if (me && !list.some((a) => a.id === me.id)) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("id, name, email")
          .eq("id", me.id)
          .maybeSingle();
        list.unshift({
          id: me.id,
          name: `${profile?.name || me.email || "Ik"} (jij)`,
          email: profile?.email || me.email || "",
        });
      }
      return list;
    },
  });

  const chosen = new Set(value.map((m) => m.userId));
  const options = accounts.filter((a) => !chosen.has(a.id));
  const selected = accounts.find((a) => a.id === userId) ?? null;

  function add() {
    if (!userId) return;
    onChange([...value, { userId, role: "lezer" }]);
    setUserId("");
  }


  function remove(user: string) {
    onChange(value.filter((m) => m.userId !== user));
  }

  return (
    <div className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-[1fr_auto]">
        <div className="min-w-0 space-y-2">
          <Label>Gebruiker</Label>
          <Popover open={pickerOpen} onOpenChange={setPickerOpen}>
            <PopoverTrigger asChild>
              <Button
                type="button"
                variant="outline"
                role="combobox"
                className="w-full justify-between font-normal"
              >
                <span className="truncate">
                  {selected
                    ? `${selected.name || selected.email}${selected.name ? ` · ${selected.email}` : ""}`
                    : "Kies een account"}
                </span>
                <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[min(24rem,90vw)] p-0" align="start">
              <Command>
                <CommandInput placeholder="Zoek op naam of e-mail…" />
                <CommandList>
                  <CommandEmpty>Geen accounts gevonden.</CommandEmpty>
                  <CommandGroup>
                    {options.map((a) => (
                      <CommandItem
                        key={a.id}
                        value={`${a.name} ${a.email}`}
                        onSelect={() => {
                          setUserId(a.id);
                          setPickerOpen(false);
                        }}
                      >
                        <Check
                          className={`mr-2 h-4 w-4 ${a.id === userId ? "opacity-100" : "opacity-0"}`}
                        />
                        <span className="min-w-0">
                          <span className="block truncate">{a.name || a.email}</span>
                          <span className="block truncate text-xs text-muted-foreground">
                            {a.email}
                          </span>
                        </span>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </CommandList>
              </Command>
            </PopoverContent>
          </Popover>
        </div>
        <div className="flex items-end">
          <Button type="button" variant="outline" onClick={add} disabled={!userId}>
            <UserPlus className="mr-1 h-4 w-4" /> Toevoegen
          </Button>
        </div>
      </div>

      {value.length ? (
        <div className="divide-y rounded-lg border">
          {value.map((m) => {
            const account = accounts.find((a) => a.id === m.userId);
            return (
              <div
                key={m.userId}
                className="flex flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">
                    {account?.name || account?.email || "Gebruiker"}
                  </p>
                  {account?.name ? (
                    <p className="truncate text-xs text-muted-foreground">{account.email}</p>
                  ) : null}
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <span className="text-sm text-muted-foreground">Lezer of beheerrol</span>
                  <Button
                    type="button"
                    size="icon"
                    variant="ghost"
                    aria-label="Teamlid verwijderen"
                    onClick={() => remove(m.userId)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">Nog geen teamleden toegevoegd.</p>
      )}
    </div>
  );
}
