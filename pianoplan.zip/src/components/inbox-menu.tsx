import { useNavigate } from "@tanstack/react-router";
import { Bell, Check, CheckCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { formatDateTime } from "@/lib/data";
import {
  isPersistentNotification,
  useMarkNotificationsRead,
  useNotifications,
} from "@/lib/notifications";


/** Inbox met ongelezen meldingen, rechtsboven in de balk. */
export function InboxMenu() {
  const navigate = useNavigate();
  const { data: notifications = [] } = useNotifications();
  const markRead = useMarkNotificationsRead();
  const count = notifications.length;

  function open(link: string | null, id: string) {
    markRead.mutate([id]);
    if (link) navigate({ to: link as never });
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label="Inbox">
          <Bell className="h-4 w-4" />
          {count > 0 ? (
            <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-semibold text-primary-foreground">
              {count > 99 ? "99+" : count}
            </span>
          ) : null}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between border-b px-3 py-2">
          <p className="text-sm font-semibold">Inbox</p>
          {count > 0 ? (
            <button
              type="button"
              onClick={() => markRead.mutate(null)}
              className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
            >
              <CheckCheck className="h-3.5 w-3.5" /> Alles gelezen
            </button>
          ) : null}
        </div>
        <ul className="max-h-96 divide-y overflow-y-auto">
          {notifications.map((n) => (
            <li key={n.id} className="flex items-start gap-2 px-3 py-3 hover:bg-muted/50">
              <button
                type="button"
                onClick={() => open(n.link, n.id)}
                className="min-w-0 flex-1 text-left"
              >
                <p className="truncate text-sm font-medium">{n.title}</p>
                {n.body ? (
                  <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{n.body}</p>
                ) : null}
                <p className="mt-1 text-[11px] text-muted-foreground">
                  {formatDateTime(n.created_at)}
                </p>
              </button>
              {isPersistentNotification(n) ? null : (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 shrink-0"
                  aria-label="Markeer als gelezen"
                  onClick={(e) => {
                    e.stopPropagation();
                    markRead.mutate([n.id]);
                  }}
                >
                  <Check className="h-3.5 w-3.5" />
                </Button>
              )}

            </li>
          ))}
          {count === 0 ? (
            <li className="px-3 py-10 text-center text-sm text-muted-foreground">
              Geen nieuwe meldingen.
            </li>
          ) : null}
        </ul>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
