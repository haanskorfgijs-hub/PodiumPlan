import { useState } from "react";
import { ChevronDown, ChevronUp, Plus, Trash2, Undo2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

import {
  FIELD_TYPE_LABELS,
  fieldTab,
  formatEuro,
  hasPricingRule,
  parseHiddenPriceFields,
  parsePriceExtras,
  priceLines,
  priceOverrideKey,
  priceTotal,
  serializeHiddenPriceFields,
  serializePriceExtras,
  PRICE_HIDDEN_KEY,
  PRICE_EXTRAS_KEY,
  PRICE_TOTAL_KEY,
  type FieldPricing,
  type StandardField,
} from "@/lib/data";

function num(value: string): number | null {
  if (value.trim() === "") return null;
  const n = Number(value.replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

function TimeFieldSelect({
  p,
  field,
  timeFields,
  onChange,
  compact,
}: {
  p: FieldPricing;
  field: StandardField;
  timeFields: StandardField[];
  onChange: (fieldId: string, pricing: FieldPricing) => void;
  compact?: boolean;
}) {
  if (!p.timeBased) return null;
  return (
    <div className={compact ? "flex-1 min-w-[10rem]" : "space-y-1"}>
      {!compact ? (
        <Label className="text-xs text-muted-foreground">Tijdveld om naar te kijken</Label>
      ) : null}
      <Select
        value={p.timeFieldId ?? "auto"}
        onValueChange={(v) =>
          onChange(field.id, { ...p, timeFieldId: v === "auto" ? null : v })
        }
      >
        <SelectTrigger className={cn(compact && "h-8 rounded-none text-xs")}>
          <SelectValue placeholder="Automatisch" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="auto">Automatisch (eerste tijdveld)</SelectItem>
          {timeFields.map((tf) => (
            <SelectItem key={tf.id} value={tf.id}>
              {tf.label || "Naamloos tijdveld"}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

function TimeRateGrid({
  rule,
  setRule,
  compact,
}: {
  rule: {
    baseAmount?: number | null;
    maxHours?: number | null;
    firstOvertimeRate?: number | null;
    overtimeRate?: number | null;
  };
  setRule: (patch: Partial<typeof rule>) => void;
  compact?: boolean;
}) {
  const inputClass = compact ? "h-8 rounded-none text-xs" : "";
  const labelClass = compact
    ? "text-[10px] leading-tight text-muted-foreground"
    : "text-xs text-muted-foreground";
  const wrapClass = compact ? "min-w-[6rem] flex-1 space-y-1" : "space-y-1";
  return (
    <div className={cn("gap-2", compact ? "flex flex-wrap items-end" : "grid gap-2 sm:grid-cols-4")}>
      <div className={wrapClass}>
        {!compact ? <Label className={labelClass}>Vast bedrag (€)</Label> : null}
        <Input
          type="number"
          step="0.01"
          className={inputClass}
          placeholder={compact ? "Vast €" : "Bijv. 300"}
          value={rule.baseAmount ?? ""}
          onChange={(e) => setRule({ baseAmount: num(e.target.value) })}
        />
        {compact ? <span className={labelClass}>Vast bedrag</span> : null}
      </div>
      <div className={wrapClass}>
        {!compact ? <Label className={labelClass}>Tot maximaal (uur)</Label> : null}
        <Input
          type="number"
          step="0.5"
          className={inputClass}
          placeholder={compact ? "Max uur" : "Bijv. 4"}
          value={rule.maxHours ?? ""}
          onChange={(e) => setRule({ maxHours: num(e.target.value) })}
        />
        {compact ? <span className={labelClass}>Max uur</span> : null}
      </div>
      <div className={wrapClass}>
        {!compact ? <Label className={labelClass}>Bedrag (€) 1e uur daarboven</Label> : null}
        <Input
          type="number"
          step="0.01"
          className={inputClass}
          placeholder={compact ? "1e uur €" : "Bijv. 120"}
          value={rule.firstOvertimeRate ?? ""}
          onChange={(e) => setRule({ firstOvertimeRate: num(e.target.value) })}
        />
        {compact ? <span className={labelClass}>1e uur extra</span> : null}
      </div>
      <div className={wrapClass}>
        {!compact ? <Label className={labelClass}>Bedrag (€) per uur daarna</Label> : null}
        <Input
          type="number"
          step="0.01"
          className={inputClass}
          placeholder={compact ? "Daarna €/uur" : "Bijv. 90"}
          value={rule.overtimeRate ?? ""}
          onChange={(e) => setRule({ overtimeRate: num(e.target.value) })}
        />
        {compact ? <span className={labelClass}>Per uur daarna</span> : null}
      </div>
    </div>
  );
}

/**
 * Vinkje "afhankelijk van tijd" met opbouw: een vast bedrag tot een maximum
 * aantal uur, en een bedrag per uur boven dat maximum.
 */
function TimeBasedRule({
  field,
  timeFields,
  onChange,
  compact,
}: {
  field: StandardField;
  timeFields: StandardField[];
  onChange: (fieldId: string, pricing: FieldPricing) => void;
  compact?: boolean;
}) {
  const p = field.pricing ?? {};
  return (
    <div className={cn(compact ? "space-y-2" : "space-y-3")}>
      <label className="flex items-center gap-2 text-xs text-muted-foreground">
        <Checkbox
          checked={!!p.timeBased}
          onCheckedChange={(v) => onChange(field.id, { ...p, timeBased: v === true })}
        />
        Afhankelijk van tijd
      </label>
      {p.timeBased ? (
        <>
          <TimeFieldSelect p={p} field={field} timeFields={timeFields} onChange={onChange} compact={compact} />
          {field.type === "dropdown" ? (
            (field.options ?? []).filter(Boolean).length === 0 ? (
              <p className="text-xs text-muted-foreground">
                Voeg eerst keuzeopties toe aan dit veld.
              </p>
            ) : (
              <div className={cn("space-y-2", compact && "border-t border-dashed pt-2")}>
                {!compact ? (
                  <p className="text-xs text-muted-foreground">
                    Tarieven per keuzeoptie: de gekozen optie bepaalt de berekening.
                  </p>
                ) : null}
                {(field.options ?? []).filter(Boolean).map((opt) => {
                  const rule = p.optionTime?.[opt] ?? {};
                  const setRule = (patch: Partial<typeof rule>) => {
                    const optionTime = { ...(p.optionTime ?? {}) };
                    optionTime[opt] = { ...rule, ...patch };
                    onChange(field.id, { ...p, optionTime });
                  };
                  return (
                    <div
                      key={opt}
                      className={cn(
                        "space-y-1",
                        compact ? "rounded-none border p-2" : "rounded-md border p-2",
                      )}
                    >
                      <Label className={cn("text-xs font-medium", compact && "text-[10px]")}>
                        {opt}
                      </Label>
                      <TimeRateGrid rule={rule} setRule={setRule} compact={compact} />
                    </div>
                  );
                })}
              </div>
            )
          ) : (
            <TimeRateGrid
              rule={p}
              setRule={(patch) => onChange(field.id, { ...p, ...patch })}
              compact={compact}
            />
          )}
        </>
      ) : null}
    </div>
  );
}

/** Optioneel: het bedrag van een prijsregel met een Excel-achtige formule bepalen. */
function FormulaRule({
  field,
  onChange,
  compact,
}: {
  field: StandardField;
  onChange: (fieldId: string, pricing: FieldPricing) => void;
  compact?: boolean;
}) {
  const p = field.pricing ?? {};
  const active = (p.formula ?? "").trim() !== "" || p.formula === "";
  return (
    <div className={cn("space-y-2", compact && "space-y-1")}>
      <label className="flex items-center gap-2 text-xs text-muted-foreground">
        <Checkbox
          checked={active}
          onCheckedChange={(v) => onChange(field.id, { ...p, formula: v === true ? "" : null })}
        />
        Bedrag met een formule berekenen
      </label>
      {active ? (
        <>
          <Input
            placeholder="=[Kilometers] * 0,35 + [Voorrijkosten]"
            className={cn(compact && "h-8 rounded-none text-xs")}
            value={p.formula ?? ""}
            onChange={(e) => onChange(field.id, { ...p, formula: e.target.value })}
          />
          <p className={cn("text-xs text-muted-foreground", compact && "text-[10px]")}>
            Reken met + - * / en haakjes. Verwijs naar velden of prijsregels tussen blokhaken.
          </p>
        </>
      ) : null}
    </div>
  );
}

function BookingFieldPricingCell({
  field,
  timeFields,
  onChange,
}: {
  field: StandardField;
  timeFields: StandardField[];
  onChange: (fieldId: string, pricing: FieldPricing) => void;
}) {
  const p = field.pricing ?? {};

  if ((p.formula ?? "").trim()) {
    return <FormulaRule field={field} onChange={onChange} />;
  }

  if (p.timeBased) {
    return <TimeBasedRule field={field} timeFields={timeFields} onChange={onChange} />;
  }

  if (field.type === "dropdown") {
    if ((field.options ?? []).filter(Boolean).length === 0) {
      return <p className="text-xs text-muted-foreground">Voeg eerst keuzeopties toe aan dit veld.</p>;
    }
    return (
      <div className="grid gap-2 sm:grid-cols-2">
        {(field.options ?? []).filter(Boolean).map((opt) => (
          <div key={opt} className="space-y-1">
            <Label className="text-xs text-muted-foreground">{opt}</Label>
            <Input
              type="number"
              step="0.01"
              placeholder="Bedrag (€)"
              value={p.options?.[opt] ?? ""}
              onChange={(e) => {
                const options = { ...(p.options ?? {}) };
                const v = num(e.target.value);
                if (v == null) delete options[opt];
                else options[opt] = v;
                onChange(field.id, { ...p, options });
              }}
            />
          </div>
        ))}
      </div>
    );
  }

  if (field.type === "time") {
    return (
      <div className="grid gap-2 sm:grid-cols-2">
        <div className="space-y-1">
          <Label className="text-xs text-muted-foreground">Tarief (€) per eenheid</Label>
          <Input
            type="number"
            step="0.01"
            placeholder="Bijv. 75"
            value={p.rate ?? ""}
            onChange={(e) => onChange(field.id, { ...p, rate: num(e.target.value) })}
          />
        </div>
        <div className="space-y-1">
          <Label className="text-xs text-muted-foreground">Tijdseenheid in minuten</Label>
          <Input
            type="number"
            step="1"
            placeholder="60"
            value={p.unitMinutes ?? ""}
            onChange={(e) => onChange(field.id, { ...p, unitMinutes: num(e.target.value) })}
          />
        </div>
      </div>
    );
  }

  if (field.type === "distance") {
    return (
      <div className="space-y-1">
        <Label className="text-xs text-muted-foreground">Bedrag (€) per kilometer</Label>
        <Input
          type="number"
          step="0.01"
          placeholder="Bijv. 0,35"
          value={p.perKm ?? ""}
          onChange={(e) => onChange(field.id, { ...p, perKm: num(e.target.value) })}
        />
      </div>
    );
  }

  return (
    <div className="space-y-1">
      <Label className="text-xs text-muted-foreground">Bedrag (€) zodra dit veld is ingevuld</Label>
      <Input
        type="number"
        step="0.01"
        placeholder="Geen bedrag"
        value={p.amount ?? ""}
        onChange={(e) => onChange(field.id, { ...p, amount: num(e.target.value) })}
      />
    </div>
  );
}

/**
 * Prijsregels instellen per boekingsveld (in de optredenstandaard).
 * Keuzelijsten krijgen een bedrag per optie, tijdvelden een tarief per eenheid.
 * Daarnaast kunnen eigen prijsregels toegevoegd of verwijderd worden.
 */
export function PricingRulesEditor({
  fields,
  onChange,
  onAddRule,
  onRemoveRule,
  onRelabel,
}: {
  fields: StandardField[];
  onChange: (fieldId: string, pricing: FieldPricing) => void;
  onAddRule?: () => void;
  onRemoveRule?: (fieldId: string) => void;
  onRelabel?: (fieldId: string, label: string) => void;
}) {
  const allBooking = fields.filter((f) => fieldTab(f) === "booking" && f.label.trim());
  const bookingFields = allBooking.filter((f) => !f.pricing?.excluded);
  const excluded = allBooking.filter((f) => f.pricing?.excluded);
  const ownRules = fields.filter((f) => fieldTab(f) === "pricing");
  const timeFields = allBooking.filter((f) => f.type === "time");
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});
  const groups = [
    { key: "own", label: "Eigen prijsregels", rows: ownRules },
    { key: "booking", label: "Velden uit boekingsinformatie", rows: bookingFields },
  ].filter((g) => g.rows.length > 0);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs text-muted-foreground">
          Alle velden uit Boekingsinformatie staan hier. Alleen velden met een bedrag tellen mee in
          de offerteprijs.
        </p>
        {onAddRule ? (
          <Button type="button" size="sm" variant="outline" onClick={onAddRule}>
            <Plus className="mr-1 h-4 w-4" /> Prijsregel
          </Button>
        ) : null}
      </div>

      {excluded.length ? (
        <div className="flex flex-wrap items-center gap-2 rounded-lg border border-dashed p-3">
          <p className="text-xs text-muted-foreground">
            {excluded.length} verwijderde regel(s): {excluded.map((f) => f.label).join(", ")}
          </p>
          {excluded.map((f) => (
            <Button
              key={f.id}
              type="button"
              size="sm"
              variant="ghost"
              onClick={() => onChange(f.id, { ...(f.pricing ?? {}), excluded: false })}
            >
              <Undo2 className="mr-1 h-4 w-4" /> {f.label}
            </Button>
          ))}
        </div>
      ) : null}

      <div className="space-y-8 rounded-md bg-muted/30 px-4 py-5 sm:px-5">
        {groups.length === 0 ? (
          <p className="py-2 text-center text-sm text-muted-foreground">
            Voeg eerst velden toe in het tabblad Boekingsinformatie, of maak een eigen prijsregel.
          </p>
        ) : null}

        {groups.map((group, groupIndex) => (
          <section key={group.key} className="space-y-5">
            <div className="flex items-center gap-3 border-b pb-3">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
                {groupIndex + 1}
              </span>
              <h3 className="text-sm font-semibold uppercase text-foreground">{group.label}</h3>
              <div className="ml-auto flex items-center gap-1">
                <Button
                  type="button"
                  size="icon"
                  variant="ghost"
                  className="shrink-0"
                  aria-label={collapsedSections[group.key] ? "Sectie uitklappen" : "Sectie inklappen"}
                  onClick={() =>
                    setCollapsedSections((prev) => ({
                      ...prev,
                      [group.key]: !prev[group.key],
                    }))
                  }
                >
                  {collapsedSections[group.key] ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronUp className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            {!collapsedSections[group.key] ? (
              <div className="space-y-4">
                {group.rows.map((f) => {
                  const isOwn = fieldTab(f) === "pricing";
                  const p = f.pricing ?? {};
                  return (
                    <div key={f.id} className="space-y-3 rounded-lg border p-3">
                      <div className="flex items-start gap-3">
                        <div className="min-w-0 flex-1 space-y-3">
                          {isOwn ? (
                            <div className="space-y-1.5">
                              <Label>Naam van de prijsregel</Label>
                              <Input
                                placeholder="Naam van de prijsregel"
                                value={f.label}
                                onChange={(e) => onRelabel?.(f.id, e.target.value)}
                              />
                            </div>
                          ) : (
                            <div>
                              <p className="text-sm font-medium">{f.label}</p>
                              <p className="text-xs text-muted-foreground">
                                {FIELD_TYPE_LABELS[f.type]}
                              </p>
                            </div>
                          )}

                          {isOwn ? (
                            <div className="space-y-3">
                              {!p.timeBased && !p.formula ? (
                                <div className="space-y-1.5">
                                  <Label>Bedrag (€)</Label>
                                  <Input
                                    type="number"
                                    step="0.01"
                                    placeholder="Bijv. 150"
                                    value={p.amount ?? ""}
                                    onChange={(e) =>
                                      onChange(f.id, { ...p, amount: num(e.target.value) })
                                    }
                                  />
                                </div>
                              ) : null}
                              {!p.formula ? (
                                <TimeBasedRule
                                  field={f}
                                  timeFields={timeFields}
                                  onChange={onChange}
                                />
                              ) : null}
                              <FormulaRule field={f} onChange={onChange} />
                            </div>
                          ) : (
                            <div className="space-y-3">
                              <BookingFieldPricingCell
                                field={f}
                                timeFields={timeFields}
                                onChange={onChange}
                              />
                              {!p.formula ? (
                                <FormulaRule field={f} onChange={onChange} />
                              ) : null}
                            </div>
                          )}
                        </div>

                        <div className="flex shrink-0 items-center pt-1">
                          {isOwn ? (
                            onRemoveRule ? (
                              <Button
                                type="button"
                                size="icon"
                                variant="ghost"
                                onClick={() => onRemoveRule(f.id)}
                                aria-label="Prijsregel verwijderen"
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            ) : null
                          ) : (
                            <>
                              {hasPricingRule(f) ? (
                                <Button
                                  type="button"
                                  size="sm"
                                  variant="ghost"
                                  className="text-xs"
                                  onClick={() => onChange(f.id, {})}
                                >
                                  Wissen
                                </Button>
                              ) : null}
                              <Button
                                type="button"
                                size="icon"
                                variant="ghost"
                                aria-label="Regel verwijderen"
                                onClick={() => onChange(f.id, { excluded: true })}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : null}
          </section>
        ))}
      </div>
    </div>
  );
}

/**
 * Prijsbepaling van een boeking: alleen velden met een bedrag, automatisch
 * opgeteld tot de offerteprijs. Met onChange kunnen bedragen overschreven worden,
 * regels verwijderd worden en eigen regels toegevoegd worden.
 */
export function PricingPanel({
  fields,
  values,
  onChange,
}: {
  fields: StandardField[];
  values: Record<string, string>;
  onChange?: (key: string, value: string) => void;
}) {
  const lines = priceLines(fields, values);
  const { sum, total, manual } = priceTotal(lines, values);
  const hidden = parseHiddenPriceFields(values);
  const extras = parsePriceExtras(values);

  /** Handmatige offerteprijs bijwerken zodra een regel wegvalt. */
  function dropFromTotal(amount: number) {
    if ((values[PRICE_TOTAL_KEY] ?? "").trim() === "") return;
    const next = Number((total - amount).toFixed(2));
    onChange?.(PRICE_TOTAL_KEY, String(next));
  }

  function hideLine(fieldId: string) {
    const line = lines.find((l) => l.fieldId === fieldId);
    onChange?.(PRICE_HIDDEN_KEY, serializeHiddenPriceFields([...hidden, fieldId]));
    // Een verwijderde regel telt niet meer mee: ook een eigen bedrag valt weg.
    onChange?.(priceOverrideKey(fieldId), "");
    if (line) dropFromTotal(line.amount);
  }

  function restoreHidden() {
    onChange?.(PRICE_HIDDEN_KEY, serializeHiddenPriceFields([]));
  }

  function patchExtra(id: string, patch: { label?: string; amount?: string }) {
    onChange?.(
      PRICE_EXTRAS_KEY,
      serializePriceExtras(extras.map((e) => (e.id === id ? { ...e, ...patch } : e))),
    );
  }

  function removeExtra(id: string) {
    const line = lines.find((l) => l.extraId === id);
    onChange?.(PRICE_EXTRAS_KEY, serializePriceExtras(extras.filter((e) => e.id !== id)));
    if (line) dropFromTotal(line.amount);
  }


  function addExtra() {
    onChange?.(
      PRICE_EXTRAS_KEY,
      serializePriceExtras([
        ...extras,
        { id: `x_${Date.now().toString(36)}`, label: "", amount: "" },
      ]),
    );
  }

  if (lines.length === 0 && !onChange) {
    return (
      <p className="text-sm text-muted-foreground">
        Geen velden met een bedrag. Stel prijsregels in bij de optredenstandaard.
      </p>
    );
  }

  return (
    <div className="space-y-2">
      {lines.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          Geen regels met een bedrag. Voeg hieronder een eigen regel toe of stel prijsregels in bij
          de optredenstandaard.
        </p>
      ) : null}

      {lines.map((l) =>
        l.extraId ? (
          <div
            key={l.fieldId}
            className="flex flex-wrap items-center justify-between gap-3 border-b py-2.5 last:border-0"
          >
            {onChange ? (
              <>
                <Input
                  className="min-w-40 flex-1"
                  placeholder="Omschrijving"
                  value={extras.find((e) => e.id === l.extraId)?.label ?? ""}
                  onChange={(e) => patchExtra(l.extraId!, { label: e.target.value })}
                />
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    step="0.01"
                    className="w-32"
                    placeholder="Bedrag"
                    value={extras.find((e) => e.id === l.extraId)?.amount ?? ""}
                    onChange={(e) => patchExtra(l.extraId!, { amount: e.target.value })}
                  />
                  <Button
                    type="button"
                    size="icon"
                    variant="ghost"
                    aria-label="Regel verwijderen"
                    onClick={() => removeExtra(l.extraId!)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </>
            ) : (
              <>
                <p className="text-sm font-medium">{l.label}</p>
                <span className="text-sm font-medium">{formatEuro(l.amount)}</span>
              </>
            )}
          </div>
        ) : (
          <div
            key={l.fieldId}
            className="flex flex-wrap items-center justify-between gap-3 border-b py-2.5 last:border-0"
          >
            <div className="min-w-0">
              <p className="text-sm font-medium">{l.label}</p>
              {l.detail ? <p className="text-xs text-muted-foreground">{l.detail}</p> : null}
            </div>
            {onChange ? (
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">{formatEuro(l.computed)}</span>
                <Input
                  type="number"
                  step="0.01"
                  className="w-32"
                  placeholder="Overschrijf"
                  value={values[priceOverrideKey(l.fieldId)] ?? ""}
                  onChange={(e) => onChange(priceOverrideKey(l.fieldId), e.target.value)}
                />
                <Button
                  type="button"
                  size="icon"
                  variant="ghost"
                  aria-label="Regel verwijderen"
                  onClick={() => hideLine(l.fieldId)}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            ) : (
              <span className="text-sm font-medium">{formatEuro(l.amount)}</span>
            )}
          </div>
        ),
      )}

      {onChange ? (
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <Button type="button" size="sm" variant="outline" onClick={addExtra}>
            <Plus className="mr-1 h-4 w-4" /> Regel toevoegen
          </Button>
          {hidden.length ? (
            <Button type="button" size="sm" variant="ghost" onClick={restoreHidden}>
              <Undo2 className="mr-1 h-4 w-4" /> {hidden.length} verwijderde regel(s) terugzetten
            </Button>
          ) : null}
        </div>
      ) : null}

      <div className="space-y-2 border-t pt-3">
        {onChange ? (
          <>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm font-semibold">Berekende prijs</p>
              <span className="text-sm font-medium">{formatEuro(sum)}</span>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm font-semibold">Offerteprijs</p>
              <Input
                type="number"
                step="0.01"
                className="w-32"
                placeholder="Totaal"
                value={values[PRICE_TOTAL_KEY] ?? ""}
                onChange={(e) => onChange(PRICE_TOTAL_KEY, e.target.value)}
              />
            </div>
          </>
        ) : (
          <div className="space-y-1">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm font-semibold">Berekende prijs</p>
              <span className="text-sm font-medium">{formatEuro(sum)}</span>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm font-semibold">Offerteprijs</p>
              {manual == null ? (
                <span className="text-sm font-normal text-muted-foreground">
                  nog niet ingevuld
                </span>
              ) : (
                <span className="text-base font-semibold">{formatEuro(manual)}</span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
