import { useEffect, useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import { useNavigate } from "@tanstack/react-router";
import { ChevronDown, ChevronRight, Search, X } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";
import { usePersistentState } from "@/lib/use-persistent-state";
import { useColumnOrder } from "@/lib/column-order";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  FINANCIAL_STATUSES,
  FINANCIAL_STATUS_LABELS,
  fieldTab,
  fieldValues,
  formatBookingDate,
  parseFields,
  useBookings,
  useStandardMap,
} from "@/lib/data";
import {
  BookingStatusPill,
  FinancialStatusBadge,
  financialStatusColor,
  FinancialStatusStripeCell,
  STATUS_STRIPE_CLASSES,
} from "@/components/status-badges";
import { ColumnFilter, FilterOption, monthOption as makeMonthOption } from "@/components/column-filter";
import { MobileFilters } from "@/components/mobile-filters";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type FinancialStatus = (typeof FINANCIAL_STATUSES)[number];

const formatEuro = (n: number) =>
  `€ ${n.toLocaleString("nl-NL", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

function toNumber(raw: string) {
  if (!raw) return 0;
  const cleaned = raw.replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}\b)/g, "").replace(",", ".");
  const n = Number.parseFloat(cleaned);
  return Number.isFinite(n) ? n : 0;
}

type Booking = ReturnType<typeof useBookings>["data"] extends (infer T)[] | undefined ? T : never;

type Invoice = {
  number: string;
  bookings: Booking[];
  amount: number;
};

type InvoiceCol = {
  key: string;
  label: string;
  className: string;
  cellClassName: string;
  align?: "start" | "end";
  sortOf: (inv: Invoice) => string | number;
  filterOf: (inv: Invoice) => FilterOption | null;
};

const COLUMNS: InvoiceCol[] = [
  {
    key: "number",
    label: "Factuurnummer",
    className: "w-[22%]",
    cellClassName: "text-sm font-medium",
    sortOf: (inv) => inv.number,
    filterOf: (inv) => ({ value: inv.number, label: inv.number }),
  },
  {
    key: "artist",
    label: "Artiest(en)",
    className: "w-[26%]",
    cellClassName: "truncate text-sm text-muted-foreground",
    sortOf: (inv) =>
      [...new Set(inv.bookings.map((b) => b.artists?.name).filter(Boolean))].join(", ") || "",
    filterOf: (inv) => {
      const names = [...new Set(inv.bookings.map((b) => b.artists?.name).filter(Boolean))];
      if (names.length === 0) return null;
      const label = names.join(", ");
      return { value: label, label };
    },
  },
  {
    key: "bookings",
    label: "Boekingen",
    className: "w-[12%]",
    cellClassName: "text-sm",
    sortOf: (inv) => inv.bookings.length,
    filterOf: () => null,
  },
  {
    key: "amount",
    label: "Totaal",
    className: "w-[16%] text-right",
    cellClassName: "text-right text-sm tabular-nums",
    align: "end",
    sortOf: (inv) => inv.amount,
    filterOf: () => null,
  },
  {
    key: "status",
    label: "Financiële status",
    className: "w-[24%] text-right",
    cellClassName: "text-right",
    align: "end",
    sortOf: (inv) => statusOf(inv) || "zzzz",
    filterOf: (inv) => {
      const status = statusOf(inv);
      if (!status) return null;
      return { value: status, label: FINANCIAL_STATUS_LABELS[status] ?? status };
    },
  },
];

function statusOf(inv: Invoice): FinancialStatus | "" {
  const set = new Set(inv.bookings.map((b) => b.financial_status ?? "nog_spelen"));
  return set.size === 1 ? ([...set][0] as FinancialStatus) : "";
}

/** Factuurnummer + totaalbedrag van een boeking uit de financiële velden. */
function financialInfo(booking: Booking, standardMap: Map<string, { fields?: unknown }>) {
  const standard = booking.standard_id ? standardMap.get(booking.standard_id) : undefined;
  const fields = parseFields(standard?.fields).filter((f) => fieldTab(f) === "financial");
  const values = fieldValues(booking.field_values);
  let number = "";
  let amount = 0;
  fields.forEach((f) => {
    const raw = values[f.id] ?? "";
    if (!raw) return;
    if (/factuurnummer|factuur nr|factuurnr/i.test(f.label)) {
      if (!number) number = raw.trim();
    } else if (f.type === "currency") {
      amount += toNumber(raw);
    }
  });
  return { number, amount };
}

/** Overzicht van facturen: boekingen gegroepeerd op factuurnummer. */
export function FinancialInvoices({ resetStatus }: { resetStatus?: string }) {
  const { data: bookings = [] } = useBookings();
  const standardMap = useStandardMap();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [saving, setSaving] = useState<string | null>(null);

  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<string>("number");
  const [asc, setAsc] = useState(true);
  const [filters, setFilters] = usePersistentState<Record<string, string[]>>(
    "podiumplan:filters:invoices",
    {},
  );

  useEffect(() => {
    if (!resetStatus) return;
    setSearch("");
    setSort("number");
    setAsc(true);
    setFilters({ status: [resetStatus] });
  }, [resetStatus]);

  const { order, dragProps } = useColumnOrder(
    "podiumplan:columns:invoices",
    COLUMNS.map((c) => c.key),
  );
  const orderedColumns = useMemo(
    () => order.map((key: string) => COLUMNS.find((c) => c.key === key)!).filter(Boolean),
    [order],
  );

  const invoices = useMemo<Invoice[]>(() => {
    const map = new Map<string, Invoice>();
    bookings.forEach((b) => {
      const { number, amount } = financialInfo(b as Booking, standardMap);
      if (!number) return;
      const entry = map.get(number) ?? { number, bookings: [], amount: 0 };
      entry.bookings.push(b as Booking);
      entry.amount += amount;
      map.set(number, entry);
    });
    return [...map.values()]
      .map((inv) => ({
        ...inv,
        bookings: [...inv.bookings].sort((a, b) => a.event_date.localeCompare(b.event_date)),
      }))
      .sort((a, b) => b.number.localeCompare(a.number, "nl", { numeric: true }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookings, standardMap]);

  const withoutNumber = useMemo(
    () => bookings.filter((b) => !financialInfo(b as Booking, standardMap).number).length,
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [bookings, standardMap],
  );

  const optionsFor = useMemo(() => {
    const map: Record<string, FilterOption[]> = {};
    COLUMNS.forEach((col) => {
      const seen = new Map<string, string>();
      invoices.forEach((inv) => {
        const opt = col.filterOf(inv);
        if (opt && !seen.has(opt.value)) seen.set(opt.value, opt.label);
      });
      map[col.key] = [...seen.entries()]
        .map(([value, label]) => ({ value, label }))
        .sort((a, b) => a.label.localeCompare(b.label, "nl"));
    });

    // Maandfilter gebaseerd op alle boekingsdatums binnen een factuur.
    const months = new Map<string, string>();
    invoices.forEach((inv) =>
      inv.bookings.forEach((b) => {
        const opt = makeMonthOption(b.event_date);
        if (opt && !months.has(opt.value)) months.set(opt.value, opt.label);
      }),
    );
    map["month"] = [...months.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([value, label]) => ({ value, label }));

    return map;
  }, [invoices]);

  /** Verwijder filters die niet meer voor komen in de huidige data. */
  const validFilters = useMemo(() => {
    const next: Record<string, string[]> = {};
    COLUMNS.forEach((col) => {
      const selected = filters[col.key] ?? [];
      if (!selected.length) return;
      const available = new Set((optionsFor[col.key] ?? []).map((o) => o.value));
      const valid = selected.filter((v) => available.has(v));
      if (valid.length) next[col.key] = valid;
    });
    const monthSelected = filters["month"] ?? [];
    if (monthSelected.length) {
      const available = new Set((optionsFor["month"] ?? []).map((o) => o.value));
      const valid = monthSelected.filter((v) => available.has(v));
      if (valid.length) next["month"] = valid;
    }
    return next;
  }, [filters, optionsFor]);

  const filteredInvoices = useMemo(() => {
    return invoices
      .filter((inv) =>
        COLUMNS.every((col) => {
          const selected = validFilters[col.key];
          if (!selected?.length) return true;
          const opt = col.filterOf(inv);
          return opt ? selected.includes(opt.value) : false;
        }),
      )
      .filter((inv) => {
        const selectedMonths = validFilters["month"];
        if (!selectedMonths?.length) return true;
        return inv.bookings.some((b) => {
          const opt = makeMonthOption(b.event_date);
          return opt ? selectedMonths.includes(opt.value) : false;
        });
      })
      .filter((inv) => {
        if (!search.trim()) return true;
        const terms = search.toLowerCase();
        const artists = [...new Set(inv.bookings.map((b) => b.artists?.name).filter(Boolean))]
          .join(" ")
          .toLowerCase();
        const events = inv.bookings.map((b) => b.event_name).join(" ").toLowerCase();
        return (
          inv.number.toLowerCase().includes(terms) ||
          artists.includes(terms) ||
          events.includes(terms)
        );
      })
      .sort((a, b) => {
        const col = COLUMNS.find((c) => c.key === sort);
        if (!col) return 0;
        const va = col.sortOf(a);
        const vb = col.sortOf(b);
        if (typeof va === "number" && typeof vb === "number") {
          return asc ? va - vb : vb - va;
        }
        return asc ? String(va).localeCompare(String(vb), "nl") : String(vb).localeCompare(String(va), "nl");
      });
  }, [invoices, search, sort, asc, validFilters]);

  const totalAmount = useMemo(
    () => filteredInvoices.reduce((sum, inv) => sum + inv.amount, 0),
    [filteredInvoices],
  );

  const activeFilters = useMemo(
    () =>
      [
        ...COLUMNS.filter((col) => validFilters[col.key]?.length).map((col) => ({
          key: col.key,
          label: `${col.label}: ${(validFilters[col.key] ?? []).join(", ")}`,
        })),
        ...(validFilters["month"]?.length
          ? [
              {
                key: "month",
                label: `Maand: ${(validFilters["month"] ?? []).join(", ")}`,
              },
            ]
          : []),
      ],
    [validFilters],
  );

  async function updateInvoiceStatus(number: string, ids: string[], status: FinancialStatus) {
    setSaving(number);
    const { error } = await supabase
      .from("bookings")
      .update({ financial_status: status })
      .in("id", ids);
    setSaving(null);
    if (error) {
      toast.error("Status bijwerken is niet gelukt.");
      return;
    }
    await queryClient.invalidateQueries({ queryKey: ["bookings"] });
    toast.success(
      `Factuur ${number}: ${ids.length} ${ids.length === 1 ? "boeking" : "boekingen"} op ${
        FINANCIAL_STATUS_LABELS[status] ?? status
      }.`,
    );
  }

  function toggleSort(key: string) {
    if (sort === key) setAsc((v) => !v);
    else {
      setSort(key);
      setAsc(true);
    }
  }

  function filterFor(key: string) {
    return (
      <ColumnFilter
        options={optionsFor[key] ?? []}
        selected={validFilters[key] ?? []}
        align={COLUMNS.find((c) => c.key === key)?.align === "end" ? "end" : "start"}
        onChange={(values) => setFilters((prev) => ({ ...prev, [key]: values }))}
      />
    );
  }

  const mobileColumns = useMemo(
    () => [
      ...orderedColumns.map((col) => ({ key: col.key, label: col.label })),
      { key: "month", label: "Maand" },
    ],
    [orderedColumns],
  );

  if (invoices.length === 0) {
    return (
      <div className="panel p-10 text-center text-sm text-muted-foreground">
        Nog geen facturen. Vul bij een boeking een factuurnummer in om een factuur te vormen.
      </div>
    );
  }

  return (
    <div className="panel">
      <div className="flex flex-wrap items-center gap-3 border-b p-4">
        <div className="relative min-w-56 flex-1">
          <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Zoek op factuurnummer, artiest of event…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        {activeFilters.length ? (
          <div className="hidden flex-wrap items-center gap-2 md:flex">
            <span className="text-xs text-muted-foreground">Actieve filters:</span>
            {activeFilters.map((f) => (
              <span
                key={f.key}
                className="inline-flex items-center gap-1 rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 text-xs text-primary"
              >
                {f.label}
                <button
                  type="button"
                  aria-label={`${f.label} filter wissen`}
                  onClick={() => setFilters((prev) => ({ ...prev, [f.key]: [] }))}
                  className="rounded-full p-0.5 hover:bg-primary/20"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
            <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => setFilters({})}>
              Alles wissen
            </Button>
          </div>
        ) : null}
      </div>

      <MobileFilters
        columns={mobileColumns}
        optionsFor={optionsFor}
        filters={validFilters}
        onChange={(key, values) => setFilters((prev) => ({ ...prev, [key]: values }))}
        onClearAll={() => setFilters({})}
      />

      <div className="hidden overflow-x-auto md:block">
        <Table className="table-fixed [&_td]:py-4">
          <TableHeader>
            <TableRow>
              <TableHead className="w-1.5 p-0" />
              {orderedColumns.map((col) => (
                <TableHead
                  key={col.key}
                  {...dragProps(col.key)}
                  title="Versleep om de kolomvolgorde te wijzigen"
                  className={`${col.className} select-none cursor-grab align-middle data-[dragging=true]:opacity-50`}
                >
                  <span
                    className={`inline-flex w-full min-w-0 items-center gap-1 whitespace-nowrap ${col.align === "end" ? "justify-end" : ""}`}
                  >
                    <span
                      className="cursor-pointer truncate whitespace-nowrap hover:underline"
                      onClick={() => toggleSort(col.key)}
                    >
                      {col.label}
                      {sort === col.key ? (asc ? " ↑" : " ↓") : ""}
                    </span>
                    {col.filterOf !== nullFn && (optionsFor[col.key]?.length ?? 0) > 0 ? filterFor(col.key) : null}
                  </span>
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredInvoices.map((inv) => {
              const artistNames = [
                ...new Set(inv.bookings.map((b) => b.artists?.name).filter(Boolean)),
              ].join(", ");
              const current = statusOf(inv);
              const expanded = open[inv.number] ?? false;
              return [
                <TableRow key={inv.number} className="hover:bg-muted/50">
                  <FinancialStatusStripeCell status={current || null} />
                  {orderedColumns.map((col) => {
                    const right = col.align === "end";
                    let content: React.ReactNode;
                    switch (col.key) {
                      case "number":
                        content = (
                          <span className="inline-flex items-center gap-2">
                            <button
                              type="button"
                              aria-label={expanded ? "Inklappen" : "Uitklappen"}
                              className="rounded p-1 text-muted-foreground hover:bg-muted"
                              onClick={() => setOpen((p) => ({ ...p, [inv.number]: !expanded }))}
                            >
                              {expanded ? (
                                <ChevronDown className="h-4 w-4" />
                              ) : (
                                <ChevronRight className="h-4 w-4" />
                              )}
                            </button>
                            {inv.number}
                          </span>
                        );
                        break;
                      case "artist":
                        content = artistNames || "—";
                        break;
                      case "bookings":
                        content = inv.bookings.length;
                        break;
                      case "amount":
                        content = formatEuro(inv.amount);
                        break;
                      case "status":
                        content = (
                          <Select
                            value={current || undefined}
                            disabled={saving === inv.number}
                            onValueChange={(value) =>
                              updateInvoiceStatus(
                                inv.number,
                                inv.bookings.map((b) => b.id),
                                value as FinancialStatus,
                              )
                            }
                          >
                            <SelectTrigger className="ml-auto w-[13rem]">
                              <SelectValue placeholder="Gemengde status" />
                            </SelectTrigger>
                            <SelectContent>
                              {FINANCIAL_STATUSES.map((status) => (
                                <SelectItem key={status} value={status}>
                                  {FINANCIAL_STATUS_LABELS[status] ?? status}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        );
                        break;
                      default:
                        content = null;
                    }
                    return (
                      <TableCell
                        key={col.key}
                        className={cn(
                          col.cellClassName,
                          right && "text-right",
                          col.key === "status" && "!py-2",
                        )}
                      >
                        {content}
                      </TableCell>
                    );
                  })}
                </TableRow>,
                expanded ? (
                  <TableRow key={`${inv.number}-details`} className="bg-muted/30">
                    <FinancialStatusStripeCell status={current || null} />
                    <TableCell colSpan={orderedColumns.length} className="p-0">
                      <ul className="divide-y">
                        {inv.bookings.map((b) => (
                          <li
                            key={b.id}
                            className="flex cursor-pointer items-center gap-3 px-2 py-3 hover:bg-muted/50"
                            onClick={() =>
                              navigate({
                                to: "/bookings/$id",
                                params: { id: b.id },
                                search: { tab: "financial" },
                              })
                            }
                          >
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-sm font-medium">{b.event_name}</p>
                              <p className="text-xs text-muted-foreground">
                                {b.artists?.name} · {formatBookingDate(b.event_date)}
                              </p>
                            </div>
                            <div className="w-[16%] shrink-0 text-right">
                              <span className="text-sm tabular-nums text-muted-foreground">
                                {formatEuro(financialInfo(b as Booking, standardMap).amount)}
                              </span>
                            </div>
                            <div className="flex w-[24%] shrink-0 items-center justify-end gap-2">
                              <BookingStatusPill booking={b} />
                              <FinancialStatusBadge status={b.financial_status ?? "nog_spelen"} />
                            </div>
                          </li>
                        ))}
                      </ul>
                    </TableCell>
                  </TableRow>
                ) : null,
              ];
            })}
            {filteredInvoices.length > 0 ? (
              <TableRow className="bg-muted/40 font-semibold hover:bg-muted/40">
                <TableCell />
                {orderedColumns.map((col) => (
                  <TableCell
                    key={col.key}
                    className={`text-sm ${col.align === "end" ? "text-right" : ""}`}
                  >
                    {col.key === "number"
                      ? `Totaal (${filteredInvoices.length} ${filteredInvoices.length === 1 ? "factuur" : "facturen"})`
                      : col.key === "amount"
                        ? formatEuro(totalAmount)
                        : null}
                  </TableCell>
                ))}
              </TableRow>
            ) : null}
          </TableBody>
        </Table>
      </div>

      {filteredInvoices.length === 0 ? (
        <div className="hidden p-10 text-center text-sm text-muted-foreground md:block">
          Geen facturen gevonden die voldoen aan de zoekopdracht of filters.
        </div>
      ) : null}

      {/* Mobiele weergave */}
      <ul className="divide-y md:hidden">
        {filteredInvoices.map((inv) => {
          const current = statusOf(inv);
          const expanded = open[inv.number] ?? false;
          const color = financialStatusColor(current || null);
          return (
            <li key={inv.number} className="overflow-hidden">
              <div className="flex w-full items-stretch text-left transition-colors active:bg-muted/60">
                <div
                  className={cn("w-1.5 shrink-0", STATUS_STRIPE_CLASSES[color])}
                  aria-hidden
                />
                <div className="flex min-w-0 flex-1 flex-col gap-2 px-4 py-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <p className="text-base font-semibold">{inv.number}</p>
                      <p className="text-sm text-muted-foreground">
                        {inv.bookings.length} {inv.bookings.length === 1 ? "boeking" : "boekingen"} ·{" "}
                        {formatEuro(inv.amount)}
                      </p>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      aria-label={expanded ? "Factuur inklappen" : "Factuur uitklappen"}
                      className="-mr-2 h-8 w-8 shrink-0"
                      onClick={() => setOpen((previous) => ({ ...previous, [inv.number]: !expanded }))}
                    >
                      {expanded ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  <Select
                    value={current || undefined}
                    disabled={saving === inv.number}
                    onValueChange={(value) =>
                      updateInvoiceStatus(
                        inv.number,
                        inv.bookings.map((b) => b.id),
                        value as FinancialStatus,
                      )
                    }
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Gemengde status" />
                    </SelectTrigger>
                    <SelectContent>
                      {FINANCIAL_STATUSES.map((status) => (
                        <SelectItem key={status} value={status}>
                          {FINANCIAL_STATUS_LABELS[status] ?? status}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {expanded ? (
                    <ul className="divide-y rounded-md border">
                      {inv.bookings.map((b) => (
                        <li
                          key={b.id}
                          className="flex items-center justify-between gap-2 px-3 py-2"
                          onClick={() =>
                            navigate({
                              to: "/bookings/$id",
                              params: { id: b.id },
                              search: { tab: "financial" },
                            })
                          }
                        >
                          <div className="min-w-0">
                            <p className="truncate text-sm font-medium">{b.event_name}</p>
                            <p className="text-xs text-muted-foreground">
                              {b.artists?.name} · {formatBookingDate(b.event_date)}
                            </p>
                          </div>
                          <div className="flex shrink-0 items-center gap-2">
                            <span className="text-sm tabular-nums text-muted-foreground">
                              {formatEuro(financialInfo(b as Booking, standardMap).amount)}
                            </span>
                            <FinancialStatusBadge status={b.financial_status ?? "nog_spelen"} />
                          </div>
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </div>
              </div>
            </li>
          );
        })}
        {filteredInvoices.length > 0 ? (
          <li className="bg-muted/40 px-4 py-4">
            <p className="text-sm font-semibold">
              Totaal ({filteredInvoices.length} {filteredInvoices.length === 1 ? "factuur" : "facturen"})
            </p>
            <dl className="mt-2 grid grid-cols-2 gap-x-4 gap-y-2">
              <div className="min-w-0">
                <dt className="text-xs text-muted-foreground">Totaal</dt>
                <dd className="text-sm font-semibold tabular-nums">{formatEuro(totalAmount)}</dd>
              </div>
            </dl>
          </li>
        ) : null}
      </ul>

      {filteredInvoices.length === 0 ? (
        <div className="p-10 text-center text-sm text-muted-foreground md:hidden">
          Geen facturen gevonden die voldoen aan de zoekopdracht of filters.
        </div>
      ) : null}

      {withoutNumber > 0 ? (
        <div className="border-t p-4 text-xs text-muted-foreground">
          {withoutNumber} {withoutNumber === 1 ? "boeking heeft" : "boekingen hebben"} nog geen
          factuurnummer.
        </div>
      ) : null}
    </div>
  );
}

// Hulpje om te bepalen of een kolom filterbaar is zonder elke cel apart te controleren.
const nullFn = () => null;
