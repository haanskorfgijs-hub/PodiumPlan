import { X } from "lucide-react";

import { ColumnFilter, FilterOption } from "@/components/column-filter";
import { Button } from "@/components/ui/button";

export type MobileFilterColumn = { key: string; label: string };

type Props = {
  columns: MobileFilterColumn[];
  optionsFor: Record<string, FilterOption[]>;
  filters: Record<string, string[]>;
  onChange: (key: string, values: string[]) => void;
  onClearAll: () => void;
};

/**
 * Filterbalk voor mobiel: dezelfde kolomfilters als in de tabelkoppen,
 * maar als horizontaal scrollbare chips omdat de tabel op telefoon verborgen is.
 */
export function MobileFilters({ columns, optionsFor, filters, onChange, onClearAll }: Props) {
  const activeCount = columns.reduce((n, c) => n + (filters[c.key]?.length ? 1 : 0), 0);

  return (
    <div className="border-b p-3 md:hidden">
      <div className="flex items-center justify-between gap-2 pb-2">
        <p className="text-xs font-medium text-muted-foreground">Filters</p>
        {activeCount > 0 ? (
          <Button variant="ghost" size="sm" className="h-8 px-2 text-xs" onClick={onClearAll}>
            <X className="mr-1 h-3 w-3" /> Alles wissen
          </Button>
        ) : null}
      </div>
      <div className="-mx-3 flex flex-wrap gap-2 px-3 pb-1">
        {columns.map((col) => {
          const selected = filters[col.key] ?? [];
          return (
            <span
              key={col.key}
              className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-2 text-xs ${
                selected.length ? "border-primary/40 bg-primary/10 text-primary" : "bg-background"
              }`}
            >
              <span className="whitespace-nowrap">{col.label}</span>
              {selected.length ? (
                <span className="rounded-full bg-primary/20 px-1.5 tabular-nums">
                  {selected.length}
                </span>
              ) : null}
              <ColumnFilter
                options={optionsFor[col.key] ?? []}
                selected={selected}
                onChange={(values) => onChange(col.key, values)}
              />
            </span>
          );
        })}
      </div>
    </div>
  );
}
