import { cn } from "@/lib/utils";
import { STATUS_STRIPE_CLASSES } from "@/components/status-badges";
import type { StatusColor } from "@/lib/data";

const WEEKDAYS = ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"];

/**
 * Mobiele boekingsregel met een datumblok links en een gekleurde statusbalk,
 * zodat de datum direct opvalt bij het scrollen.
 */
export function MobileDateCard({
  date,
  color,
  onClick,
  children,
}: {
  date?: string | null;
  color: StatusColor;
  onClick: () => void;
  children: React.ReactNode;
}) {
  const d = date ? new Date(date) : null;
  const valid = d && !Number.isNaN(d.getTime());

  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-stretch text-left transition-colors active:bg-muted/60"
    >
      <div className="flex w-16 shrink-0 flex-col items-center justify-center gap-0.5 bg-foreground py-4 text-background">
        <div className="text-[11px] font-medium tracking-wide">
          {valid ? WEEKDAYS[d!.getDay()] : "—"}
        </div>
        <div className="text-2xl leading-none font-bold tabular-nums">
          {valid ? String(d!.getDate()).padStart(2, "0") : ""}
        </div>
      </div>
      <div className={cn("w-1.5 shrink-0", STATUS_STRIPE_CLASSES[color])} />
      <div className="flex min-w-0 flex-1 flex-col gap-1.5 px-4 py-4">{children}</div>
    </button>
  );
}
