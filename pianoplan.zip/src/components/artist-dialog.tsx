import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  logActivity,
  parseArtistStatuses,
  defaultArtistStatuses,
  STATUS_COLORS,
  STATUS_COLOR_LABELS,
  type Artist,
  type ArtistStatus,
  type StatusColor,
  type StatusStage,
} from "@/lib/data";
import { STATUS_COLOR_CLASSES } from "@/components/status-badges";
import { PlaceInput } from "@/components/dynamic-field-input";

export function ArtistDialog({
  open,
  onOpenChange,
  artist,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  artist?: Artist | null;
}) {
  const queryClient = useQueryClient();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [homeLocation, setHomeLocation] = useState("");
  const [statuses, setStatuses] = useState<ArtistStatus[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setName(artist?.name ?? "");
    setDescription(artist?.description ?? "");
    setHomeLocation(artist?.home_location ?? "");
    // Bestaande statussen zonder fase gelden voor beide fases: splitsen in twee regels.
    const parsed = artist ? parseArtistStatuses(artist.booking_statuses) : defaultArtistStatuses();
    const migrated: ArtistStatus[] = [];
    for (const s of parsed) {
      if (s.stage) migrated.push(s);
      else {
        migrated.push({ ...s, stage: "create" });
        migrated.push({ ...s, id: crypto.randomUUID(), stage: "edit" });
      }
    }
    setStatuses(migrated);
  }, [open, artist]);

  function addStatus(stage: StatusStage) {
    setStatuses((prev) => [
      ...prev,
      { id: crypto.randomUUID(), label: "", color: "gray" as StatusColor, stage },
    ]);
  }

  function updateStatus(id: string, patch: Partial<ArtistStatus>) {
    setStatuses((prev) => prev.map((s) => (s.id === id ? { ...s, ...patch } : s)));
  }

  function removeStatus(id: string) {
    setStatuses((prev) => prev.filter((s) => s.id !== id));
  }


  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return toast.error("Vul een naam in.");
    const cleaned = statuses
      .map((s) => ({ ...s, label: s.label.trim() }))
      .filter((s) => s.label.length > 0);
    setSaving(true);
    if (artist) {
      const { error } = await supabase
        .from("artists")
        .update({
          name: name.trim(),
          description: description.trim() || null,
          home_location: homeLocation.trim() || null,
          booking_statuses: cleaned,
        })
        .eq("id", artist.id);
      setSaving(false);
      if (error) return toast.error(error.message);
      await logActivity({
        entityType: "artist",
        entityId: artist.id,
        action: "update",
        summary: `Artiest ${name} bijgewerkt`,
      });
    } else {
      const { data: userData } = await supabase.auth.getUser();
      const { data, error } = await supabase
        .from("artists")
        .insert({
          name: name.trim(),
          description: description.trim() || null,
          home_location: homeLocation.trim() || null,
          booking_statuses: cleaned,
          created_by: userData.user?.id ?? null,
        })
        .select()
        .maybeSingle();
      setSaving(false);
      if (error) return toast.error(error.message);
      await logActivity({
        entityType: "artist",
        entityId: data?.id,
        action: "create",
        summary: `Artiest ${name} toegevoegd`,
      });
    }
    queryClient.invalidateQueries();
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{artist ? "Artiest bewerken" : "Nieuwe artiest"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={save} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="artist-name">Naam</Label>
            <Input id="artist-name" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="artist-desc">Omschrijving</Label>
            <Textarea
              id="artist-desc"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="artist-home">Thuislocatie</Label>
            <PlaceInput
              id="artist-home"
              value={homeLocation}
              onChange={setHomeLocation}
              placeholder="Zoek thuislocatie of adres…"
            />
          </div>

          {(
            [
              {
                stage: "create" as StatusStage,
                title: "Statussen bij aanmaken boeking",
                hint: "Kies uit deze statussen bij het aanmaken van een boeking.",
              },
              {
                stage: "edit" as StatusStage,
                title: "Statussen bij aanpassen boeking",
                hint: "Kies uit deze statussen bij het aanpassen van een boeking.",
              },
              {
                stage: "after" as StatusStage,
                title: "Statussen na boeking",
                hint: "Deze statussen zijn pas te kiezen vanaf de dag dat de boeking plaatsvindt.",
              },
            ] as const
          ).map((section) => {
            const list = statuses.filter((s) => s.stage === section.stage);
            return (
              <div key={section.stage} className="space-y-3 rounded-lg border p-3">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <Label>{section.title}</Label>
                    <p className="text-xs text-muted-foreground">{section.hint}</p>
                  </div>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    onClick={() => addStatus(section.stage)}
                  >
                    <Plus className="mr-1 h-4 w-4" /> Status
                  </Button>
                </div>
                {list.length === 0 ? (
                  <p className="text-xs text-muted-foreground">
                    Nog geen statussen in deze fase.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {list.map((s) => (
                      <div key={s.id} className="flex items-center gap-2">
                        <Input
                          value={s.label}
                          placeholder="Statusnaam"
                          onChange={(e) => updateStatus(s.id, { label: e.target.value })}
                        />
                        <Select
                          value={s.color}
                          onValueChange={(v) => updateStatus(s.id, { color: v as StatusColor })}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {STATUS_COLORS.map((c) => (
                              <SelectItem key={c} value={c}>
                                <span
                                  className={`mr-2 inline-block h-2.5 w-2.5 rounded-full border ${STATUS_COLOR_CLASSES[c]}`}
                                />
                                {STATUS_COLOR_LABELS[c]}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeStatus(s.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}


          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Annuleren
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Bezig…" : "Opslaan"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
