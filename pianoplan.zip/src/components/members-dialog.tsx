import { sendBookingEmails } from "@/lib/booking-emails.functions";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Check, ChevronsUpDown, Trash2, UserPlus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import type { Database } from "@/integrations/supabase/types";
import { useCurrentUser } from "@/lib/session";
import { useRoleLabels } from "@/lib/roles";
import { usesAccountPermissions } from "@/lib/role-permission-access";

export type MemberRole = Database["public"]["Enums"]["member_role"];

export const MEMBER_ROLES: MemberRole[] = ["boeker", "gebruiker", "lezer"];
export const MEMBER_ROLE_LABELS: Record<MemberRole, string> = {
  boeker: "Boeker (mag aanpassen, geen artiesten)",
  gebruiker: "Manager (mag aanpassen)",
  lezer: "Lezer (alleen bekijken)",
};

type Scope = "artist" | "booking";

async function fetchRows(scope: Scope, id: string) {
  if (scope === "artist") {
    const { data, error } = await supabase
      .from("artist_members")
      .select("id, user_id, role, status, created_at")
      .eq("artist_id", id)
      .order("created_at");
    if (error) throw error;
    return data ?? [];
  }
  const { data, error } = await supabase
    .from("booking_members")
    .select("id, user_id, role, status, created_at")
    .eq("booking_id", id)
    .order("created_at");
  if (error) throw error;
  const { data: effective, error: roleError } = await supabase.rpc("booking_member_roles", { _booking_id: id });
  if (roleError) throw roleError;
  return (data ?? []).map((member) => {
    const inherited = effective?.find((entry) => entry.user_id === member.user_id);
    return { ...member, role: inherited?.role ?? member.role, role_locked: inherited?.role_locked ?? false };
  });
}

export function useMembers(scope: Scope, id?: string) {
  return useQuery({
    queryKey: ["members", scope, id],
    enabled: !!id,
    queryFn: async () => {
      if (!id) return [];
      const rows = await fetchRows(scope, id);
      const ids = rows.map((m) => m.user_id);
      let profiles: { id: string; name: string; email: string }[] = [];
      if (ids.length) {
        const { data: p } = await supabase
          .from("profiles")
          .select("id, name, email")
          .in("id", ids);
        profiles = p ?? [];
      }
      return rows.map((m) => ({
        ...m,
        role: m.role as MemberRole,
        role_locked: "role_locked" in m && m.role_locked === true,
        profile: profiles.find((p) => p.id === m.user_id) ?? null,
      }));
    },
  });
}


export function MembersDialog({
  scope,
  id,
  title,
  open,
  onOpenChange,
}: {
  scope: Scope;
  id: string;
  artistId?: string;
  title: string;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const queryClient = useQueryClient();
  const currentUser = useCurrentUser();
  const roleLabels = useRoleLabels();
  const { data: accountTypes = [], isSuccess: accountTypesLoaded } = useQuery({
    queryKey: ["member-account-types", scope, id],
    enabled: open,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("member_account_types", { _scope: scope, _id: id });
      if (error) throw error;
      return data ?? [];
    },
  });
  const accountRole = (memberUserId: string) => accountTypes.find((a) => a.user_id === memberUserId)?.account_role;
  const { data: members = [], refetch } = useMembers(scope, open ? id : undefined);
  const [userId, setUserId] = useState("");
  const [pickerOpen, setPickerOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [newRole, setNewRole] = useState<MemberRole>("gebruiker");

  async function changeRole(memberId: string, role: MemberRole) {
    const { data, error } = await supabase
      .from("artist_members")
      .update({ role })
      .eq("id", memberId)
      .select("id");
    if (error) return toast.error(error.message);
    if (!data?.length) return toast.error("Je hebt geen rechten om deze rol aan te passen.");
    toast.success("Rol aangepast");
    refetch();
    queryClient.invalidateQueries();
  }

  const { data: invitable = [] } = useQuery({
    queryKey: ["invitable-users"],
    enabled: open,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("invitable_users");
      if (error) throw error;
      return (data ?? []) as { id: string; name: string; email: string }[];
    },
  });

  const accounts =
    scope === "booking" && currentUser.id && !invitable.some((a) => a.id === currentUser.id)
      ? [
          { id: currentUser.id, name: `${currentUser.name || currentUser.email || "Ik"} (jij)`, email: currentUser.email },
          ...invitable,
        ]
      : invitable;

  const invited = new Set(members.map((m) => m.user_id));
  const options = accounts.filter((a) => !invited.has(a.id));
  const selected = accounts.find((a) => a.id === userId) ?? null;

  async function invite() {
    if (!userId) return;
    setBusy(true);
    const isSelf = userId === currentUser.id;
    const { error } =
      scope === "artist"
        ? await supabase
            .from("artist_members")
            .upsert({ artist_id: id, user_id: userId, role: usesAccountPermissions(accountRole(userId)) ? "lezer" : newRole, status: "pending" }, { onConflict: "artist_id,user_id" })
        : await supabase
            .from("booking_members")
            .upsert(
              { booking_id: id, user_id: userId, role: "lezer", status: isSelf ? "accepted" : "pending" },
              { onConflict: "booking_id,user_id" },
            );
    setBusy(false);
    if (error) return toast.error(error.message);
    if (isSelf && scope === "booking") toast.success("Je bent toegevoegd aan het team");
    if (!isSelf && scope === "booking") sendBookingEmails({ data: { bookingId: id, kind: "invitation" } }).catch(() => {});
    setUserId("");
    refetch();
    queryClient.invalidateQueries();
  }

  async function remove(memberId: string) {
    const { error } =
      scope === "artist"
        ? await supabase.from("artist_members").delete().eq("id", memberId)
        : await supabase.from("booking_members").delete().eq("id", memberId);
    if (error) return toast.error(error.message);

    refetch();
    queryClient.invalidateQueries();
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>{scope === "artist" ? "Beheerder toevoegen" : "Gebruikers uitnodigen"}</DialogTitle>
          <DialogDescription>
            {scope === "artist"
              ? `Na acceptatie beheert deze gebruiker ${title} met de gekozen rol. Die rol bepaalt de rechten bij alle boekingen van deze artiest. Dit voegt de gebruiker niet toe aan boekingsteams.`
              : `Uitgenodigde gebruikers krijgen alleen toegang tot de boeking "${title}" zodra zij de uitnodiging accepteren.`}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 sm:grid-cols-2">
          {scope === "artist" && userId && accountTypesLoaded && !usesAccountPermissions(accountRole(userId)) ? (
            <div className="min-w-0 space-y-2 sm:col-span-2">
              <Label>Rol binnen artiest</Label>
              <Select value={newRole} onValueChange={(v) => setNewRole(v as MemberRole)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {MEMBER_ROLES.map((r) => (
                    <SelectItem key={r} value={r}>{MEMBER_ROLE_LABELS[r]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : null}
          <div className={`min-w-0 space-y-2 ${scope === "artist" ? "sm:col-span-2" : ""}`}>
            <Label>Gebruiker</Label>
            <Popover open={pickerOpen} onOpenChange={setPickerOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  className="w-full justify-between font-normal"
                >
                  <span className="truncate">
                    {selected
                      ? `${selected.name || selected.email}${selected.name ? ` · ${selected.email}` : ""}`
                      : "Kies een account"}
                  </span>
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[min(24rem,90vw)] p-0" align="start">
                <Command>
                  <CommandInput placeholder="Zoek op naam of e-mail…" />
                  <CommandList>
                    <CommandEmpty>Geen accounts gevonden.</CommandEmpty>
                    <CommandGroup>
                      {options.map((a) => (
                        <CommandItem
                          key={a.id}
                          value={`${a.name} ${a.email}`}
                          onSelect={() => {
                            setUserId(a.id);
                            setPickerOpen(false);
                          }}
                        >
                          <Check
                            className={`mr-2 h-4 w-4 ${a.id === userId ? "opacity-100" : "opacity-0"}`}
                          />
                          <span className="min-w-0">
                            <span className="block truncate">{a.name || a.email}</span>
                            <span className="block truncate text-xs text-muted-foreground">
                              {a.email}
                            </span>
                          </span>
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>

          {scope === "booking" ? (
            <p className="text-xs text-muted-foreground sm:col-span-2">
              Teamleden kunnen de boeking alleen bekijken. Is iemand beheerder van deze artiest, dan gelden diens beheerrechten.
            </p>
          ) : null}
          {scope === "artist" && usesAccountPermissions(accountRole(userId)) ? (
            <div className="sm:col-span-2"><Label>Accounttype</Label><p className="text-sm">{roleLabels[accountRole(userId) ?? "lezer"]}</p></div>
          ) : null}
          <Button onClick={invite} disabled={busy || !userId || !accountTypesLoaded} className="sm:col-span-2">
            <UserPlus className="mr-1 h-4 w-4" /> {scope === "artist" ? "Beheerder toevoegen" : "Uitnodigen"}
          </Button>
        </div>


        <div className="mt-2 divide-y rounded-lg border">
          {members.map((m) => (
            <div
              key={m.id}
              className="flex flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center sm:justify-between"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">
                  {m.profile?.name || m.profile?.email || "Gebruiker"}
                </p>
                <p className="truncate text-xs text-muted-foreground">{m.profile?.email ?? ""}</p>
                <p className="mt-1 text-xs">
                  {m.status === "accepted" ? (
                    <span className="text-muted-foreground">Uitnodiging geaccepteerd</span>
                  ) : m.status === "declined" ? (
                    <span className="text-destructive">Uitnodiging geweigerd</span>
                  ) : (
                    <span className="text-muted-foreground">Wacht op acceptatie</span>
                  )}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                {usesAccountPermissions(accountRole(m.user_id)) ? (
                  <Badge variant="secondary">{roleLabels[accountRole(m.user_id) ?? "lezer"]}</Badge>
                ) : scope === "artist" && accountTypesLoaded ? (
                  <Select value={m.role} onValueChange={(v) => changeRole(m.id, v as MemberRole)}>
                    <SelectTrigger className="h-9 w-[200px]" aria-label="Rol binnen artiest">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {MEMBER_ROLES.map((r) => (
                        <SelectItem key={r} value={r}>{MEMBER_ROLE_LABELS[r]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : scope === "booking" ? (
                  <span className="text-sm text-muted-foreground">
                    {m.role_locked && m.role !== "lezer"
                      ? `${MEMBER_ROLE_LABELS[m.role]} (artiestbeheer)`
                      : MEMBER_ROLE_LABELS.lezer}
                  </span>
                ) : null}
                <Button
                  size="icon"
                  variant="ghost"
                  aria-label="Lid verwijderen"
                  onClick={() => remove(m.id)}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))}
          {members.length === 0 ? (
            <p className="px-4 py-8 text-center text-sm text-muted-foreground">
              Nog niemand uitgenodigd.
            </p>
          ) : null}
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Sluiten
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function MemberCountBadge({ count }: { count: number }) {
  if (!count) return null;
  return <Badge variant="secondary">{count} leden</Badge>;
}
