import { sendBookingEmails } from "@/lib/booking-emails.functions";
import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DynamicFieldInput } from "@/components/dynamic-field-input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  parseArtistStatuses,
  statusesForStage,
  statusOptions,
  FINANCIAL_STATUSES,
  FINANCIAL_STATUS_LABELS,
  FIELD_TABS,
  BOOKING_TAB_LABELS,
  PRICING_TAB,
  eventNameField,
  fieldTab,
  logActivity,
  parseDefaultTasks,
  parseDefaultTeam,
  parseRunSheet,

  parseFields,
  inSheetForBooking,
  toggleSheetField,
  SHEET_EXCLUDE_KEY,
  useArtists,
  useStandards,
  type StandardField,
  type DefaultTeamMember,
} from "@/lib/data";
import { DefaultTeamEditor } from "@/components/default-team-editor";
import { PricingPanel } from "@/components/pricing";
import { usePermission } from "@/lib/permissions";

export function NewBookingDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { data: artists = [] } = useArtists();
  const { allowed: canViewPricing } = usePermission("pricing.view");
  const { allowed: canViewFinancialTab } = usePermission("financial.view");
  const isAdmin = canViewFinancialTab;
  const visibleTabs: string[] = [
    FIELD_TABS[0],
    ...(canViewFinancialTab ? [FIELD_TABS[1]] : []),
    ...(canViewPricing ? [PRICING_TAB] : []),
  ];

  const [artistId, setArtistId] = useState<string>("");
  const [standardId, setStandardId] = useState<string>("");
  const { data: standards = [] } = useStandards(artistId || undefined);
  const [saving, setSaving] = useState(false);
  const [values, setValues] = useState<Record<string, string>>({});
  const [customStatus, setCustomStatus] = useState<string>("");
  const [financialStatus, setFinancialStatus] =
    useState<(typeof FINANCIAL_STATUSES)[number]>("nog_spelen");
  const [tab, setTab] = useState<string>("booking");
  const [team, setTeam] = useState<DefaultTeamMember[]>([]);

  const artistStatuses = statusesForStage(
    parseArtistStatuses(artists.find((a) => a.id === artistId)?.booking_statuses),
    "create",
  );
  const statusChoices = statusOptions(artistStatuses);
  const statusValue = customStatus || artistStatuses[0]?.label || "";

  const standard = standards.find((s) => s.id === standardId);
  const fields: StandardField[] = standard ? parseFields(standard.fields) : [];
  const artist = artists.find((a) => a.id === artistId);
  const distanceLocations = [
    ...(artist?.home_location
      ? [
          {
            id: "__artist_home",
            label: `Thuislocatie ${artist.name}`,
            address: artist.home_location,
          },
        ]
      : []),
    ...fields
      .filter((f) => f.type === "map")
      .map((f) => ({ id: f.id, label: f.label, address: values[f.id] ?? "" })),
  ];

  function firstValueOfType(type: string) {
    const f = fields.find((x) => x.type === type);
    return f ? (values[f.id] ?? "") : "";
  }

  function pickStandard(id: string) {
    setStandardId(id);
    const s = standards.find((x) => x.id === id);
    const defaults: Record<string, string> = {};
    parseFields(s?.fields).forEach((f) => {
      if (f.default) defaults[f.id] = f.default;
    });
    setValues(defaults);
    setTeam(s ? parseDefaultTeam(s.default_team) : []);
  }

  async function save() {
    if (!artistId || !statusChoices.some((s) => s.value === statusValue)) return toast.error("Kies een artiest en een status van die artiest.");
    const nameField = eventNameField(fields);
    const eventName =
      (nameField ? (values[nameField.id] ?? "").trim() : "") ||
      artists.find((a) => a.id === artistId)?.name ||
      "Boeking";
    const eventDate =
      firstValueOfType("date") ||
      firstValueOfType("datetime").slice(0, 10) ||
      new Date().toISOString().slice(0, 10);
    setSaving(true);
    const { data: userData } = await supabase.auth.getUser();
    const { data, error } = await supabase
      .from("bookings")
      .insert({
        artist_id: artistId,
        standard_id: standardId || null,
        event_name: eventName,
        event_date: eventDate,
        artist_status: statusValue || null,
        financial_status: financialStatus,
        field_values: values,
        run_sheet: (standard?.run_sheet_enabled
          ? parseRunSheet(standard.run_sheet)
          : []) as unknown as never,

        created_by: userData.user?.id ?? null,
      })
      .select("id")
      .single();
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    const defaultTasks = parseDefaultTasks(standard?.default_tasks);
    if (defaultTasks.length) {
      const rows = defaultTasks.map((t) => {
        let deadline: string | null = null;
        if (t.daysBefore != null && eventDate) {
          const d = new Date(eventDate);
          d.setDate(d.getDate() - t.daysBefore);
          deadline = d.toISOString().slice(0, 10);
        }
        return {
          title: t.title,
          description: t.description || null,
          booking_id: data.id,
          deadline,
          created_by: userData.user?.id ?? null,
        };
      });
      const { error: taskError } = await supabase.from("tasks").insert(rows);
      if (taskError) toast.error(`Taken aanmaken mislukt: ${taskError.message}`);
    }

    const teamRows = team
      .filter((m) => m.userId)
      .map((m) => ({
        booking_id: data.id,
        user_id: m.userId,
        role: "lezer" as const,
        status: "pending" as const,
      }));
    if (teamRows.length) {
      const { error: teamError } = await supabase.from("booking_members").insert(teamRows);
      if (teamError) toast.error(`Teamleden uitnodigen mislukt: ${teamError.message}`);
      else sendBookingEmails({ data: { bookingId: data.id, kind: "invitation" } }).catch(() => {});
    }

    await logActivity({
      entityType: "booking",
      entityId: data.id,
      action: "aangemaakt",
      summary: `heeft boeking "${eventName}" aangemaakt.`,
    });
    queryClient.invalidateQueries();
    onOpenChange(false);
    navigate({ to: "/bookings/$id", params: { id: data.id }, search: { tab: "booking" } });
  }


  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="flex max-h-[90vh] w-full max-w-4xl flex-col gap-0 overflow-hidden p-0"
      >
        <DialogHeader className="border-b px-6 py-4 text-left">
          <DialogTitle>Nieuwe boeking</DialogTitle>
          <DialogDescription>
            Kies een artiest, optredenstandaard en status, vul daarna de gegevens aan.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto px-6 py-5">
          <div className="mx-auto max-w-3xl space-y-8">
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <Label>Artiest *</Label>
                <Select
                  value={artistId || undefined}
                  onValueChange={(v) => {
                    setArtistId(v);
                    setCustomStatus("");
                    setStandardId("");
                    setValues({});
                    setTeam([]);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecteer artiest" />
                  </SelectTrigger>
                  <SelectContent>
                    {artists.map((a) => (
                      <SelectItem key={a.id} value={a.id}>
                        {a.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Optredenstandaard</Label>
                <Select value={standardId || undefined} onValueChange={pickStandard} disabled={!artistId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecteer standaard" />
                  </SelectTrigger>
                  <SelectContent>
                    {standards.map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                {tab === "financial" && isAdmin ? (
                  <>
                    <Label>Financiële status</Label>
                    <Select
                      value={financialStatus}
                      onValueChange={(v) =>
                        setFinancialStatus(v as (typeof FINANCIAL_STATUSES)[number])
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {FINANCIAL_STATUSES.map((s) => (
                          <SelectItem key={s} value={s}>
                            {FINANCIAL_STATUS_LABELS[s]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </>
                ) : (
                  <>
                    <Label>Boekingsstatus</Label>
                    <Select
                      value={statusValue || undefined}
                      onValueChange={(v) => setCustomStatus(v)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={statusChoices.length ? "Status" : "Geen statussen bij deze artiest"} />
                      </SelectTrigger>
                      <SelectContent>
                        {statusChoices.map((s) => (
                          <SelectItem key={s.value} value={s.value}>
                            {s.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </>
                )}
              </div>
            </div>

            {fields.length > 0 && (
              <Tabs value={tab} onValueChange={setTab}>

                {visibleTabs.length > 1 ? (<TabsList>
                  {visibleTabs.map((t) => (
                    <TabsTrigger key={t} value={t}>
                      {BOOKING_TAB_LABELS[t]}
                    </TabsTrigger>
                  ))}
                </TabsList>) : null}
                {visibleTabs.map((t) => {
                  const tabFields = fields.filter((f) => fieldTab(f) === t);
                  const tabSections = Array.from(
                    new Set(tabFields.map((f) => f.section ?? "Extra velden")),
                  );
                  return (
                    <TabsContent key={t} value={t} className="mt-6 space-y-8">
                      {t === PRICING_TAB ? (
                        <PricingPanel
                          fields={fields}
                          values={values}
                          onChange={(key, v) => setValues((prev) => ({ ...prev, [key]: v }))}
                        />
                      ) : tabFields.length === 0 ? (
                        <p className="text-sm text-muted-foreground">
                          Nog geen velden in dit tabblad.
                        </p>
                      ) : (

                        tabSections.map((section, sectionIndex) => (
                          <div key={section} className="space-y-4">
                            <div className="flex items-center gap-2 border-b pb-2">
                              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[10px] font-bold text-primary">
                                {sectionIndex + 1}
                              </span>
                              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                                {section}
                              </h3>
                            </div>
                            <div className="grid grid-cols-1 gap-5">
                              {tabFields
                                .filter((f) => (f.section ?? "Extra velden") === section)
                                .map((f) => (
                                  <Field key={f.id} label={f.label}>
                                    <DynamicFieldInput
                                      field={f}
                                      fields={fields}
                                      values={values}
                                      locations={distanceLocations}
                                      value={values[f.id] ?? ""}
                                      onChange={(v) =>
                                        setValues((prev) => ({ ...prev, [f.id]: v }))
                                      }
                                    />
                                    {t === "booking" ? (
                                      <label className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                                        <Checkbox
                                          checked={inSheetForBooking(f, values)}
                                          onCheckedChange={(c) =>
                                            setValues((prev) => ({
                                              ...prev,
                                              [SHEET_EXCLUDE_KEY]: toggleSheetField(
                                                prev,
                                                fields,
                                                f.id,
                                                c === true,
                                              ),
                                            }))
                                          }
                                        />
                                        In gegevensblad
                                      </label>
                                    ) : null}
                                  </Field>
                                ))}
                            </div>
                          </div>
                        ))
                      )}
                    </TabsContent>
                  );
                })}
              </Tabs>
            )}

            {standardId ? (
              <div className="space-y-3 border-t pt-4">
                <div>
                  <Label>Teamleden</Label>
                  <p className="text-xs text-muted-foreground">
                    Deze teamleden worden automatisch uitgenodigd bij deze boeking. Je kunt de
                    lijst hier nog aanpassen.
                  </p>
                </div>
                <DefaultTeamEditor value={team} onChange={setTeam} />
              </div>
            ) : null}
          </div>
        </div>

        <DialogFooter className="gap-2 border-t px-6 py-4 sm:justify-between">
          <div />
          <div className="flex gap-2">
            <Button variant="ghost" onClick={() => onOpenChange(false)}>
              Annuleren
            </Button>
            <Button onClick={save} disabled={saving}>
              {saving ? "Opslaan…" : "Boeking opslaan"}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  children,
  wide,
}: {
  label: string;
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <div className={`space-y-2 ${wide ? "sm:col-span-2" : ""}`}>
      <Label>{label}</Label>
      {children}
    </div>
  );
}
