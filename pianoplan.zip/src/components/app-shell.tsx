import { useState, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  BarChart3,
  CalendarDays,
  CalendarRange,
  CheckSquare,
  Euro,
  History,
  LayoutDashboard,
  LogOut,
  MailQuestion,
  Menu,
  Mic2,
  Plus,
  Settings,
  User,

  Users,
  Contact,
  X,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

import { useRealtimeSync } from "@/lib/data";
import { NewBookingDialog } from "@/components/new-booking-dialog";
import { usePermission } from "@/lib/permissions";
import { useIncomingContactRequests, useInvitations } from "@/lib/invitations";
import { AccountSwitcher } from "@/components/account-switcher";
import { InboxMenu } from "@/components/inbox-menu";
import { YearFilterSelect } from "@/components/year-filter-select";
import logoAsset from "@/assets/podiumplan-logo.png.asset.json";


const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/bookings", label: "Boekingen", icon: CalendarDays },
  { to: "/tasks", label: "Takenlijst", icon: CheckSquare },
  { to: "/artists", label: "Artiesten", icon: Mic2 },
] as const;

export function AppShell({
  title,
  subtitle,
  actions,
  children,
  user,
}: {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  children: ReactNode;
  user: { email?: string; name?: string; avatarUrl?: string | null };
}) {
  useRealtimeSync();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [mobileOpen, setMobileOpen] = useState(false);
  const [bookingOpen, setBookingOpen] = useState(false);
  const { allowed: canManageUsers } = usePermission("users.manage");
  const { allowed: canViewArtists } = usePermission("artists.view");
  const { allowed: canSeeStats } = usePermission("statistics.view");
  const { allowed: canSeeFinancial } = usePermission("financial.view");
  const { allowed: canSeeActivity } = usePermission("activity.view");
  const { allowed: canCreateBooking } = usePermission("bookings.create");
  const { data: invitations = [] } = useInvitations();



  const initials = (user.name || user.email || "?").slice(0, 2).toUpperCase();

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    localStorage.removeItem("podiumplan-admin-original-session");
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const { data: contactRequests = [] } = useIncomingContactRequests();
  const showInvitations = invitations.length > 0 || contactRequests.length > 0;

  const titleBlock = (
    <div className="min-w-0 flex-1">
      <h1 className="truncate text-lg font-semibold">{title}</h1>
      {subtitle ? (
        <p className="truncate text-xs text-muted-foreground">{subtitle}</p>
      ) : null}
    </div>
  );

  const hamburger = (
    <Button
      variant="ghost"
      size="icon"
      className="lg:hidden"
      onClick={() => setMobileOpen(true)}
    >
      <Menu className="h-5 w-5" />
    </Button>
  );

  const onBookingDetail = pathname.startsWith("/bookings/");

  const showMobileBookingButton =
    canCreateBooking &&
    (pathname === "/dashboard" || pathname === "/bookings");

  const actionItems = (
    <>
      {actions}
      {!canCreateBooking || onBookingDetail ? null : (
        <Button
          size="sm"
          className="hidden lg:inline-flex"
          onClick={() => setBookingOpen(true)}
          aria-label="Nieuwe boeking"
        >
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">Nieuwe boeking</span>
        </Button>
      )}
    </>
  );


  const mobileBookingButton = !showMobileBookingButton ? null : (
    <div className="lg:hidden">
      <Button
        className="w-full"
        onClick={() => setBookingOpen(true)}
        aria-label="Nieuwe boeking"
      >
        <Plus className="h-4 w-4" />
        Nieuwe boeking
      </Button>
    </div>
  );

  const rightItems = (
    <>
      <YearFilterSelect />
      <InboxMenu />
    </>
  );


  const accountMenu = (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          className="rounded-full ring-offset-background focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
          aria-label="Account"
        >
          <Avatar className="h-9 w-9 border">
            {user.avatarUrl ? (
              <AvatarImage src={user.avatarUrl} alt="Profielfoto" />
            ) : null}
            <AvatarFallback className="bg-primary text-primary-foreground text-xs">
              {initials}
            </AvatarFallback>
          </Avatar>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" collisionPadding={8} className="w-56 max-w-[calc(100vw-1rem)]">
        <AccountSwitcher label={user.name || user.email || ""} />
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => navigate({ to: "/account" })}>
          <Settings className="mr-2 h-4 w-4" /> Accountinstellingen
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => navigate({ to: "/gebruiksinstellingen" })}>
          <User className="mr-2 h-4 w-4" /> Gebruiksinstellingen
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => navigate({ to: "/contacten" })}>
          <Contact className="mr-2 h-4 w-4" /> Contacten
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => navigate({ to: "/widgets" })}>
          <CalendarRange className="mr-2 h-4 w-4" /> Widgets
        </DropdownMenuItem>
        {canManageUsers ? (
          <DropdownMenuItem onClick={() => navigate({ to: "/users" })}>
            <Users className="mr-2 h-4 w-4" /> Accountbeheer
          </DropdownMenuItem>
        ) : null}
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={signOut}>
          <LogOut className="mr-2 h-4 w-4" /> Afmelden
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );

  const nav = (
    <nav className="flex flex-col gap-1 p-3">
      {[
        ...NAV.filter((item) => !(!canViewArtists && item.to === "/artists")),
        ...(canSeeStats ? [{ to: "/statistics", label: "Statistieken", icon: BarChart3 } as const] : []),
        ...(canSeeFinancial ? [{ to: "/financial", label: "Financieel", icon: Euro } as const] : []),
        ...(canSeeActivity ? [{ to: "/activity", label: "Activiteitenlog", icon: History } as const] : []),
        ...(showInvitations ? [{ to: "/invitations", label: "Uitnodigingen", icon: MailQuestion } as const] : []),
      ].map((item) => {
        const active = pathname === item.to || pathname.startsWith(item.to + "/");
        return (
          <Link
            key={item.to}
            to={item.to}
            onClick={() => setMobileOpen(false)}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
              active
                ? "bg-sidebar-accent text-sidebar-accent-foreground"
                : "text-sidebar-foreground/75 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
            )}
          >
            <item.icon className="h-4 w-4" />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );


  return (
    <div className="flex min-h-screen w-full bg-background">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col bg-sidebar text-sidebar-foreground lg:flex">
        <Brand />
        {nav}
        <div className="mt-auto p-3 text-xs text-sidebar-foreground/50">
          PodiumPlan · artiestenbeheer
        </div>
      </aside>

      {/* Mobile drawer */}
      {mobileOpen ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-foreground/40"
            onClick={() => setMobileOpen(false)}
            aria-hidden
          />
          <aside className="absolute inset-y-0 left-0 flex w-64 flex-col bg-sidebar text-sidebar-foreground">
            <div className="flex items-center justify-between">
              <Brand />
              <Button
                variant="ghost"
                size="icon"
                className="mr-2 text-sidebar-foreground"
                onClick={() => setMobileOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            {nav}
          </aside>
        </div>
      ) : null}

      <div className="flex min-w-0 flex-1 flex-col lg:pl-64">
<header className="sticky top-0 z-20 border-b bg-background/85 backdrop-blur">
          <div className="flex flex-col px-4 pt-2 sm:px-6 lg:hidden">
            <div className="flex h-12 items-center justify-between gap-3">
              <div className="flex min-w-0 flex-1 items-center gap-3">
                {hamburger}
                {titleBlock}
              </div>
              <div className="flex items-center gap-2">
                {rightItems}
                {accountMenu}
              </div>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-3 pb-2">
              {actionItems}
            </div>
          </div>
          <div className="hidden h-16 items-center gap-3 px-6 lg:flex">
            {hamburger}
            {titleBlock}
            <div className="flex-1" />
            <div className="flex items-center gap-2">
              {actionItems}
            </div>
            <div className="flex items-center gap-2">
              {rightItems}
              {accountMenu}
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6">
          {mobileBookingButton ? (
            <div className="mb-4">{mobileBookingButton}</div>
          ) : null}
          {children}
        </main>
      </div>

      <NewBookingDialog open={bookingOpen} onOpenChange={setBookingOpen} />
    </div>
  );
}

function Brand() {
  return (
    <div className="flex h-16 items-center gap-2.5 px-5">
      <img
        src={logoAsset.url}
        alt="PodiumPlan logo"
        className="h-8 w-8 rounded-lg object-contain"
      />
      <span className="font-display text-base font-semibold text-sidebar-accent-foreground">
        PodiumPlan
      </span>
    </div>
  );
}
