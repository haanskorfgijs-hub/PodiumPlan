import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  logActivity,
  useWidgetArtists,
  widgetStatusOptions,
  WIDGET_CONTENT_DEFAULT,
  WIDGET_CONTENT_OPTIONS,
  WIDGET_INCLUDE_DEFAULT,
  WIDGET_INCLUDE_OPTIONS,
} from "@/lib/data";

type Widget = {
  id: string;
  name: string;
  artist_ids: string[];
  statuses: string[] | null;
  content?: string[] | null;
  include?: string[] | null;
};


function toggle(list: string[], value: string) {
  return list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
}

export function WidgetDialog({
  open,
  onOpenChange,
  widget,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  widget: Widget | null;
}) {
  const queryClient = useQueryClient();
  const { data: artists = [] } = useWidgetArtists();
  const [name, setName] = useState("");
  const [artistIds, setArtistIds] = useState<string[]>([]);
  const [statuses, setStatuses] = useState<string[]>([]);
  const [content, setContent] = useState<string[]>([...WIDGET_CONTENT_DEFAULT]);
  const [include, setInclude] = useState<string[]>([...WIDGET_INCLUDE_DEFAULT]);
  const [saving, setSaving] = useState(false);
  const statusOpts = widgetStatusOptions(artists, artistIds);

  useEffect(() => {
    if (!open || !widget) return;
    setName(widget.name ?? "");
    setArtistIds(widget.artist_ids ?? []);
    setStatuses(widget.statuses ?? []);
    setContent(widget.content ?? [...WIDGET_CONTENT_DEFAULT]);
    setInclude(
      widget.include?.length ? widget.include : [...WIDGET_INCLUDE_DEFAULT],
    );
  }, [open, widget]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!widget) return;
    if (!name.trim()) return toast.error("Vul een naam in.");
    if (include.length === 0) return toast.error("Kies boekingen, taken of beide.");
    setSaving(true);
    const { error } = await supabase
      .from("calendar_widgets")
      .update({ name: name.trim(), artist_ids: artistIds, statuses, content, include })
      .eq("id", widget.id);

    setSaving(false);
    if (error) return toast.error(error.message);
    await logActivity({
      entityType: "widget",
      entityId: widget.id,
      action: "update",
      summary: `paste kalenderwidget "${name.trim()}" aan`,
    });
    queryClient.invalidateQueries();
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Widget aanpassen</DialogTitle>
        </DialogHeader>
        <form onSubmit={save} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="edit-widget-name">Naam</Label>
            <Input
              id="edit-widget-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label>Wat komt in de agenda?</Label>
            <div className="space-y-2 rounded-md border p-3">
              {WIDGET_INCLUDE_OPTIONS.map((o) => (
                <label key={o.value} className="flex items-center gap-2 text-sm">
                  <Checkbox
                    checked={include.includes(o.value)}
                    onCheckedChange={() => setInclude((prev) => toggle(prev, o.value))}
                  />
                  {o.label}
                </label>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">
              Taken komen alleen mee als ze bij de taak zijn aangevinkt voor de widget.
            </p>
          </div>



          <div className="space-y-2">
            <Label>Artiesten</Label>
            <p className="text-xs text-muted-foreground">
              Niets aanvinken = alle artiesten in de agenda.
            </p>
            <div className="max-h-52 space-y-2 overflow-y-auto rounded-md border p-3">
              {artists.map((a) => (
                <label key={a.id} className="flex items-center gap-2 text-sm">
                  <Checkbox
                    checked={artistIds.includes(a.id)}
                    onCheckedChange={() => setArtistIds((prev) => toggle(prev, a.id))}
                  />
                  {a.name}
                </label>
              ))}
              {artists.length === 0 ? (
                <p className="text-xs text-muted-foreground">Nog geen artiesten.</p>
              ) : null}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Statussen</Label>
            <p className="text-xs text-muted-foreground">
              Niets aanvinken = alle statussen.
            </p>
            <div className="max-h-52 space-y-2 overflow-y-auto rounded-md border p-3">
              {statusOpts.standard.map((s) => (
                <label key={s.value} className="flex items-center gap-2 text-sm">
                  <Checkbox
                    checked={statuses.includes(s.value)}
                    onCheckedChange={() => setStatuses((prev) => toggle(prev, s.value))}
                  />
                  {s.label}
                </label>
              ))}
              {statusOpts.custom.length ? (
                <>
                  <p className="pt-2 text-xs font-medium text-muted-foreground">
                    Eigen statussen
                  </p>
                  {statusOpts.custom.map((s) => (
                    <label key={s.value} className="flex items-center gap-2 text-sm">
                      <Checkbox
                        checked={statuses.includes(s.value)}
                        onCheckedChange={() => setStatuses((prev) => toggle(prev, s.value))}
                      />
                      {s.label}
                      <span className="text-xs text-muted-foreground">· {s.hint}</span>
                    </label>
                  ))}
                </>
              ) : null}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Inhoud van de agenda-items</Label>
            <p className="text-xs text-muted-foreground">
              Kies wat er per optreden in de agenda komt.
            </p>
            <div className="space-y-2 rounded-md border p-3">
              {WIDGET_CONTENT_OPTIONS.map((o) => (
                <label key={o.value} className="flex items-center gap-2 text-sm">
                  <Checkbox
                    checked={content.includes(o.value)}
                    onCheckedChange={() => setContent((prev) => toggle(prev, o.value))}
                  />
                  {o.label}
                </label>
              ))}
            </div>
          </div>


          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Annuleren
            </Button>
            <Button type="submit" disabled={saving}>
              Opslaan
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
