import { usePermission } from "@/lib/permissions";
import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import { DynamicFieldInput } from "@/components/dynamic-field-input";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  fieldValues,
  fieldTab,
  eventNameField,
  logActivity,
  parseFields,
  inSheetForBooking,
  toggleSheetField,
  SHEET_EXCLUDE_KEY,
  useStandards,
  useArtists,
  FIELD_TABS,
  BOOKING_TAB_LABELS,
  PRICING_TAB,
  type BookingWithArtist,
  type StandardField,
} from "@/lib/data";
import { PricingPanel } from "@/components/pricing";
import { pricingChanges } from "@/lib/pricing-activity";
import { bookingDataTabs } from "@/lib/booking-edit-access";
import { useCanEditBooking, useMyRole } from "@/lib/roles";
import { useScopedPermission } from "@/lib/permissions";

export function EditBookingDialog({
  booking,
  open,
  onOpenChange,
  defaultTab = "booking",
}: {
  booking: BookingWithArtist;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  defaultTab?: string;
}) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { data: role } = useMyRole();
  const { allowed: hasFullAccess } = usePermission("admin.full_access");
  const { canEdit } = useCanEditBooking(booking.id);
  const { allowed: canEditBookings } = useScopedPermission("bookings.edit", {
    bookingId: booking.id,
  });
  const { allowed: canViewPricing } = useScopedPermission("pricing.view", {
    bookingId: booking.id,
  });
  const { allowed: canDeleteBooking } = useScopedPermission("bookings.delete", {
    bookingId: booking.id,
  });
  const { allowed: canViewFinancialTab } = useScopedPermission("financial.view", { bookingId: booking.id });
  const canSave = canEdit && canEditBookings;
  const visibleTabs = bookingDataTabs(canSave, hasFullAccess, canViewFinancialTab, canViewPricing);
  const startTab = visibleTabs.includes(defaultTab) ? defaultTab : "booking";


  const { data: standards = [] } = useStandards(booking.artist_id ?? undefined);
  const [values, setValues] = useState<Record<string, string>>(() =>
    fieldValues(booking.field_values),
  );
  const [standardId, setStandardId] = useState<string>(booking.standard_id ?? "");
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    if (open) {
      setValues(fieldValues(booking.field_values));
      setStandardId(booking.standard_id ?? "");
    }
  }, [open, booking]);

  const standard = standards.find((s) => s.id === standardId) ?? standards[0];
  const fields: StandardField[] = parseFields(standard?.fields);
  const { data: artists = [] } = useArtists();
  const artist = artists.find((a) => a.id === booking.artist_id);
  const distanceLocations = [
    ...(artist?.home_location
      ? [
          {
            id: "__artist_home",
            label: `Thuislocatie ${artist.name}`,
            address: artist.home_location,
          },
        ]
      : []),
    ...fields
      .filter((f) => f.type === "map")
      .map((f) => ({ id: f.id, label: f.label, address: values[f.id] ?? "" })),
  ];

  function pickStandard(id: string) {
    setStandardId(id);
    const next = standards.find((s) => s.id === id);
    setValues((prev) => {
      const merged = { ...prev };
      parseFields(next?.fields).forEach((f) => {
        if (fieldTab(f) === "financial" && !canViewFinancialTab) return;
        if (f.default) merged[f.id] = f.default;
      });
      return merged;
    });
  }

  async function save() {
    if (!canSave) return;
    setSaving(true);
    const before = fieldValues(booking.field_values);
    const dateField = fields.find((f) => f.type === "date" || f.type === "datetime");
    const eventDate = dateField ? (values[dateField.id] ?? "").slice(0, 10) : "";
    const nameField = eventNameField(fields);
    const eventName = nameField ? (values[nameField.id] ?? "").trim() : "";
    const { data: updated, error } = await supabase
      .from("bookings")
      .update({
        field_values: values,
        standard_id: standardId || null,
        ...(eventDate ? { event_date: eventDate } : {}),
        ...(eventName ? { event_name: eventName } : {}),
      })
      .eq("id", booking.id)
      .select("id");

    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    if (!updated?.length) {
      toast.error("Je hebt geen recht om deze boeking aan te passen.");
      return;
    }
    const changed = fields.filter((f) => (before[f.id] ?? "") !== (values[f.id] ?? ""));
    const toChange = (f: StandardField) => ({
      field: f.label,
      from: before[f.id] ?? null,
      to: values[f.id] ?? null,
    });
    const bookingChanges = changed.filter((f) => fieldTab(f) === "booking").map(toChange);
    const financialChanges = changed.filter((f) => fieldTab(f) === "financial").map(toChange);
    const beforeStandard = standards.find((s) => s.id === booking.standard_id) ?? standards[0];
    const priceChanges = pricingChanges(parseFields(beforeStandard?.fields), fields, before, values);
    const priceFieldChanges = changed.filter((f) => fieldTab(f) === PRICING_TAB).map(toChange);
    const allPriceChanges = [...priceFieldChanges, ...priceChanges];
    if (bookingChanges.length || (financialChanges.length === 0 && allPriceChanges.length === 0)) {
      await logActivity({
        entityType: "booking",
        entityId: booking.id,
        action: "update",
        summary: `paste boeking "${booking.event_name}" aan`,
        changes: bookingChanges,
      });
    }
    if (financialChanges.length) {
      await logActivity({
        entityType: "booking",
        entityId: booking.id,
        action: "update_financial",
        summary: `paste financiële gegevens van "${booking.event_name}" aan`,
        changes: financialChanges,
      });
    }
    if (allPriceChanges.length) {
      await logActivity({
        entityType: "booking",
        entityId: booking.id,
        action: "update_financial",
        summary: `paste prijsbepaling van "${booking.event_name}" aan`,
        changes: allPriceChanges,
      });
    }
    queryClient.invalidateQueries();
    onOpenChange(false);
  }

  async function remove() {
    const { error } = await supabase.from("bookings").delete().eq("id", booking.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    await logActivity({
      entityType: "booking",
      entityId: booking.id,
      action: "delete",
      summary: `verwijderde boeking "${booking.event_name}"`,
    });
    queryClient.invalidateQueries();
    onOpenChange(false);
    navigate({ to: "/bookings" });
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent
          className="flex max-h-[90vh] w-full max-w-4xl flex-col gap-0 overflow-hidden p-0"
        >
          <DialogHeader className="border-b px-6 py-4 text-left">
            <DialogTitle>Boeking aanpassen</DialogTitle>
            <DialogDescription>
              Werk de velden uit de standaard bij of verwijder de boeking.
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto px-6 py-5">
            <div className="mx-auto w-full max-w-3xl space-y-6">


          {standards.length > 1 ? (
            <div className="space-y-2">
              <Label>Optredenstandaard</Label>
              <Select value={standardId || undefined} onValueChange={pickStandard}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecteer standaard" />
                </SelectTrigger>
                <SelectContent>
                  {standards.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : null}


          {fields.length === 0 ? (
            <p className="py-6 text-sm text-muted-foreground">
              Deze boeking heeft geen velden uit een optredenstandaard.
            </p>
          ) : (
            <Tabs key={startTab} defaultValue={startTab}>
              {visibleTabs.length > 1 ? (<TabsList>
                {visibleTabs.map((t) => (
                  <TabsTrigger key={t} value={t}>
                    {BOOKING_TAB_LABELS[t]}
                  </TabsTrigger>
                ))}
              </TabsList>) : null}
              {visibleTabs.map((t) => {
                const tabFields = fields.filter((f) => fieldTab(f) === t);
                const tabSections = Array.from(
                  new Set(tabFields.map((f) => f.section ?? "Extra velden")),
                );
                return (
                  <TabsContent key={t} value={t} className="mt-4 space-y-8">
                    {t === PRICING_TAB ? (
                      <PricingPanel
                        fields={fields}
                        values={values}
                        onChange={(key, v) => setValues((prev) => ({ ...prev, [key]: v }))}
                      />
                    ) : tabFields.length === 0 ? (
                      <p className="text-sm text-muted-foreground">
                        Nog geen velden in dit tabblad.
                      </p>
                    ) : (

                      tabSections.map((section, idx) => (
                        <div key={section} className="space-y-5">
                          <div className="flex items-center gap-3 border-b pb-3">
                            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                              {idx + 1}
                            </span>
                            <h3 className="text-sm font-semibold tracking-wide uppercase">
                              {section}
                            </h3>
                          </div>
                          <div className="grid grid-cols-1 gap-5">
                            {tabFields
                              .filter((f) => (f.section ?? "Extra velden") === section)
                              .map((f) => (
                                <div key={f.id} className="space-y-2">
                                  <Label>{f.label}</Label>
                                  <DynamicFieldInput
                                    field={f}
                                    fields={fields}
                                    values={values}
                                    locations={distanceLocations}
                                    value={values[f.id] ?? ""}
                                    onChange={(v) =>
                                      setValues((prev) => ({ ...prev, [f.id]: v }))
                                    }
                                  />
                                  {t === "booking" ? (
                                    <label className="flex items-center gap-2 text-xs text-muted-foreground">
                                      <Checkbox
                                        checked={inSheetForBooking(f, values)}
                                        onCheckedChange={(c) =>
                                          setValues((prev) => ({
                                            ...prev,
                                            [SHEET_EXCLUDE_KEY]: toggleSheetField(
                                              prev,
                                              fields,
                                              f.id,
                                              c === true,
                                            ),
                                          }))
                                        }
                                      />
                                      In gegevensblad
                                    </label>
                                  ) : null}
                                </div>
                              ))}
                          </div>
                        </div>
                      ))
                    )}
                  </TabsContent>
                );
              })}
            </Tabs>
          )}
            </div>
          </div>

          <DialogFooter className="gap-2 border-t px-6 py-4 sm:justify-between">

            {canDeleteBooking ? (
              <Button variant="destructive" onClick={() => setConfirmDelete(true)}>
                <Trash2 className="mr-1 h-4 w-4" /> Boeking verwijderen
              </Button>
            ) : <span />}
            <div className="flex gap-2">
              <Button variant="ghost" onClick={() => onOpenChange(false)}>
                Annuleren
              </Button>
              <Button onClick={save} disabled={saving || !canSave}>
                {saving ? "Opslaan…" : "Opslaan"}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Boeking verwijderen?</AlertDialogTitle>
            <AlertDialogDescription>
              Dit verwijdert "{booking.event_name}" definitief. Dit kan niet ongedaan worden
              gemaakt.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuleren</AlertDialogCancel>
            <AlertDialogAction onClick={remove}>Verwijderen</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
