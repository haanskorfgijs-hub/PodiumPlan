import { useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { useCurrentUser } from "@/lib/session";

/**
 * Stuurt een gebruiker zonder recht terug naar het dashboard, ook wanneer de
 * pagina direct via de URL wordt geopend.
 */
export function useAccessRedirect(allowed: boolean, isLoading: boolean) {
  const navigate = useNavigate();
  useEffect(() => {
    if (isLoading || allowed) return;
    toast.error("Je hebt geen toegang tot deze pagina.");
    navigate({ to: "/dashboard", replace: true });
  }, [allowed, isLoading, navigate]);
}

/** Tussenscherm terwijl de doorverwijzing plaatsvindt. */
export function AccessDenied({ title }: { title: string }) {
  const user = useCurrentUser();
  return (
    <AppShell title={title} user={user}>
      <div className="panel p-10 text-center">
        <h2 className="text-base font-semibold">Geen toegang</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Je hebt geen toegang tot deze pagina.
        </p>
      </div>
    </AppShell>
  );
}
