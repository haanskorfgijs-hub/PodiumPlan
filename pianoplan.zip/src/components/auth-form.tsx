import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import logoAsset from "@/assets/podiumplan-logo.png.asset.json";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

/** Zet Supabase-foutmeldingen om naar Nederlandse tekst. */
function translateAuthError(message: string): string {
  const m = message.toLowerCase();
  if (m.includes("invalid login credentials")) return "E-mailadres of wachtwoord is onjuist.";
  if (m.includes("email not confirmed"))
    return "Je e-mailadres is nog niet bevestigd. Controleer je inbox.";
  if (m.includes("user already registered") || m.includes("already been registered"))
    return "Er bestaat al een account met dit e-mailadres.";
  if (m.includes("password should be at least"))
    return "Het wachtwoord moet minimaal 6 tekens bevatten.";
  if (m.includes("password") && m.includes("weak"))
    return "Dit wachtwoord is te zwak. Kies een sterker wachtwoord.";
  if (m.includes("unable to validate email address") || m.includes("invalid email"))
    return "Vul een geldig e-mailadres in.";
  if (m.includes("email rate limit") || m.includes("rate limit"))
    return "Te veel pogingen. Probeer het over enkele minuten opnieuw.";
  if (m.includes("signups not allowed") || m.includes("signup is disabled"))
    return "Registreren is momenteel niet mogelijk.";
  if (m.includes("failed to fetch") || m.includes("network"))
    return "Geen verbinding met de server. Controleer je internetverbinding.";
  return "Er ging iets mis. Probeer het opnieuw.";
}

function FormMessage({ error, success }: { error?: string; success?: string }) {
  if (!error && !success) return null;
  return (
    <p
      role="alert"
      aria-live="polite"
      className={error ? "text-sm font-medium text-destructive" : "text-sm font-medium text-primary"}
    >
      {error ?? success}
    </p>
  );
}

export function AuthForm() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState<string>();
  const [loginInfo, setLoginInfo] = useState<string>();
  const [signupError, setSignupError] = useState<string>();
  const [signupInfo, setSignupInfo] = useState<string>();

  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setLoginError(undefined);
    setLoginInfo(undefined);
    if (!email.trim()) return setLoginError("Vul je e-mailadres in.");
    if (!password) return setLoginError("Vul je wachtwoord in.");
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) return setLoginError(translateAuthError(error.message));
    navigate({ to: "/dashboard" });
  }

  async function signUp(e: React.FormEvent) {
    e.preventDefault();
    setSignupError(undefined);
    setSignupInfo(undefined);
    if (!name.trim()) return setSignupError("Vul je naam in.");
    if (!email.trim()) return setSignupError("Vul je e-mailadres in.");
    if (password.length < 6) return setSignupError("Het wachtwoord moet minimaal 6 tekens bevatten.");
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { name }, emailRedirectTo: window.location.origin },
    });
    setLoading(false);
    if (error) return setSignupError(translateAuthError(error.message));
    // Supabase verbergt bestaande accounts: dan komt de gebruiker terug zonder identities.
    if (data.user && (data.user.identities?.length ?? 0) === 0) {
      return setSignupError(
        "Er bestaat al een account met dit e-mailadres. Log in of vraag een nieuw wachtwoord aan.",
      );
    }
    if (!data.session) {
      return setSignupInfo(
        "Account aangemaakt. Controleer je e-mail en klik op de bevestigingslink om in te loggen.",
      );
    }
    navigate({ to: "/dashboard" });
  }

  async function resetPassword() {
    setLoginError(undefined);
    setLoginInfo(undefined);
    if (!email.trim()) return setLoginError("Vul eerst je e-mailadres in.");
    setResetting(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setResetting(false);
    if (error) return setLoginError(translateAuthError(error.message));
    setLoginInfo(
      "We hebben je een e-mail gestuurd om je wachtwoord opnieuw in te stellen. Controleer ook je spammap.",
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 py-12">
      <div className="w-full max-w-md">
        <div className="mb-8 flex items-center justify-center gap-2.5">
          <img src={logoAsset.url} alt="PodiumPlan logo" className="h-9 w-9 rounded-lg object-contain" />
          <span className="font-display text-xl font-semibold">PodiumPlan</span>
        </div>

        <div className="panel p-6">
          <Tabs defaultValue="login">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Inloggen</TabsTrigger>
              <TabsTrigger value="signup">Registreren</TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="mt-6">
              <form onSubmit={signIn} className="space-y-4" noValidate>
                <div className="space-y-2">
                  <Label htmlFor="login-email">E-mailadres</Label>
                  <Input
                    id="login-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-password">Wachtwoord</Label>
                  <Input
                    id="login-password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                <FormMessage error={loginError} success={loginInfo} />
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? "Bezig…" : "Inloggen"}
                </Button>
                <button
                  type="button"
                  onClick={resetPassword}
                  disabled={resetting}
                  className="w-full text-sm text-muted-foreground hover:text-foreground disabled:opacity-60"
                >
                  {resetting ? "Bezig…" : "Wachtwoord vergeten?"}
                </button>
              </form>
            </TabsContent>

            <TabsContent value="signup" className="mt-6">
              <form onSubmit={signUp} className="space-y-4" noValidate>
                <div className="space-y-2">
                  <Label htmlFor="signup-name">Naam</Label>
                  <Input
                    id="signup-name"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="signup-email">E-mailadres</Label>
                  <Input
                    id="signup-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="signup-password">Wachtwoord</Label>
                  <Input
                    id="signup-password"
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                <FormMessage error={signupError} success={signupInfo} />
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? "Bezig…" : "Account aanmaken"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
