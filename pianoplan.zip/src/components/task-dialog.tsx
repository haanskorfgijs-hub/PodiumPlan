import { useEffect, useMemo, useState } from "react";
import { useCurrentUser } from "@/lib/session";
import { Trash2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  TASK_STATUSES,
  TASK_STATUS_LABELS,
  formatBookingDate,
  logActivity,
  useBookings,
  useBookingAssignees,
  type Task,
} from "@/lib/data";
import { useTaskAccess } from "@/lib/permissions";

export function TaskDialog({
  open,
  onOpenChange,
  task,
  defaultBookingId,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  task?: Task | null;
  defaultBookingId?: string;
}) {
  const queryClient = useQueryClient();
  const currentUser = useCurrentUser();
  const { data: bookings = [] } = useBookings();
  const today = new Date().toISOString().slice(0, 10);
  const filteredBookings = useMemo(
    () =>
      bookings
        .filter((b) => b.event_date && b.event_date >= today)
        .sort((a, b) => a.event_date.localeCompare(b.event_date)),
    [bookings, today],
  );
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    title: "",
    description: "",
    booking_id: defaultBookingId ?? "",
    assigned_to: "",
    deadline: "",
    deadline_time: "",
    status: "open",
    show_in_widget: false,
  });
  const { canEditTask, ownOnly, userId } = useTaskAccess(form.booking_id || task?.booking_id || defaultBookingId);
  const canManageTasks = canEditTask(task);
  const { data: assignees = [] } = useBookingAssignees(form.booking_id || undefined);
  const assignedTo = ownOnly ? userId : form.assigned_to;
  const assignedToSelf = Boolean(assignedTo) && assignedTo === currentUser.id;
  const widgetAllowed = Boolean(form.deadline) && assignedToSelf;



  useEffect(() => {
    if (!open) return;
    setForm({
      title: task?.title ?? "",
      description: task?.description ?? "",
      booking_id: task?.booking_id ?? defaultBookingId ?? "",
      assigned_to: task?.assigned_to ?? "",
      deadline: task?.deadline ?? "",
      deadline_time: task?.deadline_time ? String(task.deadline_time).slice(0, 5) : "",
      status: task?.status ?? "open",
      show_in_widget: task?.show_in_widget ?? false,
    });
  }, [open, task, defaultBookingId]);

  async function remove() {
    if (!task || !canManageTasks) return;
    if (!window.confirm(`Taak "${task.title}" verwijderen?`)) return;
    setSaving(true);
    const { error } = await supabase.from("tasks").delete().eq("id", task.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    await logActivity({
      entityType: "task",
      entityId: task.booking_id ?? task.id,
      action: "delete",
      summary: `verwijderde taak "${task.title}"`,
    });
    queryClient.invalidateQueries();
    onOpenChange(false);
  }

  async function save() {
    if (!canManageTasks) return;
    if (!form.title.trim()) {
      toast.error("Taaknaam is verplicht.");
      return;
    }
    setSaving(true);
    const payload = {
      title: form.title.trim(),
      description: form.description || null,
      booking_id: form.booking_id || null,
      assigned_to: ownOnly ? userId || null : form.assigned_to || null,
      deadline: form.deadline || null,
      deadline_time: form.deadline ? form.deadline_time || null : null,
      status: form.status as (typeof TASK_STATUSES)[number],
      show_in_widget: widgetAllowed ? form.show_in_widget : false,
    };

    if (task) {
      const { error } = await supabase.from("tasks").update(payload).eq("id", task.id);
      setSaving(false);
      if (error) return toast.error(error.message);
      await logActivity({
        entityType: "task",
        entityId: task.booking_id ?? task.id,
        action: "taak bijgewerkt",
        summary: `heeft taak "${payload.title}" bijgewerkt.`,
        changes: [
          { field: "Status", from: task.status, to: payload.status },
          { field: "Deadline", from: task.deadline, to: payload.deadline },
        ].filter((c) => c.from !== c.to),
      });
    } else {
      const { data: userData } = await supabase.auth.getUser();
      const { error } = await supabase
        .from("tasks")
        .insert({ ...payload, created_by: userData.user?.id ?? null });
      setSaving(false);
      if (error) return toast.error(error.message);
      await logActivity({
        entityType: "task",
        entityId: payload.booking_id,
        action: "taak toegevoegd",
        summary: `heeft taak "${payload.title}" toegevoegd.`,
      });
    }
    queryClient.invalidateQueries();
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{task ? "Taak bewerken" : "Nieuwe taak"}</DialogTitle>
          <DialogDescription>Koppel een taak aan een boeking en wijs deze toe.</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Taaknaam *</Label>
            <Input
              value={form.title}
              disabled={!canManageTasks}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label>Omschrijving</Label>
            <Textarea
              rows={3}
              value={form.description}
              disabled={!canManageTasks}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label>Boeking koppelen</Label>
            <Select
              value={form.booking_id || "none"}
              disabled={!canManageTasks}
              onValueChange={(v) =>
                setForm({
                  ...form,
                  booking_id: v === "none" ? "" : v,
                  assigned_to: ownOnly ? userId : "",
                })
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Geen boeking" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Geen boeking</SelectItem>
                {filteredBookings.map((b) => (
                  <SelectItem key={b.id} value={b.id}>
                    {formatBookingDate(b.event_date)} — {b.event_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Deadline</Label>
              <Input
                type="date"
                value={form.deadline}
                disabled={!canManageTasks}
                onChange={(e) => setForm({ ...form, deadline: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Tijd</Label>
              <Input
                type="time"
                value={form.deadline_time}
                disabled={!canManageTasks || !form.deadline}
                onChange={(e) => setForm({ ...form, deadline_time: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Toegewezen aan</Label>
              {ownOnly ? (
                <>
                  <Input value="Jijzelf" disabled />
                  <p className="text-xs text-muted-foreground">
                    Je mag alleen taken voor je eigen account beheren.
                  </p>
                </>
              ) : (
                <>
                  <Select
                    value={form.assigned_to || "none"}
                    onValueChange={(v) => setForm({ ...form, assigned_to: v === "none" ? "" : v })}
                    disabled={!form.booking_id || !canManageTasks}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Niemand" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Niemand</SelectItem>
                      {assignees.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name || p.email}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {!form.booking_id ? (
                    <p className="text-xs text-muted-foreground">
                      Kies eerst een boeking om iemand toe te wijzen.
                    </p>
                  ) : null}
                </>
              )}
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select
                value={form.status}
                disabled={!canManageTasks}
                onValueChange={(v) => setForm({ ...form, status: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TASK_STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {TASK_STATUS_LABELS[s]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
          </div>

          <label className="flex items-start gap-2 text-sm text-muted-foreground">
            <Checkbox
              checked={form.show_in_widget && widgetAllowed}
              disabled={!canManageTasks || !widgetAllowed}
              onCheckedChange={(v) => setForm({ ...form, show_in_widget: v === true })}
              className="mt-0.5"
            />
            <span>
              Opnemen in kalenderwidget
              {!widgetAllowed && (
                <span className="block text-xs text-muted-foreground/70 mt-0.5">
                  {!form.deadline
                    ? "Kies eerst een deadline"
                    : !assignedTo
                      ? "Wijs de taak eerst aan iemand toe"
                      : "Alleen taken die aan jezelf zijn toegewezen kunnen in de widget"}
                </span>
              )}
            </span>
          </label>
        </div>
        </div>

        <DialogFooter className="sm:justify-between">
          {task && canManageTasks ? (
            <Button variant="destructive" onClick={remove} disabled={saving}>
              <Trash2 className="mr-2 h-4 w-4" /> Verwijderen
            </Button>
          ) : (
            <span />
          )}
          <div className="flex items-center gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            {canManageTasks ? "Annuleren" : "Sluiten"}
          </Button>
          {canManageTasks ? (
            <Button onClick={save} disabled={saving}>
              {saving ? "Opslaan…" : "Opslaan"}
            </Button>
          ) : null}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
