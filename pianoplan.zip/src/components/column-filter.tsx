import { useMemo, useState } from "react";
import { Check, Filter, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

export type FilterOption = { value: string; label: string };

type Props = {
  /** Alle beschikbare waardes voor deze kolom. */
  options: FilterOption[];
  /** Geselecteerde waardes; leeg = alles. */
  selected: string[];
  onChange: (values: string[]) => void;
  align?: "start" | "end";
};

/** Excel-achtige uitklapbare kolomfilter met zoeken en selectievakjes. */
export function ColumnFilter({ options, selected, onChange, align = "start" }: Props) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const active = selected.length > 0;

  const visible = useMemo(
    () =>
      query.trim()
        ? options.filter((o) => o.label.toLowerCase().includes(query.trim().toLowerCase()))
        : options,
    [options, query],
  );

  function toggle(value: string) {
    onChange(selected.includes(value) ? selected.filter((v) => v !== value) : [...selected, value]);
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          onClick={(e) => e.stopPropagation()}
          onPointerDown={(e) => e.stopPropagation()}
          aria-label="Filter kolom"
          className={`inline-flex h-5 w-5 shrink-0 items-center justify-center rounded transition-colors hover:bg-muted ${
            active ? "text-primary" : "text-muted-foreground/60"
          }`}
        >
          <Filter className={`h-3.5 w-3.5 ${active ? "fill-current" : ""}`} />
        </button>
      </PopoverTrigger>
      <PopoverContent
        align={align}
        className="w-60 p-0"
        onClick={(e) => e.stopPropagation()}
        onPointerDown={(e) => e.stopPropagation()}
      >
        <div className="border-b p-2">
          <Input
            autoFocus
            className="h-8 text-xs"
            placeholder="Zoeken…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <div className="max-h-64 overflow-y-auto p-1">
          {visible.length === 0 ? (
            <p className="p-3 text-center text-xs text-muted-foreground">Geen waardes</p>
          ) : (
            visible.map((o) => (
              <label
                key={o.value}
                className="flex cursor-pointer items-center gap-2 rounded px-2 py-1.5 text-xs hover:bg-muted"
              >
                <Checkbox
                  checked={selected.includes(o.value)}
                  onCheckedChange={() => toggle(o.value)}
                />
                <span className="truncate">{o.label}</span>
              </label>
            ))
          )}
        </div>
        <div className="flex items-center justify-between gap-2 border-t p-2">
          <Button
            variant="ghost"
            size="sm"
            className="h-7 px-2 text-xs"
            onClick={() => onChange([])}
          >
            <X className="mr-1 h-3 w-3" /> Wissen
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 px-2 text-xs"
            onClick={() => onChange(visible.map((o) => o.value))}
          >
            <Check className="mr-1 h-3 w-3" /> Alles
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

/** "2026-08-03" -> { value: "2026-08", label: "augustus 2026" } */
export function monthOption(date?: string | null): FilterOption | null {
  if (!date) return null;
  const value = date.slice(0, 7);
  const d = new Date(`${value}-01T00:00:00`);
  if (Number.isNaN(d.getTime())) return null;
  const label = d.toLocaleDateString("nl-NL", { month: "long", year: "numeric" });
  return { value, label: label.charAt(0).toUpperCase() + label.slice(1) };
}

export function uniqueOptions(values: (string | null | undefined)[]): FilterOption[] {
  const set = new Set<string>();
  values.forEach((v) => {
    if (v && v.trim()) set.add(v.trim());
  });
  return [...set].sort((a, b) => a.localeCompare(b)).map((v) => ({ value: v, label: v }));
}
