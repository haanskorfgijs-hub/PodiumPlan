import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Pencil } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Pill } from "@/components/status-badges";
import { usePermission } from "@/lib/permissions";

export const AVAILABILITY_LABELS: Record<string, string> = {
  available: "Beschikbaar",
  tentative: "Misschien",
  unavailable: "Niet beschikbaar",
};

const VARIANT: Record<string, string> = {
  available: "bg-success/15 text-success border-success/30",
  tentative: "bg-warning/15 text-warning-foreground dark:text-warning border-warning/30",
  unavailable: "bg-destructive/15 text-destructive border-destructive/30",
};

export function useBookingAvailability(bookingId: string) {
  return useQuery({
    queryKey: ["booking-availability", bookingId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("booking_availability")
        .select("user_id, availability")
        .eq("booking_id", bookingId);
      if (error) throw error;
      return Object.fromEntries((data ?? []).map((r) => [r.user_id, r.availability])) as Record<
        string,
        string
      >;
    },
  });
}

export function TeamAvailability({
  bookingId,
  userId,
  isSelf,
}: {
  artistId?: string | null;
  bookingId: string;
  userId: string;
  isSelf: boolean;
}) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const { data = {} } = useBookingAvailability(bookingId);
  const { allowed: canEditOthers } = usePermission("admin.availability");
  const canEdit = isSelf || canEditOthers;
  const value = data[userId];
  const save = useMutation({
    mutationFn: async (availability: string) => {
      const { error } = await supabase
        .from("booking_availability")
        .upsert(
          { booking_id: bookingId, user_id: userId, availability, updated_at: new Date().toISOString() },
          { onConflict: "booking_id,user_id" },
        );
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["booking-availability", bookingId] });
      qc.invalidateQueries({ queryKey: ["activity"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Opslaan mislukt."),
  });

  const badge = value ? (
    <Pill label={AVAILABILITY_LABELS[value] ?? value} className={VARIANT[value] ?? ""} />
  ) : (
    <span className="text-xs text-muted-foreground">Onbekend</span>
  );

  if (!canEdit) {
    return <div className="ml-auto flex shrink-0 items-center gap-1">{badge}</div>;
  }

  return (
    <DropdownMenu open={open} modal={false} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label="Beschikbaarheid aanpassen"
          aria-expanded={open}
          className="ml-auto flex shrink-0 items-center gap-1 rounded-sm p-1 text-muted-foreground transition-colors hover:text-foreground"
        >
          <Pencil className="h-3.5 w-3.5" />
          {badge}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-[9.5rem]">
        {Object.entries(AVAILABILITY_LABELS).map(([k, l]) => (
          <DropdownMenuItem
            key={k}
            disabled={save.isPending}
            className={`text-xs ${value === k ? "font-semibold" : ""}`}
            onSelect={() => save.mutate(k)}
          >
            {l}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
