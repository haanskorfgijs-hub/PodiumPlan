import { useNavigate } from "@tanstack/react-router";
import { MapPin } from "lucide-react";

import { MobileDateCard } from "@/components/mobile-date-card";
import { BookingStatusPill, useBookingStatusColor } from "@/components/status-badges";
import { formatBookingDate, mapsUrl } from "@/lib/data";

type BookingLike = {
  id: string;
  event_name: string;
  event_date: string;
  artist_status?: string | null;
  artist_id?: string | null;
  artists?: { name: string } | null;
};

/** Mobiele boekingsregel: datumblok links, gekleurde statusbalk, tikbare hele regel. */
export function MobileBookingRow({
  booking,
  time,
  presenceTime,
  playTime,
  location,
  tab = "booking",
}: {
  booking: BookingLike;
  time?: string;
  presenceTime?: string;
  playTime?: string;
  location?: string;
  tab?: "booking" | "financial";
}) {
  const navigate = useNavigate();
  const color = useBookingStatusColor(booking);

  return (
    <MobileDateCard
      date={booking.event_date}
      color={color}
      onClick={() => navigate({ to: "/bookings/$id", params: { id: booking.id }, search: { tab } })}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-base font-semibold break-words">{booking.event_name}</p>
          <p className="mt-0.5 text-sm text-muted-foreground">{booking.artists?.name}</p>
        </div>
        <span className="shrink-0">
          <BookingStatusPill booking={booking} />
        </span>
      </div>
      <p className="text-sm text-muted-foreground">{formatBookingDate(booking.event_date)}</p>
      {presenceTime || playTime ? (
        <div className="flex flex-col gap-0.5 text-sm text-muted-foreground">
          {presenceTime ? <span className="tabular-nums">Aanwezig: {presenceTime}</span> : null}
          {playTime ? <span className="tabular-nums">Begintijd: {playTime}</span> : null}
        </div>
      ) : time ? (
        <p className="text-sm tabular-nums text-muted-foreground">{time}</p>
      ) : null}
      {location ? (
        <a
          href={mapsUrl(location)}
          target="_blank"
          rel="noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="inline-flex items-center gap-1.5 py-1 text-sm text-primary"
        >
          <MapPin className="h-4 w-4 shrink-0" />
          <span className="break-words">{location}</span>
        </a>
      ) : null}
    </MobileDateCard>
  );
}
