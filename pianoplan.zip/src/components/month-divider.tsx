const MONTHS = [
  "januari",
  "februari",
  "maart",
  "april",
  "mei",
  "juni",
  "juli",
  "augustus",
  "september",
  "oktober",
  "november",
  "december",
];

/** Sleutel per maand+jaar, zodat we weten wanneer er een scheiding nodig is. */
export function monthKey(date?: string | null) {
  if (!date) return "onbekend";
  const d = new Date(date);
  if (Number.isNaN(d.getTime())) return "onbekend";
  return `${d.getFullYear()}-${d.getMonth()}`;
}

export function monthLabel(date?: string | null) {
  if (!date) return "Zonder datum";
  const d = new Date(date);
  if (Number.isNaN(d.getTime())) return "Zonder datum";
  return `${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

/** Tussenkop tussen mobiele regels wanneer de maand verandert. */
export function MonthDivider({ date }: { date?: string | null }) {
  return (
    <div className="bg-muted/60 px-4 py-2 text-xs font-semibold tracking-wide text-muted-foreground uppercase">
      {monthLabel(date)}
    </div>
  );
}
