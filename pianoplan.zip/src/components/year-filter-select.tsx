import { CalendarRange, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAllBookings } from "@/lib/data";
import { useYearFilter } from "@/lib/year-filter";

/** Globale jaarfilter: geldt op alle pagina's en wordt per account onthouden. */
export function YearFilterSelect() {
  const { data: bookings = [] } = useAllBookings();
  const { years, toggleYear, clear } = useYearFilter();

  const available = [
    ...new Set([
      new Date().getFullYear(),
      ...bookings.map((b) => Number(String(b.event_date).slice(0, 4))).filter(Boolean),
      ...years,
    ]),
  ].sort((a, b) => b - a);

  const label =
    years.length === 0
      ? "Alle jaren"
      : years.length <= 3
        ? [...years].sort((a, b) => b - a).join(", ")
        : `${years.length} jaren`;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2 px-2 text-muted-foreground" aria-label="Jaar filteren">
          <CalendarRange className="h-4 w-4" />
          <span className="hidden text-xs font-medium tabular-nums sm:inline">{label}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-52">
        <DropdownMenuLabel>Jaar filteren</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onSelect={(e) => (e.preventDefault(), clear())}>
          <span className="flex-1">Alle jaren</span>
          {years.length === 0 ? <Check className="h-4 w-4" /> : null}
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        {available.map((y) => (
          <DropdownMenuItem key={y} onSelect={(e) => (e.preventDefault(), toggleYear(y))}>
            <span className="flex-1 tabular-nums">{y}</span>
            {years.includes(y) ? <Check className="h-4 w-4" /> : null}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
