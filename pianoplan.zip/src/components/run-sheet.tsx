import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { Clock, Pencil } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  logActivity,
  parseRunSheetText,
  runSheetTimeLabel,
  runSheetToText,
  runSheetInSheet,
  toggleSheetField,
  SHEET_EXCLUDE_KEY,
  RUN_SHEET_SHEET_ID,
  type RunSheetItem,
  type StandardField,
} from "@/lib/data";

/** Draaiboek als vrije tekst: één regel per gebeurtenis, toelichting eronder. */
export function RunSheetEditor({
  items,
  onChange,
}: {
  items: RunSheetItem[];
  onChange: (items: RunSheetItem[]) => void;
}) {
  const [text, setText] = useState(() => runSheetToText(items));

  return (
    <div className="space-y-2">
      <Textarea
        rows={14}
        className="font-mono text-sm leading-7"
        aria-label="Draaiboek"
        placeholder={"16:00 - 17:00 Opbouw\n17:00 - 17:30 Eten"}
        value={text}
        onChange={(e) => {
          setText(e.target.value);
          onChange(parseRunSheetText(e.target.value));
        }}
      />
      <div className="text-xs text-muted-foreground">
        <p>Maak je draaiboek als volgt op:</p>
        <ul className="ml-4 list-disc">
          <li>Één regel per gebeurtenis: “Start - Eind Titel” of “Start Titel”</li>
          <li>Optioneel: voeg één of meer beschrijvingsregels direct onder de gebeurtenis toe</li>
        </ul>
      </div>
    </div>
  );
}


/** Draaiboekblok op de boekingspagina. */
export function RunSheetPanel({
  bookingId,
  bookingName,
  runSheet,
  canEdit,
  values,
  fields,
}: {
  bookingId: string;
  bookingName: string;
  runSheet: RunSheetItem[];
  canEdit: boolean;
  values: Record<string, string>;
  fields: StandardField[];
}) {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<RunSheetItem[]>(runSheet);
  const [sheetDraft, setSheetDraft] = useState(() => runSheetInSheet(values));
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!editing) {
      setDraft(runSheet);
      setSheetDraft(runSheetInSheet(values));
    }
  }, [runSheet, editing, values]);

  const items = runSheet;



  async function save() {
    const cleaned = draft
      .filter((i) => i.title.trim() || i.time || i.endTime)
      .map((i) => ({
        ...i,
        title: i.title.trim(),
        description: (i.description ?? "").trim(),
      }));

    const patch: Record<string, unknown> = { run_sheet: cleaned };
    if (sheetDraft !== runSheetInSheet(values)) {
      patch.field_values = {
        ...values,
        [SHEET_EXCLUDE_KEY]: toggleSheetField(
          values,
          fields,
          RUN_SHEET_SHEET_ID,
          sheetDraft,
        ),
      };
    }

    setSaving(true);
    const { error } = await supabase
      .from("bookings")
      .update(patch as unknown as never)
      .eq("id", bookingId);
    setSaving(false);

    if (error) return toast.error(error.message);
    await logActivity({
      entityType: "booking",
      entityId: bookingId,
      action: "update",
      summary: `werkte het draaiboek van ${bookingName} bij`,
    });
    queryClient.invalidateQueries();
    setEditing(false);
  }

  return (
    <section className="panel">
      <div className="flex min-h-8 items-center justify-between gap-3 border-b px-5 py-4">
        <h2 className="text-sm font-semibold">Draaiboek</h2>
        {canEdit ? (
          <Button
            variant="outline"
            size="sm"
            className="h-8 shrink-0"
            onClick={() => { setDraft(runSheet); setEditing(true); }}
          >
            <Pencil className="mr-1 h-4 w-4" /> Aanpassen
          </Button>
        ) : null}
      </div>
      <ul className="divide-y">

          {items.map((item) => (
            <li
              key={item.id}
              className="flex flex-col gap-1 px-4 py-4 sm:flex-row sm:gap-3 sm:px-5 sm:py-3"
            >
              <span className="flex shrink-0 items-start gap-1 text-sm font-semibold tabular-nums sm:w-28">
                {runSheetTimeLabel(item) || (
                  <Clock className="h-4 w-4 text-muted-foreground" />
                )}
              </span>

              <span className="min-w-0">
                <p className="text-sm font-medium break-words">{item.title || "—"}</p>
                {item.description ? (
                  <p className="mt-0.5 text-xs whitespace-pre-line text-muted-foreground">
                    {item.description}
                  </p>
                ) : null}
              </span>
            </li>
          ))}
          {items.length === 0 ? (
            <li className="px-5 py-10 text-center text-sm text-muted-foreground">
              Nog geen draaiboek.
            </li>
          ) : null}
        </ul>
      <Dialog open={editing} onOpenChange={setEditing}>
        <DialogContent className="flex max-h-[90vh] w-full max-w-3xl flex-col gap-0 overflow-hidden p-0">
          <DialogHeader className="border-b px-6 py-4 text-left">
            <DialogTitle>Draaiboek aanpassen</DialogTitle>
            <DialogDescription>Werk de planning van dit optreden bij.</DialogDescription>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto px-6 py-5">
            {editing ? <RunSheetEditor items={draft} onChange={setDraft} /> : null}
            <label className="mt-4 flex items-start gap-2 border-t pt-4 text-sm">
              <Checkbox
                className="mt-0.5"
                checked={sheetDraft}
                onCheckedChange={(c) => setSheetDraft(c === true)}
              />
              <span>
                <span className="font-medium">In gegevensblad</span>
                <span className="block text-xs text-muted-foreground">
                  Neem het draaiboek op in het gegevensblad van deze boeking.
                </span>
              </span>
            </label>
          </div>

          <DialogFooter className="gap-2 border-t px-6 py-4">
            <Button variant="ghost" onClick={() => setEditing(false)}>Annuleren</Button>
            <Button onClick={save} disabled={saving}>{saving ? "Opslaan…" : "Opslaan"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}
