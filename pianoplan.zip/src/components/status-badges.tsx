import { cn } from "@/lib/utils";
import {
  FINANCIAL_STATUS_LABELS,
  TASK_STATUS_LABELS,
  parseArtistStatuses,
  useArtists,
  useWidgetArtists,
  type StatusColor,
} from "@/lib/data";

export const STATUS_COLOR_CLASSES: Record<StatusColor, string> = {
  green: "bg-success/15 text-success border-success/30",
  amber: "bg-warning/15 text-warning-foreground dark:text-warning border-warning/30",
  blue: "bg-info/15 text-info border-info/30",
  red: "bg-destructive/15 text-destructive border-destructive/30",
  purple: "bg-primary/15 text-primary border-primary/30",
  gray: "bg-muted text-muted-foreground border-border",
};


const financialStyles: Record<string, string> = {
  factureren: "bg-warning/15 text-warning-foreground dark:text-warning border-warning/30",
  gefactureerd: "bg-info/15 text-info border-info/30",
  geannuleerd: "bg-destructive/15 text-destructive border-destructive/30",
  voldaan: "bg-success/15 text-success border-success/30",
  nog_spelen: "bg-primary/15 text-primary border-primary/30",
};

const taskStyles: Record<string, string> = {
  open: "bg-info/15 text-info border-info/30",
  in_behandeling: "bg-warning/15 text-warning-foreground dark:text-warning border-warning/30",
  afgerond: "bg-success/15 text-success border-success/30",
};

/**
 * Artiesten voor statuskleuren. Lezers (en accounts die alleen aan losse
 * boekingen zijn toegevoegd) kunnen de artiestentabel niet lezen; daarom
 * wordt de beveiligde widget-lijst als aanvulling gebruikt zodat eigen
 * artieststatussen ook voor hen de juiste kleur krijgen.
 */
function useStatusArtists() {
  const { data: artists = [] } = useArtists();
  const { data: widgetArtists = [] } = useWidgetArtists();
  const map = new Map<string, { id: string; booking_statuses?: unknown }>();
  for (const a of widgetArtists) map.set(a.id, a);
  for (const a of artists) map.set(a.id, a);
  return [...map.values()];
}

export function Pill({ label, className }: { label: string; className: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium whitespace-nowrap",
        className,
      )}
    >
      {label}
    </span>
  );
}

/** Statusbadge van een boeking: eigen artieststatus (met kleur) of de standaardstatus. */
export function BookingStatusPill({
  booking,
}: {
  booking: { artist_status?: string | null; artist_id?: string | null };
}) {
  const artists = useStatusArtists();
  if (booking.artist_status) {
    const list = parseArtistStatuses(
      artists.find((a) => a.id === booking.artist_id)?.booking_statuses,
    );
    const found = list.find((s) => s.label === booking.artist_status);
    return (
      <Pill
        label={booking.artist_status}
        className={STATUS_COLOR_CLASSES[found?.color ?? "gray"]}
      />
    );
  }
  return <Pill label="—" className={STATUS_COLOR_CLASSES.gray} />;
}


export function TaskStatusBadge({ status }: { status: string }) {
  return <Pill label={TASK_STATUS_LABELS[status] ?? status} className={taskStyles[status]} />;
}

export function FinancialStatusBadge({ status }: { status: string }) {
  return (
    <Pill
      label={FINANCIAL_STATUS_LABELS[status] ?? status}
      className={financialStyles[status] ?? ""}
    />
  );
}

const financialStatusColors: Record<string, StatusColor> = {
  nog_spelen: "purple",
  factureren: "amber",
  gefactureerd: "blue",
  geannuleerd: "red",
  voldaan: "green",
};

/** Effen achtergrondkleur per statuskleur, voor de gekleurde datumbalk op mobiel. */
export const STATUS_STRIPE_CLASSES: Record<StatusColor, string> = {
  green: "bg-success",
  amber: "bg-warning",
  blue: "bg-info",
  red: "bg-destructive",
  purple: "bg-primary",
  gray: "bg-muted-foreground",
};

/** Kleur van de boekingsstatus (inclusief eigen artieststatussen). */
export function useBookingStatusColor(booking: {
  artist_status?: string | null;
  artist_id?: string | null;
}): StatusColor {
  const artists = useStatusArtists();
  if (booking.artist_status) {
    const list = parseArtistStatuses(
      artists.find((a) => a.id === booking.artist_id)?.booking_statuses,
    );
    return list.find((s) => s.label === booking.artist_status)?.color ?? "gray";
  }
  return "gray";
}

export function financialStatusColor(status?: string | null): StatusColor {
  return financialStatusColors[status ?? "nog_spelen"] ?? "gray";
}

/** Kleurwaarden per statuskleur, voor grafieken (recharts kan geen classes gebruiken). */
export const STATUS_CHART_COLORS: Record<StatusColor, string> = {
  green: "var(--success)",
  amber: "var(--warning)",
  blue: "var(--info)",
  red: "var(--destructive)",
  purple: "var(--primary)",
  gray: "var(--muted-foreground)",
};

/** Statuskleur van een boeking zonder hook (artiestenlijst wordt meegegeven). */
export function bookingStatusColorOf(
  booking: { artist_status?: string | null; artist_id?: string | null },
  artists: { id: string; booking_statuses?: unknown }[],
): StatusColor {
  if (booking.artist_status) {
    const list = parseArtistStatuses(
      artists.find((a) => a.id === booking.artist_id)?.booking_statuses,
    );
    return list.find((s) => s.label === booking.artist_status)?.color ?? "gray";
  }
  return "gray";
}

/** Smalle verticale statusbalk vooraan een tabelrij (desktop). */
export function StatusStripeCell({
  booking,
}: {
  booking: { artist_status?: string | null; artist_id?: string | null };
}) {
  const color = useBookingStatusColor(booking);
  return <td className={cn("w-1.5 p-0", STATUS_STRIPE_CLASSES[color])} aria-hidden />;
}

/** Smalle verticale statusbalk op de financiële pagina: kleur volgens financiële status. */
export function FinancialStatusStripeCell({ status }: { status?: string | null }) {
  const color = financialStatusColor(status);
  return <td className={cn("w-1.5 p-0", STATUS_STRIPE_CLASSES[color])} aria-hidden />;
}
