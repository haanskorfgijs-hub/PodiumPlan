import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeftRight, ChevronDown, Undo2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { usePermission } from "@/lib/permissions";
import { listAllAccounts, switchToAccount } from "@/lib/admin-users.functions";
import {
  DropdownMenuItem,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";

const ORIGINAL_KEY = "podiumplan-admin-original-session";

export function AccountSwitcher({ label }: { label: string }) {
  const qc = useQueryClient();
  const listFn = useServerFn(listAllAccounts);
  const switchFn = useServerFn(switchToAccount);
  const [original, setOriginal] = useState<string | null>(null);
  useEffect(() => setOriginal(localStorage.getItem(ORIGINAL_KEY)), []);
  const { allowed: isAdmin } = usePermission("admin.switch_account");
  const [listOpen, setListOpen] = useState(false);

  const { data: accounts = [] } = useQuery({
    queryKey: ["switch-accounts"],
    enabled: isAdmin,
    queryFn: async () => {
      const list = await listFn();
      const { data: profiles } = await supabase.from("profiles").select("id, name");
      const names = new Map((profiles ?? []).map((p) => [p.id, p.name]));
      return list
        .map((a) => ({ id: a.id, email: a.email, name: names.get(a.id) || a.email }))
        .sort((a, b) => a.name.localeCompare(b.name));
    },
  });

  const finish = () => {
    qc.clear();
    window.location.assign("/dashboard");
  };

  const switchTo = async (userId: string) => {
    try {
      const { data: s } = await supabase.auth.getSession();
      if (!s.session) return;
      if (s.session.user.id === userId) return;
      const { tokenHash } = await switchFn({ data: { userId } });
      if (!localStorage.getItem(ORIGINAL_KEY)) {
        localStorage.setItem(
          ORIGINAL_KEY,
          JSON.stringify({ access_token: s.session.access_token, refresh_token: s.session.refresh_token }),
        );
      }
      const { error } = await supabase.auth.verifyOtp({ token_hash: tokenHash, type: "magiclink" });
      if (error) throw error;
      finish();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Wisselen mislukt.");
    }
  };

  const switchBack = async () => {
    const raw = localStorage.getItem(ORIGINAL_KEY);
    if (!raw) return;
    localStorage.removeItem(ORIGINAL_KEY);
    const { error } = await supabase.auth.setSession(JSON.parse(raw));
    if (error) {
      toast.error("Terugkeren mislukt. Log opnieuw in.");
      await supabase.auth.signOut();
    }
    finish();
  };

  if (!isAdmin && !original) {
    return <DropdownMenuLabel className="truncate">{label}</DropdownMenuLabel>;
  }

  return (
    <>
      {isAdmin ? (
        <>
          <DropdownMenuItem
            className="font-semibold"
            onSelect={(e) => {
              e.preventDefault();
              setListOpen((v) => !v);
            }}
          >
            <ArrowLeftRight className="mr-2 h-4 w-4 shrink-0" />
            <span className="min-w-0 flex-1 truncate">{label}</span>
            <ChevronDown className={`ml-2 h-4 w-4 shrink-0 transition-transform ${listOpen ? "rotate-180" : ""}`} />
          </DropdownMenuItem>
          {listOpen ? (
            <div className="max-h-[min(16rem,45dvh)] overflow-y-auto border-y bg-muted/30 py-1">
              <DropdownMenuLabel className="text-xs text-muted-foreground">Wissel naar account</DropdownMenuLabel>
              {accounts.map((a) => (
                <DropdownMenuItem key={a.id} onClick={() => switchTo(a.id)} className="min-w-0">
                  <span className="w-full truncate text-sm">{a.name}</span>
                </DropdownMenuItem>
              ))}
            </div>
          ) : null}
        </>
      ) : (
        <DropdownMenuLabel className="truncate">{label}</DropdownMenuLabel>
      )}
      {original ? (
        <DropdownMenuItem onClick={switchBack}>
          <Undo2 className="mr-2 h-4 w-4" /> Terug naar mijn account
        </DropdownMenuItem>
      ) : null}
    </>
  );
}
