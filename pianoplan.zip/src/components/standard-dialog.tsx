import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, ArrowUp, ArrowDown, ChevronDown, ChevronUp, Pencil } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { DynamicFieldInput } from "@/components/dynamic-field-input";
import { Textarea } from "@/components/ui/textarea";
import {
  BOOKING_TAB_LABELS,
  FIELD_TABS,
  FIELD_TYPE_LABELS,
  PRICING_TAB,
  fieldTab,
  isPriceKey,

  fieldValues,
  eventNameField,
  ensureBaseFields,
  isBaseField,
  logActivity,
  parseDefaultTasks,
  parseDefaultTeam,
  parseFields,
  parseRunSheet,

  type DefaultTask,
  type DefaultTeamMember,
  type FieldPricing,
  type FieldTab,
  type FieldType,
  type RunSheetItem,
  type Standard,
  type StandardField,
} from "@/lib/data";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RunSheetEditor } from "@/components/run-sheet";
import { DefaultTeamEditor } from "@/components/default-team-editor";
import { PricingRulesEditor } from "@/components/pricing";
import { Switch } from "@/components/ui/switch";
import { usePermission } from "@/lib/permissions";



function newField(tab: FieldTab = "booking"): StandardField {
  return {
    id: `f_${Math.random().toString(36).slice(2, 10)}`,
    label: "",
    type: "text",
    tab,
  };
}

const NO_SECTION = "__no_section__";

function sectionKey(field: StandardField) {
  return field.section?.trim() || NO_SECTION;
}

function sectionLabel(section: string) {
  return section === NO_SECTION ? "Overig" : section;
}

function baseFields(): StandardField[] {
  return ensureBaseFields([]);
}

/**
 * Past wijzigingen in een standaard door in alle bestaande boekingen van die
 * standaard: verwijderde velden worden opgeruimd, nieuwe velden krijgen hun
 * standaardwaarde en waarden die nog gelijk waren aan de oude standaardwaarde
 * volgen de nieuwe standaardwaarde.
 */
async function syncBookings(
  standardId: string,
  previous: StandardField[],
  next: StandardField[],
  prevRunSheet: RunSheetItem[],
  nextRunSheet: RunSheetItem[],
) {
  const { data: bookings } = await supabase
    .from("bookings")
    .select("id, event_name, event_date, field_values, run_sheet")
    .eq("standard_id", standardId);
  if (!bookings?.length) return;

  



  for (const booking of bookings) {
    const current = fieldValues(booking.field_values);
    const merged: Record<string, string> = {};
    // Handmatig overschreven prijzen blijven altijd bewaard.
    for (const [key, value] of Object.entries(current)) {
      if (isPriceKey(key)) merged[key] = value;
    }
    for (const f of next) {
      const value = current[f.id];
      const newDefault = f.default ?? "";
      // Alleen lege velden krijgen (nieuwe) standaardwaarden; al ingevulde
      // informatie in een boeking wordt nooit overschreven.
      const filled = typeof value === "string" && value.trim() !== "";
      merged[f.id] = filled ? value : newDefault;
    }



    const dateField = next.find((f) => f.type === "date" || f.type === "datetime");
    const eventDate = dateField ? (merged[dateField.id] ?? "").slice(0, 10) : "";
    const nameField = eventNameField(next);
    const eventName = nameField ? (merged[nameField.id] ?? "").trim() : "";

    // Draaiboek: heeft de boeking al een eigen draaiboek (één regel is genoeg),
    // dan blijft dat volledig ongewijzigd. Alleen een leeg draaiboek wordt
    // gevuld met het sjabloon uit de standaard.
    const bookingRun = parseRunSheet(booking.run_sheet);
    const hasOwnRunSheet = bookingRun.some(
      (i) =>
        (i.title ?? "").trim() !== "" ||
        (i.time ?? "") !== "" ||
        (i.endTime ?? "") !== "" ||
        (i.description ?? "").trim() !== "",
    );
    const nextRun = hasOwnRunSheet ? bookingRun : nextRunSheet;


    await supabase
      .from("bookings")
      .update({
        field_values: merged,
        run_sheet: nextRun as unknown as never,
        ...(eventDate ? { event_date: eventDate } : {}),
        ...(eventName ? { event_name: eventName } : {}),
      })
      .eq("id", booking.id);
  }
}



function newTask(): DefaultTask {
  return {
    id: `t_${Math.random().toString(36).slice(2, 10)}`,
    title: "",
    description: "",
    daysBefore: null,
  };
}

export function StandardDialog({
  open,
  onOpenChange,
  artistId,
  artistName,
  standard,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  artistId: string;
  artistName: string;
  standard?: Standard | null;
}) {
  const queryClient = useQueryClient();
  const [name, setName] = useState("");
  const [fields, setFields] = useState<StandardField[]>([]);
  const [tasks, setTasks] = useState<DefaultTask[]>([]);
  const [team, setTeam] = useState<DefaultTeamMember[]>([]);
  const [runSheetEnabled, setRunSheetEnabled] = useState(false);
  const [runSheet, setRunSheet] = useState<RunSheetItem[]>([]);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<string>("booking");
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});
  const [collapsedFields, setCollapsedFields] = useState<Record<string, boolean>>({});
  const { allowed: canViewFinancialTab } = usePermission("financial.view");
  const { allowed: canViewPricing } = usePermission("pricing.view");
  const isAdmin = canViewFinancialTab;
  const visibleTabs: string[] = [
    FIELD_TABS[0],
    ...(canViewFinancialTab ? [FIELD_TABS[1]] : []),
    ...(canViewPricing ? [PRICING_TAB] : []),
  ];
  const isPricingTab = activeTab === PRICING_TAB;
  const sections = Array.from(
    new Set(fields.filter((field) => fieldTab(field) === activeTab).map(sectionKey)),
  );

  function renameSection(section: string) {
    const entered = window.prompt("Nieuwe naam voor de sectie", sectionLabel(section));
    const next = entered?.trim();
    if (!next || next === section) return;
    setFields((prev) =>
      prev.map((f) =>
        fieldTab(f) === activeTab && sectionKey(f) === section ? { ...f, section: next } : f,
      ),
    );
  }

  function deleteSection(section: string) {
    if (!window.confirm(`Sectie "${sectionLabel(section)}" en alle velden erin verwijderen?`)) return;
    setFields((prev) =>
      prev.filter((f) => !(fieldTab(f) === activeTab && sectionKey(f) === section)),
    );
  }

  function moveSection(section: string, direction: -1 | 1) {
    const idx = sections.indexOf(section);
    const target = idx + direction;
    if (idx < 0 || target < 0 || target >= sections.length) return;
    const order = [...sections];
    [order[idx], order[target]] = [order[target], order[idx]];
    setFields((prev) => {
      const others = prev.filter((f) => fieldTab(f) !== activeTab);
      const tabFields = order.flatMap((s) =>
        prev.filter((f) => fieldTab(f) === activeTab && sectionKey(f) === s),
      );
      return [...others, ...tabFields];
    });
  }

  function setPricing(fieldId: string, pricing: FieldPricing) {
    setFields((prev) => prev.map((f) => (f.id === fieldId ? { ...f, pricing } : f)));
  }



  useEffect(() => {
    if (!open) return;
    const nextFields = standard ? parseFields(standard.fields) : baseFields();
    setName(standard?.name ?? "");
    setFields(nextFields);
    setCollapsedFields(Object.fromEntries(nextFields.map((field) => [field.id, true])));
    setTasks(standard ? parseDefaultTasks(standard.default_tasks) : []);
    setTeam(standard ? parseDefaultTeam(standard.default_team) : []);
    setRunSheetEnabled(standard?.run_sheet_enabled ?? false);
    setRunSheet(standard ? parseRunSheet(standard.run_sheet) : []);
  }, [open, standard]);


  function patchTask(index: number, changes: Partial<DefaultTask>) {
    setTasks((prev) => prev.map((t, i) => (i === index ? { ...t, ...changes } : t)));
  }


  function patch(index: number, changes: Partial<StandardField>) {
    setFields((prev) => prev.map((f, i) => (i === index ? { ...f, ...changes } : f)));
  }

  function move(index: number, dir: -1 | 1) {
    setFields((prev) => {
      const next = [...prev];
      const target = index + dir;
      if (target < 0 || target >= next.length) return prev;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    const cleaned = ensureBaseFields(fields)
      .filter((f) => f.label.trim())
      .map((f) => ({
        ...f,
        label: f.label.trim(),
        options:
          f.type === "dropdown"
            ? (f.options ?? []).filter(Boolean)
            : undefined,
      }));
    if (cleaned.length === 0) return toast.error("Voeg minimaal één veld toe.");
    if (!name.trim()) return toast.error("Geef de standaard een naam.");


    const cleanedTasks = tasks
      .filter((t) => t.title.trim())
      .map((t) => ({ ...t, title: t.title.trim(), description: (t.description ?? "").trim() }));

    setSaving(true);
    const payload = {
      name: name.trim(),
      fields: cleaned as unknown as never,
      default_tasks: cleanedTasks as unknown as never,
      default_team: team as unknown as never,
      run_sheet_enabled: runSheetEnabled,
      run_sheet: (runSheetEnabled
        ? runSheet
            .filter((i) => i.title.trim() || i.time || i.endTime)
            .map((i) => ({
              ...i,
              title: i.title.trim(),
              description: (i.description ?? "").trim(),
            }))
        : []) as unknown as never,
    };


    if (standard) {
      const previous = parseFields(standard.fields);
      const prevRunSheet = parseRunSheet(standard.run_sheet);
      const nextRunSheet = payload.run_sheet as unknown as RunSheetItem[];
      const { data: updated, error } = await supabase
        .from("performance_standards")
        .update(payload)
        .eq("id", standard.id)
        .select("id");
      if (!error && !updated?.length) {
        setSaving(false);
        return toast.error("Je hebt geen recht om deze standaard aan te passen.");
      }
      if (error) {
        setSaving(false);
        return toast.error(error.message);
      }
      await syncBookings(
        standard.id,
        previous,
        cleaned as StandardField[],
        prevRunSheet,
        nextRunSheet,
      );

      setSaving(false);
      await logActivity({
        entityType: "standard",
        entityId: standard.id,
        action: "update",
        summary: `Standaard ${name} van ${artistName} bijgewerkt`,
      });
    } else {
      const { data, error } = await supabase
        .from("performance_standards")
        .insert({ ...payload, artist_id: artistId })
        .select()
        .maybeSingle();
      setSaving(false);
      if (error) return toast.error(error.message);
      await logActivity({
        entityType: "standard",
        entityId: data?.id,
        action: "create",
        summary: `Standaard ${name} toegevoegd aan ${artistName}`,
      });
    }
    queryClient.invalidateQueries();
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-5xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {standard ? "Optredenstandaard bewerken" : "Nieuwe optredenstandaard"} — {artistName}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={save} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="standard-name">Naam optredenstandaard *</Label>
            <Input
              id="standard-name"
              placeholder="Bijv. Solo pianoshow"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Alleen intern zichtbaar — in het boekingoverzicht toont de evenementnaam uit de
              boeking.
            </p>
          </div>

          <div className="space-y-3">
            {visibleTabs.length > 1 ? (
              <>
                <Label>Velden per tabblad</Label>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList>
                    {visibleTabs.map((t) => (
                      <TabsTrigger key={t} value={t}>
                        {BOOKING_TAB_LABELS[t]}
                        {t === PRICING_TAB
                          ? ""
                          : ` (${fields.filter((f) => fieldTab(f) === t).length})`}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </Tabs>
              </>
            ) : (
              <Label>Velden</Label>
            )}

            {isPricingTab ? (
              <PricingRulesEditor
                fields={fields}
                onChange={setPricing}
                onAddRule={() =>
                  setFields((p) => [
                    ...p,
                    {
                      id: `f_${Date.now().toString(36)}`,
                      label: "",
                      type: "currency" as FieldType,
                      tab: "pricing" as FieldTab,
                      pricing: {},
                    },
                  ])
                }
                onRemoveRule={(id) => setFields((p) => p.filter((f) => f.id !== id))}
                onRelabel={(id, label) =>
                  setFields((p) => p.map((f) => (f.id === id ? { ...f, label } : f)))
                }
              />

            ) : (
              <div className="flex items-center justify-between gap-4">
                <p className="text-xs text-muted-foreground">
                  Velden in dit tabblad verschijnen onder “{BOOKING_TAB_LABELS[activeTab]}” op de
                  boekingspagina.
                </p>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  className="shrink-0"
                  onClick={() => {
                    const entered = window.prompt("Naam van de nieuwe sectie");
                    const section = entered?.trim();
                    if (!section) return;
                    setFields((previous) => [
                      ...previous,
                      { ...newField(activeTab as FieldTab), section },
                    ]);
                  }}
                >
                  <Plus className="mr-1 h-4 w-4" /> Sectie
                </Button>
              </div>
            )}

            {!isPricingTab ? (
              <div className="space-y-8 rounded-md bg-muted/30 px-4 py-5 sm:px-5">
                {sections.map((section, sectionIndex) => {
                  const sectionFields = fields
                    .map((field, index) => ({ field, index }))
                    .filter(
                      ({ field }) =>
                        fieldTab(field) === activeTab && sectionKey(field) === section,
                    );

                  return (
                    <section key={section} className="space-y-5">
                      <div className="flex items-center gap-3 border-b pb-3">
                        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
                          {sectionIndex + 1}
                        </span>
                        <h3 className="text-sm font-semibold uppercase text-foreground">
                          {sectionLabel(section)}
                        </h3>
                        <div className="ml-auto flex items-center gap-1">
                          <Button type="button" size="icon" variant="ghost" aria-label="Sectie omhoog" disabled={sectionIndex === 0} onClick={() => moveSection(section, -1)}>
                            <ArrowUp className="h-4 w-4" />
                          </Button>
                          <Button type="button" size="icon" variant="ghost" aria-label="Sectie omlaag" disabled={sectionIndex === sections.length - 1} onClick={() => moveSection(section, 1)}>
                            <ArrowDown className="h-4 w-4" />
                          </Button>
                          <Button type="button" size="icon" variant="ghost" aria-label="Sectie hernoemen" onClick={() => renameSection(section)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button type="button" size="icon" variant="ghost" aria-label="Sectie verwijderen" className="text-destructive" onClick={() => deleteSection(section)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                          <Button
                            type="button"
                            size="icon"
                            variant="ghost"
                            className="shrink-0"
                            aria-label={collapsedSections[`${activeTab}:${section}`] ? "Sectie uitklappen" : "Sectie inklappen"}
                            onClick={() =>
                              setCollapsedSections((prev) => ({
                                ...prev,
                                [`${activeTab}:${section}`]: !prev[`${activeTab}:${section}`],
                              }))
                            }
                          >
                            {collapsedSections[`${activeTab}:${section}`] ? (
                              <ChevronDown className="h-4 w-4" />
                            ) : (
                              <ChevronUp className="h-4 w-4" />
                            )}
                          </Button>
                          <Button
                            type="button"
                            size="sm"
                            variant="ghost"
                            className="shrink-0"
                            onClick={() =>
                              setFields((previous) => [
                                ...previous,
                                {
                                  ...newField(activeTab as FieldTab),
                                  section: section === NO_SECTION ? undefined : section,
                                },
                              ])
                            }
                          >
                            <Plus className="mr-1 h-4 w-4" /> Veld
                          </Button>
                        </div>
                      </div>

                      {!collapsedSections[`${activeTab}:${section}`] ? (
                        <div className="space-y-4">
                        {sectionFields.map(({ field: f, index: i }) => (
                          <div key={f.id} className="rounded-lg border p-3">
                            <Button
                              type="button"
                              variant="ghost"
                              className="h-auto w-full justify-between gap-3 p-0 text-left hover:bg-transparent"
                              aria-expanded={!collapsedFields[f.id]}
                              onClick={() =>
                                setCollapsedFields((previous) => ({
                                  ...previous,
                                  [f.id]: !previous[f.id],
                                }))
                              }
                            >
                              <span className="min-w-0 truncate text-sm font-medium">
                                {f.label || "Nieuw veld"}
                              </span>
                              {collapsedFields[f.id] ? (
                                <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />
                              ) : (
                                <ChevronUp className="h-4 w-4 shrink-0 text-muted-foreground" />
                              )}
                            </Button>

                            {!collapsedFields[f.id] ? (
                            <div className="mt-4 space-y-3 border-t pt-4">
                            <div className="flex items-start gap-3">
                              <div className="grid min-w-0 flex-1 gap-3 sm:grid-cols-[minmax(0,1fr)_minmax(12rem,0.65fr)]">
                                <div className="space-y-1.5">
                                  <Label htmlFor={`${f.id}-label`}>Veldnaam</Label>
                                  <Input
                                    id={`${f.id}-label`}
                                    placeholder="Veldnaam"
                                    value={f.label}
                                    readOnly={isBaseField(f)}
                                    disabled={isBaseField(f)}
                                    onChange={(e) => patch(i, { label: e.target.value })}
                                  />
                                </div>
                                <div className="space-y-1.5">
                                  <Label>Type</Label>
                                  <Select
                                    value={f.type}
                                    disabled={isBaseField(f)}
                                    onValueChange={(v) => patch(i, { type: v as FieldType })}
                                  >
                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                      {Object.entries(FIELD_TYPE_LABELS).map(([value, label]) => (
                                        <SelectItem key={value} value={value}>{label}</SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                              </div>
                              <div className="flex shrink-0 items-center pt-6">
                                {isBaseField(f) ? (
                                  <span className="whitespace-nowrap bg-muted px-2 py-1 text-xs text-muted-foreground">Vast veld</span>
                                ) : (
                                  <>
                                    <Button type="button" size="icon" variant="ghost" title="Omhoog" aria-label={`${f.label || "Veld"} omhoog`} onClick={() => move(i, -1)}>
                                      <ArrowUp className="h-4 w-4" />
                                    </Button>
                                    <Button type="button" size="icon" variant="ghost" title="Omlaag" aria-label={`${f.label || "Veld"} omlaag`} onClick={() => move(i, 1)}>
                                      <ArrowDown className="h-4 w-4" />
                                    </Button>
                                    <Button type="button" size="icon" variant="ghost" title="Verwijderen" aria-label={`${f.label || "Veld"} verwijderen`} onClick={() => setFields((p) => p.filter((_, idx) => idx !== i))}>
                                      <Trash2 className="h-4 w-4 text-destructive" />
                                    </Button>
                                  </>
                                )}
                              </div>
                            </div>

                            {f.type === "dropdown" ? (
                              <div className="space-y-1.5">
                                <Label htmlFor={`${f.id}-options`}>Keuzemogelijkheden</Label>
                                <Input
                                  id={`${f.id}-options`}
                                  placeholder="Opties, komma-gescheiden"
                                  value={(f.options ?? []).join(", ")}
                                  onChange={(e) => patch(i, { options: e.target.value.split(",").map((option) => option.trim()) })}
                                />
                              </div>
                            ) : null}

                            <div className="space-y-1.5">
                              <Label>Standaardwaarde</Label>
                              {f.type === "formula" ? (
                                <div>
                                  <Input
                                    placeholder="=[Kilometers] * 0,35"
                                    value={f.formula ?? ""}
                                    onChange={(e) => patch(i, { formula: e.target.value })}
                                  />
                                  <p className="mt-1 text-xs text-muted-foreground">Gebruik + - * / en veldnamen tussen blokhaken.</p>
                                </div>
                              ) : (
                                <DynamicFieldInput
                                  field={f}
                                  value={f.default ?? ""}
                                  onChange={(value) => patch(i, { default: value })}
                                />
                              )}
                            </div>
                            </div>
                            ) : null}
                          </div>
                        ))}

                      </div>
                    ) : null}
                    </section>
                  );
                })}
              </div>
            ) : null}
          </div>


          <div className="space-y-3 border-t pt-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Standaardtaken</Label>
                <p className="text-xs text-muted-foreground">
                  Deze taken worden automatisch aangemaakt bij elke boeking met deze standaard.
                </p>
              </div>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={() => setTasks((p) => [...p, newTask()])}
              >
                <Plus className="mr-1 h-4 w-4" /> Taak
              </Button>
            </div>

            {tasks.map((t, i) => (
              <div key={t.id} className="space-y-2 rounded-lg border p-3">
                <div className="flex flex-wrap items-center gap-2">
                  <Input
                    className="min-w-40 flex-1"
                    placeholder="Taaktitel"
                    value={t.title}
                    onChange={(e) => patchTask(i, { title: e.target.value })}
                  />
                  <Input
                    type="number"
                    min={0}
                    className="w-36"
                    placeholder="Dagen vooraf"
                    value={t.daysBefore ?? ""}
                    onChange={(e) =>
                      patchTask(i, {
                        daysBefore: e.target.value === "" ? null : Number(e.target.value),
                      })
                    }
                  />
                  <Button
                    type="button"
                    size="icon"
                    variant="ghost"
                    onClick={() => setTasks((p) => p.filter((_, idx) => idx !== i))}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
                <Textarea
                  rows={2}
                  placeholder="Omschrijving (optioneel)"
                  value={t.description ?? ""}
                  onChange={(e) => patchTask(i, { description: e.target.value })}
                />
              </div>
            ))}
            {tasks.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nog geen standaardtaken.</p>
            ) : null}
          </div>

          <div className="space-y-3 border-t pt-4">
            <div>
              <Label>Teamleden</Label>
              <p className="text-xs text-muted-foreground">
                Deze teamleden worden automatisch uitgenodigd bij elke nieuwe boeking met deze
                standaard. Bij het aanmaken van de boeking kun je dit nog aanpassen.
              </p>
            </div>
            <DefaultTeamEditor value={team} onChange={setTeam} />
          </div>

          <div className="space-y-3 border-t pt-4">
            <div className="flex items-center justify-between gap-4">
              <div>
                <Label htmlFor="run-sheet-toggle">Draaiboek toevoegen</Label>
                <p className="text-xs text-muted-foreground">
                  Het draaiboek wordt automatisch gekoppeld aan elke nieuwe boeking met deze
                  standaard.
                </p>
              </div>
              <Switch
                id="run-sheet-toggle"
                checked={runSheetEnabled}
                onCheckedChange={setRunSheetEnabled}
              />
            </div>
            {runSheetEnabled ? (
              <RunSheetEditor items={runSheet} onChange={setRunSheet} />
            ) : null}
          </div>


          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Annuleren
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Bezig…" : "Opslaan"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
