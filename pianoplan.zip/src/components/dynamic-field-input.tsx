import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, MapPin } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { evaluateFieldFormula, type StandardField } from "@/lib/data";
import {
  computeDrivingDistance,
  searchPlaces,
  type PlaceSuggestion,
} from "@/lib/places.functions";
import { cn } from "@/lib/utils";

export interface DistanceLocation {
  id: string;
  label: string;
  address: string;
}

export function DynamicFieldInput({
  field,
  value,
  onChange,
  locations = [],
  fields = [],
  values = {},
  className = "",
}: {
  field: StandardField;
  value: string;
  onChange: (v: string) => void;
  /** Beschikbare locaties voor het afstandsveld (thuislocatie + kaartlocaties). */
  locations?: DistanceLocation[];
  /** Alle velden van de standaard (nodig voor formulevelden). */
  fields?: StandardField[];
  /** Huidige waarden van de boeking (nodig voor formulevelden). */
  values?: Record<string, string>;
  className?: string;
}) {
  const common = { id: field.id, value: value ?? "" };

  switch (field.type) {
    case "textarea":
    case "notes":
      return (
        <Textarea
          {...common}
          rows={3}
          className={className}
          onKeyDown={(e) => {
            if (e.key === "Enter") e.stopPropagation();
          }}
          onChange={(e) => onChange(e.target.value)}
        />
      );
    case "dropdown": {
      const options = Array.from(
        new Set((field.options ?? []).map((o) => o.trim()).filter(Boolean)),
      );
      return (
        <Select value={value || undefined} onValueChange={onChange}>
          <SelectTrigger className={className}>
            <SelectValue placeholder="Selecteer…" />
          </SelectTrigger>
          <SelectContent>
            {options.length ? (
              options.map((o) => (
                <SelectItem key={o} value={o}>
                  {o}
                </SelectItem>
              ))
            ) : (
              <div className="px-3 py-2 text-xs text-muted-foreground">
                Nog geen opties ingevuld
              </div>
            )}
          </SelectContent>
        </Select>
      );
    }
    case "date":
      return <Input type="date" {...common} className={className} onChange={(e) => onChange(e.target.value)} />;
    case "time": {
      const [start = "", end = ""] = (value ?? "").split("-").map((v) => v.trim());
      const emit = (s: string, e: string) => onChange(s || e ? `${s} - ${e}` : "");
      return (
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1">
            <Label htmlFor={`${field.id}-start`} className="text-xs text-muted-foreground">
              Begintijd
            </Label>
            <Input
              id={`${field.id}-start`}
              type="time"
              className={className}
              value={start}
              onChange={(e) => emit(e.target.value, end)}
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor={`${field.id}-end`} className="text-xs text-muted-foreground">
              Eindtijd
            </Label>
            <Input
              id={`${field.id}-end`}
              type="time"
              className={className}
              value={end}
              onChange={(e) => emit(start, e.target.value)}
            />
          </div>
        </div>
      );
    }
    case "datetime":
      return (
        <Input type="datetime-local" {...common} className={className} onChange={(e) => onChange(e.target.value)} />
      );
    case "boolean":
      return (
        <div className="flex items-center gap-2">
          <Switch
            id={field.id}
            checked={value === "ja"}
            onCheckedChange={(c) => onChange(c ? "ja" : "nee")}
          />
          <Label htmlFor={field.id} className="text-sm text-muted-foreground">
            {value === "ja" ? "Ja" : "Nee"}
          </Label>
        </div>
      );
    case "currency":
      return (
        <div className="relative">
          <span className="pointer-events-none absolute top-2 left-3 text-sm text-muted-foreground">
            €
          </span>
          <Input
            {...common}
            className={cn("pl-7", className)}
            inputMode="decimal"
            placeholder="0,00"
            onChange={(e) => onChange(e.target.value)}
          />
        </div>
      );
    case "map":
      return <PlaceInput id={field.id} value={value ?? ""} onChange={onChange} className={className} />;
    case "distance":
      return <DistanceField value={value ?? ""} onChange={onChange} locations={locations} className={className} />;
    case "formula":
      return (
        <FormulaResult
          field={field}
          fields={fields}
          values={values}
          value={value ?? ""}
          onChange={onChange}
          className={className}
        />
      );


    default:
      return <Input {...common} onChange={(e) => onChange(e.target.value)} />;
  }
}

export function PlaceInput({
  id,
  value,
  onChange,
  placeholder = "Zoek locatie of adres…",
  className = "",
}: {
  id?: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  className?: string;
}) {
  const search = useServerFn(searchPlaces);
  const [query, setQuery] = useState(value);
  const [results, setResults] = useState<PlaceSuggestion[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const lastPicked = useRef(value);

  useEffect(() => {
    if (value === lastPicked.current) return;
    lastPicked.current = value;
    setQuery(value);
  }, [value]);

  useEffect(() => {
    const q = query.trim();
    if (q.length < 3 || q === lastPicked.current) {
      setResults([]);
      setLoading(false);
      return;
    }
    let active = true;
    setLoading(true);
    const timer = setTimeout(async () => {
      try {
        const found = await search({ data: { query: q } });
        if (!active) return;
        setResults(found);
        setOpen(found.length > 0);
      } catch {
        if (active) setResults([]);
      } finally {
        if (active) setLoading(false);
      }
    }, 350);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [query, search]);


  function pick(place: PlaceSuggestion) {
    const name = (place.name ?? "").trim();
    const address = (place.address ?? "").trim();
    // Avoid duplication when the place name already appears in the address
    const label =
      name && address && address.toLowerCase().includes(name.toLowerCase())
        ? address
        : [name, address].filter(Boolean).join(", ");
    lastPicked.current = label;
    setQuery(label);
    setResults([]);
    setOpen(false);
    onChange(label);
  }

  return (
    <div className="space-y-2">
      <div className="relative">
        <MapPin className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          id={id}
          value={query}
          className={cn("pl-9", className)}
          autoComplete="off"
          placeholder={placeholder}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => results.length && setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
        />

        {loading ? (
          <Loader2 className="absolute top-2.5 right-3 h-4 w-4 animate-spin text-muted-foreground" />
        ) : null}
        {open && results.length ? (
          <ul className="absolute z-50 mt-1 w-full overflow-hidden rounded-lg border bg-popover shadow-lg">
            {results.map((r) => (
              <li key={r.id}>
                <button
                  type="button"
                  className="block w-full px-3 py-2 text-left hover:bg-muted"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => pick(r)}
                >
                  <span className="block text-sm font-medium">{r.name}</span>
                  <span className="block text-xs text-muted-foreground">{r.address}</span>
                </button>
              </li>
            ))}
          </ul>
        ) : null}
      </div>
      {value ? (
        <a
          href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(value)}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 text-sm text-primary underline underline-offset-4"
        >
          <MapPin className="h-4 w-4" />
          Bekijk op Google Maps
        </a>
      ) : null}
    </div>
  );
}


export function DistanceField({
  value,
  onChange,
  locations,
  className = "",
}: {
  value: string;
  onChange: (v: string) => void;
  locations: DistanceLocation[];
  className?: string;
}) {
  const compute = useServerFn(computeDrivingDistance);
  const [selected, setSelected] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const usable = locations.filter((l) => l.address.trim().length > 2);

  function toggle(id: string) {
    setSelected((prev) => {
      if (prev.includes(id)) return prev.filter((p) => p !== id);
      if (prev.length >= 2) return [prev[1]!, id];
      return [...prev, id];
    });
  }

  async function calculate() {
    const [aId, bId] = selected;
    const a = usable.find((l) => l.id === aId);
    const b = usable.find((l) => l.id === bId);
    if (!a || !b) return;
    setBusy(true);
    setError("");
    try {
      const result = await compute({ data: { origin: a.address, destination: b.address } });
      const km = result.km.toFixed(1).replace(".", ",");
      onChange(`${km} km — ${a.label} → ${b.label}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Berekenen mislukt.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className={cn("space-y-3 rounded-lg border p-3", className)}>
      {usable.length < 2 ? (
        <p className="text-xs text-muted-foreground">
          Vul eerst minimaal twee locaties in (de thuislocatie van de artiest en/of kaartlocaties in
          deze standaard).
        </p>
      ) : (
        <>
          <p className="text-xs text-muted-foreground">Kies twee locaties om de autoafstand te berekenen.</p>
          <div className="space-y-2">
            {usable.map((l) => (
              <label key={l.id} className="flex items-start gap-2 text-sm">
                <Checkbox
                  checked={selected.includes(l.id)}
                  onCheckedChange={() => toggle(l.id)}
                  className="mt-0.5"
                />
                <span>
                  <span className="block font-medium">{l.label}</span>
                  <span className="block text-xs text-muted-foreground">{l.address}</span>
                </span>
              </label>
            ))}
          </div>
          <Button
            type="button"
            size="sm"
            variant="outline"
            className={className}
            disabled={selected.length !== 2 || busy}
            onClick={calculate}
          >
            {busy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : null}
            Afstand berekenen
          </Button>
        </>
      )}
      {error ? <p className="text-xs text-destructive">{error}</p> : null}
      {value ? <p className="text-sm font-medium">{value}</p> : null}
    </div>
  );
}

/** Rekenveld: toont de uitkomst van de formule en bewaart die in de boeking. */
export function FormulaResult({
  field,
  fields,
  values,
  value,
  onChange,
  className = "",
}: {
  field: StandardField;
  fields: StandardField[];
  values: Record<string, string>;
  value: string;
  onChange: (v: string) => void;
  className?: string;
}) {
  const formula = (field.formula ?? "").trim();
  const result = formula ? evaluateFieldFormula(field, fields, values) : null;
  const text = result == null ? "" : String(result);

  useEffect(() => {
    if (text !== value) onChange(text);
  }, [text, value, onChange]);

  return (
    <div className={cn("rounded-lg border bg-muted/40 px-3 py-2", className)}>
      {!formula ? (
        <p className="text-xs text-muted-foreground">
          Er is nog geen formule ingesteld bij dit veld in de standaard.
        </p>
      ) : result == null ? (
        <p className="text-xs text-muted-foreground">
          Uitkomst nog niet te berekenen — vul eerst de velden uit de formule in.
        </p>
      ) : (
        <p className="text-sm font-medium">{result.toLocaleString("nl-NL")}</p>
      )}
      {formula ? <p className="mt-1 text-xs text-muted-foreground">{formula}</p> : null}
    </div>
  );
}
