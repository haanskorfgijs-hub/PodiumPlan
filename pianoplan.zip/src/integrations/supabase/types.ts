export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      activity_log: {
        Row: {
          action: string
          changes: Json
          created_at: string
          entity_id: string | null
          entity_type: string
          id: string
          summary: string
          user_id: string | null
        }
        Insert: {
          action: string
          changes?: Json
          created_at?: string
          entity_id?: string | null
          entity_type: string
          id?: string
          summary?: string
          user_id?: string | null
        }
        Update: {
          action?: string
          changes?: Json
          created_at?: string
          entity_id?: string | null
          entity_type?: string
          id?: string
          summary?: string
          user_id?: string | null
        }
        Relationships: []
      }
      artist_members: {
        Row: {
          artist_id: string
          created_at: string
          created_by: string | null
          id: string
          role: Database["public"]["Enums"]["member_role"]
          status: Database["public"]["Enums"]["invite_status"]
          user_id: string
        }
        Insert: {
          artist_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["member_role"]
          status?: Database["public"]["Enums"]["invite_status"]
          user_id: string
        }
        Update: {
          artist_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["member_role"]
          status?: Database["public"]["Enums"]["invite_status"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "artist_members_artist_id_fkey"
            columns: ["artist_id"]
            isOneToOne: false
            referencedRelation: "artists"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "artist_members_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      artists: {
        Row: {
          booking_statuses: Json
          created_at: string
          created_by: string | null
          description: string | null
          home_location: string | null
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          booking_statuses?: Json
          created_at?: string
          created_by?: string | null
          description?: string | null
          home_location?: string | null
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          booking_statuses?: Json
          created_at?: string
          created_by?: string | null
          description?: string | null
          home_location?: string | null
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      booking_availability: {
        Row: {
          availability: string
          booking_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          availability?: string
          booking_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          availability?: string
          booking_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "booking_availability_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "booking_availability_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      booking_members: {
        Row: {
          booking_id: string
          created_at: string
          created_by: string | null
          id: string
          role: Database["public"]["Enums"]["member_role"]
          status: Database["public"]["Enums"]["invite_status"]
          user_id: string
        }
        Insert: {
          booking_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["member_role"]
          status?: Database["public"]["Enums"]["invite_status"]
          user_id: string
        }
        Update: {
          booking_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["member_role"]
          status?: Database["public"]["Enums"]["invite_status"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "booking_members_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "booking_members_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      bookings: {
        Row: {
          address: string | null
          artist_id: string
          artist_status: string | null
          city: string | null
          contact_email: string | null
          contact_name: string | null
          contact_phone: string | null
          created_at: string
          created_by: string | null
          custom_status: string | null
          end_time: string | null
          event_date: string
          event_name: string
          field_values: Json
          financial_status: Database["public"]["Enums"]["financial_status"]
          id: string
          location_name: string | null
          postal_code: string | null
          run_sheet: Json
          run_sheet_notes: string | null
          standard_id: string | null
          start_time: string | null
          status: Database["public"]["Enums"]["booking_status"]
          updated_at: string
        }
        Insert: {
          address?: string | null
          artist_id: string
          artist_status?: string | null
          city?: string | null
          contact_email?: string | null
          contact_name?: string | null
          contact_phone?: string | null
          created_at?: string
          created_by?: string | null
          custom_status?: string | null
          end_time?: string | null
          event_date: string
          event_name: string
          field_values?: Json
          financial_status?: Database["public"]["Enums"]["financial_status"]
          id?: string
          location_name?: string | null
          postal_code?: string | null
          run_sheet?: Json
          run_sheet_notes?: string | null
          standard_id?: string | null
          start_time?: string | null
          status?: Database["public"]["Enums"]["booking_status"]
          updated_at?: string
        }
        Update: {
          address?: string | null
          artist_id?: string
          artist_status?: string | null
          city?: string | null
          contact_email?: string | null
          contact_name?: string | null
          contact_phone?: string | null
          created_at?: string
          created_by?: string | null
          custom_status?: string | null
          end_time?: string | null
          event_date?: string
          event_name?: string
          field_values?: Json
          financial_status?: Database["public"]["Enums"]["financial_status"]
          id?: string
          location_name?: string | null
          postal_code?: string | null
          run_sheet?: Json
          run_sheet_notes?: string | null
          standard_id?: string | null
          start_time?: string | null
          status?: Database["public"]["Enums"]["booking_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookings_artist_id_fkey"
            columns: ["artist_id"]
            isOneToOne: false
            referencedRelation: "artists"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_standard_id_fkey"
            columns: ["standard_id"]
            isOneToOne: false
            referencedRelation: "performance_standards"
            referencedColumns: ["id"]
          },
        ]
      }
      calendar_widgets: {
        Row: {
          artist_ids: string[]
          content: string[]
          created_at: string
          id: string
          include: string[]
          name: string
          statuses: string[]
          token: string
          user_id: string
        }
        Insert: {
          artist_ids?: string[]
          content?: string[]
          created_at?: string
          id?: string
          include?: string[]
          name: string
          statuses?: string[]
          token?: string
          user_id: string
        }
        Update: {
          artist_ids?: string[]
          content?: string[]
          created_at?: string
          id?: string
          include?: string[]
          name?: string
          statuses?: string[]
          token?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "calendar_widgets_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      contacts: {
        Row: {
          created_at: string
          id: string
          recipient_id: string
          requester_id: string
          responded_at: string | null
          status: Database["public"]["Enums"]["invite_status"]
        }
        Insert: {
          created_at?: string
          id?: string
          recipient_id: string
          requester_id: string
          responded_at?: string | null
          status?: Database["public"]["Enums"]["invite_status"]
        }
        Update: {
          created_at?: string
          id?: string
          recipient_id?: string
          requester_id?: string
          responded_at?: string | null
          status?: Database["public"]["Enums"]["invite_status"]
        }
        Relationships: []
      }
      email_notification_preferences: {
        Row: {
          booking_invitations: boolean
          paused_snapshot: Json | null
          status_changes: boolean
          statuses: string[]
          updated_at: string
          user_id: string
        }
        Insert: {
          booking_invitations?: boolean
          paused_snapshot?: Json | null
          status_changes?: boolean
          statuses?: string[]
          updated_at?: string
          user_id: string
        }
        Update: {
          booking_invitations?: boolean
          paused_snapshot?: Json | null
          status_changes?: boolean
          statuses?: string[]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "email_notification_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          body: string
          created_at: string
          id: string
          link: string | null
          read_at: string | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          body?: string
          created_at?: string
          id?: string
          link?: string | null
          read_at?: string | null
          title: string
          type: string
          user_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          link?: string | null
          read_at?: string | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      performance_standards: {
        Row: {
          artist_id: string
          created_at: string
          default_tasks: Json
          default_team: Json
          fields: Json
          id: string
          name: string
          run_sheet: Json
          run_sheet_enabled: boolean
          updated_at: string
        }
        Insert: {
          artist_id: string
          created_at?: string
          default_tasks?: Json
          default_team?: Json
          fields?: Json
          id?: string
          name: string
          run_sheet?: Json
          run_sheet_enabled?: boolean
          updated_at?: string
        }
        Update: {
          artist_id?: string
          created_at?: string
          default_tasks?: Json
          default_team?: Json
          fields?: Json
          id?: string
          name?: string
          run_sheet?: Json
          run_sheet_enabled?: boolean
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "performance_standards_artist_id_fkey"
            columns: ["artist_id"]
            isOneToOne: false
            referencedRelation: "artists"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string
          id: string
          job_title: string
          name: string
          phone: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string
          id: string
          job_title?: string
          name?: string
          phone?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string
          id?: string
          job_title?: string
          name?: string
          phone?: string
        }
        Relationships: []
      }
      role_labels: {
        Row: {
          label: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at: string
        }
        Insert: {
          label: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at?: string
        }
        Update: {
          label?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
        }
        Relationships: []
      }
      role_permissions: {
        Row: {
          allowed: boolean
          created_at: string
          id: string
          permission: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at: string
        }
        Insert: {
          allowed?: boolean
          created_at?: string
          id?: string
          permission: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at?: string
        }
        Update: {
          allowed?: boolean
          created_at?: string
          id?: string
          permission?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
        }
        Relationships: []
      }
      tasks: {
        Row: {
          assigned_to: string | null
          booking_id: string | null
          created_at: string
          created_by: string | null
          deadline: string | null
          deadline_time: string | null
          description: string | null
          id: string
          show_in_widget: boolean
          status: Database["public"]["Enums"]["task_status"]
          title: string
          updated_at: string
        }
        Insert: {
          assigned_to?: string | null
          booking_id?: string | null
          created_at?: string
          created_by?: string | null
          deadline?: string | null
          deadline_time?: string | null
          description?: string | null
          id?: string
          show_in_widget?: boolean
          status?: Database["public"]["Enums"]["task_status"]
          title: string
          updated_at?: string
        }
        Update: {
          assigned_to?: string | null
          booking_id?: string | null
          created_at?: string
          created_by?: string | null
          deadline?: string | null
          deadline_time?: string | null
          description?: string | null
          id?: string
          show_in_widget?: boolean
          status?: Database["public"]["Enums"]["task_status"]
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tasks_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      artist_manager_booking_role: {
        Args: { _booking_id: string; _user_id: string }
        Returns: Database["public"]["Enums"]["member_role"]
      }
      artist_permission: {
        Args: { _artist_id: string; _key: string }
        Returns: boolean
      }
      artist_role: {
        Args: { _artist_id: string }
        Returns: Database["public"]["Enums"]["member_role"]
      }
      auto_complete_definitive_bookings: { Args: never; Returns: number }
      booking_member_roles: {
        Args: { _booking_id: string }
        Returns: {
          role: Database["public"]["Enums"]["member_role"]
          role_locked: boolean
          user_id: string
        }[]
      }
      booking_permission: {
        Args: { _booking_id: string; _key: string }
        Returns: boolean
      }
      booking_role: {
        Args: { _booking_id: string }
        Returns: Database["public"]["Enums"]["member_role"]
      }
      booking_team: {
        Args: { _booking_id: string }
        Returns: {
          avatar_url: string
          email: string
          id: string
          invite_status: string
          job_title: string
          name: string
          phone: string
        }[]
      }
      can_edit_artist: { Args: { _artist_id: string }; Returns: boolean }
      can_edit_booking: { Args: { _booking_id: string }; Returns: boolean }
      can_manage_booking_task: {
        Args: { _assigned_to: string; _booking_id: string; _created_by: string }
        Returns: boolean
      }
      can_view_artist: { Args: { _artist_id: string }; Returns: boolean }
      can_view_booking: { Args: { _booking_id: string }; Returns: boolean }
      can_view_booking_activity: {
        Args: { _entity_id: string; _entity_type: string }
        Returns: boolean
      }
      can_view_standard: { Args: { _standard_id: string }; Returns: boolean }
      default_artist_statuses: { Args: never; Returns: Json }
      ensure_admin_contacts: { Args: { _user_id: string }; Returns: undefined }
      find_user_by_email: { Args: { _email: string }; Returns: string }
      has_permission: { Args: { _key: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      invitable_users: {
        Args: never
        Returns: {
          email: string
          id: string
          name: string
        }[]
      }
      is_admin_user: { Args: { _user_id: string }; Returns: boolean }
      mark_invite_notification_read: {
        Args: { _title: string; _user_id: string }
        Returns: undefined
      }
      mark_notifications_read: { Args: { _ids: string[] }; Returns: undefined }
      member_account_types: {
        Args: { _id: string; _scope: string }
        Returns: {
          account_role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }[]
      }
      my_contacts: {
        Args: never
        Returns: {
          account_role: Database["public"]["Enums"]["app_role"]
          created_at: string
          email: string
          id: string
          incoming: boolean
          job_title: string
          name: string
          other_id: string
          status: Database["public"]["Enums"]["invite_status"]
        }[]
      }
      my_invitations: {
        Args: never
        Returns: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["member_role"]
          scope: string
          status: Database["public"]["Enums"]["invite_status"]
          subtitle: string
          title: string
        }[]
      }
      notify_user: {
        Args: {
          _body: string
          _link: string
          _title: string
          _type: string
          _user_id: string
        }
        Returns: undefined
      }
      owns_artist: { Args: { _artist_id: string }; Returns: boolean }
      owns_booking: { Args: { _booking_id: string }; Returns: boolean }
      purge_user_data: { Args: { _user_id: string }; Returns: undefined }
      respond_contact_request: {
        Args: { _accept: boolean; _id: string }
        Returns: undefined
      }
      respond_invitation:
        | {
            Args: { _accept: boolean; _id: string; _scope: string }
            Returns: undefined
          }
        | {
            Args: {
              _accept: boolean
              _availability?: string
              _id: string
              _scope: string
            }
            Returns: undefined
          }
      role_allows: {
        Args: { _key: string; _role: Database["public"]["Enums"]["app_role"] }
        Returns: boolean
      }
      run_artist_booking_completion: { Args: never; Returns: undefined }
      send_contact_request: { Args: { _email: string }; Returns: undefined }
      shares_membership: { Args: { _other: string }; Returns: boolean }
      user_has_permission: {
        Args: { _key: string; _user_id: string }
        Returns: boolean
      }
      uses_account_permissions: { Args: { _user_id: string }; Returns: boolean }
      widget_artists: {
        Args: never
        Returns: {
          booking_statuses: Json
          id: string
          name: string
        }[]
      }
    }
    Enums: {
      app_role: "admin" | "gebruiker" | "lezer" | "host" | "boeker"
      booking_status: "optie" | "definitief" | "geannuleerd" | "afgerond"
      financial_status:
        | "factureren"
        | "gefactureerd"
        | "voldaan"
        | "nog_spelen"
        | "geannuleerd"
      invite_status: "pending" | "accepted" | "declined"
      member_role: "gebruiker" | "lezer" | "boeker"
      task_status: "open" | "in_behandeling" | "afgerond"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "gebruiker", "lezer", "host", "boeker"],
      booking_status: ["optie", "definitief", "geannuleerd", "afgerond"],
      financial_status: [
        "factureren",
        "gefactureerd",
        "voldaan",
        "nog_spelen",
        "geannuleerd",
      ],
      invite_status: ["pending", "accepted", "declined"],
      member_role: ["gebruiker", "lezer", "boeker"],
      task_status: ["open", "in_behandeling", "afgerond"],
    },
  },
} as const
