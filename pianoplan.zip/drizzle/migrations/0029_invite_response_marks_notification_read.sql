CREATE OR REPLACE FUNCTION public.mark_invite_notification_read(_user_id uuid, _title text)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = 'public'
AS $$
  UPDATE public.notifications
  SET read_at = now()
  WHERE user_id = _user_id
    AND type = 'invite'
    AND body = _title
    AND read_at IS NULL;
$$;

CREATE OR REPLACE FUNCTION public.respond_invitation(_id uuid, _scope text, _accept boolean, _availability text DEFAULT NULL)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  new_status public.invite_status := CASE WHEN _accept THEN 'accepted' ELSE 'declined' END;
  invite_title text;
BEGIN
  IF _scope = 'artist' THEN
    UPDATE public.artist_members SET status = new_status
    WHERE id = _id AND user_id = auth.uid() AND status = 'pending';
    IF FOUND THEN
      SELECT COALESCE(a.name, 'Artiest') INTO invite_title
      FROM public.artist_members am JOIN public.artists a ON a.id = am.artist_id
      WHERE am.id = _id;
      PERFORM public.mark_invite_notification_read(auth.uid(), invite_title);
    END IF;
  ELSE
    UPDATE public.booking_members SET status = new_status
    WHERE id = _id AND user_id = auth.uid() AND status = 'pending';
    IF FOUND THEN
      SELECT COALESCE(b.event_name, 'Boeking') INTO invite_title
      FROM public.booking_members bm JOIN public.bookings b ON b.id = bm.booking_id
      WHERE bm.id = _id;
      PERFORM public.mark_invite_notification_read(auth.uid(), invite_title);
    END IF;

    IF _accept AND _availability IN ('available', 'tentative', 'unavailable') THEN
      INSERT INTO public.booking_availability (booking_id, user_id, availability)
      SELECT bm.booking_id, bm.user_id, _availability
      FROM public.booking_members bm
      WHERE bm.id = _id AND bm.user_id = auth.uid()
      ON CONFLICT (booking_id, user_id)
      DO UPDATE SET availability = EXCLUDED.availability, updated_at = now();
    END IF;
  END IF;
END;
$function$;

CREATE OR REPLACE FUNCTION public.sync_invitation_on_availability()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  invite_title text;
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.availability IS NOT DISTINCT FROM OLD.availability THEN
    RETURN NEW;
  END IF;
  IF NEW.availability = 'available' THEN
    UPDATE public.booking_members SET status = 'accepted'
    WHERE booking_id = NEW.booking_id AND user_id = NEW.user_id AND status = 'pending';
    IF FOUND THEN
      SELECT COALESCE(event_name, 'Boeking') INTO invite_title
      FROM public.bookings WHERE id = NEW.booking_id;
      PERFORM public.mark_invite_notification_read(NEW.user_id, invite_title);
    END IF;
  ELSIF NEW.availability = 'unavailable' THEN
    UPDATE public.booking_members SET status = 'declined'
    WHERE booking_id = NEW.booking_id AND user_id = NEW.user_id AND status = 'pending';
    IF FOUND THEN
      SELECT COALESCE(event_name, 'Boeking') INTO invite_title
      FROM public.bookings WHERE id = NEW.booking_id;
      PERFORM public.mark_invite_notification_read(NEW.user_id, invite_title);
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;
