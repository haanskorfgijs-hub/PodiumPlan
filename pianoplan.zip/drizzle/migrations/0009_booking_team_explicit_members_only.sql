CREATE OR REPLACE FUNCTION public.booking_team(_booking_id uuid)
RETURNS TABLE(id uuid, name text, email text, phone text, job_title text, avatar_url text, invite_status text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 WITH ranked AS (
  SELECT bm.user_id, MIN(CASE WHEN bm.status::text='accepted' THEN 0 ELSE 1 END) AS rank
  FROM public.booking_members bm
  WHERE bm.booking_id=_booking_id AND bm.status IN ('accepted','pending')
  GROUP BY bm.user_id)
 SELECT p.id,p.name,p.email,p.phone,p.job_title,p.avatar_url,CASE WHEN r.rank=0 THEN 'accepted' ELSE 'pending' END
 FROM public.profiles p JOIN ranked r ON r.user_id=p.id WHERE public.can_view_booking(_booking_id) ORDER BY p.name;
$$;