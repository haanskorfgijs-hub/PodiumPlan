ALTER TABLE public.performance_standards
  ADD COLUMN IF NOT EXISTS default_team jsonb NOT NULL DEFAULT '[]'::jsonb;

COMMENT ON COLUMN public.performance_standards.default_team IS 'Standaard teamleden (user_id + rol) die bij elke nieuwe boeking met deze standaard worden uitgenodigd.';