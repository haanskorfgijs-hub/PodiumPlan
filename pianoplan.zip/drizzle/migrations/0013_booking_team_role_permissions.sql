CREATE OR REPLACE FUNCTION public.booking_permission(_booking_id uuid, _key text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT CASE WHEN public.booking_role(_booking_id) IS NOT NULL
 THEN public.role_allows(public.booking_role(_booking_id)::text::public.app_role, _key)
 ELSE public.has_permission(_key) END;
$$;
CREATE OR REPLACE FUNCTION public.can_edit_booking(_booking_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT public.can_view_booking(_booking_id) AND public.booking_permission(_booking_id, 'bookings.edit');
$$;
ALTER POLICY "bookings editable" ON public.bookings USING (public.can_edit_booking(id)) WITH CHECK (public.can_edit_booking(id));
ALTER POLICY "bookings owner or admin delete" ON public.bookings USING ((created_by = auth.uid() OR public.has_role(auth.uid(), 'admin')) AND public.booking_permission(id, 'bookings.delete'));
ALTER POLICY "booking members manage insert" ON public.booking_members WITH CHECK (public.can_view_booking(booking_id) AND public.booking_permission(booking_id, 'members.manage'));
ALTER POLICY "booking members manage update" ON public.booking_members USING (public.can_view_booking(booking_id) AND public.booking_permission(booking_id, 'members.manage')) WITH CHECK (public.can_view_booking(booking_id) AND public.booking_permission(booking_id, 'members.manage'));
ALTER POLICY "booking members manage delete" ON public.booking_members USING (user_id = auth.uid() OR (public.can_view_booking(booking_id) AND public.booking_permission(booking_id, 'members.manage')));
CREATE OR REPLACE FUNCTION public.can_manage_booking_task(_booking_id uuid, _assigned_to uuid, _created_by uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT CASE WHEN _booking_id IS NOT NULL THEN
 public.can_view_booking(_booking_id) AND (public.booking_permission(_booking_id, 'tasks.manage') OR (public.booking_permission(_booking_id, 'tasks.manage.own') AND (_assigned_to = auth.uid() OR _created_by = auth.uid())))
 ELSE public.has_permission('tasks.manage') OR (public.has_permission('tasks.manage.own') AND (_assigned_to = auth.uid() OR _created_by = auth.uid())) END;
$$;
GRANT EXECUTE ON FUNCTION public.can_manage_booking_task(uuid, uuid, uuid) TO authenticated, service_role;
ALTER POLICY "tasks scoped insert" ON public.tasks WITH CHECK (created_by = auth.uid() AND public.can_manage_booking_task(booking_id, assigned_to, created_by));
ALTER POLICY "tasks scoped update" ON public.tasks USING (public.can_manage_booking_task(booking_id, assigned_to, created_by)) WITH CHECK (public.can_manage_booking_task(booking_id, assigned_to, created_by));
ALTER POLICY "tasks scoped delete" ON public.tasks USING (public.can_manage_booking_task(booking_id, assigned_to, created_by));
ALTER POLICY "tasks scoped select" ON public.tasks USING (CASE WHEN booking_id IS NOT NULL THEN public.can_view_booking(booking_id) AND (public.booking_permission(booking_id, 'tasks.view.all') OR assigned_to = auth.uid()) ELSE public.has_role(auth.uid(), 'admin') OR created_by = auth.uid() OR assigned_to = auth.uid() END);
ALTER POLICY "activity visible" ON public.activity_log USING (
 CASE WHEN entity_type = 'booking' AND entity_id IS NOT NULL AND EXISTS (SELECT 1 FROM public.bookings WHERE id = entity_id)
 THEN public.can_view_booking(entity_id) AND (action NOT LIKE '%\_financial' ESCAPE '\' OR public.booking_permission(entity_id, 'activity.financial.view'))
 ELSE public.has_role(auth.uid(), 'admin') OR (user_id = auth.uid() AND public.can_view_booking_activity(entity_type, entity_id)) END
);