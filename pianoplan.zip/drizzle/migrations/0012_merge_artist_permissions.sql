-- Combineer de drie artiestenrechten (aanmaken, bewerken, verwijderen) in één recht: artists.manage.

-- Bestaande rechten samenvoegen: een accounttype houdt het recht als een van de drie oude rechten aan stond.
INSERT INTO role_permissions (role, permission, allowed)
SELECT role, 'artists.manage', bool_or(allowed)
FROM role_permissions
WHERE permission IN ('artists.create', 'artists.edit', 'artists.delete')
GROUP BY role
ON CONFLICT (role, permission) DO UPDATE SET allowed = EXCLUDED.allowed;

-- host had nog geen rijen voor de oude rechten; standaard volledige rechten.
INSERT INTO role_permissions (role, permission, allowed)
SELECT 'host', 'artists.manage', true
WHERE NOT EXISTS (
  SELECT 1 FROM role_permissions WHERE role = 'host' AND permission = 'artists.manage'
);

DELETE FROM role_permissions WHERE permission IN ('artists.create', 'artists.edit', 'artists.delete');

-- Bewerken vereist het samengevoegde recht.
ALTER POLICY "artists editable" ON public.artists
  USING (public.can_edit_artist(id) AND public.has_permission('artists.manage'))
  WITH CHECK (public.can_edit_artist(id) AND public.has_permission('artists.manage'));
COMMENT ON POLICY "artists editable" ON public.artists IS 'Bewerken van artiesten vereist can_edit_artist en het accountrecht artists.manage';

-- Aanmaken volgt het accountrecht in plaats van de vaste boeker-uitsluiting.
ALTER POLICY "artists owner insert" ON public.artists
  WITH CHECK ((created_by = auth.uid() OR has_role(auth.uid(), 'admin')) AND public.has_permission('artists.manage'));

-- Verwijderen vereist het samengevoegde recht.
ALTER POLICY "artists owner or admin delete" ON public.artists
  USING ((created_by = auth.uid() OR has_role(auth.uid(), 'admin')) AND public.has_permission('artists.manage'));