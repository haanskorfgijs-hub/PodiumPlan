CREATE OR REPLACE FUNCTION public.respond_contact_request(_id uuid, _accept boolean)
 RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE c public.contacts; my_name text; req_name text;
BEGIN
  SELECT * INTO c FROM public.contacts WHERE id = _id AND recipient_id = auth.uid() AND status = 'pending';
  IF c.id IS NULL THEN RAISE EXCEPTION 'Contactverzoek niet gevonden.'; END IF;
  UPDATE public.contacts SET status = CASE WHEN _accept THEN 'accepted' ELSE 'declined' END::public.invite_status, responded_at = now() WHERE id = _id;
  SELECT COALESCE(NULLIF(name,''), email) INTO req_name FROM public.profiles WHERE id = c.requester_id;
  UPDATE public.notifications SET read_at = now()
   WHERE user_id = c.recipient_id AND type = 'contact_request' AND read_at IS NULL
     AND (body = COALESCE(req_name,'Iemand') || ' wil je toevoegen als contact.'
          OR NOT EXISTS (SELECT 1 FROM public.contacts WHERE recipient_id = c.recipient_id AND status = 'pending'));
  SELECT COALESCE(NULLIF(name,''), email) INTO my_name FROM public.profiles WHERE id = auth.uid();
  PERFORM public.notify_user(c.requester_id, 'contact_response',
    CASE WHEN _accept THEN 'Contactverzoek geaccepteerd' ELSE 'Contactverzoek afgewezen' END,
    COALESCE(my_name,'De ontvanger') || CASE WHEN _accept THEN ' heeft je contactverzoek geaccepteerd.' ELSE ' heeft je contactverzoek afgewezen.' END,
    '/contacten');
END $function$;

UPDATE public.notifications n SET read_at = now()
 WHERE n.type = 'contact_request' AND n.read_at IS NULL
   AND NOT EXISTS (SELECT 1 FROM public.contacts c WHERE c.recipient_id = n.user_id AND c.status = 'pending');