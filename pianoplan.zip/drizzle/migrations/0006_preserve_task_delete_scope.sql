ALTER POLICY "tasks scoped delete" ON public.tasks
USING (
  public.has_role(auth.uid(), 'admin'::public.app_role)
  OR (booking_id IS NOT NULL AND (
    public.owns_booking(booking_id)
    OR public.booking_role(booking_id) IN ('gebruiker'::public.member_role, 'boeker'::public.member_role)
  ))
  OR (booking_id IS NULL AND created_by = auth.uid())
);