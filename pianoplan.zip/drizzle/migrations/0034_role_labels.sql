CREATE TABLE public.role_labels (
  role public.app_role PRIMARY KEY,
  label text NOT NULL CHECK (char_length(btrim(label)) BETWEEN 1 AND 40),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.role_labels TO authenticated;
GRANT INSERT, UPDATE ON public.role_labels TO authenticated;
GRANT ALL ON public.role_labels TO service_role;
ALTER TABLE public.role_labels ENABLE ROW LEVEL SECURITY;
CREATE POLICY "role labels readable" ON public.role_labels FOR SELECT TO authenticated USING (true);
CREATE POLICY "role labels insert by managers" ON public.role_labels FOR INSERT TO authenticated WITH CHECK (public.has_permission('users.manage'));
CREATE POLICY "role labels update by managers" ON public.role_labels FOR UPDATE TO authenticated USING (public.has_permission('users.manage')) WITH CHECK (public.has_permission('users.manage'));
INSERT INTO public.role_labels(role,label) VALUES ('admin','Admin'),('host','Nieuw accounttype'),('boeker','Boeker'),('gebruiker','Manager'),('lezer','Lezer');
UPDATE public.role_permissions h SET allowed = a.allowed, updated_at = now()
FROM public.role_permissions a WHERE h.role='host' AND a.role='admin' AND a.permission=h.permission;