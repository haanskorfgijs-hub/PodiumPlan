CREATE OR REPLACE FUNCTION public.notify_new_profile()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE recipient record;
BEGIN
  FOR recipient IN
    SELECT DISTINCT ur.user_id,
      public.role_allows(ur.role, 'users.manage') AS can_manage_users
    FROM public.user_roles ur
    WHERE public.role_allows(ur.role, 'notifications.new_user')
      AND ur.user_id <> NEW.id
  LOOP
    PERFORM public.notify_user(recipient.user_id, 'new_user', 'Nieuw account geregistreerd',
      COALESCE(NULLIF(NEW.name,''), NEW.email),
      CASE WHEN recipient.can_manage_users THEN '/users' ELSE NULL END);
  END LOOP;
  RETURN NEW;
END;
$function$;