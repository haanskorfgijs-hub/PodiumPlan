CREATE OR REPLACE FUNCTION public.enforce_inherited_booking_member_role()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
BEGIN
 -- Teamleden zijn altijd lezer, tenzij ze artiestbeheerder zijn: dan geldt die rol.
 NEW.role := COALESCE(public.artist_manager_booking_role(NEW.booking_id,NEW.user_id),'lezer'::public.member_role);
 RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.booking_member_roles(_booking_id uuid)
 RETURNS TABLE(user_id uuid, role member_role, role_locked boolean)
 LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
 SELECT bm.user_id, COALESCE(public.artist_manager_booking_role(_booking_id,bm.user_id),'lezer'::public.member_role), true
 FROM public.booking_members bm
 WHERE bm.booking_id=_booking_id AND public.can_view_booking(_booking_id);
$function$;

UPDATE public.booking_members bm SET role = COALESCE(public.artist_manager_booking_role(bm.booking_id,bm.user_id),'lezer'::public.member_role);