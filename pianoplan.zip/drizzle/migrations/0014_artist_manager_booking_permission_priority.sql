CREATE OR REPLACE FUNCTION public.booking_permission(_booking_id uuid, _key text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT CASE
 WHEN EXISTS (SELECT 1 FROM public.bookings b JOIN public.artist_members am ON am.artist_id = b.artist_id WHERE b.id = _booking_id AND am.user_id = auth.uid() AND am.status = 'accepted')
 THEN public.has_permission(_key)
 WHEN public.booking_role(_booking_id) IS NOT NULL
 THEN public.role_allows(public.booking_role(_booking_id)::text::public.app_role, _key)
 ELSE public.has_permission(_key) END;
$$;