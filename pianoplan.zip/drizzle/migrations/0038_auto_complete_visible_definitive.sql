CREATE OR REPLACE FUNCTION public.auto_complete_definitive_bookings()
 RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE n integer;
BEGIN
  PERFORM set_config('app.system_job', 'on', true);
  UPDATE public.bookings
     SET status = 'afgerond',
         custom_status = CASE WHEN custom_status IS NULL THEN NULL ELSE 'Afgerond' END
   WHERE event_date < (now() AT TIME ZONE 'Europe/Amsterdam')::date
     AND ( lower(custom_status) = 'definitief'
        OR (custom_status IS NULL AND status = 'definitief')
        OR (lower(custom_status) = 'afgerond' AND status <> 'afgerond') );
  GET DIAGNOSTICS n = ROW_COUNT;
  PERFORM set_config('app.system_job', 'off', true);
  RETURN n;
END;
$$;
REVOKE ALL ON FUNCTION public.auto_complete_definitive_bookings() FROM PUBLIC, anon, authenticated;