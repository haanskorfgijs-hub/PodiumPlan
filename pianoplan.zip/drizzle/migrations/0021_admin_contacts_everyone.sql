CREATE OR REPLACE FUNCTION public.ensure_admin_contacts(_user_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _is_admin boolean;
BEGIN
  SELECT EXISTS (SELECT 1 FROM user_roles WHERE user_id = _user_id AND role IN ('admin','host')) INTO _is_admin;
  -- Bestaande niet-geaccepteerde paren direct accepteren
  UPDATE contacts c SET status = 'accepted', responded_at = now()
  WHERE c.status <> 'accepted' AND (
    (c.requester_id = _user_id OR c.recipient_id = _user_id)
    AND (_is_admin OR EXISTS (
      SELECT 1 FROM user_roles r WHERE r.role IN ('admin','host')
        AND r.user_id = CASE WHEN c.requester_id = _user_id THEN c.recipient_id ELSE c.requester_id END))
  );
  INSERT INTO contacts (requester_id, recipient_id, status, responded_at)
  SELECT DISTINCT ON (LEAST(_user_id, p.id), GREATEST(_user_id, p.id))
    _user_id, p.id, 'accepted'::invite_status, now()
  FROM profiles p
  WHERE p.id <> _user_id
    AND (_is_admin OR EXISTS (SELECT 1 FROM user_roles r WHERE r.user_id = p.id AND r.role IN ('admin','host')))
  ON CONFLICT DO NOTHING;
END $$;

CREATE OR REPLACE FUNCTION public.trg_admin_contacts()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.ensure_admin_contacts(NEW.user_id);
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS admin_contacts_on_role ON public.user_roles;
CREATE TRIGGER admin_contacts_on_role AFTER INSERT OR UPDATE OF role ON public.user_roles
FOR EACH ROW EXECUTE FUNCTION public.trg_admin_contacts();

REVOKE ALL ON FUNCTION public.ensure_admin_contacts(uuid) FROM PUBLIC, anon, authenticated;

-- Backfill voor alle bestaande admins
SELECT public.ensure_admin_contacts(user_id) FROM public.user_roles WHERE role IN ('admin','host');