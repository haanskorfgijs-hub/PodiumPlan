DROP FUNCTION public.my_contacts();
CREATE FUNCTION public.my_contacts()
RETURNS TABLE(id uuid, other_id uuid, name text, email text, status public.invite_status, incoming boolean, created_at timestamptz, job_title text, account_role public.app_role)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT c.id, p.id, p.name, p.email, c.status, c.recipient_id = auth.uid(), c.created_at, p.job_title, ur.role
  FROM public.contacts c
  JOIN public.profiles p ON p.id = CASE WHEN c.requester_id = auth.uid() THEN c.recipient_id ELSE c.requester_id END
  LEFT JOIN public.user_roles ur ON ur.user_id = p.id
  WHERE auth.uid() IN (c.requester_id, c.recipient_id)
  ORDER BY c.created_at DESC
$$;
GRANT EXECUTE ON FUNCTION public.my_contacts() TO authenticated;