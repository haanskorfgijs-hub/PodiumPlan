INSERT INTO public.role_permissions (role, permission, allowed)
SELECT r, k, (r = 'admin')
FROM unnest(array['admin','host','gebruiker','boeker','lezer']::public.app_role[]) r,
     unnest(array['admin.full_access','admin.switch_account','admin.availability','admin.contacts']) k
WHERE NOT EXISTS (SELECT 1 FROM public.role_permissions rp WHERE rp.role = r AND rp.permission = k);

CREATE OR REPLACE FUNCTION public.user_has_permission(_user_id uuid, _key text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT coalesce(bool_or(coalesce(rp.allowed,false)), false)
  FROM public.user_roles ur
  LEFT JOIN public.role_permissions rp ON rp.role = ur.role AND rp.permission = _key
  WHERE ur.user_id = _user_id;
$$;

-- 'admin' is nu een bundel rechten: has_role(..., 'admin') volgt het recht admin.full_access
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT CASE WHEN _role = 'admin'::public.app_role
    THEN public.user_has_permission(_user_id, 'admin.full_access')
    ELSE EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role) END;
$$;

CREATE OR REPLACE FUNCTION public.is_admin_user(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT public.user_has_permission(_user_id, 'admin.contacts');
$$;

DO $$
DECLARE f record; def text;
BEGIN
  FOR f IN SELECT p.oid, p.proname FROM pg_proc p WHERE p.pronamespace = 'public'::regnamespace
    AND p.proname IN ('ensure_admin_contacts','notify_artist_member','notify_booking_member') LOOP
    def := pg_get_functiondef(f.oid);
    def := regexp_replace(def, '(\w+\.)?role IN \(''admin'',''host''\)',
      'public.role_allows(\1role, ' || CASE WHEN f.proname = 'ensure_admin_contacts' THEN '''admin.contacts''' ELSE '''admin.full_access''' END || ')', 'g');
    EXECUTE def;
  END LOOP;
END $$;

DROP POLICY IF EXISTS "Admins insert team availability" ON public.booking_availability;
DROP POLICY IF EXISTS "Admins update team availability" ON public.booking_availability;
CREATE POLICY "Admins insert team availability" ON public.booking_availability FOR INSERT TO authenticated
WITH CHECK (public.has_permission('admin.availability') AND EXISTS (SELECT 1 FROM public.booking_team(booking_availability.booking_id) t WHERE t.id = booking_availability.user_id));
CREATE POLICY "Admins update team availability" ON public.booking_availability FOR UPDATE TO authenticated
USING (public.has_permission('admin.availability'))
WITH CHECK (public.has_permission('admin.availability') AND EXISTS (SELECT 1 FROM public.booking_team(booking_availability.booking_id) t WHERE t.id = booking_availability.user_id));