ALTER TABLE public.bookings ADD COLUMN artist_status text;
COMMENT ON COLUMN public.bookings.artist_status IS 'Canonical artist-defined booking status label';
COMMENT ON COLUMN public.bookings.status IS 'DEPRECATED: replaced by artist_status; retained for old deployed clients';
COMMENT ON COLUMN public.bookings.custom_status IS 'DEPRECATED: replaced by artist_status; retained for old deployed clients';
CREATE OR REPLACE FUNCTION public.default_artist_statuses() RETURNS jsonb LANGUAGE sql VOLATILE SET search_path=public AS $$ SELECT jsonb_build_array(jsonb_build_object('id',gen_random_uuid(),'label','Optie','color','amber','stage','create'),jsonb_build_object('id',gen_random_uuid(),'label','Definitief','color','green','stage','create'),jsonb_build_object('id',gen_random_uuid(),'label','Geannuleerd','color','red','stage','edit'),jsonb_build_object('id',gen_random_uuid(),'label','Afgerond','color','gray','stage','after')) $$;
ALTER TABLE public.artists ALTER COLUMN booking_statuses SET DEFAULT public.default_artist_statuses();
SELECT set_config('app.system_job','on',true);
ALTER TABLE public.bookings DISABLE TRIGGER bookings_notify_status;
ALTER TABLE public.bookings DISABLE TRIGGER trg_delete_tasks_on_cancel;
UPDATE public.bookings SET artist_status=COALESCE(NULLIF(custom_status,''),CASE status::text WHEN 'optie' THEN 'Optie' WHEN 'definitief' THEN 'Definitief' WHEN 'geannuleerd' THEN 'Geannuleerd' WHEN 'afgerond' THEN 'Afgerond' END);
UPDATE public.artists a SET booking_statuses=COALESCE(a.booking_statuses,'[]'::jsonb)||COALESCE((SELECT jsonb_agg(jsonb_build_object('id',gen_random_uuid(),'label',labels.label,'color','gray','stage',CASE WHEN lower(labels.label)='afgerond' THEN 'after' ELSE 'edit' END)) FROM (SELECT DISTINCT b.artist_status AS label FROM public.bookings b WHERE b.artist_id=a.id) labels WHERE NOT EXISTS (SELECT 1 FROM jsonb_array_elements(COALESCE(a.booking_statuses,'[]'::jsonb)) s WHERE s->>'label'=labels.label)),'[]'::jsonb);
ALTER TABLE public.bookings ENABLE TRIGGER bookings_notify_status;
ALTER TABLE public.bookings ENABLE TRIGGER trg_delete_tasks_on_cancel;
SELECT set_config('app.system_job','off',true);
CREATE OR REPLACE FUNCTION public.sync_artist_booking_status() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE changed boolean; picked jsonb;
BEGIN
  changed := TG_OP='INSERT';
  IF TG_OP='UPDATE' THEN
    changed := NEW.artist_status IS DISTINCT FROM OLD.artist_status OR NEW.artist_id IS DISTINCT FROM OLD.artist_id;
    IF NOT changed AND (NEW.custom_status IS DISTINCT FROM OLD.custom_status OR NEW.status IS DISTINCT FROM OLD.status) THEN
      NEW.artist_status:=COALESCE(NULLIF(NEW.custom_status,''),CASE NEW.status::text WHEN 'optie' THEN 'Optie' WHEN 'definitief' THEN 'Definitief' WHEN 'geannuleerd' THEN 'Geannuleerd' WHEN 'afgerond' THEN 'Afgerond' END);
      changed:=true;
    END IF;
  ELSE
    NEW.artist_status:=COALESCE(NULLIF(NEW.artist_status,''),NULLIF(NEW.custom_status,''));
    IF NEW.artist_status IS NULL THEN
      SELECT s INTO picked FROM public.artists a CROSS JOIN LATERAL jsonb_array_elements(a.booking_statuses) s WHERE a.id=NEW.artist_id AND (s->>'stage' IS NULL OR s->>'stage'='create') LIMIT 1;
      NEW.artist_status:=picked->>'label';
    END IF;
  END IF;
  IF changed THEN
    IF NEW.artist_status IS NULL OR NOT EXISTS (SELECT 1 FROM public.artists a CROSS JOIN LATERAL jsonb_array_elements(a.booking_statuses) s WHERE a.id=NEW.artist_id AND s->>'label'=NEW.artist_status) THEN
      RAISE EXCEPTION 'Kies een status van deze artiest.';
    END IF;
    IF EXISTS (SELECT 1 FROM public.artists a CROSS JOIN LATERAL jsonb_array_elements(a.booking_statuses) s WHERE a.id=NEW.artist_id AND s->>'label'=NEW.artist_status AND (s->>'stage' IS DISTINCT FROM 'after' OR NEW.event_date <= (now() AT TIME ZONE 'Europe/Amsterdam')::date)) IS FALSE THEN
      RAISE EXCEPTION 'Deze status is pas beschikbaar op de dag van de boeking.';
    END IF;
    NEW.custom_status:=NEW.artist_status;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_sync_artist_booking_status BEFORE INSERT OR UPDATE ON public.bookings FOR EACH ROW EXECUTE FUNCTION public.sync_artist_booking_status();
CREATE OR REPLACE FUNCTION public.enforce_booking_status_permission() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE changed text[];
BEGIN
  IF auth.uid() IS NULL AND current_setting('app.system_job',true)='on' THEN RETURN NEW; END IF;
  SELECT array_agg(n.key) INTO changed FROM jsonb_each(to_jsonb(NEW)) n JOIN jsonb_each(to_jsonb(OLD)) o ON o.key=n.key WHERE n.value IS DISTINCT FROM o.value;
  IF changed IS NULL THEN RETURN NEW; END IF;
  IF changed <@ ARRAY['status','custom_status','artist_status','updated_at'] THEN
    IF public.booking_permission(NEW.id,'bookings.status') THEN RETURN NEW; END IF;
    RAISE EXCEPTION 'Je hebt geen recht om de status van deze boeking te wijzigen.';
  END IF;
  IF public.can_edit_booking(NEW.id) THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'Je hebt geen recht om deze boeking aan te passen.';
END $$;
CREATE OR REPLACE FUNCTION public.delete_tasks_on_booking_cancel() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$ BEGIN
  IF (NEW.artist_status ~* '(geannuleerd|afgezegd)' AND COALESCE(OLD.artist_status,'') !~* '(geannuleerd|afgezegd)') OR (NEW.financial_status='geannuleerd' AND OLD.financial_status IS DISTINCT FROM 'geannuleerd') THEN DELETE FROM public.tasks WHERE booking_id=NEW.id; END IF;
  RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION public.notify_booking_status() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE actor uuid:=auth.uid(); actor_name text; recipient uuid; body text;
BEGIN
  IF NEW.artist_status IS NOT DISTINCT FROM OLD.artist_status THEN RETURN NEW; END IF;
  SELECT COALESCE(NULLIF(name,''),email) INTO actor_name FROM public.profiles WHERE id=actor;
  body:=COALESCE(NEW.event_name,'Boeking')||' → '||COALESCE(NEW.artist_status,'')||' · door '||COALESCE(actor_name,'automatische afronding');
  FOR recipient IN SELECT DISTINCT uid FROM (SELECT NEW.created_by AS uid UNION SELECT a.created_by FROM public.artists a WHERE a.id=NEW.artist_id UNION SELECT bm.user_id FROM public.booking_members bm WHERE bm.booking_id=NEW.id AND bm.status='accepted' UNION SELECT am.user_id FROM public.artist_members am WHERE am.artist_id=NEW.artist_id AND am.status='accepted') t WHERE uid IS NOT NULL AND uid IS DISTINCT FROM actor LOOP
    PERFORM public.notify_user(recipient,'booking_status','Status van boeking gewijzigd',body,'/bookings/'||NEW.id);
  END LOOP;
  RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION public.auto_complete_definitive_bookings() RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE n integer;
BEGIN
  PERFORM set_config('app.system_job','on',true);
  UPDATE public.bookings b SET artist_status=(SELECT s->>'label' FROM public.artists a CROSS JOIN LATERAL jsonb_array_elements(a.booking_statuses) s WHERE a.id=b.artist_id AND lower(trim(s->>'label'))='afgerond' LIMIT 1)
  WHERE b.event_date < (now() AT TIME ZONE 'Europe/Amsterdam')::date AND lower(trim(b.artist_status))='definitief'
  AND EXISTS (SELECT 1 FROM public.artists a CROSS JOIN LATERAL jsonb_array_elements(a.booking_statuses) s WHERE a.id=b.artist_id AND lower(trim(s->>'label'))='afgerond');
  GET DIAGNOSTICS n=ROW_COUNT;
  PERFORM set_config('app.system_job','off',true);
  RETURN n;
END $$;
REVOKE ALL ON FUNCTION public.auto_complete_definitive_bookings() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.auto_complete_definitive_bookings() TO service_role;
CREATE OR REPLACE FUNCTION public.run_artist_booking_completion() RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$ BEGIN IF (now() AT TIME ZONE 'Europe/Amsterdam')::time < time '00:15' THEN PERFORM public.auto_complete_definitive_bookings(); END IF; END $$;
REVOKE ALL ON FUNCTION public.run_artist_booking_completion() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.run_artist_booking_completion() TO service_role;
SELECT cron.alter_job(jobid,schedule:='5 * * * *',command:='select public.run_artist_booking_completion();') FROM cron.job WHERE jobname='auto-complete-definitive-bookings';