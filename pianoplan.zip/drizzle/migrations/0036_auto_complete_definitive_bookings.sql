CREATE OR REPLACE FUNCTION public.enforce_booking_status_permission()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  changed text[];
BEGIN
  IF auth.uid() IS NULL AND current_setting('app.system_job', true) = 'on' THEN RETURN NEW; END IF;
  SELECT array_agg(n.key) INTO changed
  FROM jsonb_each(to_jsonb(NEW)) n
  JOIN jsonb_each(to_jsonb(OLD)) o ON o.key = n.key
  WHERE n.value IS DISTINCT FROM o.value;
  IF changed IS NULL THEN RETURN NEW; END IF;
  IF changed <@ ARRAY['status','custom_status','updated_at'] THEN
    IF NEW.status = OLD.status AND NEW.custom_status IS NOT DISTINCT FROM OLD.custom_status THEN
      RETURN NEW;
    END IF;
    IF public.booking_permission(NEW.id, 'bookings.status') THEN RETURN NEW; END IF;
    RAISE EXCEPTION 'Je hebt geen recht om de status van deze boeking te wijzigen.';
  END IF;
  IF public.can_edit_booking(NEW.id) THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'Je hebt geen recht om deze boeking aan te passen.';
END;
$function$;

CREATE OR REPLACE FUNCTION public.auto_complete_definitive_bookings()
 RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE n integer;
BEGIN
  PERFORM set_config('app.system_job', 'on', true);
  UPDATE public.bookings
     SET status = 'afgerond',
         custom_status = CASE WHEN custom_status IS NULL OR lower(custom_status) = 'definitief' THEN NULL ELSE custom_status END
   WHERE status = 'definitief'
     AND (custom_status IS NULL OR lower(custom_status) = 'definitief')
     AND event_date < (now() AT TIME ZONE 'Europe/Amsterdam')::date;
  GET DIAGNOSTICS n = ROW_COUNT;
  PERFORM set_config('app.system_job', 'off', true);
  RETURN n;
END;
$$;
REVOKE ALL ON FUNCTION public.auto_complete_definitive_bookings() FROM PUBLIC, anon, authenticated;