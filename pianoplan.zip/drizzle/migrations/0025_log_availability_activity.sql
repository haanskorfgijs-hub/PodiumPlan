CREATE OR REPLACE FUNCTION public.log_booking_availability_activity()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE
  actor uuid := COALESCE(auth.uid(), NEW.user_id);
  target_name text;
  lbl text;
  old_lbl text;
  summ text;
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.availability IS NOT DISTINCT FROM OLD.availability THEN
    RETURN NEW;
  END IF;
  SELECT COALESCE(NULLIF(p.name,''), p.email) INTO target_name FROM public.profiles p WHERE p.id = NEW.user_id;
  target_name := COALESCE(target_name, 'onbekende gebruiker');
  lbl := CASE NEW.availability WHEN 'available' THEN 'Beschikbaar' WHEN 'tentative' THEN 'Misschien' WHEN 'unavailable' THEN 'Niet beschikbaar' ELSE NEW.availability END;
  old_lbl := CASE WHEN TG_OP = 'UPDATE' THEN CASE OLD.availability WHEN 'available' THEN 'Beschikbaar' WHEN 'tentative' THEN 'Misschien' WHEN 'unavailable' THEN 'Niet beschikbaar' ELSE OLD.availability END END;
  IF actor = NEW.user_id THEN
    summ := 'zette de eigen beschikbaarheid op ' || lbl;
  ELSE
    summ := 'zette de beschikbaarheid van ' || target_name || ' op ' || lbl;
  END IF;
  INSERT INTO public.activity_log (user_id, entity_type, entity_id, action, summary, changes)
  VALUES (actor, 'booking', NEW.booking_id, 'availability_changed', summ,
    jsonb_build_array(jsonb_build_object('field', 'Beschikbaarheid ' || target_name, 'from', old_lbl, 'to', lbl)));
  RETURN NEW;
END;
$$;
CREATE TRIGGER log_booking_availability_activity
AFTER INSERT OR UPDATE ON public.booking_availability
FOR EACH ROW EXECUTE FUNCTION public.log_booking_availability_activity();