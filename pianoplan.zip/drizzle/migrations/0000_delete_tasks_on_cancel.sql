CREATE OR REPLACE FUNCTION public.delete_tasks_on_booking_cancel()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF (NEW.status = 'geannuleerd' AND OLD.status IS DISTINCT FROM 'geannuleerd')
     OR (lower(coalesce(NEW.custom_status,'')) LIKE '%geannuleerd%' AND lower(coalesce(OLD.custom_status,'')) NOT LIKE '%geannuleerd%')
     OR (NEW.financial_status = 'geannuleerd' AND OLD.financial_status IS DISTINCT FROM 'geannuleerd') THEN
    DELETE FROM public.tasks WHERE booking_id = NEW.id;
  END IF;
  RETURN NEW;
END $$;
REVOKE EXECUTE ON FUNCTION public.delete_tasks_on_booking_cancel() FROM PUBLIC, anon, authenticated;
DROP TRIGGER IF EXISTS trg_delete_tasks_on_cancel ON public.bookings;
CREATE TRIGGER trg_delete_tasks_on_cancel AFTER UPDATE ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.delete_tasks_on_booking_cancel();