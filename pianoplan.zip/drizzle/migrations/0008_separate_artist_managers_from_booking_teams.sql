COMMENT ON COLUMN public.artist_members.role IS 'DEPRECATED: artist management permissions follow user_roles; retained for compatibility only.';
CREATE OR REPLACE FUNCTION public.artist_role(_artist_id uuid) RETURNS public.member_role LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT CASE WHEN ur.role IN ('gebruiker','boeker','lezer') THEN ur.role::text::public.member_role ELSE 'gebruiker'::public.member_role END
 FROM public.artist_members am JOIN public.user_roles ur ON ur.user_id=am.user_id
 WHERE am.artist_id=_artist_id AND am.user_id=auth.uid() AND am.status='accepted' LIMIT 1;
$$;
CREATE OR REPLACE FUNCTION public.artist_permission(_artist_id uuid, _key text) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$ SELECT public.has_permission(_key); $$;
CREATE OR REPLACE FUNCTION public.booking_role(_booking_id uuid) RETURNS public.member_role LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT bm.role FROM public.booking_members bm WHERE bm.booking_id=_booking_id AND bm.user_id=auth.uid() AND bm.status='accepted';
$$;
CREATE OR REPLACE FUNCTION public.can_view_booking(_booking_id uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT public.owns_booking(_booking_id) OR public.has_role(auth.uid(),'admin') OR public.booking_role(_booking_id) IS NOT NULL
 OR EXISTS (SELECT 1 FROM public.bookings b WHERE b.id=_booking_id AND public.can_view_artist(b.artist_id));
$$;
CREATE OR REPLACE FUNCTION public.booking_team(_booking_id uuid)
RETURNS TABLE(id uuid, name text, email text, phone text, job_title text, avatar_url text, invite_status text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 WITH members AS (
 SELECT b.created_by AS user_id, 'accepted'::text AS st FROM public.bookings b WHERE b.id=_booking_id AND b.created_by IS NOT NULL
 UNION ALL SELECT bm.user_id, bm.status::text FROM public.booking_members bm WHERE bm.booking_id=_booking_id AND bm.status IN ('accepted','pending')
 ), ranked AS (SELECT user_id, MIN(CASE WHEN st='accepted' THEN 0 ELSE 1 END) AS rank FROM members GROUP BY user_id)
 SELECT p.id,p.name,p.email,p.phone,p.job_title,p.avatar_url,CASE WHEN r.rank=0 THEN 'accepted' ELSE 'pending' END
 FROM public.profiles p JOIN ranked r ON r.user_id=p.id WHERE public.can_view_booking(_booking_id) ORDER BY p.name;
$$;
ALTER POLICY "artist members manage insert" ON public.artist_members WITH CHECK (public.has_role(auth.uid(),'admin') OR (public.can_view_artist(artist_id) AND public.artist_permission(artist_id,'members.manage.artist')));
ALTER POLICY "artist members manage update" ON public.artist_members USING (public.has_role(auth.uid(),'admin') OR (public.can_view_artist(artist_id) AND public.artist_permission(artist_id,'members.manage.artist'))) WITH CHECK (public.has_role(auth.uid(),'admin') OR (public.can_view_artist(artist_id) AND public.artist_permission(artist_id,'members.manage.artist')));
ALTER POLICY "artist members manage delete" ON public.artist_members USING (user_id=auth.uid() OR public.has_role(auth.uid(),'admin') OR (public.can_view_artist(artist_id) AND public.artist_permission(artist_id,'members.manage.artist')));