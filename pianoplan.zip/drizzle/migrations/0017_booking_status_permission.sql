CREATE OR REPLACE FUNCTION public.enforce_booking_status_permission()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  changed text[];
BEGIN
  SELECT array_agg(n.key) INTO changed
  FROM jsonb_each(to_jsonb(NEW)) n
  JOIN jsonb_each(to_jsonb(OLD)) o ON o.key = n.key
  WHERE n.value IS DISTINCT FROM o.value;
  IF changed IS NULL THEN RETURN NEW; END IF;
  IF changed <@ ARRAY['status','custom_status','updated_at'] THEN
    IF NEW.status = OLD.status AND NEW.custom_status IS NOT DISTINCT FROM OLD.custom_status THEN
      RETURN NEW;
    END IF;
    IF public.booking_permission(NEW.id, 'bookings.status') THEN RETURN NEW; END IF;
    RAISE EXCEPTION 'Je hebt geen recht om de status van deze boeking te wijzigen.';
  END IF;
  IF public.can_edit_booking(NEW.id) THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'Je hebt geen recht om deze boeking aan te passen.';
END;
$$;

DROP TRIGGER IF EXISTS trg_booking_status_permission ON public.bookings;
CREATE TRIGGER trg_booking_status_permission BEFORE UPDATE ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.enforce_booking_status_permission();

ALTER POLICY "bookings editable" ON public.bookings
USING (public.can_edit_booking(id) OR public.booking_permission(id, 'bookings.status'))
WITH CHECK (public.can_edit_booking(id) OR public.booking_permission(id, 'bookings.status'));