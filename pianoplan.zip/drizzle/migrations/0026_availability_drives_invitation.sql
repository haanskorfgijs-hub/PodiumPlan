CREATE OR REPLACE FUNCTION public.sync_invitation_on_availability()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.availability IS NOT DISTINCT FROM OLD.availability THEN
    RETURN NEW;
  END IF;
  IF NEW.availability = 'available' THEN
    UPDATE public.booking_members SET status = 'accepted'
    WHERE booking_id = NEW.booking_id AND user_id = NEW.user_id AND status = 'pending';
  ELSIF NEW.availability = 'unavailable' THEN
    UPDATE public.booking_members SET status = 'declined'
    WHERE booking_id = NEW.booking_id AND user_id = NEW.user_id AND status = 'pending';
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER sync_invitation_on_availability
AFTER INSERT OR UPDATE ON public.booking_availability
FOR EACH ROW EXECUTE FUNCTION public.sync_invitation_on_availability();

UPDATE public.booking_members m SET status = 'accepted'
FROM public.booking_availability a
WHERE a.booking_id = m.booking_id AND a.user_id = m.user_id
  AND m.status = 'pending' AND a.availability = 'available';