CREATE OR REPLACE FUNCTION public.add_artist_creator_as_manager()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.created_by IS NOT NULL THEN
    INSERT INTO public.artist_members (artist_id, user_id, role, created_by, status)
    SELECT NEW.id, NEW.created_by,
      COALESCE((SELECT CASE WHEN ur.role IN ('gebruiker','boeker','lezer') THEN ur.role::text::public.member_role END
                FROM public.user_roles ur WHERE ur.user_id = NEW.created_by LIMIT 1), 'gebruiker'),
      NEW.created_by, 'accepted'
    WHERE NOT EXISTS (SELECT 1 FROM public.artist_members WHERE artist_id = NEW.id AND user_id = NEW.created_by);
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS trg_artist_creator_manager ON public.artists;
CREATE TRIGGER trg_artist_creator_manager AFTER INSERT ON public.artists
FOR EACH ROW EXECUTE FUNCTION public.add_artist_creator_as_manager();

INSERT INTO public.artist_members (artist_id, user_id, role, created_by, status)
SELECT a.id, a.created_by,
  COALESCE((SELECT CASE WHEN ur.role IN ('gebruiker','boeker','lezer') THEN ur.role::text::public.member_role END
            FROM public.user_roles ur WHERE ur.user_id = a.created_by LIMIT 1), 'gebruiker'),
  a.created_by, 'accepted'
FROM public.artists a
WHERE a.created_by IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM public.artist_members m WHERE m.artist_id = a.id AND m.user_id = a.created_by);

UPDATE public.artist_members m SET status = 'accepted'
FROM public.artists a WHERE a.id = m.artist_id AND m.user_id = a.created_by AND m.status <> 'accepted';