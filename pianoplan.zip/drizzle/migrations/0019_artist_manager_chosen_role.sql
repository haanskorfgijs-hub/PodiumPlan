COMMENT ON COLUMN public.artist_members.role IS 'Role the manager holds within this artist; drives artist-managed booking permissions.';
UPDATE public.artist_members am SET role = CASE WHEN ur.role IN ('gebruiker','boeker','lezer') THEN ur.role::text::public.member_role ELSE 'gebruiker'::public.member_role END
FROM public.user_roles ur WHERE ur.user_id = am.user_id;
CREATE OR REPLACE FUNCTION public.artist_role(_artist_id uuid) RETURNS public.member_role LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT am.role FROM public.artist_members am WHERE am.artist_id=_artist_id AND am.user_id=auth.uid() AND am.status='accepted' LIMIT 1;
$$;
CREATE OR REPLACE FUNCTION public.artist_manager_booking_role(_booking_id uuid, _user_id uuid)
RETURNS public.member_role LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT am.role FROM public.bookings b JOIN public.artist_members am ON am.artist_id=b.artist_id
 WHERE b.id=_booking_id AND am.user_id=_user_id AND am.status='accepted' LIMIT 1;
$$;
CREATE OR REPLACE FUNCTION public.booking_permission(_booking_id uuid, _key text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT CASE
 WHEN public.has_role(auth.uid(),'admin') THEN public.has_permission(_key)
 WHEN public.artist_manager_booking_role(_booking_id, auth.uid()) IS NOT NULL
 THEN public.role_allows(public.artist_manager_booking_role(_booking_id, auth.uid())::text::public.app_role, _key)
 WHEN public.booking_role(_booking_id) IS NOT NULL
 THEN public.role_allows(public.booking_role(_booking_id)::text::public.app_role, _key)
 ELSE public.has_permission(_key) END;
$$;
CREATE OR REPLACE FUNCTION public.artist_permission(_artist_id uuid, _key text) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT CASE WHEN public.has_role(auth.uid(),'admin') OR public.artist_role(_artist_id) IS NULL THEN public.has_permission(_key)
 ELSE public.role_allows(public.artist_role(_artist_id)::text::public.app_role, _key) END;
$$;