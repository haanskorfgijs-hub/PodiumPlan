CREATE OR REPLACE FUNCTION public.can_edit_booking(_booking_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT public.has_role(auth.uid(), 'admin'::public.app_role)
    OR (public.can_view_booking(_booking_id)
        AND public.booking_permission(_booking_id, 'bookings.edit'));
$function$;