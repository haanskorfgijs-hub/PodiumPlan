CREATE OR REPLACE FUNCTION public.sync_availability_on_invite_response()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    IF NEW.status = 'accepted' THEN
      INSERT INTO public.booking_availability (booking_id, user_id, availability)
      VALUES (NEW.booking_id, NEW.user_id, 'available')
      ON CONFLICT (booking_id, user_id)
      DO UPDATE SET availability = 'available', updated_at = now();
    ELSIF NEW.status = 'declined' THEN
      INSERT INTO public.booking_availability (booking_id, user_id, availability)
      VALUES (NEW.booking_id, NEW.user_id, 'unavailable')
      ON CONFLICT (booking_id, user_id)
      DO UPDATE SET availability = 'unavailable', updated_at = now();
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS booking_members_sync_availability ON public.booking_members;
CREATE TRIGGER booking_members_sync_availability
AFTER UPDATE ON public.booking_members
FOR EACH ROW
EXECUTE FUNCTION sync_availability_on_invite_response();