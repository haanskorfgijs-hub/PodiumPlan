ALTER POLICY "artists editable" ON public.artists
  USING (public.can_edit_artist(id) AND public.has_permission('artists.edit'))
  WITH CHECK (public.can_edit_artist(id) AND public.has_permission('artists.edit'));

COMMENT ON POLICY "artists editable" ON public.artists IS 'Bewerken van artiesten vereist can_edit_artist en het accountrecht artists.edit';