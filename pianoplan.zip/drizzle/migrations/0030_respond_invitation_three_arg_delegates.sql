CREATE OR REPLACE FUNCTION public.respond_invitation(_id uuid, _scope text, _accept boolean)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  PERFORM public.respond_invitation(_id, _scope, _accept, NULL);
END;
$function$;
