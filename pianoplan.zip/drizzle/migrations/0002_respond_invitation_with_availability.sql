CREATE OR REPLACE FUNCTION public.respond_invitation(_id uuid, _scope text, _accept boolean, _availability text DEFAULT NULL)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE new_status public.invite_status := CASE WHEN _accept THEN 'accepted' ELSE 'declined' END;
BEGIN
  IF _scope = 'artist' THEN
    UPDATE public.artist_members SET status = new_status
    WHERE id = _id AND user_id = auth.uid() AND status = 'pending';
  ELSE
    UPDATE public.booking_members SET status = new_status
    WHERE id = _id AND user_id = auth.uid() AND status = 'pending';

    IF _accept AND _availability IN ('available', 'tentative', 'unavailable') THEN
      INSERT INTO public.booking_availability (booking_id, user_id, availability)
      SELECT bm.booking_id, bm.user_id, _availability
      FROM public.booking_members bm
      WHERE bm.id = _id AND bm.user_id = auth.uid()
      ON CONFLICT (booking_id, user_id)
      DO UPDATE SET availability = EXCLUDED.availability, updated_at = now();
    END IF;
  END IF;
END;
$function$;