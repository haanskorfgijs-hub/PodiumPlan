DROP POLICY IF EXISTS "bookings viewable" ON public.bookings;
CREATE POLICY "bookings viewable" ON public.bookings FOR SELECT TO authenticated
USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'::public.app_role) OR public.can_view_booking(id));