CREATE TABLE public.contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id uuid NOT NULL,
  recipient_id uuid NOT NULL,
  status public.invite_status NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  responded_at timestamptz,
  CONSTRAINT contacts_not_self CHECK (requester_id <> recipient_id)
);
CREATE UNIQUE INDEX contacts_pair_unique ON public.contacts (LEAST(requester_id, recipient_id), GREATEST(requester_id, recipient_id));
GRANT SELECT, DELETE ON public.contacts TO authenticated;
GRANT ALL ON public.contacts TO service_role;
ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "contacts own read" ON public.contacts FOR SELECT TO authenticated
  USING (auth.uid() IN (requester_id, recipient_id));
CREATE POLICY "contacts own delete" ON public.contacts FOR DELETE TO authenticated
  USING (auth.uid() IN (requester_id, recipient_id));

CREATE OR REPLACE FUNCTION public.send_contact_request(_email text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE me uuid := auth.uid(); target uuid; existing public.contacts; my_name text;
BEGIN
  IF me IS NULL THEN RAISE EXCEPTION 'Niet ingelogd'; END IF;
  SELECT id INTO target FROM public.profiles WHERE lower(email) = lower(trim(_email)) AND id <> me ORDER BY created_at LIMIT 1;
  IF target IS NULL THEN RAISE EXCEPTION 'Geen account gevonden met dit e-mailadres.'; END IF;
  SELECT * INTO existing FROM public.contacts
    WHERE LEAST(requester_id, recipient_id) = LEAST(me, target) AND GREATEST(requester_id, recipient_id) = GREATEST(me, target);
  IF existing.id IS NOT NULL THEN
    IF existing.status = 'accepted' THEN RAISE EXCEPTION 'Dit account is al een contact.'; END IF;
    IF existing.status = 'pending' THEN RAISE EXCEPTION 'Er staat al een contactverzoek open.'; END IF;
    DELETE FROM public.contacts WHERE id = existing.id;
  END IF;
  INSERT INTO public.contacts (requester_id, recipient_id) VALUES (me, target);
  SELECT COALESCE(NULLIF(name,''), email) INTO my_name FROM public.profiles WHERE id = me;
  PERFORM public.notify_user(target, 'contact_request', 'Nieuw contactverzoek', COALESCE(my_name,'Iemand') || ' wil je toevoegen als contact.', '/contacten');
END $$;

CREATE OR REPLACE FUNCTION public.respond_contact_request(_id uuid, _accept boolean)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE c public.contacts; my_name text;
BEGIN
  SELECT * INTO c FROM public.contacts WHERE id = _id AND recipient_id = auth.uid() AND status = 'pending';
  IF c.id IS NULL THEN RAISE EXCEPTION 'Contactverzoek niet gevonden.'; END IF;
  UPDATE public.contacts SET status = CASE WHEN _accept THEN 'accepted' ELSE 'declined' END::public.invite_status, responded_at = now() WHERE id = _id;
  SELECT COALESCE(NULLIF(name,''), email) INTO my_name FROM public.profiles WHERE id = auth.uid();
  PERFORM public.notify_user(c.requester_id, 'contact_response',
    CASE WHEN _accept THEN 'Contactverzoek geaccepteerd' ELSE 'Contactverzoek afgewezen' END,
    COALESCE(my_name,'De ontvanger') || CASE WHEN _accept THEN ' heeft je contactverzoek geaccepteerd.' ELSE ' heeft je contactverzoek afgewezen.' END,
    '/contacten');
END $$;

CREATE OR REPLACE FUNCTION public.my_contacts()
RETURNS TABLE(id uuid, other_id uuid, name text, email text, status public.invite_status, incoming boolean, created_at timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT c.id, p.id, p.name, p.email, c.status, c.recipient_id = auth.uid(), c.created_at
  FROM public.contacts c
  JOIN public.profiles p ON p.id = CASE WHEN c.requester_id = auth.uid() THEN c.recipient_id ELSE c.requester_id END
  WHERE auth.uid() IN (c.requester_id, c.recipient_id)
  ORDER BY c.created_at DESC
$$;

CREATE OR REPLACE FUNCTION public.invitable_users()
RETURNS TABLE(id uuid, name text, email text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT p.id, p.name, p.email
  FROM public.contacts c
  JOIN public.profiles p ON p.id = CASE WHEN c.requester_id = auth.uid() THEN c.recipient_id ELSE c.requester_id END
  WHERE c.status = 'accepted' AND auth.uid() IN (c.requester_id, c.recipient_id)
  ORDER BY COALESCE(NULLIF(p.name,''), p.email)
$$;

REVOKE ALL ON FUNCTION public.send_contact_request(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.respond_contact_request(uuid, boolean) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.my_contacts() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.send_contact_request(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.respond_contact_request(uuid, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.my_contacts() TO authenticated;
GRANT EXECUTE ON FUNCTION public.invitable_users() TO authenticated;