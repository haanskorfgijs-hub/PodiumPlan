CREATE OR REPLACE FUNCTION public.artist_manager_booking_role(_booking_id uuid, _user_id uuid)
RETURNS public.member_role LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT CASE WHEN ur.role IN ('gebruiker','boeker','lezer') THEN ur.role::text::public.member_role ELSE 'gebruiker'::public.member_role END
 FROM public.bookings b JOIN public.artist_members am ON am.artist_id=b.artist_id JOIN public.user_roles ur ON ur.user_id=am.user_id
 WHERE b.id=_booking_id AND am.user_id=_user_id AND am.status='accepted' LIMIT 1;
$$;
REVOKE ALL ON FUNCTION public.artist_manager_booking_role(uuid,uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.artist_manager_booking_role(uuid,uuid) TO service_role;
CREATE OR REPLACE FUNCTION public.booking_member_roles(_booking_id uuid)
RETURNS TABLE(user_id uuid, role public.member_role, role_locked boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 WITH candidates AS (
 SELECT bm.user_id,bm.role FROM public.booking_members bm WHERE bm.booking_id=_booking_id
 UNION ALL
 SELECT am.user_id,NULL::public.member_role FROM public.artist_members am JOIN public.bookings b ON b.artist_id=am.artist_id WHERE b.id=_booking_id AND am.status='accepted' AND NOT EXISTS(SELECT 1 FROM public.booking_members bm WHERE bm.booking_id=_booking_id AND bm.user_id=am.user_id)
 )
 SELECT c.user_id,COALESCE(public.artist_manager_booking_role(_booking_id,c.user_id),c.role),public.artist_manager_booking_role(_booking_id,c.user_id) IS NOT NULL
 FROM candidates c WHERE public.can_view_booking(_booking_id);
$$;
REVOKE ALL ON FUNCTION public.booking_member_roles(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.booking_member_roles(uuid) TO authenticated, service_role;
CREATE OR REPLACE FUNCTION public.booking_role(_booking_id uuid)
RETURNS public.member_role LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT COALESCE(public.artist_manager_booking_role(_booking_id,bm.user_id),bm.role) FROM public.booking_members bm
 WHERE bm.booking_id=_booking_id AND bm.user_id=auth.uid() AND bm.status='accepted';
$$;
CREATE OR REPLACE FUNCTION public.enforce_inherited_booking_member_role()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE inherited public.member_role;
BEGIN
 inherited := public.artist_manager_booking_role(NEW.booking_id,NEW.user_id);
 IF TG_OP='UPDATE' AND NEW.role IS DISTINCT FROM OLD.role AND (inherited IS NOT NULL OR public.artist_manager_booking_role(OLD.booking_id,OLD.user_id) IS NOT NULL) THEN
 RAISE EXCEPTION 'De teamrol van een artiestbeheerder volgt het accounttype en kan binnen de boeking niet worden aangepast.';
 END IF;
 IF TG_OP='INSERT' AND inherited IS NOT NULL THEN NEW.role := inherited; END IF;
 RETURN NEW;
END;
$$;
REVOKE ALL ON FUNCTION public.enforce_inherited_booking_member_role() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER inherited_booking_member_role BEFORE INSERT OR UPDATE ON public.booking_members FOR EACH ROW EXECUTE FUNCTION public.enforce_inherited_booking_member_role();