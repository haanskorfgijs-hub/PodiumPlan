CREATE OR REPLACE FUNCTION public.is_admin_user(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM user_roles WHERE user_id = _user_id AND role IN ('admin','host'))
$$;
GRANT EXECUTE ON FUNCTION public.is_admin_user(uuid) TO authenticated;

DROP POLICY IF EXISTS "contacts own delete" ON public.contacts;
CREATE POLICY "contacts own delete" ON public.contacts FOR DELETE TO authenticated
USING (
  (auth.uid() = requester_id OR auth.uid() = recipient_id)
  AND (
    public.is_admin_user(auth.uid())
    OR NOT public.is_admin_user(CASE WHEN auth.uid() = requester_id THEN recipient_id ELSE requester_id END)
  )
);