CREATE OR REPLACE FUNCTION public.uses_account_permissions(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id=_user_id AND role IN ('admin','host'));
$$;
REVOKE ALL ON FUNCTION public.uses_account_permissions(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.uses_account_permissions(uuid) TO authenticated, service_role;
COMMENT ON FUNCTION public.uses_account_permissions(uuid) IS 'Scope precedence for Admin and Gijs account types only; never grants any permission.';
CREATE OR REPLACE FUNCTION public.booking_permission(_booking_id uuid, _key text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT CASE
 WHEN public.uses_account_permissions(auth.uid()) OR public.has_role(auth.uid(),'admin') THEN public.has_permission(_key)
 WHEN public.artist_manager_booking_role(_booking_id, auth.uid()) IS NOT NULL THEN public.role_allows(public.artist_manager_booking_role(_booking_id, auth.uid())::text::public.app_role, _key)
 WHEN public.booking_role(_booking_id) IS NOT NULL THEN public.role_allows(public.booking_role(_booking_id)::text::public.app_role, _key)
 ELSE public.has_permission(_key) END;
$$;
CREATE OR REPLACE FUNCTION public.artist_permission(_artist_id uuid, _key text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT CASE WHEN public.uses_account_permissions(auth.uid()) OR public.has_role(auth.uid(),'admin') OR public.artist_role(_artist_id) IS NULL THEN public.has_permission(_key)
 ELSE public.role_allows(public.artist_role(_artist_id)::text::public.app_role, _key) END;
$$;
CREATE OR REPLACE FUNCTION public.can_edit_artist(_artist_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT CASE WHEN public.uses_account_permissions(auth.uid()) THEN public.can_view_artist(_artist_id) AND public.has_permission('artists.manage')
 ELSE public.owns_artist(_artist_id) OR public.has_role(auth.uid(),'admin') OR public.artist_role(_artist_id) IN ('gebruiker','boeker') END;
$$;
CREATE OR REPLACE FUNCTION public.enforce_account_artist_member_role()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
 IF public.uses_account_permissions(NEW.user_id) THEN
  IF TG_OP='UPDATE' THEN
   IF NEW.role IS DISTINCT FROM OLD.role THEN RAISE EXCEPTION 'Dit account gebruikt zijn accountrechten; een andere artiestrol kiezen is niet toegestaan.'; END IF;
  END IF;
  NEW.role := 'lezer';
 END IF;
 RETURN NEW;
END;
$$;
REVOKE ALL ON FUNCTION public.enforce_account_artist_member_role() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER account_artist_member_role BEFORE INSERT OR UPDATE ON public.artist_members FOR EACH ROW EXECUTE FUNCTION public.enforce_account_artist_member_role();
COMMENT ON COLUMN public.artist_members.role IS 'Chosen artist role for ordinary accounts; ignored for Admin and Gijs, whose account permissions are authoritative.';
CREATE OR REPLACE FUNCTION public.member_account_types(_scope text, _id uuid)
RETURNS TABLE(user_id uuid, account_role public.app_role)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT ur.user_id, ur.role FROM public.user_roles ur
 WHERE auth.uid() IS NOT NULL
 AND (CASE WHEN _scope='artist' THEN public.can_view_artist(_id) WHEN _scope='booking' THEN public.can_view_booking(_id) ELSE false END)
 AND (ur.user_id=auth.uid()
 OR EXISTS (SELECT 1 FROM public.invitable_users() i WHERE i.id=ur.user_id)
 OR (_scope='artist' AND EXISTS (SELECT 1 FROM public.artist_members m WHERE m.artist_id=_id AND m.user_id=ur.user_id))
 OR (_scope='booking' AND EXISTS (SELECT 1 FROM public.booking_members m WHERE m.booking_id=_id AND m.user_id=ur.user_id)));
$$;
REVOKE ALL ON FUNCTION public.member_account_types(text,uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.member_account_types(text,uuid) TO authenticated, service_role;
ALTER POLICY "artist members manage insert" ON public.artist_members WITH CHECK ((public.has_role(auth.uid(),'admin') AND NOT public.uses_account_permissions(auth.uid())) OR (public.can_view_artist(artist_id) AND public.artist_permission(artist_id,'members.manage.artist')));
ALTER POLICY "artist members manage update" ON public.artist_members USING ((public.has_role(auth.uid(),'admin') AND NOT public.uses_account_permissions(auth.uid())) OR (public.can_view_artist(artist_id) AND public.artist_permission(artist_id,'members.manage.artist'))) WITH CHECK ((public.has_role(auth.uid(),'admin') AND NOT public.uses_account_permissions(auth.uid())) OR (public.can_view_artist(artist_id) AND public.artist_permission(artist_id,'members.manage.artist')));
ALTER POLICY "artist members manage delete" ON public.artist_members USING (user_id=auth.uid() OR (public.has_role(auth.uid(),'admin') AND NOT public.uses_account_permissions(auth.uid())) OR (public.can_view_artist(artist_id) AND public.artist_permission(artist_id,'members.manage.artist')));
ALTER POLICY "standards insertable" ON public.performance_standards WITH CHECK ((public.has_role(auth.uid(),'admin') AND NOT public.uses_account_permissions(auth.uid())) OR (public.can_view_artist(artist_id) AND public.artist_permission(artist_id,'standards.create')));
ALTER POLICY "standards editable" ON public.performance_standards USING ((public.has_role(auth.uid(),'admin') AND NOT public.uses_account_permissions(auth.uid())) OR (public.can_view_artist(artist_id) AND public.artist_permission(artist_id,'standards.create'))) WITH CHECK ((public.has_role(auth.uid(),'admin') AND NOT public.uses_account_permissions(auth.uid())) OR (public.can_view_artist(artist_id) AND public.artist_permission(artist_id,'standards.create')));
ALTER POLICY "standards deletable" ON public.performance_standards USING ((public.has_role(auth.uid(),'admin') AND NOT public.uses_account_permissions(auth.uid())) OR (public.can_view_artist(artist_id) AND public.artist_permission(artist_id,'standards.create')));