CREATE OR REPLACE FUNCTION public.purge_user_data(_user_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  DELETE FROM public.artist_members WHERE user_id = _user_id;
  DELETE FROM public.booking_members WHERE user_id = _user_id;
  DELETE FROM public.booking_availability WHERE user_id = _user_id;
  DELETE FROM public.calendar_widgets WHERE user_id = _user_id;
  DELETE FROM public.notifications WHERE user_id = _user_id;
  DELETE FROM public.activity_log WHERE user_id = _user_id;
  UPDATE public.tasks SET assigned_to = NULL WHERE assigned_to = _user_id;
  UPDATE public.tasks SET created_by = NULL WHERE created_by = _user_id;
  UPDATE public.artist_members SET created_by = NULL WHERE created_by = _user_id;
  UPDATE public.booking_members SET created_by = NULL WHERE created_by = _user_id;
  UPDATE public.artists SET created_by = NULL WHERE created_by = _user_id;
  UPDATE public.bookings SET created_by = NULL WHERE created_by = _user_id;
  DELETE FROM public.user_roles WHERE user_id = _user_id;
  DELETE FROM public.profiles WHERE id = _user_id;
  DELETE FROM storage.objects WHERE owner_id = _user_id::text OR owner = _user_id;
END $$;
REVOKE ALL ON FUNCTION public.purge_user_data(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.purge_user_data(uuid) TO service_role;