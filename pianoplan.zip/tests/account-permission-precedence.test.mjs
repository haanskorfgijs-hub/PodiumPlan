import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';

const migration = await readFile(new URL('../drizzle/migrations/0040_account_rights_override_artist_roles.sql', import.meta.url), 'utf8');
const user = '00000000-0000-0000-0000-000000000001';
const artist = '00000000-0000-0000-0000-000000000002';
const booking = '00000000-0000-0000-0000-000000000003';
async function fixture(role) {
  const db = new PGlite();
  await db.exec(`
    CREATE SCHEMA auth;
    CREATE ROLE anon; CREATE ROLE authenticated; CREATE ROLE service_role;
    CREATE TYPE app_role AS ENUM ('admin','host','gebruiker','boeker','lezer');
    CREATE TYPE member_role AS ENUM ('gebruiker','boeker','lezer');
    CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql AS $$ SELECT '${user}'::uuid $$;
    CREATE TABLE user_roles(user_id uuid,role app_role);
    CREATE TABLE role_permissions(role app_role,permission text,allowed boolean);
    CREATE TABLE artist_members(artist_id uuid,user_id uuid,role member_role,status text);
    CREATE TABLE booking_members(booking_id uuid,user_id uuid,role member_role,status text);
    CREATE TABLE performance_standards(artist_id uuid);
    CREATE FUNCTION has_permission(text) RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$ SELECT coalesce((SELECT allowed FROM role_permissions JOIN user_roles USING(role) WHERE user_id=auth.uid() AND permission=$1),false) $$;
    CREATE FUNCTION has_role(uuid,app_role) RETURNS boolean LANGUAGE sql AS $$ SELECT false $$;
    CREATE FUNCTION role_allows(app_role,text) RETURNS boolean LANGUAGE sql AS $$ SELECT coalesce((SELECT allowed FROM role_permissions WHERE role=$1 AND permission=$2),false) $$;
    CREATE FUNCTION artist_role(uuid) RETURNS member_role LANGUAGE sql AS $$ SELECT role FROM artist_members WHERE user_id=auth.uid() AND artist_id=$1 AND status='accepted' $$;
    CREATE FUNCTION artist_manager_booking_role(uuid,uuid) RETURNS member_role LANGUAGE sql AS $$ SELECT role FROM artist_members WHERE user_id=$2 AND status='accepted' LIMIT 1 $$;
    CREATE FUNCTION booking_role(uuid) RETURNS member_role LANGUAGE sql AS $$ SELECT role FROM booking_members WHERE user_id=auth.uid() AND booking_id=$1 AND status='accepted' $$;
    CREATE FUNCTION can_view_artist(uuid) RETURNS boolean LANGUAGE sql AS $$ SELECT true $$;
    CREATE FUNCTION can_view_booking(uuid) RETURNS boolean LANGUAGE sql AS $$ SELECT true $$;
    CREATE FUNCTION owns_artist(uuid) RETURNS boolean LANGUAGE sql AS $$ SELECT false $$;
    CREATE FUNCTION invitable_users() RETURNS TABLE(id uuid) LANGUAGE sql AS $$ SELECT '${user}'::uuid $$;
    CREATE POLICY "artist members manage insert" ON artist_members FOR INSERT WITH CHECK(true);
    CREATE POLICY "artist members manage update" ON artist_members FOR UPDATE USING(true);
    CREATE POLICY "artist members manage delete" ON artist_members FOR DELETE USING(true);
    CREATE POLICY "standards insertable" ON performance_standards FOR INSERT WITH CHECK(true);
    CREATE POLICY "standards editable" ON performance_standards FOR UPDATE USING(true);
    CREATE POLICY "standards deletable" ON performance_standards FOR DELETE USING(true);
    INSERT INTO user_roles VALUES ('${user}','${role}');
    INSERT INTO artist_members VALUES ('${artist}','${user}','gebruiker','accepted');
    INSERT INTO booking_members VALUES ('${booking}','${user}','lezer','accepted');
    INSERT INTO role_permissions VALUES ('${role}','financial.view',true),('${role}','pricing.view',false),('${role}','artists.manage',true),('${role}','standards.create',false),('gebruiker','financial.view',false),('gebruiker','pricing.view',true);
  `);
  await db.exec(migration);
  return db;
}
for (const role of ['admin','host']) {
  test(`${role} retains enabled financial account rights over artist and team roles`, async () => {
    const db = await fixture(role);
    try {
      const result = await db.query(`SELECT artist_permission('${artist}','financial.view') artist,booking_permission('${booking}','financial.view') booking`);
      assert.deepEqual(result.rows,[{artist:true,booking:true}]);
      await db.exec('DELETE FROM artist_members');
      assert.equal((await db.query(`SELECT booking_permission('${booking}','financial.view') allowed`)).rows[0].allowed,true);
    } finally { await db.close(); }
  });
  test(`${role} cannot gain disabled account rights from a manager artist role`, async () => {
    const db = await fixture(role);
    try {
      assert.deepEqual((await db.query(`SELECT artist_permission('${artist}','pricing.view') artist,booking_permission('${booking}','pricing.view') booking`)).rows,[{artist:false,booking:false}]);
      await db.exec(`UPDATE role_permissions SET allowed=false WHERE role='${role}' AND permission='artists.manage'`);
      assert.equal((await db.query(`SELECT can_edit_artist('${artist}') allowed`)).rows[0].allowed,false);
    } finally { await db.close(); }
  });
  test(`${role} artist role cannot be changed to reader, booker or manager`, async () => {
    const db = await fixture(role);
    try {
      await db.exec('DELETE FROM artist_members');
      await db.exec(`INSERT INTO artist_members VALUES ('${artist}','${user}','gebruiker','pending')`);
      assert.equal((await db.query('SELECT role FROM artist_members')).rows[0].role,'lezer');
      for (const selected of ['gebruiker','boeker']) await assert.rejects(db.exec(`UPDATE artist_members SET role='${selected}'`),/andere artiestrol/);
      await db.exec(`UPDATE artist_members SET status='accepted'`);
      assert.equal((await db.query(`SELECT artist_permission('${artist}','financial.view') allowed`)).rows[0].allowed,true);
    } finally { await db.close(); }
  });
  test(`${role} cannot create standards when the account checkbox is disabled`, async () => {
    const db = await fixture(role);
    try {
      await db.exec('ALTER TABLE performance_standards ENABLE ROW LEVEL SECURITY; GRANT INSERT ON performance_standards TO authenticated; SET ROLE authenticated');
      await assert.rejects(db.exec(`INSERT INTO performance_standards VALUES ('${artist}')`),/row-level security/);
    } finally { await db.close(); }
  });
}