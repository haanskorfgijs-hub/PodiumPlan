import { expect, test } from "bun:test";
import { roleHasPermission, type RolePermissionRow } from "../src/lib/role-permission-access";

test("every account type follows enabled and disabled stored rights", () => {
  const roles = ["admin", "host", "gebruiker", "boeker", "lezer"] as const;
  for (const role of roles) {
    const rows: RolePermissionRow[] = [
      { role, permission: "bookings.status", allowed: true },
      { role, permission: "financial.view", allowed: false },
    ];
    expect(roleHasPermission(rows, role, "bookings.status")).toBe(true);
    expect(roleHasPermission(rows, role, "financial.view")).toBe(false);
  }
});

test("missing or unloaded rights cannot appear enabled for any account type", () => {
  for (const role of ["admin", "host", "gebruiker", "boeker", "lezer"] as const) {
    expect(roleHasPermission([], role, "bookings.status")).toBe(false);
    expect(roleHasPermission(undefined, role, "users.manage")).toBe(false);
  }
});

test("another account type's rights never grant access", () => {
  expect(roleHasPermission([{ role: "admin", permission: "users.manage", allowed: true }], "boeker", "users.manage")).toBe(false);
  expect(roleHasPermission([], null, "users.manage")).toBe(false);
});