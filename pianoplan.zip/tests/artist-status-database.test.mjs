import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';

const migration = await readFile(new URL('../drizzle/migrations/0039_artist_status_canonical.sql', import.meta.url), 'utf8');
async function setup() {
  const db = new PGlite();
  await db.exec(`
    CREATE SCHEMA auth;
    CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql AS $$ SELECT NULL::uuid $$;
    CREATE TABLE artists(id uuid PRIMARY KEY, booking_statuses jsonb);
    CREATE TABLE bookings(id uuid PRIMARY KEY,artist_id uuid,event_date date,status text DEFAULT 'optie',custom_status text,artist_status text,financial_status text);
    CREATE TABLE tasks(id int,booking_id uuid);
  `);
  for (const name of ['default_artist_statuses', 'sync_artist_booking_status', 'delete_tasks_on_booking_cancel', 'auto_complete_definitive_bookings']) {
    const statement = migration.match(new RegExp(`CREATE OR REPLACE FUNCTION public\\.${name}\\([\\s\\S]*?\\$\\$;`))?.[0];
    assert.ok(statement, name);
    await db.exec(statement);
  }
  await db.exec(`
    CREATE TRIGGER sync BEFORE INSERT OR UPDATE ON bookings FOR EACH ROW EXECUTE FUNCTION sync_artist_booking_status();
    CREATE TRIGGER cancel AFTER UPDATE ON bookings FOR EACH ROW EXECUTE FUNCTION delete_tasks_on_booking_cancel();
    INSERT INTO artists VALUES('00000000-0000-0000-0000-000000000001', default_artist_statuses());
  `);
  return db;
}
test('Definitief completes the day after the booking, only using the artist’s own Afgerond status', async () => {
  const db = await setup();
  try {
    await db.exec(`INSERT INTO bookings(id,artist_id,event_date,artist_status) SELECT ('00000000-0000-0000-0000-00000000000'||n)::uuid,'00000000-0000-0000-0000-000000000001', (now() AT TIME ZONE 'Europe/Amsterdam')::date+offset_days, 'Definitief' FROM (VALUES(2,-1),(3,0),(4,1)) v(n,offset_days)`);
    assert.equal((await db.query('SELECT auto_complete_definitive_bookings() AS n')).rows[0].n, 1);
    assert.deepEqual((await db.query('SELECT artist_status FROM bookings ORDER BY id')).rows.map(r=>r.artist_status), ['Afgerond','Definitief','Definitief']);
    assert.equal((await db.query('SELECT auto_complete_definitive_bookings() AS n')).rows[0].n, 0);
    await db.exec(`UPDATE artists SET booking_statuses='[{"label":"Definitief","stage":"create"}]'; UPDATE bookings SET event_date=event_date-10 WHERE artist_status='Definitief'`);
    assert.equal((await db.query('SELECT auto_complete_definitive_bookings() AS n')).rows[0].n, 0);
  } finally { await db.close(); }
});
test('artist status validates writes and cancellation removes tasks, irrespective of legacy status', async () => {
  const db = await setup();
  try {
    await db.exec(`INSERT INTO bookings(id,artist_id,event_date,artist_status) VALUES('00000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000001',current_date,'Optie'); INSERT INTO tasks VALUES(1,'00000000-0000-0000-0000-000000000002')`);
    await assert.rejects(db.exec(`UPDATE bookings SET artist_status='Unconfigured'`), /Kies een status/);
    await db.exec(`UPDATE bookings SET artist_status='Geannuleerd'`);
    assert.equal((await db.query('SELECT count(*) AS n FROM tasks')).rows[0].n, 0);
    assert.deepEqual((await db.query('SELECT status,artist_status,custom_status FROM bookings')).rows[0], {status:'optie',artist_status:'Geannuleerd',custom_status:'Geannuleerd'});
    await db.exec(`UPDATE bookings SET custom_status='Definitief'`);
    assert.equal((await db.query('SELECT artist_status FROM bookings')).rows[0].artist_status,'Definitief');
    await db.exec(`UPDATE bookings SET event_date=current_date+3`);
    await assert.rejects(db.exec(`UPDATE bookings SET artist_status='Afgerond'`), /pas beschikbaar/);
  } finally { await db.close(); }
});