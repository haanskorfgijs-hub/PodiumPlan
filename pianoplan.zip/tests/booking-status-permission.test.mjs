import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';

test('status changes need bookings.status when booking editing is unavailable', async () => {
  const db = new PGlite();
  try {
    await db.exec(`
      CREATE SCHEMA auth;
      CREATE TYPE public.app_role AS ENUM ('admin');
      CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql AS $$ SELECT '00000000-0000-0000-0000-000000000001'::uuid $$;
      CREATE FUNCTION public.has_role(uuid, public.app_role) RETURNS boolean LANGUAGE sql AS $$ SELECT false $$;
      CREATE TABLE access_fixture (id uuid primary key, visible boolean, editable boolean, status_allowed boolean);
      CREATE FUNCTION public.can_view_booking(uuid) RETURNS boolean LANGUAGE sql AS $$ SELECT visible FROM access_fixture WHERE id=$1 $$;
      CREATE FUNCTION public.can_edit_booking(uuid) RETURNS boolean LANGUAGE sql AS $$ SELECT editable FROM access_fixture WHERE id=$1 $$;
      CREATE FUNCTION public.booking_permission(uuid, text) RETURNS boolean LANGUAGE sql AS $$ SELECT CASE WHEN $2='bookings.status' THEN status_allowed ELSE editable END FROM access_fixture WHERE id=$1 $$;
      CREATE TABLE public.bookings (
        id uuid primary key,
        status text,
        custom_status text,
        financial_status text,
        event_name text,
        updated_at timestamptz default now()
      );
      ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
      CREATE POLICY "bookings editable" ON public.bookings USING (true) WITH CHECK (true);
      INSERT INTO access_fixture VALUES
        ('00000000-0000-0000-0000-000000000001',true,true,true),
        ('00000000-0000-0000-0000-000000000002',true,false,true),
        ('00000000-0000-0000-0000-000000000003',true,false,false);
      INSERT INTO public.bookings (id, status, event_name) VALUES
        ('00000000-0000-0000-0000-000000000001','optie','A'),
        ('00000000-0000-0000-0000-000000000002','optie','B'),
        ('00000000-0000-0000-0000-000000000003','optie','C');
    `);
    await db.exec(await readFile(new URL('../drizzle/migrations/0017_booking_status_permission.sql', import.meta.url), 'utf8'));
    // Bewerker met bookings.edit mag alles wijzigen.
    await db.query("UPDATE public.bookings SET status='definitief', event_name='X' WHERE id='00000000-0000-0000-0000-000000000001'");
    // Alleen statusrecht: status wijzigen mag, andere velden niet.
    await db.query("UPDATE public.bookings SET status='definitief' WHERE id='00000000-0000-0000-0000-000000000002'");
    await assert.rejects(
      db.query("UPDATE public.bookings SET event_name='Y' WHERE id='00000000-0000-0000-0000-000000000002'"),
    );
    // Geen statusrecht: status wijzigen wordt geweigerd.
    await assert.rejects(
      db.query("UPDATE public.bookings SET status='definitief' WHERE id='00000000-0000-0000-0000-000000000003'"),
    );
    const { rows } = await db.query('SELECT id, status, event_name FROM public.bookings ORDER BY id');
    assert.deepEqual(
      rows.map((r) => [r.status, r.event_name]),
      [
        ['definitief', 'X'],
        ['definitief', 'B'],
        ['optie', 'C'],
      ],
    );
  } finally { await db.close(); }
});
