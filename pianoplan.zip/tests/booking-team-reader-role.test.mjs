import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';

const m15 = await readFile(new URL('../drizzle/migrations/0015_inherited_booking_team_roles.sql', import.meta.url), 'utf8');
const m18 = await readFile(new URL('../drizzle/migrations/0018_booking_team_roles_reader_or_manager.sql', import.meta.url), 'utf8');
const user = '00000000-0000-0000-0000-000000000001';
const booking = '00000000-0000-0000-0000-000000000002';
const artist = '00000000-0000-0000-0000-000000000003';

async function fixture() {
  const db = new PGlite();
  await db.exec(`
    CREATE SCHEMA auth;
    CREATE ROLE anon; CREATE ROLE authenticated; CREATE ROLE service_role;
    CREATE TYPE member_role AS ENUM ('gebruiker','boeker','lezer');
    CREATE TYPE app_role AS ENUM ('admin','host','gebruiker','boeker','lezer');
    CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql AS $$ SELECT '${user}'::uuid $$;
    CREATE TABLE bookings(id uuid,artist_id uuid);
    CREATE TABLE artist_members(artist_id uuid,user_id uuid,status text);
    CREATE TABLE user_roles(user_id uuid,role app_role);
    CREATE TABLE booking_members(booking_id uuid,user_id uuid,role member_role,status text);
    CREATE FUNCTION can_view_booking(uuid) RETURNS boolean LANGUAGE sql AS $$ SELECT true $$;
    INSERT INTO bookings VALUES ('${booking}','${artist}');
    INSERT INTO user_roles VALUES ('${user}','boeker');
  `);
  await db.exec(m15);
  await db.exec(m18);
  return db;
}

test('a team member without artist management is always Lezer, whatever role is sent', async () => {
  const db = await fixture();
  try {
    await db.exec(`INSERT INTO booking_members VALUES ('${booking}','${user}','gebruiker','pending')`);
    assert.equal((await db.query(`SELECT role FROM booking_members`)).rows[0].role, 'lezer');
    await db.exec(`UPDATE booking_members SET role='boeker'`);
    assert.equal((await db.query(`SELECT role FROM booking_members`)).rows[0].role, 'lezer');
  } finally { await db.close(); }
});

test('an accepted artist manager gets their management role in the team', async () => {
  const db = await fixture();
  try {
    await db.exec(`INSERT INTO artist_members VALUES ('${artist}','${user}','accepted');
      INSERT INTO booking_members VALUES ('${booking}','${user}','lezer','pending')`);
    assert.equal((await db.query(`SELECT role FROM booking_member_roles('${booking}')`)).rows[0].role, 'boeker');
  } finally { await db.close(); }
});
