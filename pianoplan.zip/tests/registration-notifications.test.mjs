import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';
async function fixture() {
 const db = new PGlite();
 await db.exec(`
 CREATE TABLE profiles (id text PRIMARY KEY, name text, email text);
 CREATE TABLE user_roles (user_id text, role text);
 CREATE TABLE role_permissions (role text, permission text, allowed boolean);
 CREATE TABLE notifications (user_id text, type text, title text, body text, link text);
 CREATE FUNCTION public.role_allows(_role text, _key text) RETURNS boolean LANGUAGE sql AS $$ SELECT coalesce((SELECT allowed FROM role_permissions WHERE role = _role AND permission = _key LIMIT 1), false) $$;
 CREATE FUNCTION public.notify_user(uid text, kind text, heading text, message text, target text) RETURNS void LANGUAGE sql AS $$ INSERT INTO notifications VALUES (uid, kind, heading, message, target) $$;
 INSERT INTO user_roles VALUES ('admin-user','admin'), ('manager-user','gebruiker'), ('reader-user','lezer'), ('new-user','gebruiker');
 INSERT INTO role_permissions VALUES ('admin','notifications.new_user',true), ('admin','users.manage',true), ('gebruiker','notifications.new_user',true), ('gebruiker','users.manage',false), ('lezer','notifications.new_user',false);
 `);
 await db.exec(await readFile(new URL('../drizzle/migrations/0004_registration_notification_recipients.sql', import.meta.url), 'utf8'));
 await db.exec(`CREATE TRIGGER notify_profile AFTER INSERT ON profiles FOR EACH ROW EXECUTE FUNCTION public.notify_new_profile(); INSERT INTO profiles VALUES ('new-user','New account','new@example.test');`);
 return db;
}
test('only enabled account types receive registration notifications', async () => {
 const db = await fixture(); try {
 const { rows } = await db.query('SELECT user_id FROM notifications ORDER BY user_id');
 assert.deepEqual(rows.map(row => row.user_id), ['admin-user', 'manager-user']);
 } finally { await db.close(); }
});
test('new account never receives its own registration notification', async () => {
 const db = await fixture(); try {
 const { rows } = await db.query("SELECT count(*)::int AS count FROM notifications WHERE user_id='new-user'");
 assert.equal(rows[0].count, 0);
 } finally { await db.close(); }
});
test('management links require account management permission', async () => {
 const db = await fixture(); try {
 const { rows } = await db.query('SELECT user_id, link FROM notifications ORDER BY user_id');
 assert.deepEqual(rows, [{user_id:'admin-user',link:'/users'}, {user_id:'manager-user',link:null}]);
 } finally { await db.close(); }
});
