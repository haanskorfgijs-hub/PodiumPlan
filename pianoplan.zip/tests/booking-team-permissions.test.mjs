import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';

const migration = await readFile(new URL('../drizzle/migrations/0013_booking_team_role_permissions.sql', import.meta.url), 'utf8');
const priorityMigration = await readFile(new URL('../drizzle/migrations/0014_artist_manager_booking_permission_priority.sql', import.meta.url), 'utf8');
const user = '00000000-0000-0000-0000-000000000001';
const booking = '00000000-0000-0000-0000-000000000002';
const other = '00000000-0000-0000-0000-000000000003';
async function fixture() {
  const db = new PGlite();
  await db.exec(`
    CREATE SCHEMA auth;
    CREATE ROLE authenticated;
    CREATE ROLE service_role;
    CREATE TYPE app_role AS ENUM ('admin','host','gebruiker','boeker','lezer');
    CREATE TYPE member_role AS ENUM ('gebruiker','boeker','lezer');
    CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql AS $$ SELECT '${user}'::uuid $$;
    CREATE TABLE user_roles(user_id uuid, role app_role);
    CREATE TABLE role_permissions(role app_role, permission text, allowed boolean);
    CREATE TABLE bookings(id uuid, created_by uuid, artist_id uuid DEFAULT '00000000-0000-0000-0000-000000000004');
    CREATE TABLE artist_members(artist_id uuid, user_id uuid, status text);
    CREATE TABLE booking_members(booking_id uuid, user_id uuid, role member_role, status text);
    CREATE TABLE tasks(id uuid, booking_id uuid, assigned_to uuid, created_by uuid);
    CREATE TABLE activity_log(entity_type text, entity_id uuid, user_id uuid, action text);
    CREATE FUNCTION has_role(uuid, app_role) RETURNS boolean LANGUAGE sql AS $$ SELECT EXISTS(SELECT 1 FROM user_roles WHERE user_id=$1 AND role=$2) $$;
    CREATE FUNCTION role_allows(app_role, text) RETURNS boolean LANGUAGE sql AS $$ SELECT coalesce((SELECT allowed FROM role_permissions WHERE role=$1 AND permission=$2), false) $$;
    CREATE FUNCTION has_permission(text) RETURNS boolean LANGUAGE sql AS $$ SELECT role_allows((SELECT role FROM user_roles WHERE user_id=auth.uid()), $1) $$;
    CREATE FUNCTION booking_role(uuid) RETURNS member_role LANGUAGE sql AS $$ SELECT role FROM booking_members WHERE booking_id=$1 AND user_id=auth.uid() AND status='accepted' $$;
    CREATE FUNCTION can_view_booking(uuid) RETURNS boolean LANGUAGE sql AS $$ SELECT EXISTS(SELECT 1 FROM bookings WHERE id=$1) $$;
    CREATE FUNCTION can_view_booking_activity(text, uuid) RETURNS boolean LANGUAGE sql AS $$ SELECT true $$;
    CREATE POLICY "bookings editable" ON bookings FOR UPDATE USING(true);
    CREATE POLICY "bookings owner or admin delete" ON bookings FOR DELETE USING(true);
    CREATE POLICY "booking members manage insert" ON booking_members FOR INSERT WITH CHECK(true);
    CREATE POLICY "booking members manage update" ON booking_members FOR UPDATE USING(true);
    CREATE POLICY "booking members manage delete" ON booking_members FOR DELETE USING(true);
    CREATE POLICY "tasks scoped insert" ON tasks FOR INSERT WITH CHECK(true);
    CREATE POLICY "tasks scoped update" ON tasks FOR UPDATE USING(true);
    CREATE POLICY "tasks scoped delete" ON tasks FOR DELETE USING(true);
    CREATE POLICY "tasks scoped select" ON tasks FOR SELECT USING(true);
    CREATE POLICY "activity visible" ON activity_log FOR SELECT USING(true);
    INSERT INTO user_roles VALUES ('${user}', 'admin');
    INSERT INTO bookings(id,created_by) VALUES ('${booking}', '${user}');
    INSERT INTO booking_members VALUES ('${booking}', '${user}', 'lezer', 'accepted');
    INSERT INTO role_permissions SELECT r::app_role, p, r IN ('admin','gebruiker') FROM unnest(ARRAY['admin','gebruiker','lezer']) r CROSS JOIN unnest(ARRAY['bookings.edit','members.manage','bookings.delete','financial.view','pricing.view','tasks.manage','tasks.view.all','activity.financial.view']) p;
    INSERT INTO role_permissions VALUES ('lezer','tasks.manage.own',true);
  `);
  await db.exec(migration);
  await db.exec(priorityMigration);
  return db;
}
test('an accepted reader team role overrides all admin account booking grants', async () => {
  const db = await fixture();
  try {
    const { rows } = await db.query(`SELECT permission, booking_permission('${booking}',permission) allowed FROM role_permissions WHERE role='admin'`);
    assert.equal(rows.length, 8);
    assert.ok(rows.every(row => row.allowed === false));
    assert.equal((await db.query(`SELECT can_edit_booking('${booking}') allowed`)).rows[0].allowed, false);
  } finally { await db.close(); }
});
test('an accepted manager team role grants booking rights despite a reader account', async () => {
  const db = await fixture();
  try {
    await db.exec(`UPDATE user_roles SET role='lezer'; UPDATE booking_members SET role='gebruiker';`);
    assert.equal((await db.query(`SELECT can_edit_booking('${booking}') allowed`)).rows[0].allowed, true);
    assert.equal((await db.query(`SELECT booking_permission('${booking}','financial.view') allowed`)).rows[0].allowed, true);
  } finally { await db.close(); }
});
test('accounts without accepted booking membership retain account-based management rights', async () => {
  const db = await fixture();
  try {
    await db.exec(`DELETE FROM booking_members;`);
    assert.equal((await db.query(`SELECT can_edit_booking('${booking}') allowed`)).rows[0].allowed, true);
    await db.exec(`UPDATE user_roles SET role='lezer';`);
    assert.equal((await db.query(`SELECT can_edit_booking('${booking}') allowed`)).rows[0].allowed, false);
  } finally { await db.close(); }
});
test('task management follows the booking role and its independent own-task grant', async () => {
  const db = await fixture();
  try {
    assert.equal((await db.query(`SELECT can_manage_booking_task('${booking}','${other}','${other}') allowed`)).rows[0].allowed, false);
    assert.equal((await db.query(`SELECT can_manage_booking_task('${booking}','${user}','${other}') allowed`)).rows[0].allowed, true);
    await db.exec(`UPDATE role_permissions SET allowed=false WHERE role='lezer' AND permission='tasks.manage.own'`);
    assert.equal((await db.query(`SELECT can_manage_booking_task('${booking}','${user}','${other}') allowed`)).rows[0].allowed, false);
  } finally { await db.close(); }
});
test('real booking update and invitation policies do not bypass a reader team role for admins', async () => {
  const db = await fixture();
  try {
    await db.exec(`ALTER TABLE bookings ENABLE ROW LEVEL SECURITY; ALTER TABLE booking_members ENABLE ROW LEVEL SECURITY;
      GRANT SELECT,UPDATE ON bookings TO authenticated; GRANT SELECT,INSERT ON booking_members TO authenticated;
      CREATE POLICY fixture_bookings_read ON bookings FOR SELECT USING(true);
      CREATE POLICY fixture_members_read ON booking_members FOR SELECT USING(true);
      SET ROLE authenticated;`);
    const { rows } = await db.query(`UPDATE bookings SET created_by='${other}' WHERE id='${booking}' RETURNING id`);
    assert.equal(rows.length, 0);
    await assert.rejects(db.exec(`INSERT INTO booking_members VALUES ('${booking}','${other}','gebruiker','pending')`), /row-level security/);
    await db.exec(`RESET ROLE; UPDATE booking_members SET role='gebruiker'; SET ROLE authenticated;`);
    assert.equal((await db.query(`UPDATE bookings SET created_by='${other}' WHERE id='${booking}' RETURNING id`)).rows.length, 1);
    await db.exec(`INSERT INTO booking_members VALUES ('${booking}','${other}','gebruiker','pending')`);
  } finally { await db.close(); }
});
test('accepted management of the booking artist takes precedence over the reader team role', async () => {
  const db = await fixture();
  try {
    assert.equal((await db.query(`SELECT can_edit_booking('${booking}') allowed`)).rows[0].allowed, false);
    await db.exec(`INSERT INTO artist_members SELECT artist_id,'${user}','accepted' FROM bookings WHERE id='${booking}'`);
    const { rows } = await db.query(`SELECT permission,booking_permission('${booking}',permission) allowed FROM role_permissions WHERE role='admin'`);
    assert.equal(rows.length,8);
    assert.ok(rows.every(row => row.allowed === true));
    assert.equal((await db.query(`SELECT can_edit_booking('${booking}') allowed`)).rows[0].allowed,true);
  } finally { await db.close(); }
});
test('artist management permissions are authoritative even when the booking team role grants more', async () => {
  const db = await fixture();
  try {
    await db.exec(`UPDATE user_roles SET role='lezer'; UPDATE booking_members SET role='gebruiker'; INSERT INTO artist_members SELECT artist_id,'${user}','accepted' FROM bookings WHERE id='${booking}'`);
    assert.equal((await db.query(`SELECT can_edit_booking('${booking}') allowed`)).rows[0].allowed,false);
    assert.equal((await db.query(`SELECT booking_permission('${booking}','financial.view') allowed`)).rows[0].allowed,false);
  } finally { await db.close(); }
});
test('pending management or management of a different artist does not override the booking team role', async () => {
  const db = await fixture();
  try {
    await db.exec(`INSERT INTO artist_members SELECT artist_id,'${user}','pending' FROM bookings WHERE id='${booking}'; INSERT INTO artist_members VALUES ('${other}','${user}','accepted')`);
    assert.equal((await db.query(`SELECT can_edit_booking('${booking}') allowed`)).rows[0].allowed,false);
  } finally { await db.close(); }
});

test('Boeker account and team role can change booking status when the stored permission is enabled', async () => {
  const db = await fixture();
  try {
    await db.exec(`
      ALTER TABLE bookings ADD COLUMN status text DEFAULT 'optie';
      ALTER TABLE bookings ADD COLUMN custom_status text;
      ALTER TABLE bookings ADD COLUMN updated_at timestamptz DEFAULT now();
      UPDATE user_roles SET role='boeker';
      UPDATE booking_members SET role='boeker';
      INSERT INTO role_permissions VALUES ('boeker','bookings.edit',false), ('boeker','bookings.status',true);
      ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
      GRANT SELECT, UPDATE ON bookings TO authenticated;
      CREATE POLICY fixture_bookings_read ON bookings FOR SELECT USING(true);
    `);
    await db.exec(await readFile(new URL('../drizzle/migrations/0017_booking_status_permission.sql', import.meta.url), 'utf8'));
    await db.exec('SET ROLE authenticated');
    assert.equal((await db.query(`SELECT booking_permission('${booking}','bookings.status') allowed`)).rows[0].allowed, true);
    const { rows } = await db.query(`UPDATE bookings SET custom_status='Definitief' WHERE id='${booking}' RETURNING custom_status`);
    assert.deepEqual(rows, [{ custom_status: 'Definitief' }]);
    await assert.rejects(db.query(`UPDATE bookings SET created_by='${other}' WHERE id='${booking}'`), /geen recht/);
    await db.exec(`RESET ROLE; UPDATE role_permissions SET allowed=false WHERE role='boeker' AND permission='bookings.status'; SET ROLE authenticated;`);
    assert.equal((await db.query(`UPDATE bookings SET custom_status='Optie' WHERE id='${booking}' RETURNING id`)).rows.length, 0);
  } finally { await db.close(); }
});