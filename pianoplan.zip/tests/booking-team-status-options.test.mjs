import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';

test('a Boeker booking participant can read artist statuses and save one without artist management access', async () => {
  const db = new PGlite();
  const user = '00000000-0000-0000-0000-000000000001';
  const artist = '00000000-0000-0000-0000-000000000002';
  const booking = '00000000-0000-0000-0000-000000000003';
  try {
    await db.exec(`
      CREATE SCHEMA auth;
      CREATE ROLE authenticated;
      CREATE ROLE anon;
      CREATE TYPE app_role AS ENUM ('admin','boeker');
      CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql AS $$ SELECT '${user}'::uuid $$;
      CREATE FUNCTION has_role(uuid, app_role) RETURNS boolean LANGUAGE sql AS $$ SELECT false $$;
      CREATE TABLE artists(id uuid, name text, booking_statuses jsonb, created_by uuid);
      CREATE TABLE artist_members(artist_id uuid, user_id uuid, status text);
      CREATE TABLE booking_members(booking_id uuid, user_id uuid, role text, status text);
      CREATE TABLE bookings(id uuid, artist_id uuid, created_by uuid, status text, custom_status text, event_name text, updated_at timestamptz);
      CREATE TABLE role_permissions(role text, permission text, allowed boolean);
      CREATE FUNCTION booking_permission(uuid, text) RETURNS boolean LANGUAGE sql SECURITY DEFINER SET search_path=public AS $$
        SELECT coalesce((SELECT rp.allowed FROM booking_members bm JOIN role_permissions rp ON rp.role=bm.role WHERE bm.booking_id=$1 AND bm.user_id=auth.uid() AND bm.status='accepted' AND rp.permission=$2),false)
      $$;
      CREATE FUNCTION can_edit_booking(uuid) RETURNS boolean LANGUAGE sql AS $$ SELECT booking_permission($1,'bookings.edit') $$;
      CREATE POLICY "bookings editable" ON bookings FOR UPDATE USING(false);
      INSERT INTO artists VALUES ('${artist}','Artist','[{"label":"Optie"},{"label":"Definitief"}]',NULL),('00000000-0000-0000-0000-000000000004','Unrelated','[]',NULL);
      INSERT INTO bookings VALUES ('${booking}','${artist}',NULL,'optie','Optie','Event',now());
      INSERT INTO booking_members VALUES ('${booking}','${user}','boeker','accepted');
      INSERT INTO role_permissions VALUES ('boeker','bookings.status',true),('boeker','bookings.edit',false);
      ALTER TABLE artists ENABLE ROW LEVEL SECURITY;
      GRANT SELECT ON artists TO authenticated;
      ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
      GRANT SELECT,UPDATE ON bookings TO authenticated;
      CREATE POLICY booking_read ON bookings FOR SELECT USING (EXISTS(SELECT 1 FROM booking_members WHERE booking_id=id AND user_id=auth.uid() AND status='accepted'));
      GRANT SELECT ON booking_members TO authenticated;
    `);
    await db.exec(await readFile(new URL('../supabase/migrations/20260902204739_e2857967-8583-430a-ae7d-10d649926642.sql', import.meta.url), 'utf8'));
    await db.exec(await readFile(new URL('../drizzle/migrations/0017_booking_status_permission.sql', import.meta.url), 'utf8'));
    await db.exec('SET ROLE authenticated');
    assert.deepEqual((await db.query('SELECT * FROM artists')).rows, []);
    const { rows } = await db.query('SELECT * FROM widget_artists()');
    assert.equal(rows.length, 1);
    assert.equal(rows[0].id, artist);
    assert.deepEqual(rows[0].booking_statuses, [{ label: 'Optie' }, { label: 'Definitief' }]);
    assert.deepEqual((await db.query(`UPDATE bookings SET custom_status='Definitief' WHERE id='${booking}' RETURNING custom_status`)).rows, [{custom_status:'Definitief'}]);
    assert.equal((await db.query(`SELECT custom_status FROM bookings WHERE id='${booking}'`)).rows[0].custom_status, 'Definitief');
    await assert.rejects(db.query(`UPDATE bookings SET event_name='Forbidden' WHERE id='${booking}'`), /geen recht/);
    await db.exec(`RESET ROLE; UPDATE booking_members SET status='pending'; SET ROLE authenticated;`);
    assert.deepEqual((await db.query('SELECT * FROM widget_artists()')).rows, []);
    await db.exec('RESET ROLE; SET ROLE anon;');
    await assert.rejects(db.query('SELECT * FROM widget_artists()'), /permission denied/);
  } finally { await db.close(); }
});