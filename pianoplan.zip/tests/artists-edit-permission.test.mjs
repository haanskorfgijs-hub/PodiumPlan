import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PGlite } from '@electric-sql/pglite';

const USER = '00000000-0000-0000-0000-000000000001';
const ARTIST = '00000000-0000-0000-0000-000000000002';

async function fixture() {
  const db = new PGlite();
  await db.exec(`
    CREATE SCHEMA auth;
    CREATE TYPE app_role AS ENUM ('admin','host','gebruiker','boeker','lezer');
    CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql AS $$ SELECT '${USER}'::uuid $$;
    CREATE TABLE user_roles(user_id uuid, role app_role);
    CREATE TABLE artists(id uuid PRIMARY KEY, name text, created_by uuid);
    CREATE TABLE artist_members(artist_id uuid, user_id uuid, role app_role, status text);
    CREATE TABLE role_permissions(role app_role, permission text, allowed boolean);

    CREATE FUNCTION has_role(_user_id uuid, _role app_role) RETURNS boolean LANGUAGE sql STABLE AS
      $$ SELECT EXISTS(SELECT 1 FROM user_roles WHERE user_id=_user_id AND role=_role) $$;
    CREATE FUNCTION owns_artist(_artist_id uuid) RETURNS boolean LANGUAGE sql STABLE AS
      $$ SELECT EXISTS(SELECT 1 FROM artists WHERE id=_artist_id AND created_by=auth.uid()) $$;
    CREATE FUNCTION artist_role(_artist_id uuid) RETURNS app_role LANGUAGE sql STABLE AS
      $$ SELECT role FROM artist_members WHERE artist_id=_artist_id AND user_id=auth.uid() AND status='accepted' LIMIT 1 $$;
    CREATE FUNCTION has_permission(_key text) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS
      $$ SELECT coalesce(bool_or(coalesce(rp.allowed,false)),false) FROM public.user_roles ur
         LEFT JOIN public.role_permissions rp ON rp.role=ur.role AND rp.permission=_key
         WHERE ur.user_id=auth.uid() $$;
    CREATE FUNCTION can_edit_artist(_artist_id uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS
      $$ SELECT public.owns_artist(_artist_id) OR public.has_role(auth.uid(),'admin')
         OR public.artist_role(_artist_id) IN ('gebruiker','boeker') $$;


    INSERT INTO user_roles VALUES ('${USER}','gebruiker');
    INSERT INTO artists VALUES ('${ARTIST}','Oud','${USER}');
    INSERT INTO artist_members VALUES ('${ARTIST}','${USER}','gebruiker','accepted');
    INSERT INTO role_permissions VALUES ('gebruiker','artists.manage',true);

    ALTER TABLE artists ENABLE ROW LEVEL SECURITY;
    CREATE POLICY "artists editable" ON artists
      USING (can_edit_artist(id) AND has_permission('artists.manage'))
      WITH CHECK (can_edit_artist(id) AND has_permission('artists.manage'));

    CREATE ROLE ptest;
    GRANT USAGE ON SCHEMA public TO ptest;
    GRANT SELECT, UPDATE ON artists TO ptest;
    GRANT SELECT ON user_roles TO ptest;
  `);
  return db;
}

test('editing an artist requires the artists.manage permission', async () => {
  const db = await fixture();
  try {
    // SET ROLE geldt binnen één transactie: rol, update en reset in één keer.
    await db.exec(`SET ROLE ptest; UPDATE artists SET name='Nieuw' WHERE id='${ARTIST}'; RESET ROLE;`);
    // Zonder het recht wordt de update genegeerd: RLS filtert de rij weg (0 rijen aangepast).
    await db.exec(`UPDATE role_permissions SET allowed=false`);
    await db.exec(`SET ROLE ptest; UPDATE artists SET name='Anders' WHERE id='${ARTIST}'; RESET ROLE;`);
    assert.deepEqual((await db.query(`SELECT name FROM artists WHERE id='${ARTIST}'`)).rows, [{ name: 'Nieuw' }]);
  } finally { await db.close(); }
});
