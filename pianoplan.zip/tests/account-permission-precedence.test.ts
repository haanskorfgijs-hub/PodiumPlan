import { test, expect } from 'bun:test';
import { usesAccountPermissions } from '../src/lib/role-permission-access';

test('Admin and Gijs use account permissions without turning other roles into admins', () => {
  expect(usesAccountPermissions('admin')).toBe(true);
  expect(usesAccountPermissions('host')).toBe(true);
  for (const role of ['gebruiker','boeker','lezer',null,undefined] as const) expect(usesAccountPermissions(role)).toBe(false);
});