import { test, expect } from "bun:test";
import { bookingDataTabs } from "../src/lib/booking-edit-access";

test("Bookingen aanpassen does not grant financial tab access", () => {
  expect(bookingDataTabs(true, false, false, false)).toEqual(["booking", "pricing"]);
});
test("financial tab requires its separate financial permission", () => {
  expect(bookingDataTabs(true, false, true, false)).toEqual(["booking", "financial", "pricing"]);
});
test("without booking edit permission existing non-admin tab restrictions remain", () => {
  expect(bookingDataTabs(false, false, false, false)).toEqual(["booking"]);
});
test("an account admin without team-role grants cannot see pricing or financial tabs", () => {
  expect(bookingDataTabs(false, true, false, false)).toEqual(["booking"]);
});
test("team-role financial and pricing grants work without booking editing or an admin account", () => {
  expect(bookingDataTabs(false, false, true, true)).toEqual(["booking", "financial", "pricing"]);
});