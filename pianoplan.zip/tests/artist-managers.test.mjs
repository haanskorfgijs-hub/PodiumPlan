import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';

const migration = await readFile(new URL('../drizzle/migrations/0008_separate_artist_managers_from_booking_teams.sql', import.meta.url), 'utf8');
const visibilityMigration = await readFile(new URL('../drizzle/migrations/0016_artist_manager_booking_visibility.sql', import.meta.url), 'utf8');
async function fixture() {
  const db = new PGlite();
  await db.exec(`
    CREATE SCHEMA auth;
    CREATE ROLE authenticated;
    CREATE TYPE app_role AS ENUM ('admin','host','gebruiker','boeker','lezer');
    CREATE TYPE member_role AS ENUM ('gebruiker','boeker','lezer');
    CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql AS $$ SELECT '00000000-0000-0000-0000-000000000001'::uuid $$;
    CREATE TABLE user_roles(user_id uuid, role app_role);
    CREATE TABLE artist_members(artist_id uuid, user_id uuid, role member_role, status text);
    CREATE TABLE bookings(id uuid, artist_id uuid, created_by uuid);
    CREATE TABLE booking_members(booking_id uuid, user_id uuid, role member_role, status text);
    CREATE TABLE profiles(id uuid, name text, email text, phone text, job_title text, avatar_url text);
    CREATE POLICY "bookings viewable" ON bookings FOR SELECT USING (created_by=auth.uid());
    CREATE FUNCTION has_permission(text) RETURNS boolean LANGUAGE sql AS $$ SELECT EXISTS(SELECT 1 FROM user_roles WHERE user_id=auth.uid() AND role='boeker') $$;
    CREATE FUNCTION has_role(uuid,app_role) RETURNS boolean LANGUAGE sql AS $$ SELECT false $$;
    CREATE FUNCTION owns_booking(uuid) RETURNS boolean LANGUAGE sql AS $$ SELECT false $$;
    CREATE FUNCTION can_view_artist(uuid) RETURNS boolean LANGUAGE sql AS $$ SELECT EXISTS(SELECT 1 FROM artist_members WHERE artist_id=$1 AND user_id=auth.uid() AND status='accepted') $$;
    CREATE POLICY "artist members manage insert" ON artist_members FOR INSERT WITH CHECK(true);
    CREATE POLICY "artist members manage update" ON artist_members FOR UPDATE USING(true) WITH CHECK(true);
    CREATE POLICY "artist members manage delete" ON artist_members FOR DELETE USING(true);
    INSERT INTO user_roles VALUES ('00000000-0000-0000-0000-000000000001','boeker');
    INSERT INTO artist_members VALUES ('00000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000001','gebruiker','accepted');
    INSERT INTO bookings VALUES ('00000000-0000-0000-0000-000000000003','00000000-0000-0000-0000-000000000002',NULL);
    INSERT INTO profiles VALUES ('00000000-0000-0000-0000-000000000001','Manager','manager@example.test','','',NULL);
  `);
  await db.exec(migration);
  await db.exec(visibilityMigration);
  return db;
}
test('artist management follows the account role, not the legacy artist role', async () => {
  const db = await fixture();
  try {
    const query = `SELECT artist_role('00000000-0000-0000-0000-000000000002') AS role, artist_permission('00000000-0000-0000-0000-000000000002','bookings.edit') AS allowed`;
    assert.deepEqual((await db.query(query)).rows, [{ role: 'boeker', allowed: true }]);
    await db.exec(`UPDATE user_roles SET role='lezer'`);
    assert.deepEqual((await db.query(query)).rows, [{ role: 'lezer', allowed: false }]);
  } finally { await db.close(); }
});
test('actual booking reads include every managed artist booking without any team membership', async () => {
  const db = await fixture();
  try {
    await db.exec(`
      INSERT INTO bookings VALUES ('00000000-0000-0000-0000-000000000004','00000000-0000-0000-0000-000000000002',NULL),
      ('00000000-0000-0000-0000-000000000005','00000000-0000-0000-0000-000000000006',NULL);
      ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
      GRANT SELECT ON bookings TO authenticated;
      SET ROLE authenticated;
    `);
    assert.deepEqual((await db.query(`SELECT id FROM bookings ORDER BY id`)).rows.map(row=>row.id),[
      '00000000-0000-0000-0000-000000000003','00000000-0000-0000-0000-000000000004',
    ]);
    await db.exec(`RESET ROLE; UPDATE user_roles SET role='lezer'; SET ROLE authenticated`);
    assert.equal((await db.query(`SELECT count(*)::int count FROM bookings`)).rows[0].count,2);
    await db.exec(`RESET ROLE; UPDATE artist_members SET status='pending'; SET ROLE authenticated`);
    assert.equal((await db.query(`SELECT count(*)::int count FROM bookings`)).rows[0].count,0);
  } finally { await db.close(); }
});
test('an artist manager can view bookings without becoming a booking participant', async () => {
  const db = await fixture();
  try {
    assert.equal((await db.query(`SELECT can_view_booking('00000000-0000-0000-0000-000000000003') AS allowed`)).rows[0].allowed, true);
    assert.deepEqual((await db.query(`SELECT * FROM booking_team('00000000-0000-0000-0000-000000000003')`)).rows, []);
    assert.equal((await db.query(`SELECT booking_role('00000000-0000-0000-0000-000000000003') AS role`)).rows[0].role, null);
    await db.exec(`INSERT INTO booking_members VALUES ('00000000-0000-0000-0000-000000000003','00000000-0000-0000-0000-000000000001','lezer','pending')`);
    assert.equal((await db.query(`SELECT invite_status FROM booking_team('00000000-0000-0000-0000-000000000003')`)).rows[0].invite_status, 'pending');
  } finally { await db.close(); }
});