import { describe, expect, it } from "vitest";
import { normalizeEmailNotificationPreferences, wantsBookingInvitationEmail, wantsBookingStatusEmail } from "../src/lib/email-notification-preferences";

describe("email notification preferences", () => {
  it("only opts into booking invitations when checked, independently of status changes", () => {
    expect(wantsBookingInvitationEmail({ bookingInvitations: true, statusChanges: false, statuses: [] })).toBe(true);
    expect(wantsBookingInvitationEmail({ bookingInvitations: false, statusChanges: true, statuses: ["Definitief"] })).toBe(false);
  });
  it("only matches selected booking statuses when status emails are enabled", () => {
    const preferences = { bookingInvitations: false, statusChanges: true, statuses: ["Definitief"] };
    expect(wantsBookingStatusEmail(preferences, "definitief")).toBe(true);
    expect(wantsBookingStatusEmail(preferences, "Geannuleerd")).toBe(false);
    expect(wantsBookingStatusEmail({ ...preferences, statusChanges: false }, "Definitief")).toBe(false);
    expect(wantsBookingStatusEmail({ ...preferences, statuses: [] }, "Definitief")).toBe(false);
  });
  it("defaults to no consent and safely restores saved selections", () => {
    expect(normalizeEmailNotificationPreferences(null)).toEqual({ bookingInvitations: false, statusChanges: false, statuses: [] });
    expect(normalizeEmailNotificationPreferences({ bookingInvitations: true, statusChanges: true, statuses: [" Definitief ", "definitief", 42, ""] })).toEqual({ bookingInvitations: true, statusChanges: true, statuses: ["definitief"] });
  });
});