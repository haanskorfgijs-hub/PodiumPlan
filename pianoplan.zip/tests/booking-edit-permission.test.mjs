import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';

test('booking editing requires visibility and permission, not a fixed membership role', async () => {
  const db = new PGlite();
  try {
    await db.exec(`
      CREATE SCHEMA auth;
      CREATE TYPE public.app_role AS ENUM ('admin');
      CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql AS $$ SELECT '00000000-0000-0000-0000-000000000001'::uuid $$;
      CREATE FUNCTION public.has_role(uuid, public.app_role) RETURNS boolean LANGUAGE sql AS $$ SELECT false $$;
      CREATE TABLE access_fixture (id uuid, visible boolean, editable boolean);
      CREATE FUNCTION public.can_view_booking(uuid) RETURNS boolean LANGUAGE sql AS $$ SELECT visible FROM access_fixture WHERE id=$1 $$;
      CREATE FUNCTION public.booking_permission(uuid, text) RETURNS boolean LANGUAGE sql AS $$ SELECT editable AND $2='bookings.edit' FROM access_fixture WHERE id=$1 $$;
      INSERT INTO access_fixture VALUES
        ('00000000-0000-0000-0000-000000000001',true,true),
        ('00000000-0000-0000-0000-000000000002',true,false),
        ('00000000-0000-0000-0000-000000000003',false,true);
    `);
    await db.exec(await readFile(new URL('../drizzle/migrations/0005_booking_edit_permission.sql', import.meta.url), 'utf8'));
    const { rows } = await db.query('SELECT public.can_edit_booking(id) AS allowed FROM access_fixture ORDER BY id');
    assert.deepEqual(rows.map(row => row.allowed), [true, false, false]);
  } finally { await db.close(); }
});