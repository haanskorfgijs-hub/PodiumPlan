import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';

const migration = await readFile(new URL('../drizzle/migrations/0015_inherited_booking_team_roles.sql', import.meta.url), 'utf8');
const user = '00000000-0000-0000-0000-000000000001';
const booking = '00000000-0000-0000-0000-000000000002';
const artist = '00000000-0000-0000-0000-000000000003';
async function fixture() {
  const db = new PGlite();
  await db.exec(`
    CREATE SCHEMA auth;
    CREATE ROLE anon; CREATE ROLE authenticated; CREATE ROLE service_role;
    CREATE TYPE member_role AS ENUM ('gebruiker','boeker','lezer');
    CREATE TYPE app_role AS ENUM ('admin','host','gebruiker','boeker','lezer');
    CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql AS $$ SELECT '${user}'::uuid $$;
    CREATE TABLE bookings(id uuid,artist_id uuid);
    CREATE TABLE artist_members(artist_id uuid,user_id uuid,status text);
    CREATE TABLE user_roles(user_id uuid,role app_role);
    CREATE TABLE booking_members(booking_id uuid,user_id uuid,role member_role,status text);
    CREATE FUNCTION can_view_booking(uuid) RETURNS boolean LANGUAGE sql AS $$ SELECT true $$;
    INSERT INTO bookings VALUES ('${booking}','${artist}');
    INSERT INTO user_roles VALUES ('${user}','boeker');
    INSERT INTO booking_members VALUES ('${booking}','${user}','lezer','accepted');
    INSERT INTO artist_members VALUES ('${artist}','${user}','accepted');
  `);
  await db.exec(migration);
  return db;
}
test('Boeker artist manager automatically inherits Boeker in an existing Lezer booking team', async () => {
  const db = await fixture();
  try {
    assert.deepEqual((await db.query(`SELECT * FROM booking_member_roles('${booking}')`)).rows, [{user_id:user,role:'boeker',role_locked:true}]);
    assert.equal((await db.query(`SELECT booking_role('${booking}') role`)).rows[0].role,'boeker');
    await db.exec(`UPDATE user_roles SET role='gebruiker'`);
    assert.equal((await db.query(`SELECT role FROM booking_member_roles('${booking}')`)).rows[0].role,'gebruiker');
  } finally { await db.close(); }
});
test('artist manager team role cannot be changed through direct database updates', async () => {
  const db = await fixture();
  try {
    await assert.rejects(db.exec(`UPDATE booking_members SET role='gebruiker'`), /kan binnen de boeking niet worden aangepast/);
    await db.exec(`UPDATE booking_members SET status='pending'`);
    assert.equal((await db.query(`SELECT role_locked FROM booking_member_roles('${booking}')`)).rows[0].role_locked,true);
  } finally { await db.close(); }
});
test('new invitations automatically use the artist manager role', async () => {
  const db = await fixture();
  try {
    await db.exec(`DELETE FROM booking_members; INSERT INTO booking_members VALUES ('${booking}','${user}','lezer','pending')`);
    assert.equal((await db.query(`SELECT role FROM booking_members`)).rows[0].role,'boeker');
  } finally { await db.close(); }
});
test('pending management or another artist never locks or overrides the team role', async () => {
  const db = await fixture();
  try {
    await db.exec(`UPDATE artist_members SET status='pending'`);
    assert.deepEqual((await db.query(`SELECT role,role_locked FROM booking_member_roles('${booking}')`)).rows,[{role:'lezer',role_locked:false}]);
    await db.exec(`UPDATE booking_members SET role='gebruiker'; UPDATE artist_members SET status='accepted',artist_id='00000000-0000-0000-0000-000000000004'`);
    assert.deepEqual((await db.query(`SELECT role,role_locked FROM booking_member_roles('${booking}')`)).rows,[{role:'gebruiker',role_locked:false}]);
  } finally { await db.close(); }
});
test('artist management alone never creates booking participation', async () => {
  const db = await fixture();
  try {
    await db.exec(`DELETE FROM booking_members`);
    assert.equal((await db.query(`SELECT booking_role('${booking}') role`)).rows[0].role,null);
    assert.equal((await db.query(`SELECT count(*)::int count FROM booking_members`)).rows[0].count,0);
  } finally { await db.close(); }
});