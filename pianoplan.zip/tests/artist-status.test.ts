import { expect, test } from "bun:test";
import { bookingStatusLabel, defaultArtistStatuses, isActiveBooking, isCancelledBooking, isCompletedBooking } from "../src/lib/artist-status";

test("only the artist status determines the displayed booking status", () => {
  const booking = { artist_status: "In Rooster", status: "geannuleerd", custom_status: "Optie" };
  expect(bookingStatusLabel(booking)).toBe("In Rooster");
  expect(isActiveBooking(booking)).toBe(true);
  expect(isCancelledBooking(booking)).toBe(false);
  expect(bookingStatusLabel({})).toBe("");
});
test("cancellation and completion follow artist labels", () => {
  expect(isCancelledBooking({ artist_status: "Geannuleerd - Te duur" })).toBe(true);
  expect(isCancelledBooking({ artist_status: "Afgezegd" })).toBe(true);
  expect(isCompletedBooking({ artist_status: "Afgerond" })).toBe(true);
  expect(isActiveBooking({ artist_status: "Afgerond" })).toBe(false);
});
test("new artists receive their own editable basic status set", () => {
  const first = defaultArtistStatuses();
  expect(first.map(({ label, stage }) => ({ label, stage }))).toEqual([
    { label: "Optie", stage: "create" }, { label: "Definitief", stage: "create" },
    { label: "Geannuleerd", stage: "edit" }, { label: "Afgerond", stage: "after" },
  ]);
  expect(defaultArtistStatuses()[0]?.id).not.toBe(first[0]?.id);
});