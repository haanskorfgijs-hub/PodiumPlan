# Eigen artieststatussen
- [x] Admin en Gijs overal accountrechten laten behouden, rolkeuze bij artiestbeheer blokkeren en controleren.
- [x] Boekingen veilig overzetten naar één leidende artieststatus en automatische functies aanpassen.
- [x] Formulieren, badges, filters, statistieken, e-mails en kalender laten volgen uit artieststatussen.
- [x] Statusregels testen en de boekingspagina controleren.

# E-mailvoorkeuren
- [x] Voorkeuren voor boekingsuitnodigingen en geselecteerde statuswijzigingen toevoegen en per account in deze browser opslaan.
- [x] Voorkeurregels testen en opslaan/herladen op de instellingenpagina controleren.

# Artiestbeheerders
- [x] Artiestuitnodiging omzetten naar Beheerder toevoegen, zonder aparte teamrol.
- [x] Beheerrechten laten volgen uit het accounttype; artiestbeheerders scheiden van boekingsteams.
- [x] Regels en uitnodigingsvensters testen.
- [x] Alle artiestboekingen zichtbaar maken voor geaccepteerde beheerders en daadwerkelijk ophalen testen.

# Boekingsrechten volgens teamrol
- [x] Boekingsrechten en bediening laten volgen uit de toegewezen teamrol, zonder accountrol-voorrang.
- [x] Tegengestelde account- en teamrollen testen en de boekingspagina controleren.
- [x] Geaccepteerd artiestbeheer voorrang geven boven boekingsteamrollen en testen.
- [x] Artiestbeheerrol automatisch tonen in boekingsteams en rolwijzigingen blokkeren, ook in de database.
- [x] Boeker als artiestbeheerder met lezer-teamrol testen en teamvenster controleren.

# Statusrecht Boeker
- [x] Ontbrekende standaardinstellingen voor boekingsstatusrechten herstellen zonder bestaande keuzes te wijzigen.
- [x] Regressietest uitvoeren en statuswijziging via de boekingspagina controleren.
- [ ] Controleren met het getroffen Boeker-account; aanmelding is niet toegestaan door de gebruiker.

# Rechten appbreed
- [x] Alle ontbrekende rechteninstellingen aanvullen met de bestaande standaardwaarden, zonder opgeslagen keuzes te overschrijven.
- [x] Schijnbaar ingeschakelde rechten voorkomen: alle schermen laten volgen uit opgeslagen instellingen.
- [x] Rechten en behoud van bestaande keuzes testen en de rechtenpagina controleren.

# Lege statuskeuze voor boekingsteamleden
- [x] Statussen ophalen via de bestaande toegang voor boekingsteamleden, zonder artiestbeheer toegankelijk te maken.
- [x] Boeker-teamlid zonder artiestbeheer testen met beveiligde lees- en schrijfrechten; statuswijziging via de pagina met de beschikbare adminsessie controleren.