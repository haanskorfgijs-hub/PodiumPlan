<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Generate booking pricing audit entries through the shared pricing snapshot diff helper so rule names, calculation details, overrides and totals remain readable without exposing serialized storage keys.
- Email preferences live in the email_notification_preferences table (own-row RLS); booking emails are sent server-side by sendBookingEmails, which re-reads booking, recipients and preferences so the browser never chooses recipients.
- Choose registration notification recipients server-side using the global notifications.new_user role permission; link to account management only when the recipient has users.manage, so notification access does not grant account-management access.
- Use can_edit_booking as the server-side booking visibility-and-edit permission gate and the shared bookingDataTabs helper in the detail page and edit dialog; financial tab access requires its separate financial permission, while task, invitation and deletion permissions remain independent.
- Performance standards carry a default team (default_team jsonb: userId + member role) edited through the shared DefaultTeamEditor; the new-booking dialog prefills it, lets the creator adjust it, and inserts booking_members invitations (status pending) on create.
- Keep artist management assignments separate from booking participation: artist authorization resolves account roles server-side, while booking_team includes only explicit booking_members (never the creator implicitly), so management access never implies attendance.
- Use can_view_booking in the bookings SELECT policy so list and detail reads include managed artist bookings without requiring booking-team membership.
- Resolve booking permissions through booking_permission: accepted management membership of the booking's artist uses account-based artist permissions first, otherwise accepted booking membership uses its team role, with account permissions as a nonmember fallback; use the same result in scoped UI checks and booking/task/member policies to prevent conflicting authorization.
- Use the shared account-precedence helper and secured member_account_types RPC for account-only scope resolution and role-picker locking; precedence never grants permissions, and database triggers reject artist-role changes for these accounts.
- Booking team roles are never chosen in the UI: a database trigger forces every booking_members row to the inherited artist-manager role or the read-only role, and booking_member_roles reads the effective role, so no client can grant extra booking rights.
- Booking status changes use the separate bookings.status permission; the trigger on bookings blocks non-status column changes for users without bookings.edit, and the edit policy allows status-only updates.
- Persist permission defaults in role_permissions when introducing a permission; browser-only defaults cannot grant rights enforced by booking_permission.
- Use the pure role-permission-access helper for global UI rights; missing or unloaded settings deny access just like server permission functions, so all screens reflect stored choices.
- Fetch detail-page booking status choices through useWidgetArtists (the secured widget_artists RPC), not the management-only artists query; booking participants need status choices without artist-management access.
- User-owned rows reference public.profiles(id) with ON DELETE CASCADE (booking_members, booking_availability, artist_members, notifications, calendar_widgets) or ON DELETE SET NULL (tasks.created_by, tasks.assigned_to), so deleting a profile never leaves orphaned rows; new user-referencing columns must follow the same pattern.
- Admin powers are permissions (admin.full_access, admin.switch_account, admin.availability, admin.contacts) in role_permissions; has_role(uid,'admin') resolves to admin.full_access, so account types are only names and never check role === "admin" in code.

- Use bookings.artist_status as the sole booking status in application code and shared pure artist-status helpers for semantics; deprecated status/custom_status are only bridged by a database trigger for older deployed clients.
