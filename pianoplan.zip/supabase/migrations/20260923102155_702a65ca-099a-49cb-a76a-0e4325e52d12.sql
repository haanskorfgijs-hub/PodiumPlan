CREATE OR REPLACE FUNCTION public.prevent_self_role_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND NEW.user_id = auth.uid() AND NEW.role IS DISTINCT FROM OLD.role THEN
    RAISE EXCEPTION 'Je kunt je eigen rol niet aanpassen.';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS prevent_self_role_change_artist_members ON public.artist_members;
CREATE TRIGGER prevent_self_role_change_artist_members
BEFORE UPDATE ON public.artist_members
FOR EACH ROW EXECUTE FUNCTION public.prevent_self_role_change();

DROP TRIGGER IF EXISTS prevent_self_role_change_booking_members ON public.booking_members;
CREATE TRIGGER prevent_self_role_change_booking_members
BEFORE UPDATE ON public.booking_members
FOR EACH ROW EXECUTE FUNCTION public.prevent_self_role_change();