ALTER TABLE public.tasks ADD COLUMN IF NOT EXISTS show_in_widget boolean NOT NULL DEFAULT false;
ALTER TABLE public.tasks ADD COLUMN IF NOT EXISTS deadline_time time without time zone;
ALTER TABLE public.calendar_widgets ADD COLUMN IF NOT EXISTS include text[] NOT NULL DEFAULT '{bookings}';