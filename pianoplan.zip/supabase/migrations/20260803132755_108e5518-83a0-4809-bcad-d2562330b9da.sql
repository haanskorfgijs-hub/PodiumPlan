CREATE OR REPLACE FUNCTION public.can_view_standard(_standard_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.bookings b
    WHERE b.standard_id = _standard_id
      AND (b.created_by = auth.uid()
           OR public.has_role(auth.uid(),'admin')
           OR public.booking_role(b.id) IS NOT NULL)
  );
$$;

DROP POLICY IF EXISTS "standards viewable" ON public.performance_standards;
CREATE POLICY "standards viewable" ON public.performance_standards
FOR SELECT TO authenticated
USING (public.can_view_artist(artist_id) OR public.can_view_standard(id));