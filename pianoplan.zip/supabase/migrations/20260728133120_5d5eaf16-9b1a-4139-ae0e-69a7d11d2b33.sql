ALTER TABLE public.performance_standards
ADD COLUMN IF NOT EXISTS default_tasks jsonb NOT NULL DEFAULT '[]'::jsonb;