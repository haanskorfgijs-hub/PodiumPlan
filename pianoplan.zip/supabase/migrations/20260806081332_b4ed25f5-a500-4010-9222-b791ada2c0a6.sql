ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS job_title text NOT NULL DEFAULT '';

CREATE POLICY "admins update profiles" ON public.profiles
FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));