CREATE OR REPLACE FUNCTION public.log_booking_member_activity()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_name text;
  actor uuid := auth.uid();
  b_id uuid;
  act text;
  summ text;
BEGIN
  b_id := COALESCE(NEW.booking_id, OLD.booking_id);
  SELECT COALESCE(NULLIF(p.name,''), p.email) INTO target_name
  FROM public.profiles p WHERE p.id = COALESCE(NEW.user_id, OLD.user_id);
  target_name := COALESCE(target_name, 'onbekende gebruiker');

  IF TG_OP = 'INSERT' THEN
    IF NEW.status = 'pending' THEN
      act := 'invite_sent';
      summ := 'stuurde een uitnodiging naar ' || target_name;
    ELSE
      act := 'invite_added';
      summ := 'voegde ' || target_name || ' toe aan de boeking';
    END IF;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.status IS DISTINCT FROM OLD.status THEN
      IF NEW.status = 'accepted' THEN
        act := 'invite_accepted';
        summ := 'accepteerde de uitnodiging voor deze boeking';
      ELSIF NEW.status = 'declined' THEN
        act := 'invite_declined';
        summ := 'wees de uitnodiging voor deze boeking af';
      ELSE
        act := 'invite_updated';
        summ := 'wijzigde de uitnodiging van ' || target_name;
      END IF;
      IF actor IS DISTINCT FROM NEW.user_id THEN
        summ := CASE WHEN NEW.status = 'accepted' THEN 'markeerde de uitnodiging van ' || target_name || ' als geaccepteerd'
                     WHEN NEW.status = 'declined' THEN 'markeerde de uitnodiging van ' || target_name || ' als afgewezen'
                     ELSE summ END;
      END IF;
    ELSIF NEW.role IS DISTINCT FROM OLD.role THEN
      act := 'invite_role_changed';
      summ := 'wijzigde de rol van ' || target_name || ' naar ' || NEW.role::text;
    ELSE
      RETURN NEW;
    END IF;
  ELSE
    act := 'invite_removed';
    summ := 'verwijderde ' || target_name || ' van de boeking';
  END IF;

  INSERT INTO public.activity_log (user_id, entity_type, entity_id, action, summary, changes)
  VALUES (COALESCE(actor, COALESCE(NEW.user_id, OLD.user_id)), 'booking', b_id, act, summ, '[]'::jsonb);

  RETURN COALESCE(NEW, OLD);
END;
$$;

REVOKE ALL ON FUNCTION public.log_booking_member_activity() FROM PUBLIC, anon, authenticated;