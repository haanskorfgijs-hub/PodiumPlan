ALTER TABLE public.calendar_widgets
ADD COLUMN IF NOT EXISTS content text[] NOT NULL DEFAULT ARRAY['event_name','location','booking_link']::text[];