CREATE OR REPLACE FUNCTION public.can_edit_artist(_artist_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
  SELECT public.owns_artist(_artist_id)
    OR public.has_role(auth.uid(),'admin')
    OR public.artist_role(_artist_id) IN ('gebruiker','boeker');
$function$;

CREATE OR REPLACE FUNCTION public.can_edit_booking(_booking_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
  SELECT public.owns_booking(_booking_id)
    OR public.has_role(auth.uid(),'admin')
    OR public.booking_role(_booking_id) IN ('gebruiker','boeker');
$function$;