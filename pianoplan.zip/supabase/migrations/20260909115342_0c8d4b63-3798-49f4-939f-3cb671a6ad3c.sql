revoke all on function public.role_allows(app_role, text) from anon, authenticated;
revoke all on function public.artist_permission(uuid, text) from anon;
revoke all on function public.booking_permission(uuid, text) from anon;