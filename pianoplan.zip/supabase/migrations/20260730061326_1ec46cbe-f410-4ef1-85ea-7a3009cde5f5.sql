-- New role enum
CREATE TYPE public.app_role_new AS ENUM ('admin', 'gebruiker', 'lezer');

ALTER TABLE public.user_roles ALTER COLUMN role DROP DEFAULT;
ALTER TABLE public.user_roles
  ALTER COLUMN role TYPE public.app_role_new
  USING (CASE WHEN role::text = 'admin' THEN 'admin' ELSE 'gebruiker' END)::public.app_role_new;

DROP FUNCTION IF EXISTS public.has_role(uuid, public.app_role);
DROP TYPE public.app_role;
ALTER TYPE public.app_role_new RENAME TO app_role;

ALTER TABLE public.user_roles ALTER COLUMN role SET DEFAULT 'gebruiker'::public.app_role;

-- deduplicate to one role per user
DELETE FROM public.user_roles a
USING public.user_roles b
WHERE a.user_id = b.user_id
  AND a.ctid > b.ctid;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  INSERT INTO public.profiles (id, name, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email,'@',1)), COALESCE(NEW.email,''))
  ON CONFLICT (id) DO NOTHING;
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, CASE WHEN lower(NEW.email) = 'gijshaanskorf@hotmail.com' THEN 'admin'::public.app_role ELSE 'gebruiker'::public.app_role END)
  ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ensure every existing user has a role
INSERT INTO public.user_roles (user_id, role)
SELECT u.id, 'gebruiker'::public.app_role
FROM auth.users u
LEFT JOIN public.user_roles r ON r.user_id = u.id
WHERE r.user_id IS NULL;

-- assign admin to the requested account
UPDATE public.user_roles r
SET role = 'admin'::public.app_role
FROM auth.users u
WHERE u.id = r.user_id AND lower(u.email) = 'gijshaanskorf@hotmail.com';

-- one role per user
CREATE UNIQUE INDEX IF NOT EXISTS user_roles_user_id_key ON public.user_roles (user_id);

-- admin-only management policies
DROP POLICY IF EXISTS "admins manage roles insert" ON public.user_roles;
CREATE POLICY "admins manage roles insert" ON public.user_roles
FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "admins manage roles update" ON public.user_roles;
CREATE POLICY "admins manage roles update" ON public.user_roles
FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

GRANT SELECT, INSERT, UPDATE ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;