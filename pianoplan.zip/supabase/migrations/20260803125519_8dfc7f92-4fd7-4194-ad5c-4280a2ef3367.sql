CREATE TYPE public.member_role AS ENUM ('gebruiker','lezer');

CREATE TABLE public.artist_members (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  artist_id uuid NOT NULL REFERENCES public.artists(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  role public.member_role NOT NULL DEFAULT 'lezer',
  created_by uuid DEFAULT auth.uid(),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (artist_id, user_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.artist_members TO authenticated;
GRANT ALL ON public.artist_members TO service_role;
ALTER TABLE public.artist_members ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.booking_members (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  booking_id uuid NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  role public.member_role NOT NULL DEFAULT 'lezer',
  created_by uuid DEFAULT auth.uid(),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (booking_id, user_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.booking_members TO authenticated;
GRANT ALL ON public.booking_members TO service_role;
ALTER TABLE public.booking_members ENABLE ROW LEVEL SECURITY;

-- role lookups
CREATE OR REPLACE FUNCTION public.artist_role(_artist_id uuid)
RETURNS public.member_role LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT role FROM public.artist_members WHERE artist_id = _artist_id AND user_id = auth.uid();
$$;

CREATE OR REPLACE FUNCTION public.booking_role(_booking_id uuid)
RETURNS public.member_role LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE(
    (SELECT bm.role FROM public.booking_members bm WHERE bm.booking_id = _booking_id AND bm.user_id = auth.uid()),
    (SELECT am.role FROM public.bookings b JOIN public.artist_members am ON am.artist_id = b.artist_id
      WHERE b.id = _booking_id AND am.user_id = auth.uid())
  );
$$;

CREATE OR REPLACE FUNCTION public.can_view_artist(_artist_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.owns_artist(_artist_id)
    OR public.has_role(auth.uid(),'admin')
    OR public.artist_role(_artist_id) IS NOT NULL;
$$;

CREATE OR REPLACE FUNCTION public.can_edit_artist(_artist_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.owns_artist(_artist_id)
    OR public.has_role(auth.uid(),'admin')
    OR public.artist_role(_artist_id) = 'gebruiker';
$$;

CREATE OR REPLACE FUNCTION public.can_view_booking(_booking_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.owns_booking(_booking_id)
    OR public.has_role(auth.uid(),'admin')
    OR public.booking_role(_booking_id) IS NOT NULL;
$$;

CREATE OR REPLACE FUNCTION public.can_edit_booking(_booking_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.owns_booking(_booking_id)
    OR public.has_role(auth.uid(),'admin')
    OR public.booking_role(_booking_id) = 'gebruiker';
$$;

CREATE OR REPLACE FUNCTION public.shares_membership(_other uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.artist_members am
    JOIN public.artists a ON a.id = am.artist_id
    WHERE (am.user_id = _other AND (a.created_by = auth.uid() OR EXISTS (
            SELECT 1 FROM public.artist_members me WHERE me.artist_id = a.id AND me.user_id = auth.uid())))
       OR (am.user_id = auth.uid() AND a.created_by = _other)
  ) OR EXISTS (
    SELECT 1 FROM public.booking_members bm
    JOIN public.bookings b ON b.id = bm.booking_id
    WHERE (bm.user_id = _other AND (b.created_by = auth.uid() OR EXISTS (
            SELECT 1 FROM public.booking_members me WHERE me.booking_id = b.id AND me.user_id = auth.uid())))
       OR (bm.user_id = auth.uid() AND b.created_by = _other)
  );
$$;

CREATE OR REPLACE FUNCTION public.find_user_by_email(_email text)
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT id FROM public.profiles WHERE lower(email) = lower(trim(_email)) LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.can_view_booking_activity(_entity_type text, _entity_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT CASE
    WHEN _entity_type <> 'booking' OR _entity_id IS NULL THEN true
    WHEN NOT EXISTS (SELECT 1 FROM public.bookings WHERE id = _entity_id) THEN true
    ELSE public.can_view_booking(_entity_id)
  END;
$$;

-- membership table policies
CREATE POLICY "artist members visible" ON public.artist_members FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.can_view_artist(artist_id));
CREATE POLICY "artist members manage insert" ON public.artist_members FOR INSERT TO authenticated
  WITH CHECK (public.owns_artist(artist_id) OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "artist members manage update" ON public.artist_members FOR UPDATE TO authenticated
  USING (public.owns_artist(artist_id) OR public.has_role(auth.uid(),'admin'))
  WITH CHECK (public.owns_artist(artist_id) OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "artist members manage delete" ON public.artist_members FOR DELETE TO authenticated
  USING (public.owns_artist(artist_id) OR public.has_role(auth.uid(),'admin') OR user_id = auth.uid());

CREATE POLICY "booking members visible" ON public.booking_members FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.can_view_booking(booking_id));
CREATE POLICY "booking members manage insert" ON public.booking_members FOR INSERT TO authenticated
  WITH CHECK (public.owns_booking(booking_id) OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "booking members manage update" ON public.booking_members FOR UPDATE TO authenticated
  USING (public.owns_booking(booking_id) OR public.has_role(auth.uid(),'admin'))
  WITH CHECK (public.owns_booking(booking_id) OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "booking members manage delete" ON public.booking_members FOR DELETE TO authenticated
  USING (public.owns_booking(booking_id) OR public.has_role(auth.uid(),'admin') OR user_id = auth.uid());

-- widen existing policies to members
DROP POLICY "artists owner or admin select" ON public.artists;
CREATE POLICY "artists viewable" ON public.artists FOR SELECT TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin') OR public.artist_role(id) IS NOT NULL);
DROP POLICY "artists owner or admin update" ON public.artists;
CREATE POLICY "artists editable" ON public.artists FOR UPDATE TO authenticated
  USING (public.can_edit_artist(id)) WITH CHECK (public.can_edit_artist(id));

DROP POLICY "standards owner or admin select" ON public.performance_standards;
CREATE POLICY "standards viewable" ON public.performance_standards FOR SELECT TO authenticated
  USING (public.can_view_artist(artist_id));
DROP POLICY "standards owner or admin update" ON public.performance_standards;
CREATE POLICY "standards editable" ON public.performance_standards FOR UPDATE TO authenticated
  USING (public.can_edit_artist(artist_id)) WITH CHECK (public.can_edit_artist(artist_id));
DROP POLICY "standards owner insert" ON public.performance_standards;
CREATE POLICY "standards insertable" ON public.performance_standards FOR INSERT TO authenticated
  WITH CHECK (public.can_edit_artist(artist_id));
DROP POLICY "standards owner or admin delete" ON public.performance_standards;
CREATE POLICY "standards deletable" ON public.performance_standards FOR DELETE TO authenticated
  USING (public.can_edit_artist(artist_id));

DROP POLICY "bookings owner or admin select" ON public.bookings;
CREATE POLICY "bookings viewable" ON public.bookings FOR SELECT TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin') OR public.booking_role(id) IS NOT NULL);
DROP POLICY "bookings owner or admin update" ON public.bookings;
CREATE POLICY "bookings editable" ON public.bookings FOR UPDATE TO authenticated
  USING (public.can_edit_booking(id)) WITH CHECK (public.can_edit_booking(id));
DROP POLICY "bookings owner insert" ON public.bookings;
CREATE POLICY "bookings insertable" ON public.bookings FOR INSERT TO authenticated
  WITH CHECK ((created_by = auth.uid() AND public.can_edit_artist(artist_id)) OR public.has_role(auth.uid(),'admin'));

DROP POLICY "tasks scoped select" ON public.tasks;
CREATE POLICY "tasks scoped select" ON public.tasks FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(),'admin')
    OR (booking_id IS NOT NULL AND public.can_view_booking(booking_id))
    OR (booking_id IS NULL AND (created_by = auth.uid() OR assigned_to = auth.uid())));
DROP POLICY "tasks scoped insert" ON public.tasks;
CREATE POLICY "tasks scoped insert" ON public.tasks FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(),'admin')
    OR (created_by = auth.uid() AND (booking_id IS NULL OR public.can_edit_booking(booking_id))));
DROP POLICY "tasks scoped update" ON public.tasks;
CREATE POLICY "tasks scoped update" ON public.tasks FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'admin')
    OR (booking_id IS NOT NULL AND public.can_edit_booking(booking_id))
    OR (booking_id IS NULL AND (created_by = auth.uid() OR assigned_to = auth.uid())))
  WITH CHECK (public.has_role(auth.uid(),'admin')
    OR (booking_id IS NOT NULL AND public.can_edit_booking(booking_id))
    OR (booking_id IS NULL AND (created_by = auth.uid() OR assigned_to = auth.uid())));
DROP POLICY "tasks scoped delete" ON public.tasks;
CREATE POLICY "tasks scoped delete" ON public.tasks FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(),'admin')
    OR (booking_id IS NOT NULL AND public.can_edit_booking(booking_id))
    OR (booking_id IS NULL AND created_by = auth.uid()));

DROP POLICY "activity own or admin select" ON public.activity_log;
CREATE POLICY "activity visible" ON public.activity_log FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(),'admin')
    OR (entity_type = 'booking' AND entity_id IS NOT NULL AND public.can_view_booking(entity_id))
    OR (user_id = auth.uid() AND public.can_view_booking_activity(entity_type, entity_id)));

DROP POLICY "profiles own or admin select" ON public.profiles;
CREATE POLICY "profiles visible" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.has_role(auth.uid(),'admin') OR public.shares_membership(id));