CREATE OR REPLACE FUNCTION public.invitable_users()
RETURNS TABLE(id uuid, name text, email text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.id, p.name, p.email
  FROM public.profiles p
  WHERE p.id <> auth.uid() AND auth.uid() IS NOT NULL
  ORDER BY COALESCE(NULLIF(p.name,''), p.email);
$$;

REVOKE ALL ON FUNCTION public.invitable_users() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.invitable_users() TO authenticated;