CREATE OR REPLACE FUNCTION public.log_booking_member_activity()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_name text;
  actor uuid := auth.uid();
  b_id uuid;
  act text;
  summ text;
BEGIN
  b_id := COALESCE(NEW.booking_id, OLD.booking_id);
  SELECT COALESCE(NULLIF(p.name,''), p.email) INTO target_name
  FROM public.profiles p WHERE p.id = COALESCE(NEW.user_id, OLD.user_id);
  target_name := COALESCE(target_name, 'Onbekende gebruiker');

  IF TG_OP = 'INSERT' THEN
    IF NEW.status = 'pending' THEN
      act := 'invite_sent';
      summ := 'Uitnodiging verstuurd naar ' || target_name;
    ELSE
      act := 'invite_added';
      summ := target_name || ' toegevoegd aan de boeking';
    END IF;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.status IS DISTINCT FROM OLD.status THEN
      IF NEW.status = 'accepted' THEN
        act := 'invite_accepted';
        summ := 'Uitnodiging geaccepteerd door ' || target_name;
      ELSIF NEW.status = 'declined' THEN
        act := 'invite_declined';
        summ := 'Uitnodiging afgewezen door ' || target_name;
      ELSE
        act := 'invite_updated';
        summ := 'Uitnodiging van ' || target_name || ' gewijzigd';
      END IF;
    ELSIF NEW.role IS DISTINCT FROM OLD.role THEN
      act := 'invite_role_changed';
      summ := 'Rol van ' || target_name || ' gewijzigd naar ' || NEW.role::text;
    ELSE
      RETURN NEW;
    END IF;
  ELSE
    act := 'invite_removed';
    summ := target_name || ' verwijderd van de boeking';
  END IF;

  INSERT INTO public.activity_log (user_id, entity_type, entity_id, action, summary, changes)
  VALUES (COALESCE(actor, COALESCE(NEW.user_id, OLD.user_id)), 'booking', b_id, act, summ, '[]'::jsonb);

  RETURN COALESCE(NEW, OLD);
END;
$$;

REVOKE ALL ON FUNCTION public.log_booking_member_activity() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS booking_members_activity ON public.booking_members;
CREATE TRIGGER booking_members_activity
AFTER INSERT OR UPDATE OR DELETE ON public.booking_members
FOR EACH ROW EXECUTE FUNCTION public.log_booking_member_activity();