CREATE OR REPLACE FUNCTION public.widget_artists()
RETURNS TABLE(id uuid, name text, booking_statuses jsonb)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT DISTINCT a.id, a.name, a.booking_statuses
  FROM public.artists a
  WHERE auth.uid() IS NOT NULL
    AND (
      a.created_by = auth.uid()
      OR public.has_role(auth.uid(),'admin')
      OR EXISTS (SELECT 1 FROM public.artist_members am
                 WHERE am.artist_id = a.id AND am.user_id = auth.uid() AND am.status = 'accepted')
      OR EXISTS (SELECT 1 FROM public.bookings b
                 JOIN public.booking_members bm ON bm.booking_id = b.id
                 WHERE b.artist_id = a.id AND bm.user_id = auth.uid() AND bm.status = 'accepted')
      OR EXISTS (SELECT 1 FROM public.bookings b
                 WHERE b.artist_id = a.id AND b.created_by = auth.uid())
    )
  ORDER BY a.name;
$$;

REVOKE ALL ON FUNCTION public.widget_artists() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.widget_artists() TO authenticated;