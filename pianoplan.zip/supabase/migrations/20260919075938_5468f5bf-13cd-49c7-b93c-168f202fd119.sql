DROP POLICY IF EXISTS "role permissions readable" ON public.role_permissions;
CREATE POLICY "role permissions readable"
ON public.role_permissions
FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'admin')
  OR role IN ('gebruiker'::public.app_role, 'lezer'::public.app_role, 'boeker'::public.app_role)
  OR EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.user_id = auth.uid() AND ur.role = role_permissions.role
  )
);

DROP POLICY IF EXISTS "avatars readable by authenticated" ON storage.objects;
CREATE POLICY "avatars readable by authenticated"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'avatars'
  AND (
    (storage.foldername(name))[1] = (auth.uid())::text
    OR public.has_role(auth.uid(), 'admin')
    OR EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id::text = (storage.foldername(name))[1]
        AND public.shares_membership(p.id)
    )
  )
);