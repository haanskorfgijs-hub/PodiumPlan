ALTER TABLE public.artists ADD COLUMN IF NOT EXISTS booking_statuses jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS custom_status text;