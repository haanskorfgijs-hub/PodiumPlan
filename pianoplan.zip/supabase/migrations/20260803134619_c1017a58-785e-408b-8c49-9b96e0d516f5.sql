CREATE TYPE public.invite_status AS ENUM ('pending','accepted','declined');

ALTER TABLE public.artist_members ADD COLUMN status public.invite_status NOT NULL DEFAULT 'pending';
ALTER TABLE public.booking_members ADD COLUMN status public.invite_status NOT NULL DEFAULT 'pending';
UPDATE public.artist_members SET status = 'accepted';
UPDATE public.booking_members SET status = 'accepted';

CREATE OR REPLACE FUNCTION public.artist_role(_artist_id uuid)
 RETURNS member_role LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
  SELECT role FROM public.artist_members
  WHERE artist_id = _artist_id AND user_id = auth.uid() AND status = 'accepted';
$function$;

CREATE OR REPLACE FUNCTION public.booking_role(_booking_id uuid)
 RETURNS member_role LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
  SELECT COALESCE(
    (SELECT bm.role FROM public.booking_members bm
      WHERE bm.booking_id = _booking_id AND bm.user_id = auth.uid() AND bm.status = 'accepted'),
    (SELECT am.role FROM public.bookings b JOIN public.artist_members am ON am.artist_id = b.artist_id
      WHERE b.id = _booking_id AND am.user_id = auth.uid() AND am.status = 'accepted')
  );
$function$;

CREATE OR REPLACE FUNCTION public.shares_membership(_other uuid)
 RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1 FROM public.artist_members am
    JOIN public.artists a ON a.id = am.artist_id
    WHERE (am.user_id = _other AND (a.created_by = auth.uid() OR EXISTS (
            SELECT 1 FROM public.artist_members me WHERE me.artist_id = a.id AND me.user_id = auth.uid())))
       OR (am.user_id = auth.uid() AND a.created_by = _other)
  ) OR EXISTS (
    SELECT 1 FROM public.booking_members bm
    JOIN public.bookings b ON b.id = bm.booking_id
    WHERE (bm.user_id = _other AND (b.created_by = auth.uid() OR EXISTS (
            SELECT 1 FROM public.booking_members me WHERE me.booking_id = b.id AND me.user_id = auth.uid())))
       OR (bm.user_id = auth.uid() AND b.created_by = _other)
  );
$function$;

-- invited users may respond to their own invitation
DROP POLICY IF EXISTS "artist members respond" ON public.artist_members;
CREATE POLICY "artist members respond" ON public.artist_members
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "booking members respond" ON public.booking_members;
CREATE POLICY "booking members respond" ON public.booking_members
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- invited users need to read the name of what they are invited to
CREATE OR REPLACE FUNCTION public.my_invitations()
 RETURNS TABLE (
   id uuid,
   scope text,
   role member_role,
   status invite_status,
   title text,
   subtitle text,
   created_at timestamptz
 ) LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
  SELECT am.id, 'artist'::text, am.role, am.status, a.name, NULL::text, am.created_at
  FROM public.artist_members am JOIN public.artists a ON a.id = am.artist_id
  WHERE am.user_id = auth.uid() AND am.status = 'pending'
  UNION ALL
  SELECT bm.id, 'booking'::text, bm.role, bm.status, b.event_name,
         to_char(b.event_date,'DD-MM-YYYY') || COALESCE(' · ' || b.location_name, ''), bm.created_at
  FROM public.booking_members bm JOIN public.bookings b ON b.id = bm.booking_id
  WHERE bm.user_id = auth.uid() AND bm.status = 'pending'
  ORDER BY 7 DESC;
$function$;

GRANT EXECUTE ON FUNCTION public.my_invitations() TO authenticated;

CREATE OR REPLACE FUNCTION public.respond_invitation(_id uuid, _scope text, _accept boolean)
 RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE new_status public.invite_status := CASE WHEN _accept THEN 'accepted' ELSE 'declined' END;
BEGIN
  IF _scope = 'artist' THEN
    UPDATE public.artist_members SET status = new_status
    WHERE id = _id AND user_id = auth.uid() AND status = 'pending';
  ELSE
    UPDATE public.booking_members SET status = new_status
    WHERE id = _id AND user_id = auth.uid() AND status = 'pending';
  END IF;
END;
$function$;

GRANT EXECUTE ON FUNCTION public.respond_invitation(uuid, text, boolean) TO authenticated;