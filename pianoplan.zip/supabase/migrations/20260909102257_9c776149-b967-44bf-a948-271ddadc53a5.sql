create or replace function public.has_permission(_key text)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(bool_or(coalesce(rp.allowed, false)), false)
  from public.user_roles ur
  left join public.role_permissions rp
    on rp.role = ur.role and rp.permission = _key
  where ur.user_id = auth.uid();
$$;

insert into public.role_permissions (role, permission, allowed)
select r, 'standards.create', r in ('admin','host','gebruiker')
from unnest(array['admin','host','gebruiker','boeker','lezer']::app_role[]) as r
where not exists (
  select 1 from public.role_permissions rp
  where rp.role = r and rp.permission = 'standards.create'
);

drop policy if exists "standards insertable" on public.performance_standards;
drop policy if exists "standards editable" on public.performance_standards;
drop policy if exists "standards deletable" on public.performance_standards;

create policy "standards insertable" on public.performance_standards
for insert to authenticated
with check (
  has_role(auth.uid(),'admin')
  or (can_view_artist(artist_id) and has_permission('standards.create'))
);

create policy "standards editable" on public.performance_standards
for update to authenticated
using (
  has_role(auth.uid(),'admin')
  or (can_view_artist(artist_id) and has_permission('standards.create'))
)
with check (
  has_role(auth.uid(),'admin')
  or (can_view_artist(artist_id) and has_permission('standards.create'))
);

create policy "standards deletable" on public.performance_standards
for delete to authenticated
using (
  has_role(auth.uid(),'admin')
  or (can_view_artist(artist_id) and has_permission('standards.create'))
);