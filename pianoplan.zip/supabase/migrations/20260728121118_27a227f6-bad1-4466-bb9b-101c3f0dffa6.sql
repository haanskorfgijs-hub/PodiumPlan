-- profiles
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY,
  name text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  avatar_url text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles readable by authenticated" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "own profile insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TYPE public.app_role AS ENUM ('admin','manager','member');
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL DEFAULT 'member',
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "roles readable by authenticated" ON public.user_roles FOR SELECT TO authenticated USING (true);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, name, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email,'@',1)), COALESCE(NEW.email,''))
  ON CONFLICT (id) DO NOTHING;
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'member') ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- artists
CREATE TABLE public.artists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.artists TO authenticated;
GRANT ALL ON public.artists TO service_role;
ALTER TABLE public.artists ENABLE ROW LEVEL SECURITY;
CREATE POLICY "artists all authenticated" ON public.artists FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER artists_updated BEFORE UPDATE ON public.artists FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- performance standards
CREATE TABLE public.performance_standards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id uuid NOT NULL REFERENCES public.artists(id) ON DELETE CASCADE,
  name text NOT NULL,
  fields jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.performance_standards TO authenticated;
GRANT ALL ON public.performance_standards TO service_role;
ALTER TABLE public.performance_standards ENABLE ROW LEVEL SECURITY;
CREATE POLICY "standards all authenticated" ON public.performance_standards FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER standards_updated BEFORE UPDATE ON public.performance_standards FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- bookings
CREATE TYPE public.booking_status AS ENUM ('optie','definitief','geannuleerd','afgerond');
CREATE TABLE public.bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id uuid NOT NULL REFERENCES public.artists(id) ON DELETE CASCADE,
  standard_id uuid REFERENCES public.performance_standards(id) ON DELETE SET NULL,
  event_name text NOT NULL,
  event_date date NOT NULL,
  start_time time,
  end_time time,
  status public.booking_status NOT NULL DEFAULT 'optie',
  contact_name text,
  contact_phone text,
  contact_email text,
  location_name text,
  address text,
  postal_code text,
  city text,
  field_values jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bookings TO authenticated;
GRANT ALL ON public.bookings TO service_role;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "bookings all authenticated" ON public.bookings FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER bookings_updated BEFORE UPDATE ON public.bookings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- tasks
CREATE TYPE public.task_status AS ENUM ('open','in_behandeling','afgerond');
CREATE TYPE public.task_priority AS ENUM ('laag','normaal','hoog','urgent');
CREATE TABLE public.tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  booking_id uuid REFERENCES public.bookings(id) ON DELETE CASCADE,
  assigned_to uuid,
  priority public.task_priority NOT NULL DEFAULT 'normaal',
  deadline date,
  status public.task_status NOT NULL DEFAULT 'open',
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tasks TO authenticated;
GRANT ALL ON public.tasks TO service_role;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tasks all authenticated" ON public.tasks FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER tasks_updated BEFORE UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- activity log
CREATE TABLE public.activity_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  entity_type text NOT NULL,
  entity_id uuid,
  action text NOT NULL,
  summary text NOT NULL DEFAULT '',
  changes jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.activity_log TO authenticated;
GRANT ALL ON public.activity_log TO service_role;
ALTER TABLE public.activity_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "activity readable" ON public.activity_log FOR SELECT TO authenticated USING (true);
CREATE POLICY "activity insert" ON public.activity_log FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- calendar widgets
CREATE TABLE public.calendar_widgets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  name text NOT NULL,
  artist_ids uuid[] NOT NULL DEFAULT '{}',
  statuses text[] NOT NULL DEFAULT '{}',
  token text NOT NULL DEFAULT encode(gen_random_bytes(16),'hex'),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.calendar_widgets TO authenticated;
GRANT ALL ON public.calendar_widgets TO service_role;
ALTER TABLE public.calendar_widgets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own widgets" ON public.calendar_widgets FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

ALTER PUBLICATION supabase_realtime ADD TABLE public.bookings;
ALTER PUBLICATION supabase_realtime ADD TABLE public.tasks;
ALTER PUBLICATION supabase_realtime ADD TABLE public.activity_log;

-- seed artists
INSERT INTO public.artists (id, name, description) VALUES
 ('11111111-1111-1111-1111-111111111111','The Pianoman and Friends','Live pianoshow met band'),
 ('22222222-2222-2222-2222-222222222222','De Jongens van Jeweetwel','Feestband / DJ-act');

INSERT INTO public.performance_standards (artist_id, name, fields) VALUES
('11111111-1111-1111-1111-111111111111','Standaard optreden', '[
 {"id":"eventnaam","label":"Eventnaam","type":"text","section":"Algemeen"},
 {"id":"aantal_personen","label":"Aantal personen","type":"text","section":"Algemeen"},
 {"id":"band","label":"Band","type":"text","section":"Algemeen"},
 {"id":"techniek","label":"Techniek","type":"dropdown","section":"Techniek","options":["Inprikset The Pianoman & Friends met DB-ES602 set","Seeburg GSub 1501-DP+ / X6 set van RBS","Seeburg GSub 1501-DP+ / GL16-set van RBS","Seeburg KSub 1801-DP / GL16-set van RBS","Seeburg KSub 1801-DP / GL24-set van RBS (tot 200 pers.)","JBL SRX 718S / VRX 932LA-1(1/1) van RBS","Adamson S119 / S10p set (1/1) van RBS"]},
 {"id":"technicus_geluid","label":"Technicus geluid","type":"dropdown","section":"Techniek","options":["Jente van de Water","Via RBS"]},
 {"id":"speeltijden_start","label":"Speeltijden begin","type":"time","section":"Techniek"},
 {"id":"speeltijden_eind","label":"Speeltijden eind","type":"time","section":"Techniek"},
 {"id":"soundcheck","label":"Soundcheck","type":"time","section":"Techniek"},
 {"id":"soundcheck_opmerkingen","label":"Opmerkingen soundcheck","type":"textarea","section":"Techniek"},
 {"id":"opbouw","label":"Opbouw","type":"time","section":"Techniek"},
 {"id":"afbouw","label":"Afbouw","type":"time","section":"Techniek"},
 {"id":"laden_lossen","label":"Laden en lossen","type":"text","section":"Locatie"},
 {"id":"parkeren","label":"Parkeren","type":"text","section":"Locatie"},
 {"id":"locatie_bijzonderheden","label":"Bijzonderheden","type":"textarea","section":"Locatie"},
 {"id":"kleding","label":"Kleding en kleedruimte","type":"textarea","section":"Overig","default":"Zwart overhemd / shirt / polo"},
 {"id":"maaltijd","label":"Maaltijd","type":"text","section":"Overig"},
 {"id":"monitor","label":"Monitor","type":"textarea","section":"Overig","default":"In-ear bedraad. Met de app Qu-You kun je jouw eigen monitormix regelen. Inloggen via QU-PAC 5 of 2.4 Ghz. Wachtwoord: pianomixer. Kies vervolgens je mix."},
 {"id":"opbergruimte","label":"Opbergruimte","type":"text","section":"Overig"},
 {"id":"overig_bijzonderheden","label":"Bijzonderheden","type":"textarea","section":"Overig"}
]'::jsonb);

INSERT INTO public.performance_standards (artist_id, name, fields) VALUES
('22222222-2222-2222-2222-222222222222','De Vrienden Live Rotterdam','[
 {"id":"naam","label":"Naam","type":"text","section":"Algemeen","default":"De Vrienden Live Rotterdam"},
 {"id":"datum","label":"Datum","type":"date","section":"Algemeen"},
 {"id":"locatie","label":"Locatie","type":"map","section":"Locatie","default":"Haringvliet 100, 3011 TH Rotterdam"},
 {"id":"aanvang","label":"Aanvang","type":"time","section":"Tijden","default":"21:00"},
 {"id":"einde","label":"Einde","type":"time","section":"Tijden","default":"00:30"}
]'::jsonb),
('22222222-2222-2222-2222-222222222222','Club Poema Utrecht','[
 {"id":"naam","label":"Naam","type":"text","section":"Algemeen","default":"Club Poema Utrecht"},
 {"id":"datum","label":"Datum","type":"date","section":"Algemeen"},
 {"id":"locatie","label":"Locatie","type":"map","section":"Locatie","default":"Drieharingstraat 22, Utrecht"},
 {"id":"aanvang","label":"Aanvang","type":"time","section":"Tijden","default":"23:00"},
 {"id":"einde","label":"Einde","type":"time","section":"Tijden","default":"02:00"}
]'::jsonb),
('22222222-2222-2222-2222-222222222222','Studio Dependance Breda','[
 {"id":"naam","label":"Naam","type":"text","section":"Algemeen","default":"Studio Dependance Breda"},
 {"id":"datum","label":"Datum","type":"date","section":"Algemeen"},
 {"id":"locatie","label":"Locatie","type":"map","section":"Locatie","default":"Vismarktstraat 2, Breda"},
 {"id":"aanvang","label":"Aanvang","type":"time","section":"Tijden","default":"21:30"},
 {"id":"einde","label":"Einde","type":"time","section":"Tijden","default":"00:00"}
]'::jsonb),
('22222222-2222-2222-2222-222222222222','Stadscafé Spijker Eindhoven','[
 {"id":"naam","label":"Naam","type":"text","section":"Algemeen","default":"Stadscafé Spijker Eindhoven"},
 {"id":"datum","label":"Datum","type":"date","section":"Algemeen"},
 {"id":"locatie","label":"Locatie","type":"map","section":"Locatie","default":"Stratumseind 15-21, 5611 EN Eindhoven"},
 {"id":"aanvang","label":"Aanvang","type":"time","section":"Tijden","default":"21:30"},
 {"id":"einde","label":"Einde","type":"time","section":"Tijden","default":"00:30"}
]'::jsonb);