ALTER TABLE public.tasks DROP COLUMN IF EXISTS priority;
DROP TYPE IF EXISTS public.task_priority;