-- Seed ontbrekende standaardwaarden voor boekingsrechten
insert into public.role_permissions (role, permission, allowed)
select r, k, case
    when r in ('admin','host') then true
    when r = 'lezer' then false
    else true
  end
from unnest(array['admin','host','gebruiker','boeker','lezer']::app_role[]) as r
cross join unnest(array['bookings.create','bookings.edit','bookings.delete']) as k
where not exists (
  select 1 from public.role_permissions rp where rp.role = r and rp.permission = k
);

drop policy if exists "bookings insertable" on public.bookings;
create policy "bookings insertable" on public.bookings
for insert to authenticated
with check (
  has_role(auth.uid(),'admin')
  or (created_by = auth.uid() and can_edit_artist(artist_id) and has_permission('bookings.create'))
);

drop policy if exists "bookings editable" on public.bookings;
create policy "bookings editable" on public.bookings
for update to authenticated
using (has_role(auth.uid(),'admin') or (can_edit_booking(id) and has_permission('bookings.edit')))
with check (has_role(auth.uid(),'admin') or (can_edit_booking(id) and has_permission('bookings.edit')));

drop policy if exists "bookings owner or admin delete" on public.bookings;
create policy "bookings owner or admin delete" on public.bookings
for delete to authenticated
using (
  has_role(auth.uid(),'admin')
  or (created_by = auth.uid() and has_permission('bookings.delete'))
);
