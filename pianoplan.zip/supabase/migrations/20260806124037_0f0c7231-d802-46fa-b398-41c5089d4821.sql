ALTER TABLE public.performance_standards
  ADD COLUMN IF NOT EXISTS run_sheet_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS run_sheet jsonb NOT NULL DEFAULT '[]'::jsonb;

ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS run_sheet jsonb NOT NULL DEFAULT '[]'::jsonb;