create or replace function public.role_allows(_role app_role, _key text)
returns boolean language sql stable security definer set search_path to 'public' as $$
  select coalesce((select rp.allowed from public.role_permissions rp
                   where rp.role = _role and rp.permission = _key limit 1), false);
$$;

create or replace function public.artist_permission(_artist_id uuid, _key text)
returns boolean language sql stable security definer set search_path to 'public' as $$
  select public.has_permission(_key)
     or public.role_allows((public.artist_role(_artist_id))::text::public.app_role, _key);
$$;

create or replace function public.booking_permission(_booking_id uuid, _key text)
returns boolean language sql stable security definer set search_path to 'public' as $$
  select public.has_permission(_key)
     or public.role_allows((public.booking_role(_booking_id))::text::public.app_role, _key);
$$;

drop policy if exists "bookings editable" on public.bookings;
create policy "bookings editable" on public.bookings
for update to authenticated
using (has_role(auth.uid(),'admin') or (can_edit_booking(id) and booking_permission(id,'bookings.edit')))
with check (has_role(auth.uid(),'admin') or (can_edit_booking(id) and booking_permission(id,'bookings.edit')));

drop policy if exists "bookings insertable" on public.bookings;
create policy "bookings insertable" on public.bookings
for insert to authenticated
with check (
  has_role(auth.uid(),'admin')
  or (created_by = auth.uid() and can_edit_artist(artist_id) and artist_permission(artist_id,'bookings.create'))
);

drop policy if exists "bookings owner or admin delete" on public.bookings;
create policy "bookings owner or admin delete" on public.bookings
for delete to authenticated
using (
  has_role(auth.uid(),'admin')
  or (created_by = auth.uid() and (has_permission('bookings.delete') or booking_permission(id,'bookings.delete')))
);

drop policy if exists "standards insertable" on public.performance_standards;
create policy "standards insertable" on public.performance_standards
for insert to authenticated
with check (has_role(auth.uid(),'admin') or (can_view_artist(artist_id) and artist_permission(artist_id,'standards.create')));

drop policy if exists "standards editable" on public.performance_standards;
create policy "standards editable" on public.performance_standards
for update to authenticated
using (has_role(auth.uid(),'admin') or (can_view_artist(artist_id) and artist_permission(artist_id,'standards.create')))
with check (has_role(auth.uid(),'admin') or (can_view_artist(artist_id) and artist_permission(artist_id,'standards.create')));

drop policy if exists "standards deletable" on public.performance_standards;
create policy "standards deletable" on public.performance_standards
for delete to authenticated
using (has_role(auth.uid(),'admin') or (can_view_artist(artist_id) and artist_permission(artist_id,'standards.create')));