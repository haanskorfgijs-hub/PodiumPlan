DROP FUNCTION IF EXISTS public.booking_team(uuid);

CREATE OR REPLACE FUNCTION public.booking_team(_booking_id uuid)
RETURNS TABLE(id uuid, name text, email text, phone text, job_title text, avatar_url text, invite_status text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  WITH members AS (
    SELECT b.created_by AS user_id, 'accepted'::text AS st FROM public.bookings b WHERE b.id = _booking_id AND b.created_by IS NOT NULL
    UNION ALL
    SELECT a.created_by, 'accepted'::text FROM public.bookings b JOIN public.artists a ON a.id = b.artist_id WHERE b.id = _booking_id AND a.created_by IS NOT NULL
    UNION ALL
    SELECT bm.user_id, bm.status::text FROM public.booking_members bm WHERE bm.booking_id = _booking_id AND bm.status IN ('accepted','pending')
    UNION ALL
    SELECT am.user_id, am.status::text FROM public.artist_members am JOIN public.bookings b ON b.artist_id = am.artist_id
      WHERE b.id = _booking_id AND am.status IN ('accepted','pending')
  ), ranked AS (
    SELECT user_id, MIN(CASE WHEN st = 'accepted' THEN 0 ELSE 1 END) AS rank FROM members GROUP BY user_id
  )
  SELECT p.id, p.name, p.email, p.phone, p.job_title, p.avatar_url,
         CASE WHEN r.rank = 0 THEN 'accepted' ELSE 'pending' END AS invite_status
  FROM public.profiles p
  JOIN ranked r ON r.user_id = p.id
  WHERE public.can_view_booking(_booking_id)
  ORDER BY p.name;
$$;

REVOKE ALL ON FUNCTION public.booking_team(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.booking_team(uuid) TO authenticated;