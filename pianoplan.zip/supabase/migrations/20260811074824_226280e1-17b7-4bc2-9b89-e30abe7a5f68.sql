DO $$
DECLARE f record;
BEGIN
  FOR f IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prosecdef
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC, anon, authenticated', f.sig);
  END LOOP;
END $$;

GRANT EXECUTE ON FUNCTION public.my_invitations() TO authenticated;
GRANT EXECUTE ON FUNCTION public.respond_invitation(uuid, text, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.invitable_users() TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_edit_booking(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.owns_artist(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.owns_booking(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.artist_role(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.booking_role(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_edit_artist(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_view_artist(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_view_booking(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_view_booking_activity(text, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_view_standard(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.shares_membership(uuid) TO authenticated;