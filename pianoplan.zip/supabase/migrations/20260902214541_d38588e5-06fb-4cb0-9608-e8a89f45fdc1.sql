DROP POLICY IF EXISTS "tasks scoped insert" ON public.tasks;
CREATE POLICY "tasks scoped insert" ON public.tasks FOR INSERT TO authenticated
WITH CHECK (
  public.has_role(auth.uid(),'admin')
  OR (created_by = auth.uid() AND (
        (booking_id IS NULL)
     OR public.can_view_booking(booking_id)
  ))
);

DROP POLICY IF EXISTS "tasks scoped update" ON public.tasks;
CREATE POLICY "tasks scoped update" ON public.tasks FOR UPDATE TO authenticated
USING (
  public.has_role(auth.uid(),'admin')
  OR (booking_id IS NOT NULL AND public.can_view_booking(booking_id))
  OR (booking_id IS NULL AND (created_by = auth.uid() OR assigned_to = auth.uid()))
)
WITH CHECK (
  public.has_role(auth.uid(),'admin')
  OR (booking_id IS NOT NULL AND public.can_view_booking(booking_id))
  OR (booking_id IS NULL AND (created_by = auth.uid() OR assigned_to = auth.uid()))
);