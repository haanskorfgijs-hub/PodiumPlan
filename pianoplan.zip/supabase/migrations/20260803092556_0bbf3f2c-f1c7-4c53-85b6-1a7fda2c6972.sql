DROP POLICY IF EXISTS "tasks owner or admin select" ON public.tasks;
DROP POLICY IF EXISTS "tasks owner or admin update" ON public.tasks;
DROP POLICY IF EXISTS "tasks owner or admin delete" ON public.tasks;
DROP POLICY IF EXISTS "tasks owner insert" ON public.tasks;

CREATE POLICY "tasks scoped select" ON public.tasks FOR SELECT TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR (booking_id IS NOT NULL AND owns_booking(booking_id))
  OR (booking_id IS NULL AND (created_by = auth.uid() OR assigned_to = auth.uid()))
);

CREATE POLICY "tasks scoped insert" ON public.tasks FOR INSERT TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role)
  OR (created_by = auth.uid() AND (booking_id IS NULL OR owns_booking(booking_id)))
);

CREATE POLICY "tasks scoped update" ON public.tasks FOR UPDATE TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR (booking_id IS NOT NULL AND owns_booking(booking_id))
  OR (booking_id IS NULL AND (created_by = auth.uid() OR assigned_to = auth.uid()))
)
WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role)
  OR (booking_id IS NOT NULL AND owns_booking(booking_id))
  OR (booking_id IS NULL AND (created_by = auth.uid() OR assigned_to = auth.uid()))
);

CREATE POLICY "tasks scoped delete" ON public.tasks FOR DELETE TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR (booking_id IS NOT NULL AND owns_booking(booking_id))
  OR (booking_id IS NULL AND created_by = auth.uid())
);