CREATE TABLE public.notifications (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  type text NOT NULL,
  title text NOT NULL,
  body text NOT NULL DEFAULT '',
  link text,
  read_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE INDEX notifications_user_idx ON public.notifications (user_id, created_at DESC);

GRANT SELECT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own notifications select" ON public.notifications
  FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "own notifications update" ON public.notifications
  FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "own notifications delete" ON public.notifications
  FOR DELETE TO authenticated USING (user_id = auth.uid());

ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;

-- Helper om meldingen te maken (bypass RLS)
CREATE OR REPLACE FUNCTION public.notify_user(_user_id uuid, _type text, _title text, _body text, _link text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF _user_id IS NULL THEN RETURN; END IF;
  INSERT INTO public.notifications (user_id, type, title, body, link)
  VALUES (_user_id, _type, _title, COALESCE(_body,''), _link);
END;
$$;
REVOKE ALL ON FUNCTION public.notify_user(uuid, text, text, text, text) FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.mark_notifications_read(_ids uuid[])
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  UPDATE public.notifications SET read_at = now()
  WHERE user_id = auth.uid() AND read_at IS NULL
    AND (_ids IS NULL OR id = ANY(_ids));
$$;
REVOKE ALL ON FUNCTION public.mark_notifications_read(uuid[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.mark_notifications_read(uuid[]) TO authenticated;

-- 1 & 2: uitnodigingen voor boekingen
CREATE OR REPLACE FUNCTION public.notify_booking_member()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE b record; actor_name text;
BEGIN
  SELECT event_name, id INTO b FROM public.bookings WHERE id = NEW.booking_id;
  IF TG_OP = 'INSERT' AND NEW.status = 'pending' THEN
    PERFORM public.notify_user(NEW.user_id, 'invite',
      'Nieuwe uitnodiging voor boeking',
      COALESCE(b.event_name,'Boeking'), '/invitations');
  ELSIF TG_OP = 'UPDATE' AND OLD.status = 'pending' AND NEW.status <> 'pending' THEN
    SELECT COALESCE(NULLIF(name,''), email) INTO actor_name FROM public.profiles WHERE id = NEW.user_id;
    IF NEW.created_by IS DISTINCT FROM NEW.user_id THEN
      PERFORM public.notify_user(NEW.created_by, 'invite_response',
        CASE WHEN NEW.status = 'accepted' THEN 'Uitnodiging geaccepteerd' ELSE 'Uitnodiging afgewezen' END,
        COALESCE(actor_name,'Iemand') || ' · ' || COALESCE(b.event_name,'Boeking'),
        '/bookings/' || NEW.booking_id);
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER booking_members_notify
AFTER INSERT OR UPDATE ON public.booking_members
FOR EACH ROW EXECUTE FUNCTION public.notify_booking_member();

-- uitnodigingen voor artiesten
CREATE OR REPLACE FUNCTION public.notify_artist_member()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE a_name text; actor_name text;
BEGIN
  SELECT name INTO a_name FROM public.artists WHERE id = NEW.artist_id;
  IF TG_OP = 'INSERT' AND NEW.status = 'pending' THEN
    PERFORM public.notify_user(NEW.user_id, 'invite',
      'Nieuwe uitnodiging voor artiest', COALESCE(a_name,'Artiest'), '/invitations');
  ELSIF TG_OP = 'UPDATE' AND OLD.status = 'pending' AND NEW.status <> 'pending' THEN
    SELECT COALESCE(NULLIF(name,''), email) INTO actor_name FROM public.profiles WHERE id = NEW.user_id;
    IF NEW.created_by IS DISTINCT FROM NEW.user_id THEN
      PERFORM public.notify_user(NEW.created_by, 'invite_response',
        CASE WHEN NEW.status = 'accepted' THEN 'Uitnodiging geaccepteerd' ELSE 'Uitnodiging afgewezen' END,
        COALESCE(actor_name,'Iemand') || ' · ' || COALESCE(a_name,'Artiest'), '/artists');
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER artist_members_notify
AFTER INSERT OR UPDATE ON public.artist_members
FOR EACH ROW EXECUTE FUNCTION public.notify_artist_member();

-- 3: statuswijziging van boeking
CREATE OR REPLACE FUNCTION public.notify_booking_status()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE actor uuid := auth.uid(); actor_name text; recipient uuid; body text;
BEGIN
  IF NEW.status IS NOT DISTINCT FROM OLD.status
     AND NEW.custom_status IS NOT DISTINCT FROM OLD.custom_status THEN
    RETURN NEW;
  END IF;
  SELECT COALESCE(NULLIF(name,''), email) INTO actor_name FROM public.profiles WHERE id = actor;
  body := COALESCE(NEW.event_name,'Boeking') || ' → ' || COALESCE(NULLIF(NEW.custom_status,''), NEW.status::text)
          || ' · door ' || COALESCE(actor_name,'iemand');
  FOR recipient IN
    SELECT DISTINCT uid FROM (
      SELECT NEW.created_by AS uid
      UNION SELECT a.created_by FROM public.artists a WHERE a.id = NEW.artist_id
      UNION SELECT bm.user_id FROM public.booking_members bm
        WHERE bm.booking_id = NEW.id AND bm.status = 'accepted'
      UNION SELECT am.user_id FROM public.artist_members am
        WHERE am.artist_id = NEW.artist_id AND am.status = 'accepted'
    ) t WHERE uid IS NOT NULL AND uid IS DISTINCT FROM actor
  LOOP
    PERFORM public.notify_user(recipient, 'booking_status', 'Status van boeking gewijzigd', body,
      '/bookings/' || NEW.id);
  END LOOP;
  RETURN NEW;
END;
$$;

CREATE TRIGGER bookings_notify_status
AFTER UPDATE ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.notify_booking_status();

-- 4: nieuwe registratie (alleen admins)
CREATE OR REPLACE FUNCTION public.notify_new_profile()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE admin_id uuid;
BEGIN
  FOR admin_id IN SELECT user_id FROM public.user_roles WHERE role = 'admin' LOOP
    PERFORM public.notify_user(admin_id, 'new_user', 'Nieuw account geregistreerd',
      COALESCE(NULLIF(NEW.name,''), NEW.email), '/users');
  END LOOP;
  RETURN NEW;
END;
$$;

CREATE TRIGGER profiles_notify_new
AFTER INSERT ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.notify_new_profile();