CREATE OR REPLACE FUNCTION public.shares_membership(_other uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1 FROM public.artist_members am
    JOIN public.artists a ON a.id = am.artist_id
    WHERE (am.user_id = _other AND (a.created_by = auth.uid() OR EXISTS (
            SELECT 1 FROM public.artist_members me WHERE me.artist_id = a.id AND me.user_id = auth.uid())))
       OR (am.user_id = auth.uid() AND a.created_by = _other)
  ) OR EXISTS (
    SELECT 1 FROM public.booking_members bm
    JOIN public.bookings b ON b.id = bm.booking_id
    WHERE (bm.user_id = _other AND (b.created_by = auth.uid() OR EXISTS (
            SELECT 1 FROM public.booking_members me WHERE me.booking_id = b.id AND me.user_id = auth.uid())))
       OR (bm.user_id = auth.uid() AND b.created_by = _other)
  ) OR EXISTS (
    -- Teamleden van een boeking waar ik lid van ben: ook de artiest-eigenaar
    -- en artiest-leden horen bij het team en moeten zichtbaar zijn.
    SELECT 1
    FROM public.bookings b
    JOIN public.artists a ON a.id = b.artist_id
    WHERE (b.created_by = auth.uid() OR EXISTS (
            SELECT 1 FROM public.booking_members me
            WHERE me.booking_id = b.id AND me.user_id = auth.uid() AND me.status = 'accepted'))
      AND (
        a.created_by = _other
        OR b.created_by = _other
        OR EXISTS (SELECT 1 FROM public.artist_members am2
                   WHERE am2.artist_id = a.id AND am2.user_id = _other AND am2.status = 'accepted')
        OR EXISTS (SELECT 1 FROM public.booking_members bm2
                   WHERE bm2.booking_id = b.id AND bm2.user_id = _other AND bm2.status = 'accepted')
      )
  );
$function$;