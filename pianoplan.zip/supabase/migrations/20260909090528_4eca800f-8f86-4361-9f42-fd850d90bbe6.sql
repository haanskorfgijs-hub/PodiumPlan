CREATE TABLE public.role_permissions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  role app_role NOT NULL,
  permission text NOT NULL,
  allowed boolean NOT NULL DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (role, permission)
);

GRANT SELECT ON public.role_permissions TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.role_permissions TO authenticated;
GRANT ALL ON public.role_permissions TO service_role;

ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "role permissions readable" ON public.role_permissions
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "admins manage role permissions insert" ON public.role_permissions
  FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "admins manage role permissions update" ON public.role_permissions
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "admins manage role permissions delete" ON public.role_permissions
  FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER role_permissions_updated_at
  BEFORE UPDATE ON public.role_permissions
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

INSERT INTO public.role_permissions (role, permission, allowed) VALUES
  ('admin','artists.create',true),
  ('admin','artists.delete',true),
  ('admin','standards.create',true),
  ('admin','bookings.create',true),
  ('admin','bookings.delete',true),
  ('admin','pricing.view',true),
  ('admin','financial.view',true),
  ('admin','statistics.view',true),
  ('admin','tasks.manage',true),
  ('admin','members.manage',true),
  ('boeker','artists.create',false),
  ('boeker','artists.delete',false),
  ('boeker','standards.create',false),
  ('boeker','bookings.create',true),
  ('boeker','bookings.delete',true),
  ('boeker','pricing.view',true),
  ('boeker','financial.view',true),
  ('boeker','statistics.view',false),
  ('boeker','tasks.manage',true),
  ('boeker','members.manage',true),
  ('gebruiker','artists.create',true),
  ('gebruiker','artists.delete',true),
  ('gebruiker','standards.create',true),
  ('gebruiker','bookings.create',true),
  ('gebruiker','bookings.delete',true),
  ('gebruiker','pricing.view',true),
  ('gebruiker','financial.view',true),
  ('gebruiker','statistics.view',false),
  ('gebruiker','tasks.manage',true),
  ('gebruiker','members.manage',true),
  ('lezer','artists.create',false),
  ('lezer','artists.delete',false),
  ('lezer','standards.create',false),
  ('lezer','bookings.create',false),
  ('lezer','bookings.delete',false),
  ('lezer','pricing.view',false),
  ('lezer','financial.view',false),
  ('lezer','statistics.view',false),
  ('lezer','tasks.manage',false),
  ('lezer','members.manage',false);