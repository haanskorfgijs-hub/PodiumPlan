REVOKE ALL ON FUNCTION public.notify_booking_member() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.notify_artist_member() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.notify_booking_status() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.notify_new_profile() FROM PUBLIC, anon, authenticated;