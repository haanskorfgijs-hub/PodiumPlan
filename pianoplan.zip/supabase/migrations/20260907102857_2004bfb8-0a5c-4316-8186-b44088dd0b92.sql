-- Booking member management: allow app-role 'gebruiker' the same rights as admin
DROP POLICY IF EXISTS "booking members manage insert" ON public.booking_members;
CREATE POLICY "booking members manage insert" ON public.booking_members
FOR INSERT TO authenticated
WITH CHECK (
  owns_booking(booking_id)
  OR has_role(auth.uid(), 'admin'::app_role)
  OR (has_role(auth.uid(), 'gebruiker'::app_role) AND can_view_booking(booking_id))
);

DROP POLICY IF EXISTS "booking members manage update" ON public.booking_members;
CREATE POLICY "booking members manage update" ON public.booking_members
FOR UPDATE TO authenticated
USING (
  owns_booking(booking_id)
  OR has_role(auth.uid(), 'admin'::app_role)
  OR (has_role(auth.uid(), 'gebruiker'::app_role) AND can_view_booking(booking_id))
)
WITH CHECK (
  owns_booking(booking_id)
  OR has_role(auth.uid(), 'admin'::app_role)
  OR (has_role(auth.uid(), 'gebruiker'::app_role) AND can_view_booking(booking_id))
);

DROP POLICY IF EXISTS "booking members manage delete" ON public.booking_members;
CREATE POLICY "booking members manage delete" ON public.booking_members
FOR DELETE TO authenticated
USING (
  owns_booking(booking_id)
  OR has_role(auth.uid(), 'admin'::app_role)
  OR user_id = auth.uid()
  OR (has_role(auth.uid(), 'gebruiker'::app_role) AND can_view_booking(booking_id))
);

-- Profiles: role 'gebruiker' may read names/emails like an admin
DROP POLICY IF EXISTS "profiles visible" ON public.profiles;
CREATE POLICY "profiles visible" ON public.profiles
FOR SELECT TO authenticated
USING (
  id = auth.uid()
  OR has_role(auth.uid(), 'admin'::app_role)
  OR has_role(auth.uid(), 'gebruiker'::app_role)
  OR shares_membership(id)
);