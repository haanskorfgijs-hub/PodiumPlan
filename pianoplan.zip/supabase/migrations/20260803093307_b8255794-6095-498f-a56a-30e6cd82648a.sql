CREATE OR REPLACE FUNCTION public.can_view_booking_activity(_entity_type text, _entity_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT CASE
    WHEN _entity_type <> 'booking' OR _entity_id IS NULL THEN true
    WHEN NOT EXISTS (SELECT 1 FROM public.bookings WHERE id = _entity_id) THEN true
    ELSE EXISTS (SELECT 1 FROM public.bookings WHERE id = _entity_id AND created_by = auth.uid())
  END;
$$;

DROP POLICY IF EXISTS "activity own or admin select" ON public.activity_log;
CREATE POLICY "activity own or admin select" ON public.activity_log
FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::public.app_role)
  OR (user_id = auth.uid() AND public.can_view_booking_activity(entity_type, entity_id))
);