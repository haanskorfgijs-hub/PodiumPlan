REVOKE ALL ON FUNCTION public.can_view_booking_activity(text, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_view_booking_activity(text, uuid) TO authenticated, service_role;