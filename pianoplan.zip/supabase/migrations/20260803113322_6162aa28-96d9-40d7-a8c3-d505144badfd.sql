CREATE TYPE public.financial_status AS ENUM ('factureren', 'gefactureerd', 'voldaan');

ALTER TABLE public.bookings
  ADD COLUMN financial_status public.financial_status NOT NULL DEFAULT 'factureren';