CREATE OR REPLACE FUNCTION public.notify_booking_member()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $function$
DECLARE b record; actor_name text; r record; t text; body text;
BEGIN
  SELECT event_name, id, created_by, artist_id INTO b FROM public.bookings WHERE id = NEW.booking_id;
  IF TG_OP = 'INSERT' AND NEW.status = 'pending' THEN
    PERFORM public.notify_user(NEW.user_id, 'invite',
      'Nieuwe uitnodiging voor boeking', COALESCE(b.event_name,'Boeking'), '/invitations');
  ELSIF TG_OP = 'UPDATE' AND OLD.status = 'pending' AND NEW.status <> 'pending' THEN
    SELECT COALESCE(NULLIF(name,''), email) INTO actor_name FROM public.profiles WHERE id = NEW.user_id;
    t := CASE WHEN NEW.status = 'accepted' THEN 'Uitnodiging geaccepteerd' ELSE 'Uitnodiging afgewezen' END;
    body := COALESCE(actor_name,'Iemand') || ' · ' || COALESCE(b.event_name,'Boeking');
    FOR r IN
      SELECT DISTINCT uid FROM (
        SELECT NEW.created_by AS uid
        UNION SELECT b.created_by
        UNION SELECT bm.user_id FROM public.booking_members bm
          WHERE bm.booking_id = NEW.booking_id AND bm.status = 'accepted'
        UNION SELECT a.created_by FROM public.artists a WHERE a.id = b.artist_id
        UNION SELECT am.user_id FROM public.artist_members am
          WHERE am.artist_id = b.artist_id AND am.status = 'accepted'
        UNION SELECT ur.user_id FROM public.user_roles ur WHERE ur.role IN ('admin','host')
      ) s WHERE uid IS NOT NULL AND uid IS DISTINCT FROM NEW.user_id
    LOOP
      PERFORM public.notify_user(r.uid, 'invite_response', t, body, '/bookings/' || NEW.booking_id);
    END LOOP;
  END IF;
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.notify_artist_member()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $function$
DECLARE a record; actor_name text; r record; t text; body text;
BEGIN
  SELECT name, created_by INTO a FROM public.artists WHERE id = NEW.artist_id;
  IF TG_OP = 'INSERT' AND NEW.status = 'pending' THEN
    PERFORM public.notify_user(NEW.user_id, 'invite',
      'Nieuwe uitnodiging voor artiest', COALESCE(a.name,'Artiest'), '/invitations');
  ELSIF TG_OP = 'UPDATE' AND OLD.status = 'pending' AND NEW.status <> 'pending' THEN
    SELECT COALESCE(NULLIF(name,''), email) INTO actor_name FROM public.profiles WHERE id = NEW.user_id;
    t := CASE WHEN NEW.status = 'accepted' THEN 'Uitnodiging geaccepteerd' ELSE 'Uitnodiging afgewezen' END;
    body := COALESCE(actor_name,'Iemand') || ' · ' || COALESCE(a.name,'Artiest');
    FOR r IN
      SELECT DISTINCT uid FROM (
        SELECT NEW.created_by AS uid
        UNION SELECT a.created_by
        UNION SELECT am.user_id FROM public.artist_members am
          WHERE am.artist_id = NEW.artist_id AND am.status = 'accepted'
        UNION SELECT ur.user_id FROM public.user_roles ur WHERE ur.role IN ('admin','host')
      ) s WHERE uid IS NOT NULL AND uid IS DISTINCT FROM NEW.user_id
    LOOP
      PERFORM public.notify_user(r.uid, 'invite_response', t, body, '/artists');
    END LOOP;
  END IF;
  RETURN NEW;
END;
$function$;