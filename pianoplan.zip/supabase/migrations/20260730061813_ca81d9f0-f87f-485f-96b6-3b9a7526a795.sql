-- assign orphaned artists to an admin
UPDATE public.artists a
SET created_by = (SELECT user_id FROM public.user_roles WHERE role = 'admin' ORDER BY id LIMIT 1)
WHERE a.created_by IS NULL;

ALTER TABLE public.artists ALTER COLUMN created_by SET DEFAULT auth.uid();
ALTER TABLE public.bookings ALTER COLUMN created_by SET DEFAULT auth.uid();
ALTER TABLE public.tasks ALTER COLUMN created_by SET DEFAULT auth.uid();

-- ARTISTS
DROP POLICY IF EXISTS "artists all authenticated" ON public.artists;
CREATE POLICY "artists owner or admin select" ON public.artists FOR SELECT TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "artists owner insert" ON public.artists FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "artists owner or admin update" ON public.artists FOR UPDATE TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "artists owner or admin delete" ON public.artists FOR DELETE TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));

-- BOOKINGS
DROP POLICY IF EXISTS "bookings all authenticated" ON public.bookings;
CREATE POLICY "bookings owner or admin select" ON public.bookings FOR SELECT TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "bookings owner insert" ON public.bookings FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "bookings owner or admin update" ON public.bookings FOR UPDATE TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "bookings owner or admin delete" ON public.bookings FOR DELETE TO authenticated
  USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));

-- helper: does the current user own the artist?
CREATE OR REPLACE FUNCTION public.owns_artist(_artist_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT EXISTS (SELECT 1 FROM public.artists WHERE id = _artist_id AND created_by = auth.uid());
$$;

CREATE OR REPLACE FUNCTION public.owns_booking(_booking_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT EXISTS (SELECT 1 FROM public.bookings WHERE id = _booking_id AND created_by = auth.uid());
$$;

-- PERFORMANCE STANDARDS (owned via artist)
DROP POLICY IF EXISTS "standards all authenticated" ON public.performance_standards;
CREATE POLICY "standards owner or admin select" ON public.performance_standards FOR SELECT TO authenticated
  USING (public.owns_artist(artist_id) OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "standards owner insert" ON public.performance_standards FOR INSERT TO authenticated
  WITH CHECK (public.owns_artist(artist_id) OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "standards owner or admin update" ON public.performance_standards FOR UPDATE TO authenticated
  USING (public.owns_artist(artist_id) OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.owns_artist(artist_id) OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "standards owner or admin delete" ON public.performance_standards FOR DELETE TO authenticated
  USING (public.owns_artist(artist_id) OR public.has_role(auth.uid(), 'admin'));

-- TASKS (own task or task on own booking)
DROP POLICY IF EXISTS "tasks all authenticated" ON public.tasks;
CREATE POLICY "tasks owner or admin select" ON public.tasks FOR SELECT TO authenticated
  USING (created_by = auth.uid() OR assigned_to = auth.uid() OR public.owns_booking(booking_id) OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "tasks owner insert" ON public.tasks FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "tasks owner or admin update" ON public.tasks FOR UPDATE TO authenticated
  USING (created_by = auth.uid() OR assigned_to = auth.uid() OR public.owns_booking(booking_id) OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (created_by = auth.uid() OR assigned_to = auth.uid() OR public.owns_booking(booking_id) OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "tasks owner or admin delete" ON public.tasks FOR DELETE TO authenticated
  USING (created_by = auth.uid() OR public.owns_booking(booking_id) OR public.has_role(auth.uid(), 'admin'));

REVOKE EXECUTE ON FUNCTION public.owns_artist(uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.owns_booking(uuid) FROM anon;