CREATE OR REPLACE FUNCTION public.booking_team(_booking_id uuid)
RETURNS TABLE(id uuid, name text, email text, phone text, job_title text, avatar_url text)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT p.id, p.name, p.email, p.phone, p.job_title, p.avatar_url
  FROM public.profiles p
  WHERE public.can_view_booking(_booking_id)
    AND p.id IN (
      SELECT b.created_by FROM public.bookings b WHERE b.id = _booking_id
      UNION
      SELECT a.created_by FROM public.bookings b JOIN public.artists a ON a.id = b.artist_id WHERE b.id = _booking_id
      UNION
      SELECT bm.user_id FROM public.booking_members bm WHERE bm.booking_id = _booking_id AND bm.status = 'accepted'
      UNION
      SELECT am.user_id FROM public.artist_members am JOIN public.bookings b ON b.artist_id = am.artist_id
        WHERE b.id = _booking_id AND am.status = 'accepted'
    )
  ORDER BY p.name;
$$;

REVOKE ALL ON FUNCTION public.booking_team(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.booking_team(uuid) TO authenticated;